#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
base=A6_MODDIV_BLINDAGE_C1_v1_1
xelatex -interaction=nonstopmode -halt-on-error "$base.tex" >/dev/null
xelatex -interaction=nonstopmode -halt-on-error "$base.tex" >/dev/null

rm -f "$base.aux" "$base.log" "$base.out"
