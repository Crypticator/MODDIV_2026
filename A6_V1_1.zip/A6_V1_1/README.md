# A6 v1.1 - MODDIV-BLINDAGE C1

Public research package for:

**MODDIV-BLINDAGE C1: Module Rounding, Dependent-Remainder Correctness, and Conditional Classical-ROM CCA Security**

## Scope

This is the C1-P12-CBD1 profile only:
- `R = Z_4096[x]/(x^256+1)`;
- module rank `k = 3`;
- public-key divisor `Q = 4`;
- ciphertext divisor `C = 2`;
- secret and explicit errors `CBD1`.

The correctness certificate is exact, but confidentiality is conditional on two explicitly defined Module-LWE source problems. The KEM theorem is single-user and classical-ROM only. No concrete 128-bit, QROM, side-channel, or deployment claim is made. CBD2 is outside scope.

## Artifact boundary

The programs verify base-PKE arithmetic, coefficient encodings, random-tape distributions, and the exact finite checks described in the paper. They do **not** implement the random oracles `G` and `H`, their tuple encodings, or a production KEM wrapper. The CCA theorem is stated for the abstract independent-oracle model.

The canonical article PDF in this package is `A6_MODDIV_BLINDAGE_C1_v1_1.pdf`.

## Reproduce

```bash
python3 verify_a6.py --output /tmp/A6_RESULTS.json
python3 verify_a6_independent.py --output /tmp/A6_INDEPENDENT.json
bash build_and_verify.sh
bash compile_pdf.sh
```

The two verification programs use independent arithmetic implementations for their central checks. Successful finite tests do not prove source hardness or adaptive CCA security.
