# A6 public source record

This package cites only public sources as scientific references.

1. Dennis Hofheinz, Kathrin Hövelmanns, Eike Kiltz, *A Modular Analysis of the Fujisaki-Okamoto Transformation*, TCC 2017, corrected full version dated 2 November 2021, ePrint 2017/604. The corrected text explicitly records the plaintext-checking query corrections used by A6.
2. Bos et al., *CRYSTALS - Kyber: a CCA-secure module-lattice-based KEM*, EuroS&P 2018, ePrint 2017/634. Prior Module-LWE encryption and FO/KEM context only.
3. D'Anvers et al., *Saber: Module-LWR based key exchange, CPA-secure encryption and CCA-secure KEM*, AFRICACRYPT 2018, ePrint 2018/230. Prior power-of-two module rounding / KEM context only.
4. Bai et al., *Middle-Product Learning with Rounding Problem and its Applications*, ASIACRYPT 2019, ePrint 2019/1001. Prior randomized preimage lifting / rounding context only.
5. Jianhua Hou, Haodong Jiang, Tabitha Ogilvie, *Careful with the Ring! Concrete Hardness Gaps Between LWE and MLWE*, CRYPTO 2026, LNCS 16802, pp. 462-497, DOI 10.1007/978-3-032-35377-1_15. The conference article merges ePrint 2026/279 and 2026/366. A6 uses it only as a structural warning against equating MLWE and unstructured LWE concrete hardness.
6. Samir Bouftass, *Multidimentional ModDiv public key exchange protocol*, ePrint 2021/701. Historical MODDIV lineage only; no security theorem is transferred.

No private chat, internal audit, mission report, thesis chapter, or private ZIP is a scientific reference of A6.
