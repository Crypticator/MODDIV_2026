#!/usr/bin/env python3
"""Independent A6 verifier. Does not import a6_blindage or the primary verifier."""
import argparse,itertools,json,math
from fractions import Fraction as F
from pathlib import Path
from collections import Counter

def signed_conv(a,b):
    full=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): full[i+j]+=x*y
    n=len(a)
    return tuple(full[i]-(full[i+n] if i+n<len(full) else 0) for i in range(n))

def packed_mul(a,b,P):
    n=len(a);width=(n*(P-1)**2).bit_length()+1;base=1<<width
    aa=sum((x%P)<<(width*i) for i,x in enumerate(a));bb=sum((x%P)<<(width*i) for i,x in enumerate(b))
    prod=aa*bb;full=[]
    for i in range(2*n-1):full.append((prod>>(width*i))&(base-1))
    return tuple((full[i]-(full[i+n] if i+n<len(full) else 0))%P for i in range(n))

def dot(v,w,P=None):
    f=[packed_mul(a,b,P) if P else signed_conv(a,b) for a,b in zip(v,w)]
    return tuple(sum(c)%P if P else sum(c) for c in zip(*f))

def run(out):
    counts=Counter();R={}
    root=Path(__file__).parent
    t=json.loads((root/'A6_SYNTHETIC.json').read_text());P=4096;Q=4;C=2;n=256;k=3
    A,s,e0,r,e1,e2,rho=[t[x] for x in ('A','s','e0','r','e1','e2','rho')]
    mu=t['message'];At=list(zip(*A))
    z0=tuple(tuple((x+y)%P for x,y in zip(dot(row,s,P),e)) for row,e in zip(A,e0))
    b=tuple(tuple(x//Q for x in row) for row in z0)
    v=tuple(tuple(Q*x+y for x,y in zip(bb,rr)) for bb,rr in zip(b,rho))
    z1=tuple(tuple((x+y)%P for x,y in zip(dot(row,r,P),e)) for row,e in zip(At,e1))
    inner=dot(v,r,P);z2=tuple((x+e+(P//2)*m)%P for x,e,m in zip(inner,e2,mu))
    ct=(tuple(tuple(x//C for x in row) for row in z1),tuple(x//C for x in z2))
    assert json.loads(json.dumps(ct))==t['ct']
    assert json.loads(json.dumps(b))==t['b']
    zz=tuple((C*x-y)%P for x,y in zip(ct[1],dot(tuple(tuple(C*x for x in row) for row in ct[0]),s,P)))
    decoded=tuple(int(P//4<x<3*P//4) for x in zz);assert decoded==tuple(mu)
    r0=tuple(tuple(x%Q for x in row) for row in z0);r1=tuple(tuple(x%C for x in row) for row in z1)
    r2=tuple((x+e)%C for x,e in zip(inner,e2))
    a0=tuple(tuple(e+t-r for e,t,r in zip(ee,rr,r00)) for ee,rr,r00 in zip(e0,rho,r0))
    a1=tuple(tuple(r-e for r,e in zip(rr,ee)) for rr,ee in zip(r1,e1))
    eps=tuple(x+y+e-r for x,y,e,r in zip(dot(a0,t['r']),dot(a1,s),e2,r2));assert eps==tuple(t['error'])
    # A different bit encoder: write bits, rather than shift-OR whole fields.
    vals=[x for row in ct[0] for x in row]+list(ct[1]);bits=[(v>>j)&1 for v in vals for j in range(11)]
    wire=bytes(sum(bits[8*i+j]<<j for j in range(8)) for i in range(len(bits)//8));assert wire.hex()==t['wire_hex']
    counts['production_transcript_recomputed']=1;counts['production_residue_coordinates']=256;counts['ciphertext_bytes_rebuilt']=1408
    # Direct Bernoulli construction of CBD1, all 4 equally likely atoms.
    atoms=[x-y for x,y in itertools.product((0,1),repeat=2)];u=F(3,2)
    a=sum(u**((abs(e)+T)*r) for e,r,T in itertools.product(atoms,atoms,range(4)))/64
    beta=sum(max(sum(u**(s*((c+e)%2-e)) for e in atoms)/4 for c in (0,1)) for s in atoms)/4
    cc=sum(u**e for e in atoms)/4
    cert=256*(1+u)*(a*beta)**768*cc/u**1024
    assert a==F(52261,41472) and beta==F(67,64) and cc==F(25,24)
    assert (cert.numerator<<282)<cert.denominator
    R['certificate']={'strict_lt_2^-282':True,'fraction_factors':[str(a),str(beta),str(cc)]}
    # Entire scalar joint law, including all latent rounding remainders.
    for P,Q in ((8,2),(16,4)):
        totals=[F(0),F(0)];maxavg=F(0)
        for A in range(P):
            pos=neg=F(0)
            for s,e0,r,e1,e2,rho in itertools.product(atoms,atoms,atoms,atoms,atoms,range(Q)):
                pub=((A*s+e0)%P)//Q;v=Q*pub+rho
                rr0=(A*s+e0)%Q;rr1=(A*r+e1)%2;rr2=(v*r+e2)%2
                err=(e0+rho-rr0)*r+(rr1-e1)*s+e2-rr2
                z=(2*(((v*r+e2)%P)//2)-2*(((A*r+e1)%P)//2)*s)%P
                assert z==err%P
                pos+=u**err;neg+=u**(-err)
                counts['fully_enumerated_scalar_latent_atoms']+=1
            denom=4**5*Q
            pos/=denom;neg/=denom
            aa=sum(u**((abs(e)+T)*r) for e,r,T in itertools.product(atoms,atoms,range(Q)))/(16*Q)
            assert pos<=aa*beta*cc and neg<=u*aa*beta*cc
            counts['whole_joint_mgf_profiles']+=1
    # A complete finite second-hybrid, independently from integer scalars.
    for A in range(8):
        for bb in range(4):
            for msg in (0,1):
                law=Counter();image=Counter()
                for rr,e,f,V in itertools.product(atoms,atoms,atoms,range(2*bb,2*bb+2)):
                    y=(A*rr+e)%8;z=(V*rr+f)%8
                    law[(y//2,((z+4*msg)%8)//2)]+=1
                    # Re-evaluate full 2x1 matrix source using sum of products.
                    mat=((A,),(V,));sol=(rr,);err=(e,f)
                    outs=tuple((sum(x*y for x,y in zip(row,sol))+ee)%8 for row,ee in zip(mat,err))
                    image[(outs[0]//2,((outs[1]+4*msg)%8)//2)]+=1
                assert law==image;counts['scalar_second_hybrid_laws']=counts['scalar_second_hybrid_laws']+1
    # Dynamic cyclic-word counting by the number of trailing zeros at a cut.
    def no_run_count(N,zeta):
        total=0
        for first in range(zeta):
            v=[0]*zeta;v[first]=1
            for _ in range(N):
                w=[0]*zeta
                w[0]=sum(v)
                for j in range(1,zeta):w[j]=v[j-1]
                v=w
            total+=v[first]
        return total
    for N in range(1,10):
        for zeta in range(1,N+1):
            enumerated=sum(not any(all(bits[(i+j)%N] for j in range(zeta)) for i in range(N)) for bits in itertools.product((0,1),repeat=N))
            assert no_run_count(N,zeta)==enumerated;counts['cyclic_comparisons']+=1
    pr=1-F(no_run_count(256,16),1<<256)
    primary=json.loads((root/'A6_RESULTS.json').read_text())
    assert str(pr.numerator)==primary['cyclic_256_16']['num'] and str(pr.denominator)==primary['cyclic_256_16']['den']
    R.update(status='PASS',counts=dict(counts),scope='Independent A6 arithmetic and probability implementation; finite checks only.')
    Path(out).write_text(json.dumps(R,sort_keys=True,indent=2)+'\n');print(json.dumps(R,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',default='A6_INDEPENDENT.json');run(p.parse_args().output)
