# A6 v1.1 public revision notes

A6 v1.1 is a targeted documentary/reproducibility revision of A6 v1.0. No mathematical equation, cryptographic algorithm, source distribution, security bound, parameter, or payload size is changed.

Changes made for closure:
- removed the obsolete reproduction command referring to the nonexistent `verify_package.py`;
- retained only the documented commands using `verify_a6.py`, `verify_a6_independent.py`, `bash build_and_verify.sh`, and `bash compile_pdf.sh`;
- corrected the artifact-scope statement: the distributed programs verify base-PKE arithmetic, coefficient encodings, and random-tape distributions, but do not implement random oracles `G`/`H`, their tuple encodings, or a KEM wrapper;
- restated injective tuple encodings and domain separation as requirements of the abstract independent-oracle KEM model, not as implemented test artifacts;
- replaced the editorial cross-reference to an earlier NOISE lemma by a self-contained explanation of the independence requirement;
- removed the Python bytecode cache from the public archive;
- designated `A6_MODDIV_BLINDAGE_C1_v1_1.pdf` as the single canonical PDF for this release.

Scientific scope is unchanged: C1-P12-CBD1 only; conditional single-user classical-ROM CCA; no concrete 128-bit certification, QROM result, CBD2 transfer, side-channel claim, or deployment recommendation.
