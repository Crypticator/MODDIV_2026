#!/usr/bin/env python3
"""Deterministic A6 checks. Finite tests, not hardness certification."""
import argparse, hashlib, itertools, json, math, random
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import a6_blindage as b

def record(fr): return {'num':str(fr.numerator),'den':str(fr.denominator)}
def main(path):
    rng=random.Random(2026110812);counts=Counter(); results={}
    # Every coefficient of a product is a signed Toeplitz row; cancellation.
    for n in (1,2,4,8):
        p=b.Params(n=n,k=2,P=64,Q=4,C=2)
        for _ in range(50):
            A=b.matrix(rng,p);s=b.small_vec(rng,p.k,n);r=b.small_vec(rng,p.k,n)
            assert b.inner(b.matvec(A,s),r)==b.inner(b.matvec(b.transpose(A),r),s)
            counts['module_cancellation']+=1
    for P in (8,16,32,64,128):
        for mu in (0,1):
            for e in range(-P//4+1,P//4):
                assert b.decode((P//2)*mu+e,P)==mu
                counts['strict_decoder_inputs']+=1
        assert b.decode(P//4,P)==b.decode(3*P//4,P)==0
    # Signed error with every message, and arbitrary A (not rank conditioned).
    for n in (1,2,4,8):
        p=b.Params(n=n,k=2,P=128,Q=4,C=2)
        for _ in range(24):
            A=b.matrix(rng,p);s=b.small_vec(rng,2,n);e0=b.small_vec(rng,2,n)
            r=b.small_vec(rng,2,n);e1=b.small_vec(rng,2,n);e2=b.small(rng,n)
            rho=tuple(tuple(rng.randrange(4) for _ in range(n)) for j in range(2))
            for mu in itertools.product((0,1),repeat=n):
                pk,eps,rems=b.error_identity(p,A,s,e0,mu,r,e1,e2,rho)
                ct=b.enc_from_coins(p,A,pk,mu,r,e1,e2,rho);out,z=b.dec(p,s,ct)
                assert z==tuple(((p.P//2)*v+e)%p.P for v,e in zip(mu,eps))
                if max(abs(e) for e in eps)<p.P//4: assert out==mu
                assert b.unpack_ct(p,b.pack_ct(p,ct))==ct
                counts['signed_error_messages']+=1
    # MGF: endpoint maximization, negacyclic sign, no independence of r0 used.
    for u in (F(9,8),F(5,4),F(3,2),F(2)):
        for Q in (2,4,8):
            for e in range(-5,6):
                upper=sum(pr*F(1,Q)*u**((abs(e)+t)*r) for r,pr in b.CBD.items() for t in range(Q))
                for r0 in range(Q):
                    for sig in (-1,1):
                        val=sum(pr*F(1,Q)*u**(sig*(e+t-r0)*r) for r,pr in b.CBD.items() for t in range(Q))
                        assert val<=upper;counts['pointwise_remainder_mgf']+=1
    p=b.Params();a,bb,c=b.mgf_terms(F(3,2));cert=b.failure_bound()
    assert (a,bb,c)==(F(52261,41472),F(67,64),F(25,24))
    assert cert*(1<<282)<1
    results['correctness_certificate']={'a':str(a),'b':str(bb),'c':str(c),'u':'3/2',
        'n':256,'kn':768,'threshold':1024,'numerator_bits':cert.numerator.bit_length(),
        'denominator_bits':cert.denominator.bit_length(),'strict_delta_lt_2^-282':True,
        'log2_display_only':round(math.log2(cert.numerator)-math.log2(cert.denominator),12)}
    # A complete legal failure configuration, independent of the choice of A.
    zero=(0,)*256;ones=(1,)*256;minus=(-1,)*256
    A=b.matrix(rng,p);s=(zero,)*3;e0=(minus,)*3;r=(ones,)*3;e1=(zero,)*3;e2=zero;rho=(zero,)*3
    pk,eps,_=b.error_identity(p,A,s,e0,zero,r,e1,e2,rho)
    ct=b.enc_from_coins(p,A,pk,zero,r,e1,e2,rho);out,z=b.dec(p,s,ct)
    assert eps[0]==3048 and z[0]==3048 and out[0]==1
    assert 768+1536+1536+768+256+1536==6400
    results['nonzero_failure']={'first_error':3048,'signed_residue':-1048,'probability':'2^-6400','message':'all zero','wrong_first_bit':1}
    # New implementation production-dimensional functional cases: not old replay.
    for i in range(12):
        A=b.matrix(rng,p);s=b.small_vec(rng,3,256);e0=b.small_vec(rng,3,256)
        r=b.small_vec(rng,3,256);e1=b.small_vec(rng,3,256);e2=b.small(rng,256)
        rho=tuple(tuple(rng.randrange(4) for _ in range(256)) for j in range(3))
        mu=tuple(rng.randrange(2) for _ in range(256))
        pk,eps,_=b.error_identity(p,A,s,e0,mu,r,e1,e2,rho)
        ct=b.enc_from_coins(p,A,pk,mu,r,e1,e2,rho);out,z=b.dec(p,s,ct)
        assert out==mu and z==tuple(((p.P//2)*x+y)%p.P for x,y in zip(mu,eps))
        wire=b.pack_ct(p,ct);assert len(wire)==1408 and b.unpack_ct(p,wire)==ct
        counts['production_functional_encryptions']+=1
        if i==0:
            transcript={'A':A,'s':s,'e0':e0,'message':mu,'r':r,'e1':e1,'e2':e2,'rho':rho,'b':pk,'ct':ct,'error':eps,'wire_hex':wire.hex()}
    Path(path).with_name('A6_SYNTHETIC.json').write_text(json.dumps(transcript,indent=2)+'\n')
    # Exact lift with side public independent; all small atoms.
    for P,Q,n in ((8,2,1),(8,4,2),(16,4,2)):
        cnt=Counter()
        for v in itertools.product(range(P),repeat=n):
            cnt[(tuple(x//Q for x in v),tuple(x%Q for x in v))]+=1
        assert len(cnt)==P**n and set(cnt.values())=={1}
        counts['joint_lift_atoms']+=P**n
    # Complete scalar second hybrid laws, P=8,Q=C=2, outside C1 profile.
    weights={-1:1,0:2,1:1};P=8;Q=C=2
    for A in range(P):
        for pub in range(P//Q):
            for mu in (0,1):
                direct=Counter();sim=Counter()
                for rho in range(Q):
                    v=Q*pub+rho
                    for r,e1,e2 in itertools.product(weights,repeat=3):
                        w=weights[r]*weights[e1]*weights[e2]
                        direct[(((A*r+e1)%P)//C,((v*r+e2+4*mu)%P)//C)]+=w
                        source=((A*r+e1)%P,(v*r+e2)%P)
                        sim[(source[0]//C,((source[1]+4*mu)%P)//C)]+=w
                        counts['scalar_real_hybrid_atoms']+=1
                assert direct==sim and sum(direct.values())==128
                null=Counter((y1//C,((y2+4*mu)%P)//C) for y1 in range(P) for y2 in range(P))
                assert set(null.values())=={C*C}
                counts['scalar_joint_hybrid_laws']+=1
    # CBD1 random-tape allocation and high bits of matrix oracle.
    z=Counter((x&1)-((x>>1)&1) for x in range(256));assert z=={-1:64,0:128,1:64}
    for P in (8,16,4096):
        assert set(Counter(x%P for x in range(65536)).values())=={65536//P}
        counts['matrix_word_uniformity_profiles']+=1
    tape=bytes(rng.randrange(256) for _ in range(2176));r,e1,e2,rho=b.coins_from_bytes(p,tape)
    assert len(r)==len(e1)==len(rho)==3 and len(e2)==256
    assert p.payload_bits()==(7944,11264)
    for _ in range(100):
        vals=tuple(rng.randrange(1024) for _ in range(768));blob=b.pack_fields(vals,10)
        assert len(blob)==960 and b.unpack_fields(blob,768,10)==vals
        counts['public_quotient_pack_roundtrips']+=1
    # Exhaustive canonical codec in an auxiliary n=1, k=1, P=8,C=2 profile.
    toy=b.Params(n=1,k=1,P=8,Q=2,C=2)
    for x in range(256):
        try: ct=b.unpack_ct(toy,bytes([x]));valid=True
        except ValueError:valid=False
        assert valid==(x<16)
        if valid:assert b.pack_ct(toy,ct)==bytes([x])
        counts['toy_byte_containers']+=1
    # Ciphertext translations: outside decoder ties it complements exactly.
    for z in range(4096):
        comp=b.decode(z,4096)!=b.decode(z+2048,4096)
        assert comp==(z not in (1024,3072));counts['decoder_complement_residues']+=1
    # Cyclic zero-run exactness: exhaustive binary words (1 denotes zero).
    for N in range(1,11):
        for zz in range(1,N+1):
            hit=0
            for bits in itertools.product((0,1),repeat=N):
                hit+=any(all(bits[(j+t)%N] for t in range(zz)) for j in range(N))
                counts['cyclic_words_across_tests']+=1
            assert b.cyclic_run_probability(N,zz)==F(hit,1<<N)
            counts['cyclic_run_profiles']+=1
    pr=b.cyclic_run_probability(256,16)
    results['cyclic_256_16']=dict(record(pr),display=float(pr),independence_surrogate_display=float(1-(1-F(1,1<<16))**256))
    # Guessing optimality small finite lists and exact production quantiles.
    for zeta in range(1,9):
        probs=sorted((F(1,1<<(zeta+sum(v!=0 for v in x))) for x in itertools.product((-1,0,1),repeat=zeta)),reverse=True)
        for target in (F(1,4),F(1,2),F(3,4)):
            _,g=b.guess_quantile(zeta,target);assert sum(probs[:g])>=target and sum(probs[:g-1])<target
            counts['guess_quantiles_exhaustive']+=1
    results['guessing_768']={str(t):{'weight':w,'guesses':str(g)} for t in (F(1,4),F(1,2),F(3,4)) for w,g in [b.guess_quantile(768,t)]}
    # Low quotient modulo 2: x=z-1 change of basis, then truncation.
    for n in (2,4,8):
        for t in range(1,n+1):
            images=Counter()
            for bits in itertools.product((0,1),repeat=n):
                y=tuple(sum(bits[j]*math.comb(j,i) for j in range(i,n))%2 for i in range(t))
                images[y]+=1;counts['low_quotient_bit_vectors']+=1
            assert len(images)==1<<t and set(images.values())=={1<<(n-t)}
            counts['low_quotient_profiles']+=1
    # Exact probability that explicit noise changes floor quotient.
    for P in (8,16,32,64):
        for Q in (2,4):
            for z in range(P):
                prob=sum(w for e,w in b.CBD.items() if ((z+e)%P)//Q!=(z%P)//Q)
                assert prob==F(int(z%Q==0)+int(z%Q==Q-1),4)
                counts['scalar_noise_boundary_cases']+=1
    # HHK budgets / illustrative conditional resource thresholds, integer arithmetic.
    thresholds=[]
    for logkap in (0,10,16,20,24):
        kap=1<<logkap
        def budget(s):return 12*kap*F(1,1<<s)+10*F(1,1<<282)+42*F(1,1<<256)
        s=128
        while budget(s)>=F(1,1<<128):s+=1
        assert budget(s-1)>=F(1,1<<128)
        thresholds.append([logkap,s]);counts['conditional_resource_thresholds']+=1
    results['conditional_thresholds']=thresholds
    results.update(status='PASS',seed=2026110812,counts=dict(counts),scope='Public A6 mathematical checks; finite identities and exact arithmetic only; no concrete-hardness or CCA certification.')
    Path(path).write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','counts':dict(counts)},indent=2))
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--output',default='A6_RESULTS.json');main(a.parse_args().output)
