#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
python3 verify_a6.py --output "$tmp/A6_RESULTS.json" >/dev/null
cmp A6_RESULTS.json "$tmp/A6_RESULTS.json"
cmp A6_SYNTHETIC.json "$tmp/A6_SYNTHETIC.json"
python3 verify_a6_independent.py --output "$tmp/A6_INDEPENDENT.json" >/dev/null
cmp A6_INDEPENDENT.json "$tmp/A6_INDEPENDENT.json"
python3 - <<'PY'
import json
for f in ('A6_RESULTS.json','A6_INDEPENDENT.json'):
    d=json.load(open(f)); assert d['status']=='PASS',f
print('PASS: A6 primary and independent checks reproduce exactly.')
PY
