"""Public mathematical reference for A6 / MODDIV-BLINDAGE C1 (C1-P12-CBD1).
Research reference only; no deployment, side-channel, or concrete-hardness claim.
All products use arbitrary-precision integers. Samplers require an explicit RNG.
"""
from dataclasses import dataclass
from fractions import Fraction
from math import comb

@dataclass(frozen=True)
class Params:
    n: int = 256
    k: int = 3
    P: int = 4096
    Q: int = 4
    C: int = 2
    def __post_init__(self):
        if self.n < 1 or self.n & (self.n-1) or self.k < 1:
            raise ValueError('n must be a power of two and k positive')
        if self.P < 8 or self.P & (self.P-1):
            raise ValueError('P must be a power of two >=8')
        if not 1 <= self.Q < self.P or self.P % self.Q:
            raise ValueError('Q must properly divide P')
        if self.C < 1 or self.P % self.C or (self.P//2) % self.C:
            raise ValueError('C must divide P/2')
    def payload_bits(self):
        # Seeded public key, fixed 8-bit identifier + 256-bit seed.
        wq=(self.P//self.Q).bit_length()-1
        wc=(self.P//self.C).bit_length()-1
        return (264+self.k*self.n*wq,(self.k+1)*self.n*wc)

def mul(a,b,mod=None):
    if len(a)!=len(b) or not a: raise ValueError('equal nonempty lengths required')
    n=len(a); out=[0]*n
    for i,x in enumerate(a):
        if x:
            for j,y in enumerate(b):
                s=i+j; out[s%n] += x*y if s<n else -x*y
    return tuple(v%mod if mod else v for v in out)

def add(*polys, mod=None):
    if not polys or len({len(x) for x in polys})!=1: raise ValueError('shape')
    return tuple(sum(v)%mod if mod else sum(v) for v in zip(*polys))

def inner(x,y,mod=None):
    if len(x)!=len(y) or not x: raise ValueError('vector shape')
    return add(*(mul(a,b,mod) for a,b in zip(x,y)),mod=mod)

def matvec(A,s,mod=None):
    if not A or any(len(row)!=len(s) for row in A): raise ValueError('matrix shape')
    return tuple(inner(row,s,mod) for row in A)

def transpose(A): return tuple(tuple(x) for x in zip(*A))
def floor_poly(z,P,D): return tuple((x%P)//D for x in z)
def cbd1(rng): return rng.randrange(2)-rng.randrange(2)
def small(rng,n): return tuple(cbd1(rng) for _ in range(n))
def small_vec(rng,k,n): return tuple(small(rng,n) for _ in range(k))
def matrix(rng,p,rows=None):
    return tuple(tuple(tuple(rng.randrange(p.P) for _ in range(p.n)) for _ in range(p.k))
                 for _ in range(p.k if rows is None else rows))

def key_from_coins(p,A,s,e0):
    z=tuple(add(a,b,mod=p.P) for a,b in zip(matvec(A,s,p.P),e0))
    return tuple(floor_poly(a,p.P,p.Q) for a in z)

def enc_from_coins(p,A,b,mu,r,e1,e2,rho):
    if len(mu)!=p.n or any(x not in (0,1) for x in mu): raise ValueError('message')
    if len(b)!=p.k or len(rho)!=p.k: raise ValueError('shape')
    v=tuple(tuple(p.Q*u+t for u,t in zip(a,rr)) for a,rr in zip(b,rho))
    z1=tuple(add(a,e,mod=p.P) for a,e in zip(matvec(transpose(A),r,p.P),e1))
    z2=add(inner(v,r,p.P),e2,tuple((p.P//2)*x for x in mu),mod=p.P)
    return (tuple(floor_poly(z,p.P,p.C) for z in z1),floor_poly(z2,p.P,p.C))

def decode(z,P): return int(P//4 < z%P < 3*P//4)
def dec(p,s,ct):
    c1,c2=ct
    if len(c1)!=p.k or any(len(x)!=p.n for x in c1) or len(c2)!=p.n:
        raise ValueError('ciphertext shape')
    if any(not 0<=v<p.P//p.C for row in c1+(c2,) for v in row):
        raise ValueError('ciphertext range')
    z=tuple((p.C*u-v)%p.P for u,v in zip(c2,inner(tuple(tuple(p.C*v for v in a) for a in c1),s,p.P)))
    return tuple(decode(t,p.P) for t in z),z

def error_identity(p,A,s,e0,mu,r,e1,e2,rho):
    b=key_from_coins(p,A,s,e0)
    v=tuple(tuple(p.Q*u+t for u,t in zip(a,rr)) for a,rr in zip(b,rho))
    z0=tuple(add(a,e) for a,e in zip(matvec(A,s),e0))
    z1=tuple(add(a,e) for a,e in zip(matvec(transpose(A),r),e1))
    z2=add(inner(v,r),e2)
    r0=tuple(tuple(t%p.Q for t in a) for a in z0)
    r1=tuple(tuple(t%p.C for t in a) for a in z1)
    r2=tuple(t%p.C for t in z2)
    f0=tuple(tuple(e+t-u for e,t,u in zip(ee,rr,ss)) for ee,rr,ss in zip(e0,rho,r0))
    f1=tuple(tuple(u-e for u,e in zip(rr,ee)) for rr,ee in zip(r1,e1))
    eps=add(inner(f0,r),inner(f1,s),tuple(e-u for e,u in zip(e2,r2)))
    return b,eps,(r0,r1,r2)

CBD={-1:Fraction(1,4),0:Fraction(1,2),1:Fraction(1,4)}
def mgf_terms(u,Q=4,C=2):
    u=Fraction(u)
    if u<=1: raise ValueError('u>1')
    a=sum(pe*pr*Fraction(1,Q)*u**((abs(e)+t)*r)
          for e,pe in CBD.items() for r,pr in CBD.items() for t in range(Q))
    b=sum(ps*max(sum(pe*u**(s*((j+e)%C-e)) for e,pe in CBD.items()) for j in range(C))
          for s,ps in CBD.items())
    c=sum(pe*u**e for e,pe in CBD.items())
    return a,b,c

def failure_bound(p=Params(),u=Fraction(3,2)):
    a,b,c=mgf_terms(u,p.Q,p.C)
    return p.n*(1+u**(p.C-1))*(a*b)**(p.k*p.n)*c*u**(-p.P//4)

def pack_fields(values,width):
    if width<1: raise ValueError('width')
    acc=0
    for i,v in enumerate(values):
        if type(v) is not int or not 0<=v<1<<width: raise ValueError('field')
        acc|=v<<(width*i)
    return acc.to_bytes((len(values)*width+7)//8,'little')

def unpack_fields(blob,count,width):
    if not isinstance(blob,bytes) or len(blob)!=(count*width+7)//8: raise ValueError('length')
    acc=int.from_bytes(blob,'little')
    if acc>>(count*width): raise ValueError('padding')
    return tuple((acc>>(i*width))&((1<<width)-1) for i in range(count))

def pack_ct(p,ct):
    c1,c2=ct
    return pack_fields(tuple(v for row in c1 for v in row)+tuple(c2),(p.P//p.C).bit_length()-1)

def unpack_ct(p,blob):
    w=(p.P//p.C).bit_length()-1
    allv=unpack_fields(blob,(p.k+1)*p.n,w)
    return tuple(tuple(allv[j*p.n:(j+1)*p.n]) for j in range(p.k)),tuple(allv[p.k*p.n:])

def coins_from_bytes(p,tape):
    # C1 original article's described allocation: one byte/CBD1 coefficient;
    # then one nibble per remainder for Q=4. No original domain tags assumed.
    if p.Q!=4: raise ValueError('described tape is restricted to Q=4')
    nsmall=(2*p.k+1)*p.n; nrem=p.k*p.n
    if len(tape)!=nsmall+(nrem+1)//2: raise ValueError('coin length')
    vals=tuple((v&1)-((v>>1)&1) for v in tape[:nsmall])
    r=tuple(vals[j*p.n:(j+1)*p.n] for j in range(p.k))
    e1=tuple(vals[(p.k+j)*p.n:(p.k+j+1)*p.n] for j in range(p.k))
    e2=vals[2*p.k*p.n:]
    rem=tuple(((tape[nsmall+i//2]>>(4*(i%2)))&3) for i in range(nrem))
    rho=tuple(rem[j*p.n:(j+1)*p.n] for j in range(p.k))
    return r,e1,e2,rho

def matmul_int(A,B):
    cols=tuple(zip(*B))
    return [[sum(x*y for x,y in zip(row,col)) for col in cols] for row in A]
def matpow_int(A,n):
    d=len(A);out=[[int(i==j) for j in range(d)] for i in range(d)]
    while n:
        if n&1:out=matmul_int(out,A)
        A=matmul_int(A,A);n//=2
    return out

def cyclic_run_probability(N,zeta):
    if not 1<=zeta<=N: raise ValueError('run length')
    T=[[0]*zeta for _ in range(zeta)]
    for j in range(zeta):
        T[j][0]+=1
        if j+1<zeta:T[j][j+1]+=1
    V=matpow_int(T,N)
    return 1-Fraction(sum(V[i][i] for i in range(zeta)),1<<N)

def guess_quantile(zeta,target):
    target=Fraction(target)
    if not 0<target<=1: raise ValueError('target')
    covered=Fraction(0); guesses=0
    for w in range(zeta+1):
        size=comb(zeta,w)*(1<<w); prob=Fraction(1,1<<(zeta+w))
        if covered+size*prob>=target:
            missing=(target-covered)/prob
            return w,guesses+(missing.numerator+missing.denominator-1)//missing.denominator
        guesses+=size;covered+=size*prob
    raise AssertionError('unreachable')
