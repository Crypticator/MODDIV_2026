# A5 public sources

Public scientific sources used by A5 v1.1:

1. Samir Bouftass, *Multidimentional ModDiv public key exchange protocol*, IACR ePrint 2021/701 (2021). Historical context only.
2. Oded Regev, *On Lattices, Learning with Errors, Random Linear Codes, and Cryptography*, JACM 56(6), 2009.
3. Daniele Micciancio, *On the Hardness of Learning With Errors with Binary Secrets*, Theory of Computing 14(13), 2018.
4. Miruna Rosca, Amin Sakzad, Damien Stehle, Ron Steinfeld, *Middle-Product Learning With Errors*, CRYPTO 2017 / ePrint 2017/628.
5. Shi Bai, Katharina Boudgoust, Dipayan Das, Adeline Roux-Langlois, Weiqiang Wen, Zhenfei Zhang, *Middle-Product Learning with Rounding Problem and Its Applications*, ASIACRYPT 2019 / ePrint 2019/1001.
6. Chris Peikert, Zachary Pepin, *Algebraically Structured LWE, Revisited*, Journal of Cryptology 37(3), 2024.

A5 does not cite chats, internal audits, private reports, mission orders, or thesis chapters as scientific premises. The article proves its local algebraic and game-based claims directly. The hardness of the declared HB source remains an explicit open premise.
