#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 verify_a5.py --output A5_RESULTS_RECHECK.json >/dev/null
python3 verify_a5_independent.py --output A5_INDEPENDENT_RECHECK.json >/dev/null
python3 verify_a5_encoding.py --output A5_ENCODING_RESULTS_RECHECK.json >/dev/null
python3 a5_kat.py --output A5_KAT_RECHECK.json >/dev/null
cmp A5_RESULTS_RECHECK.json A5_RESULTS.json
cmp A5_INDEPENDENT_RECHECK.json A5_INDEPENDENT.json
cmp A5_ENCODING_RESULTS_RECHECK.json A5_ENCODING_RESULTS.json
cmp A5_KAT_RECHECK.json A5_KAT.json
rm -f A5_RESULTS_RECHECK.json A5_INDEPENDENT_RECHECK.json A5_ENCODING_RESULTS_RECHECK.json A5_KAT_RECHECK.json
if [[ -f SHA256SUMS.txt ]]; then sha256sum -c SHA256SUMS.txt; fi
