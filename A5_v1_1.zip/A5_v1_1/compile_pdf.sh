#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for i in 1 2 3; do pdflatex -interaction=nonstopmode -halt-on-error A5_MODDIV_NOISE_v1_1.tex >/tmp/a5_pdflatex_$i.log; done
