A5 v1.1 - MODDIV-NOISE

Public reproducibility package. Python 3.10+; standard library only.

Main files:
- A5_MODDIV_NOISE_v1_1.tex / .pdf
- a5_noise.py: research reference implementation for the CBD1 profile
- a5_codec.py: canonical lossless packing
- verify_a5.py: primary arithmetic/distribution verifier
- verify_a5_independent.py: independent verifier; imports neither a5_noise.py nor a5_codec.py
- verify_a5_encoding.py: deterministic codec regression (1500 round trips, 2500 rejections, 60 encoded encryptions)
- a5_kat.py: deterministic synthetic known-answer test
- A5_TRANSCRIPTS.json: public synthetic transcript fixtures used by the independent checker
- A5_RESULTS.json / A5_INDEPENDENT.json / A5_ENCODING_RESULTS.json / A5_KAT.json
- A5_PUBLIC_SOURCES.md
- SHA256SUMS.txt

Reproduce:
  python3 verify_a5.py --output A5_RESULTS_RECHECK.json
  python3 verify_a5_independent.py --output A5_INDEPENDENT_RECHECK.json
  python3 verify_a5_encoding.py --output A5_ENCODING_RESULTS_RECHECK.json
  python3 a5_kat.py --output A5_KAT_RECHECK.json

Build PDF:
  bash compile_pdf.sh

Full package check:
  bash build_and_verify.sh

Scope: these checks verify the stated arithmetic, selected exact finite joint laws, canonical encodings, negative controls, and the documented encoding-test counts. They do not establish HB hardness, a reduction from standard LWE/MP-LWE, CCA security, concrete 128-bit security, or deployment readiness.
