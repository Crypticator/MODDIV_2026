# A5 v1.1 public-edition notes

A5 v1.1 is a targeted reproducibility revision of A5 v1.0. No theorem, construction algorithm, source distribution, reduction loss, correctness bound, or CCA2 result is changed.

Closure changes:
- R5-01: added `verify_a5_encoding.py` and `A5_ENCODING_RESULTS.json`; the public package now reproduces exactly 1500 canonical round trips, 2500 noncanonical-format rejections, and 60 encryption/decryption cycles through canonical encodings. `build_and_verify.sh` executes and compares this result.
- R5-02: corrected the independent verifier docstring from `Independent Chapter 11 checks` to `Independent A5 checks`.
- README, article version labels, reproduction instructions, PDF and SHA-256 manifest were regenerated for the revised bytes.

Scientific safeguards retained:
- the conditional deferred-lift lemma explicitly requires independence of the public sequence A and the uniform lift B;
- the CPA theorem retains two distinct HB distinguishers, B0 and B1, and does not collapse their advantages;
- the HB assumption is not identified with standard LWE, MP-LWE, or MP-LWR;
- the unwrapped scheme is explicitly stated to be non-CCA2-secure;
- no 128-bit or deployment claim is made;
- the public package contains no chats, internal audit reports, mission documents, or private proof dossiers.
