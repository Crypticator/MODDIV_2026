A1 - Scalar ModDiv Revisited - v1.1
===================================

Contents
--------
A1_SCALAR_MODDIV_v1_1.pdf        Article PDF (13 pages)
A1_SCALAR_MODDIV_v1_1.tex        LaTeX source
verify_a1_v1_1.py                     Python 3 exact-arithmetic verifier
count_agreement_a1.cpp           C++17 exact finite closure q=1..11
check_upper_half_a1.cpp          C++17 direct q=7 upper-half enumeration
A1_COUNTS_Q1_Q11.csv             Exact q=1..11 closure certificate
A1_UPPER_HALF_DIRECT.csv         Direct 134,217,728-triple counterexample count
A1_VERIFY_RESULTS.json           Python verification results
A1_PUBLIC_SOURCES.md             Public-source record
SHA256SUMS.txt                   SHA-256 manifest

Verification
------------
Standard Python checks:
  python3 verify_a1_v1_1.py

Full finite closure q=1..11 (requires a C++17 compiler):
  python3 verify_a1_v1_1.py --full-closure

Independent seven-bit direct enumeration:
  g++ -O3 -std=c++17 check_upper_half_a1.cpp -o check_upper_half_a1
  ./check_upper_half_a1

The package uses exact integer arithmetic for the finite certificates. It does not
claim IND-CPA/IND-CCA security, a lattice-hardness reduction, or a concrete bit-security
level. The article's public bibliography is the only provenance used for historical claims.

A1 v1.1 corrections
-------------------
- Guard in the standalone interval-count formula made explicit.
- Nonaligned phase proof uses g_H = gcd(xy,H) and an explicit truncated-support bound.
- Conditional independence/posterior randomness assumptions stated explicitly.
- Integer domains and nonempty-uniform supports clarified.
- C++ compilation comment corrected.
