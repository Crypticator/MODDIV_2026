# A1 public source record

A1 is self-contained mathematically. The historical/contextual bibliography uses only public sources:

1. A. Azhari and S. Bouftass, *On a New Fast Public Key Cryptosystem*, IACR ePrint 2014/946, revised 29 Oct 2015.
   https://eprint.iacr.org/2014/946
2. Y. Zhang, *A Practical Attack to Bouftass's Cryptosystem*, arXiv:1605.00987, 2016.
   https://arxiv.org/abs/1605.00987
3. M. Barcau, V. Pasol, C. Plesca, M. Togan, *On a Key Exchange Protocol*, SecITC 2017, LNCS 10543, pp. 187-199.
   https://doi.org/10.1007/978-3-319-69284-5_13
4. S. Bouftass, *Multidimentional ModDiv Public Key Exchange Protocol*, IACR ePrint 2021/701, 2021.
   https://eprint.iacr.org/2021/701
5. T. Tao, *254B, Notes 1: Equidistribution of Polynomial Sequences in Tori*, 2010.
   https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/

