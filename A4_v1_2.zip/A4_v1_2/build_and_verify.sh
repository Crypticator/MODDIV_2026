#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 "$ROOT/verify_a4.py" --output "$TMP/A4_RESULTS.json" >/dev/null
python3 "$ROOT/verify_a4_independent.py" --output "$TMP/A4_INDEPENDENT.json" >/dev/null
cmp "$TMP/A4_RESULTS.json" "$ROOT/A4_RESULTS.json"
cmp "$TMP/A4_INDEPENDENT.json" "$ROOT/A4_INDEPENDENT.json"
printf 'A4 verification: PASS\n'
