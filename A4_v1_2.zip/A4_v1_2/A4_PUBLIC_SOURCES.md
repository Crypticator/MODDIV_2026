# A4 — Public sources and attribution record

This file lists only public sources used to frame or support the article. Internal chats, audits, mission files, and private archives are not scientific references for A4.

1. **Samir Bouftass, “MODDIV-WC: Unit-Anchored Toeplitz/Hankel Rounding with Exact Binary-LWE Masking and an IND-CCA Security Route,” Cryptology ePrint Archive, Paper 2026/2747 (2026).** Public first version of MODDIV-WC. A4 is a revised public treatment: it corrects the modular correctness proof, separates BASE/FAST/COMPACT/FO, and states the proof-route size barrier.
2. **Samir Bouftass, “Multidimentional ModDiv public key exchange protocol,” Cryptology ePrint Archive 2021/701 (2021).** Historical multidimensional ModDiv context only; no security theorem is transferred to MODDIV-WC.
3. **Samir Bouftass, “On a new fast public key cryptosystem,” arXiv:1508.07756 (2015).** Historical scalar ModDiv context.
4. **Y. Zhang, “A practical attack to Bouftass's cryptosystem,” arXiv:1605.00987 (2016).** Historical scalar cryptanalysis context.
5. **Oded Regev, “On Lattices, Learning with Errors, Random Linear Codes, and Cryptography,” JACM 56(6), 2009.** Background for LWE foundations.
6. **Chris Peikert, “Public-Key Cryptosystems from the Worst-Case Shortest Vector Problem,” STOC 2009; full version IACR ePrint 2008/481.** Background for classical worst-case lattice foundations.
7. **Zvika Brakerski, Adeline Langlois, Chris Peikert, Oded Regev, Damien Stehlé, “Classical Hardness of Learning with Errors,” STOC 2013; arXiv:1306.0281.** Binary-secret/modulus-transformation context. A4 does not claim that citing this paper alone completes a finite-parameter grounding for WC.
8. **Abhishek Banerjee, Chris Peikert, Alon Rosen, “Pseudorandom Functions and Lattices,” EUROCRYPT 2012.** LWR background.
9. **Andrej Bogdanov, Siyao Guo, Daniel Masny, Silas Richelson, Alon Rosen, “On the Hardness of Learning with Rounding over Small Modulus,” TCC 2016-A; IACR ePrint 2015/769.** Probability-preserving LWE/LWR methodology.
10. **Shi Bai, Katharina Boudgoust, Dipayan Das, Adeline Roux-Langlois, Weiqiang Wen, Zhenfei Zhang, “Middle-Product Learning with Rounding Problem and its Applications,” ASIACRYPT 2019; IACR ePrint 2019/1001.** Structured middle-product LWR context and attribution.
11. **Eiichiro Fujisaki, Tatsuaki Okamoto, “Secure Integration of Asymmetric and Symmetric Encryption Schemes,” CRYPTO 1999.** Original FO context.
12. **Dennis Hofheinz, Kathrin Hövelmanns, Eike Kiltz, “A Modular Analysis of the Fujisaki–Okamoto Transformation,” TCC 2017; corrected full version IACR ePrint 2017/604 (2021 revision).** Classical-ROM modular FO interface and corrected plaintext-checking/query accounting used as the public reference for the conditional CCA composition.

## Scope boundary

A4 proves statements about the WC construction it specifies. It does **not** infer security for historical ModDiv by similarity; it does **not** prove a standard-model theorem for SHAKE256; it does **not** prove QROM or multi-user CCA security; and it does **not** certify any parameter set at 128-bit concrete security.
