A4 / MODDIV-WC V2 — public reproducibility package
==================================================

Article:
  MODDIV-WC V2: Unit-Anchored Hankel Rounding with Exact Fast Evaluation,
  Seeded Public-Key Compression, and a Conditional IND-CCA Route

Author: Samir Bouftass
A4 package version: v1.2
Date: 10 November 2026

Contents
--------
A4_MODDIV_WC_V2_v1_2.tex   self-contained article source
A4_MODDIV_WC_V2_v1_2.pdf   compiled article
A4_PUBLIC_SOURCES.md        public-source and attribution record
REVISION_NOTES.md           public revision summary

a4_wc_tools.py              mathematical reference functions
verify_a4.py                primary deterministic finite checker
verify_a4_independent.py    independent checker; imports no candidate arithmetic module
A4_RESULTS.json             expected primary checker output
A4_INDEPENDENT.json         expected independent checker output
PDF_PREFLIGHT.txt           structural PDF preflight

build_and_verify.sh         rerun both checkers and compare outputs
compile_pdf.sh              compile the TeX with pdflatex
SHA256SUMS.txt              package-file digests

Reproduction
------------
From the extracted package directory:

  bash build_and_verify.sh

To rebuild the PDF (requires pdflatex and the listed standard LaTeX packages):

  bash compile_pdf.sh

Scope
-----
The programs perform finite algebraic, exact-arithmetic, strict-wire, persistent-fallback, key-only decapsulation, challenge-refusal, functional KEM, payload, and witness checks. The public functional decapsulation helper returns only the key; a private diagnostic helper exposes validity only to regression assertions. They do not prove LWE hardness, the random-oracle model,
IND-CCA security, QROM security, or a concrete 128-bit security level. The SHAKE256
expansion test is functional only; it is not a standard-model realization of a programmable
random oracle.

Runtime
-------
Python 3.10 or newer, standard library only. Environment-version metadata is not part of the deterministic result JSON, so mathematical replay is portable across supported Python versions.
