# A4 v1.2 — Public closure revision notes

A4 v1.2 preserves all scientific statements of A4 v1.1 and makes three artifact-level closure changes.

1. The functional public decapsulation API is now key-only. A private diagnostic helper retains a validity flag solely for regression assertions; the IND-CCA test-game wrapper never returns that flag.
2. The independent checker now contains a real challenge-refusal model with a decapsulation-call counter: the exact challenge is refused before decapsulation, while a distinct byte string reaches the model. The former tautological `challenge == challenge` assertion is removed.
3. The primary asymptotic checker now uses `math.isqrt` only; its comment explicitly describes the conservative integer envelope `lambda^5 * ceil(sqrt((log_2 lambda)^5))`.

The unit-anchor surjectivity proof, shared-mask binary-LWE embedding, signed modular correctness proof, FAST identity, residual hashing, Rényi transfer, persistent-fallback KEM specification, COMPACT programmable-ROM coupling, conditional OW/CCA route, final-noise premises, and the 4,726,272-byte proof-route barrier are unchanged in substance from A4 v1.1.
