#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
pdflatex -interaction=nonstopmode -halt-on-error A4_MODDIV_WC_V2_v1_2.tex >/dev/null
pdflatex -interaction=nonstopmode -halt-on-error A4_MODDIV_WC_V2_v1_2.tex >/dev/null
printf 'PDF rebuilt: %s\n' "$ROOT/A4_MODDIV_WC_V2_v1_2.pdf"
