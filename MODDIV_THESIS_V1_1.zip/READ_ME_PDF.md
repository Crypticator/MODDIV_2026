# MODDIV V1.1 — final public PDF

Open **`MODDIV_Thesis_V1_1_FINAL.pdf`** at the root of this archive. It contains **227 pages**, all 17 chapters, a linked table of contents, mathematical typesetting and the public bibliography.

This editorial revision replaces three residual work identifiers with chapter and construction references and restores spaces in the repository-wide command. The Markdown, TeX and PDF agree. No mathematical expression or cryptographic program is changed. See `PDF_EDITORIAL_CHANGES.md` for the exact changes and checks.

Manuscript SHA-256: `c87a67db78bfe6322c2b9d9e404318430b3420f2e72a559eea0fa4c6e7d5e50d`  
PDF SHA-256: `ff0055b8d2654883d8e454af1b8fca3c1c1aaa166e4954d14fd872d6c94b35d5`

## Reproduction

From the extracted bundle root, run `sha256sum -c PDF_BUNDLE_SHA256.txt` to verify file integrity. From `MODDIV_Thesis_V1_1_FINAL/`, run `python3 verify_repository.py --jobs 4` to execute the chapter verifiers. That complete campaign was not rerun for this purely editorial change; the six principal and independent checks of Chapters 10, 13 and 17 were rerun successfully.

`pdf_source/README.md` describes rebuilding the PDF. Rebuilding may change PDF timestamps, identifiers or pagination with different engine/font versions. The delivered SHA-256 identifies this exact PDF.

The integrity and typesetting checks do not prove the mathematical or cryptographic claims.
