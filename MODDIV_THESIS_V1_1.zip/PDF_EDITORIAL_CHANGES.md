# MODDIV V1.1 — public PDF editorial corrections

Date: 11 November 2026.

This revision makes three terminology corrections and repairs command typesetting. No theorem, equation, hypothesis, parameter, source distribution, security claim or cryptographic program is changed.

## Exact changes

| Location | Previous wording | Revised wording |
|---|---|---|
| Section 10.18 | From `supplementary/chapter-10/`, reproduce the public A4 verification layer with: | From `supplementary/chapter-10/`, run the verification programs for this chapter with: |
| Section 13.12 | the final A4 interface does not add | the WC interface specified in Section 10.11 does not add |
| Section 17.19 | checks the canonical corrected A3–A6 facts imported by the conclusion | checks results from Chapters 9–12 used in the conclusion |
| Section 17.19 | requires the exact compatible-window statement (17.9) to occur in its corrected form | requires the exact compatible-window statement (17.9) to occur in its stated form |

The code-wrapping filter now leaves whitespace-containing inline code to Pandoc's normal code formatter. The five inline occurrences of `python3 verify_repository.py --jobs 4` are placed on a new line and kept together. The existing fenced-code occurrence is preserved. All six PDF occurrences retain the command's spaces and appear on a single line. The manuscript and mathematical expressions are not altered by this formatting step.

## Identity and checks

Previous source SHA-256: `6064d7ded39865bc4611617a558521c036874989803fdedc848ab3a8446c0db0`.

Revised source SHA-256: `c87a67db78bfe6322c2b9d9e404318430b3420f2e72a559eea0fa4c6e7d5e50d`.

Revised PDF SHA-256: `ff0055b8d2654883d8e454af1b8fca3c1c1aaa166e4954d14fd872d6c94b35d5`.

The ordered sequence of all 4,552 mathematical expressions is identical to that in the previous source. All are present in the generated TeX. The PDF contains 227 pages and the 17 chapters in order. Targeted principal and independent verifiers for Chapters 10, 13 and 17 were rerun from a fresh copy and all six completed successfully; the programs themselves were not changed. These checks do not constitute a new audit of the entire thesis.

All pages were rendered with Poppler and reviewed in contact sheets; the edited passages and the repository commands were also inspected in larger renders. Automated checks found no text outside page boundaries, no missing glyph warnings and no invalid internal link destinations. A pre-existing 0.20084 pt paragraph-width warning remains inside the page margins; it does not clip text. External public references were not re-audited.

See `pdf_source/PDF_CHECKS.json` and `pdf_source/TARGETED_VERIFIER_RESULTS.json` for exact results. All package manifests are updated after the edits. The final outer ZIP digest is recorded separately in `MODDIV_FINAL_PUBLIC_CLEAN_SHA256.txt`.
