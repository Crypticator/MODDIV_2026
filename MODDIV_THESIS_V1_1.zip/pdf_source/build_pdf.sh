#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p build
pandoc ../MODDIV_Thesis_V1_1_FINAL/thesis/MODDIV_Thesis_V1_1_PUBLIC.md \
  -f markdown+tex_math_single_backslash+raw_tex -s -t latex \
  --top-level-division=chapter --lua-filter=wrap-code.lua \
  -V documentclass=book -V classoption=oneside -V classoption=openany \
  -V papersize=a4 -V fontsize=11pt -V geometry:margin=22mm \
  -V mainfont='Latin Modern Roman' -V mathfont='Latin Modern Math' \
  -V monofont='DejaVu Sans Mono' -V monofontoptions=Scale=0.85 \
  -V linestretch=1.05 -H pdf-style.tex -o build/MODDIV_Thesis_V1_1_FINAL.tex
python3 layout_postprocess.py build/MODDIV_Thesis_V1_1_FINAL.tex
for pass in 1 2 3; do
  xelatex -interaction=nonstopmode -halt-on-error -output-directory=build build/MODDIV_Thesis_V1_1_FINAL.tex
done
# Rebuild stays in pdf_source/build; the delivered PDF and manifests are not overwritten.
