# PDF typesetting source

The supplied `.tex` file is self-contained and can be compiled with XeLaTeX. Rebuilding it does not require Pandoc. Compile three times for the table of contents and internal references.

To regenerate TeX from the current Markdown, run `bash build_pdf.sh` from this directory. Requirements: Pandoc 3.1.11.1 (used here), Python 3, a complete TeX Live installation with XeLaTeX, Latin Modern Roman and Latin Modern Math, and DejaVu Sans Mono. The LaTeX packages used by the supplied preamble must be installed. The build writes only into `pdf_source/build/`.

The delivered PDF was compiled with XeTeX 0.999996, TeX Live 2025/dev/Debian. PDF timestamps, identifiers, engine and font versions can change the rebuilt file's hash. No claim of cross-environment byte-identical PDF regeneration is made. The delivered SHA-256 identifies the actual distributed PDF.

The style file controls only presentation. The Lua filter allows long inline filenames to wrap. The Python layout pass moves three part dividers to immediately before their first chapter, keeps short supplementary-material sections together, and adds spacing between bibliography entries. No equation or scientific sentence is changed.

The inline-code filter preserves whitespace in commands. The layout pass places the repository-wide command on its own line and keeps it unbroken. This is a formatting operation only.
