function Code(el)
  if FORMAT:match('latex') and #el.text > 35 and not el.text:match('[{}%%]') and not el.text:match('%s') then
    return pandoc.RawInline('latex', '\\nolinkurl{' .. el.text .. '}')
  end
end
