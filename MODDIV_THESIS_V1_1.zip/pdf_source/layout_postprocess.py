from pathlib import Path
import re,sys
p=Path(sys.argv[1]);s=p.read_text()
# Keep the previous chapter's supplementary note before the next part divider.
for part,ch in [('II',5),('III',9),('V',16)]:
    pattern=r'(\\part\*\{[^\n]*\{PART '+part+r' —[^\n]*\}\n)\n([\s\S]*?)(?=\\chapter\{Chapter '+str(ch)+r' ---)'
    s,n=re.subn(pattern,lambda m:m.group(2)+'\n'+m.group(1)+'\n',s)
    if n!=1:raise RuntimeError(f'Expected exactly one divider for part {part}; got {n}')
# Keep every short supplementary-material section together on one page.
pattern=r'(\\section\{Supplementary Material and Reproducibility[\s\S]*?)(?=\\chapter\{|\\part\*\{|\\end\{document\})'
s,n=re.subn(pattern,lambda m:'\\Needspace{12\\baselineskip}\n\\begin{samepage}\n'+m.group(1)+'\\end{samepage}\n\n',s)
if n!=17:raise RuntimeError(f'Expected 17 supplementary sections; got {n}')
# Separate bibliographic entries even when the previous one ends in a URL.
s,n=re.subn(r'(?=\\subsection\{B\d{2}\}\\label\{bib-b\d{2}\})',lambda m:'\\par\\vspace{9pt}\\Needspace{5\\baselineskip}\n',s)
if n!=38:raise RuntimeError(f'Expected 38 bibliography entries; got {n}')
# Keep the repository-wide command on one line for accurate copy/paste.
command = r'\texttt{python3\ verify\_repository.py\ -\/-jobs\ 4}'
if s.count(command) != 5:
    raise RuntimeError('Expected five inline repository-wide commands')
s = s.replace(command, r'\newline\mbox{' + command + '}')
p.write_text(s)
