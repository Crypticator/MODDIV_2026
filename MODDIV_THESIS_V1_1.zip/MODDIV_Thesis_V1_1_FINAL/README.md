# MODDIV Thesis V1.1 — Public Reproducibility Package

This release contains the publication-facing thesis manuscript and populated supplementary material for Chapters 1–17.

Run the reproducibility check with:

```sh
python3 verify_repository.py --jobs 4
```

See `REPRODUCIBILITY.md` and each `supplementary/chapter-XX/README.md` for the exact scope and limitations of the executable checks.
