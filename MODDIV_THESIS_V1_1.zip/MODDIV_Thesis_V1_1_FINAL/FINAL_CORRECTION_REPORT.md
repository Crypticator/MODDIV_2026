# MODDIV Thesis V1.1 — Public Closure Note

Date: 11 November 2026.

## Purpose

This release aligns the public manuscript with the executable material actually distributed. It changes reproducibility descriptions, verification entry points, editorial residue, and finite-check packaging without strengthening any hardness assumption or security conclusion.

## Finite certificates

- The 57-prime certificate is regenerated exactly through `Q=269` by `supplementary/chapter-07/regenerate_prime_certificate.py`.
- The three displayed general-modulus counterexamples are directly enumerated by the delivered C++17 counter.
- The independent Python path rechecks the first two general-modulus profiles and the small prime cases through `Q=11`.

## Security-game and cryptanalysis checks

- Chapter 13 explicitly enumerates the fixed-length-premise counterexample from Section 13.4 and two negative controls.
- Chapter 14 publishes exact small-fiber enumeration and dimension-16 compatibility regressions only. The public release does not claim to reproduce an LLL/Babai secret-recovery algorithm or its timings.
- Chapter 17 retains its compatible-window regressions and negative mutations.

## Editorial autonomy

Public wording refers to locally defined propositions, public literature and distributed test vectors rather than private working archives or review records.

## Integrity

All chapter-local and root SHA-256 manifests are regenerated after the final edits. Generated Python caches are excluded.

## Scientific scope

No theorem is upgraded from conditional to unconditional. No source hardness is newly claimed. No concrete 128-bit certificate is added. No deployment winner is selected.
