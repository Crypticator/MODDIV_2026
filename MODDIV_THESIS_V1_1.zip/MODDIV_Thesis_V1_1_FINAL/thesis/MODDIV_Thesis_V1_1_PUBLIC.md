---
title: "MODDIV"
subtitle: "Modular Reduction, Integer Division, and Structured Polynomial Products in Public-Key Cryptography"
author: "Samir Bouftass"
date: "Consolidated V1.1 edition — 11 November 2026"
lang: en-GB
---

\frontmatter

# Editorial and scientific scope {#scope}

This thesis presents seventeen chapters on modular reduction followed by integer quotient extraction and on several distinct cryptographic constructions built around that arithmetic. The mathematical objects studied in the scalar, polynomial-window, P-REF, WC, NOISE and BLINDAGE C1 branches are not interchangeable; each theorem retains its own distributions, dimensions, security game and assumptions.

**MODDIV V1.1 does not claim a general 128-bit security certificate, and it recommends no V1 construction for deployment.** Conditional reductions remain conditional on the exact source problems and oracle models stated in the corresponding chapters. Finite verification, successful compilation and reproducible experiments do not establish computational hardness.

The thesis is self-contained at the level of its essential mathematical arguments. Scientific claims are proved in the text or supported by public literature.

Each chapter has a public supplementary-data location under `supplementary/chapter-XX/` in the repository release associated with this thesis. Supplementary files contain executable checks, exact computations, parameter tables, counterexamples and test vectors where appropriate. They support reproducibility but do not replace essential proofs in the thesis.

# Abstract {#abstract}

This thesis studies modular reduction followed by integer quotient extraction as an arithmetic operation and as a component of several distinct public-key cryptographic constructions. Exact identities retain the quotients, remainders and carries that would be lost in a purely linear model. Scalar analysis separates honest key agreement from confidentiality through exact fiber counting and posterior sampling. General-modulus results identify the support and alignment conditions under which agreement guarantees hold and exhibit counterexamples outside those conditions.

Toeplitz and Hankel operators connect structured observations with polynomial middle products. Distributional analysis distinguishes deterministic remainders from independent noise and characterizes randomized lifting with the full public view retained. The construction chapters treat a published middle-product reference, an anchored WC construction, explicitly noisy Hankel observations and the BLINDAGE C1 module profile through their own correctness and conditional security interfaces. Cryptanalysis, parameter accounting and implementation requirements delimit what those interfaces establish. The volume concludes with construction-specific limitations and open research questions; it selects no deployment profile and provides no general concrete-security certificate.

**Keywords:** modular arithmetic; integer division; carries; Toeplitz and Hankel matrices; polynomial middle products; randomized lifting; LWE and LWR; conditional security; cryptanalysis; reproducibility.

\tableofcontents
\clearpage

# Notation and abbreviations {#notation}

Notation remains local to the chapter and construction. In particular, symbols reused by different source problems are not identified merely because they have the same letter.

| Symbol or abbreviation | Reading convention |
|---|---|
| \([z]_P\) | Canonical residue modulo the positive integer \(P\). |
| \(F_{P,Q}(z)\) | \(\lfloor [z]_P/Q\rfloor\), with domains and divisibility assumptions stated locally. |
| \(P,Q,p,q\) | Moduli, divisors or their bit-length parameters, as explicitly defined in each chapter. |
| \(H,T\) | Hankel or Toeplitz operators where locally defined; not global security assumptions. |
| TV | Total variation distance. |
| \(\mathcal R_2\) | Exponentiated order-two Rényi comparison under the chapter's convention. |
| CPA / CCA | Chosen-plaintext / chosen-ciphertext security experiments with specified interfaces. |
| ROM / QROM | Classical / quantum random-oracle model. A ROM result is not a QROM result. |
| LWE / LWR | Learning With Errors / Learning With Rounding, with exact laws specified for each use. |
| MP-CLWR | The task-specific computational middle-product rounding interface used for P-REF. |
| FO / HHK | Fujisaki–Okamoto transformation / the cited modular analysis. |
| P-REF / WC / NOISE / C1 | Distinct constructions or profiles; their proofs are not interchangeable. |
| SHA-256 | Byte-identity digest used for the edition and its reproducibility materials. |

\mainmatter



```{=latex}
\part*{\phantomsection\addcontentsline{toc}{part}{PART I — Foundations and Historical Context}PART I — Foundations and Historical Context}
```


# Chapter 1 — Introduction {#ch1}

## 1.1 The Central Research Question

Modern public-key cryptography relies on mathematical problems that are efficiently computable in one direction but computationally difficult to reverse without additional information. Lattice-based cryptography often uses noisy linear observations over finite algebraic structures. Learning With Errors (LWE) is a prominent example [Regev 2009]; Learning With Rounding (LWR) uses deterministic loss of precision [Banerjee–Peikert–Rosen 2012].

MODDIV begins with multiplication, modular reduction, and integer quotient extraction. For positive integers \(P,Q\), define
\[
\operatorname{MD}_{P,Q}(z)=\left\lfloor\frac{[z]_P}{Q}\right\rfloor,
\]
where \([z]_P\in\{0,\ldots,P-1\}\) is the canonical residue. With a scalar, matrix, or structured polynomial operator \(A\), a secret \(X\), and optional error \(E\), the public observation is
\[
U=\operatorname{MD}_{P,Q}(AX+E).
\]
Information loss alone does not establish computational security. The principal question is:

**Under which algebraic, distributional, and computational assumptions can modular quotient extraction support a correct and provably secure public-key cryptographic construction?**

Three dimensions must be studied separately: algebraic structure, probability distributions (including carries and overlapping windows), and computational complexity.

## 1.2 Quotient Extraction Is Not Ordinary Linear Algebra

If \(z=kP+r\) with \(0\le r<P\), reduction removes the multiple \(kP\), and division extracts a quotient from \(r\). The composition is not generally additive. For example, with \(P=4,Q=2,a=b=1\), we have
\[
\operatorname{MD}_{4,2}(a+b)=1,\qquad
\operatorname{MD}_{4,2}(a)+\operatorname{MD}_{4,2}(b)=0.
\]
Thus even interpreting the output modulo \(H=2\) does not restore additivity in general.
The discrepancy involves carries and modular wraparound. Exact remainder identities are therefore preferable to treating rounding residues as independent noise without justification.

For structured polynomial products, multiple output coefficients can depend on overlapping public coefficients, inducing joint correlations that are invisible in marginal distributions.

## 1.3 From Scalar Arithmetic to Structured Polynomial Products

A scalar observation has the schematic form
\[
U=\left\lfloor\frac{[AX]_P}{Q}\right\rfloor.
\]
A non-cyclic Hankel construction uses a public ribbon \(A=(A_0,\ldots,A_{n+d-2})\) and
\[
(H_{n,d}(A)X)_i=\sum_{j=0}^{d-1}A_{i+j}X_j,\quad 0\le i<n,
\]
followed by
\[
U=F_Q(H_{n,d}(A)X+E).
\]
In this example, take positive integers \(P=QH\) and define \(F_Q=\operatorname{MD}_{P,Q}\). Let \(A\in\mathbb Z^{n+d-1}\), \(X\in\mathbb Z^d\), and \(E\in\mathbb Z^n\); then \(U\in\{0,\ldots,H-1\}^n\). Quotient extraction acts componentwise. When \(d\ge2\) and at least two adjacent output windows are present, these windows reuse public coefficient positions. The corresponding observation problem is not automatically equivalent to standard LWE with an independently uniform matrix.

## 1.4 Correctness and Security Are Separate Obligations

Correctness requires legitimate decryption with an acceptable failure probability. Confidentiality requires that an efficient adversary cannot distinguish the relevant messages or observations with non-negligible advantage. A perfectly correct system may leak its secret; a difficult observation problem may not by itself yield a decryption mechanism.

Security claims must distinguish: (a) unconditional mathematical identities; (b) conditional reductions to explicit hardness assumptions; (c) experimental observations; and (d) unresolved conjectures.

## 1.5 The Role of Cryptanalysis

Cryptanalysis is integral to the investigation. Important questions include whether a structured public operator admits a lower-dimensional representation, whether overlapping windows leak secret information, whether quotient remainders can be exploited, whether primal/dual lattice attacks benefit from structure, and whether proposed reductions preserve the full public and ciphertext distributions. Negative results and precise obstructions are scientific contributions.

## 1.6 Scope and Methodology

Four principles govern this manuscript: exact specification of algorithms and distributions; proof before security claims; independent adversarial cryptanalysis; and reproducible experiments. Historical MODDIV formulations and subsequent constructions must be distinguished, not retrospectively identified. In particular, a new encryption layer cannot be attributed to a historical key-exchange observation.

## 1.7 Organization

Chapter 2 studies quotient extraction, fibers, carries, statistical distance, and entropy. Chapter 3 develops Toeplitz/Hankel operators, polynomial middle products, overlapping windows, and exact double-product identities. Later chapters will address historical constructions, conditional security reductions, attacks, and open problems.

**Status of Chapter 1:** Expository. No novel hardness theorem is claimed.

---




## Supplementary Material and Reproducibility — Chapter 1

The public supplementary material for this chapter is assigned to `supplementary/chapter-01/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 2 — Mathematical Foundations of Modular Reduction and Integer Division {#ch2}

## 2.1 Introduction

We study the composition of integer arithmetic, modular reduction, and quotient extraction. Throughout the arithmetic sections, \(P,Q,H\) are positive integers with \(P=QH\), except in Section 2.11. We write \(F_Q\) for \(F_{P,Q}\), with \(P\) fixed. Residue classes use canonical integer representatives. Quotient and remainder maps extend componentwise to vectors and coefficientwise to polynomials. Dimensions are positive integers, and indices start at zero.

## 2.2 Euclidean Division and Canonical Residues

**Definition 2.1 (Canonical residue).** For \(z\in\mathbb Z\), \([z]_P\) is the unique integer in \([0,P)\) congruent to \(z\bmod P\).

**Definition 2.2 (Quotient and remainder).**
\[
F_Q(z)=\left\lfloor\frac{[z]_P}{Q}\right\rfloor\in\{0,\ldots,H-1\},\qquad
R_{P,Q}(z)=[z]_P-QF_Q(z).
\]

**Proposition 2.1 (Exact decomposition).**
\[
[z]_P=QF_Q(z)+R_{P,Q}(z),\qquad 0\le R_{P,Q}(z)<Q,
\]
uniquely.

*Proof.* Euclidean division of \([z]_P\) by \(Q\) gives unique quotient and remainder. Since \([z]_P<QH\), the quotient lies in \([0,H)\). \(\square\)

**Corollary 2.1.** The pair \((F_Q(z),R_{P,Q}(z))\) reconstructs \([z]_P\) uniquely. If \(Q>1\), \(F_Q\) is noninjective on \(\mathbb Z_P\), with \(Q\) residues per fiber. If \(Q=1\), it is the identity on canonical residues. Noninjectivity does not imply positive entropy loss for every input distribution.

## 2.3 Fibers and Information Loss

**Definition 2.3.** The fiber at \(u\in\mathbb Z_H\) is \(\mathcal F_u=\{z\in\mathbb Z_P:F_Q(z)=u\}\).

**Theorem 2.1 (Uniform fibers).** If \(Q\mid P\), every fiber has exactly \(Q\) elements.

*Proof.* Its canonical residues are \(Qu,Qu+1,\ldots,Qu+Q-1\). \(\square\)

**Corollary 2.2.** If \(Z\) is uniform modulo \(P\), then \(F_Q(Z)\) is uniform modulo \(H\), and \(F_Q(Z)\) and \(R_{P,Q}(Z)\) are independent uniforms on \(\mathbb Z_H\) and \(\mathbb Z_Q\), respectively.

*Proof.* The quotient–remainder map is a bijection \(\mathbb Z_P\to\mathbb Z_H\times\mathbb Z_Q\), preserving the uniform counting measure. \(\square\)

**Proposition 2.2 (Exact randomized lifting).** If \(U\leftarrow\operatorname{Unif}(\mathbb Z_H)\) and \(\rho\leftarrow\operatorname{Unif}(\mathbb Z_Q)\) independently, then \(B=QU+\rho\) is uniform modulo \(P\), with \(F_Q(B)=U\).

*Proof.* The map \((u,\rho)\mapsto Qu+\rho\) is a bijection onto the canonical residues modulo \(P\). Every output has probability \(1/(HQ)=1/P\). \(\square\)

**Caution.** Although \(B\) is marginally uniform, it is dependent on \(U\) when \(H>1\), because \(F_Q(B)=U\) and \(U\) is nonconstant. When \(H=1\), \(U\) is constant and hence independent of \(B\). In every case, simulations must preserve the full joint law.

## 2.4 Modular Addition and Carry Propagation

Let \([z]_P=Qu+r\) and \([w]_P=Qv+s\), with \(0\le r,s<Q\).

**Theorem 2.2 (Exact addition identity).**
\[
F_Q(z+w)=\left(u+v+\left\lfloor\frac{r+s}{Q}\right\rfloor\right)\bmod H.
\]

*Proof.* Write \(r+s=Qc+t\), \(0\le t<Q\). Then \(z+w\equiv Q(u+v+c)+t\pmod{QH}\). Its quotient is \(u+v+c\bmod H\). \(\square\)

**Definition 2.4 (Carry indicator).**
\[
C_Q(r,s)=\left\lfloor\frac{r+s}{Q}\right\rfloor\in\{0,1\}.
\]

**Proposition 2.3 (Uniform carry probability).** For independent uniform \(R,S\in\{0,\ldots,Q-1\}\),
\[
\Pr[C_Q(R,S)=1]=\frac{Q-1}{2Q}.
\]

*Proof.* For each \(r\), exactly \(r\) values of \(s\) satisfy \(r+s\ge Q\). Thus the favorable pairs number \(\sum_{r=0}^{Q-1}r=Q(Q-1)/2\), out of \(Q^2\). \(\square\)

The uniform-independence assumption is essential; structured-product remainders need not satisfy it.

## 2.5 General Carry Identity

**Theorem 2.3 (Multioperand quotient identity).** For \(t\ge1\), if \([z_i]_P=Qu_i+r_i\) with \(0\le r_i<Q\), then
\[
F_Q\left(\sum_{i=1}^t z_i\right)=
\left(\sum_{i=1}^t u_i+
\left\lfloor\frac{\sum_{i=1}^t r_i}{Q}\right\rfloor\right)\bmod H.
\]

*Proof.* Sum the congruences \(z_i\equiv Qu_i+r_i\pmod{QH}\) and divide the sum of remainders by \(Q\). \(\square\)

The carry lies between \(0\) and \(t-1\). It is a deterministic function of all the discarded remainders, not generally independent noise.

## 2.6 Multiplication and Quotient Extraction

**Theorem 2.4 (Exact multiplication identity).** With \([z]_P=Qu+r\), \([w]_P=Qv+s\),
\[
F_Q(zw)=\left(Quv+us+vr+\left\lfloor\frac{rs}{Q}\right\rfloor\right)\bmod H.
\]

*Proof.* Expand
\[
(Qu+r)(Qv+s)=Q^2uv+Qus+Qvr+rs.
\]
Euclidean division of \(rs\) by \(Q\) isolates a remainder below \(Q\). Reducing the quotient modulo \(H\) gives the formula. \(\square\)

The term \(\lfloor rs/Q\rfloor\) is a multiplication-induced carry. Knowledge of the quotient components \(u,v\) alone need not determine the product quotient.

## 2.7 Quotient Extraction as a Nonlinear Observation

For \(U=F_Q(AX+E)\), the sequence
\[
X\longmapsto AX+E\longmapsto[AX+E]_P\longmapsto F_Q(AX+E)
\]
contains a final operation that is generally not a group homomorphism. This can create nonlinear secret dependence, but nonlinearity does not imply one-wayness or computational hardness.

## 2.8 Statistical Distance and Data Processing

**Definition 2.5 (Total variation on a finite or countable space).**
\[
\operatorname{TV}(\mathcal D_0,\mathcal D_1)
=\frac12\sum_{\omega\in\Omega}
|\Pr[\mathcal D_0=\omega]-\Pr[\mathcal D_1=\omega]|.
\]

**Theorem 2.5 (Discrete data processing).** For any deterministic \(f:\Omega\to\Omega'\),
\[
\operatorname{TV}(f(\mathcal D_0),f(\mathcal D_1))
\le\operatorname{TV}(\mathcal D_0,\mathcal D_1).
\]

*Proof.* Group input probabilities by preimage fibers of \(f\) and apply the triangle inequality:
\[
\begin{aligned}
2\operatorname{TV}(f(\mathcal D_0),f(\mathcal D_1))
&=\sum_y\left|\sum_{x:f(x)=y}(p_0(x)-p_1(x))\right|\\
&\le\sum_y\sum_{x:f(x)=y}|p_0(x)-p_1(x)|\\
&=2\operatorname{TV}(\mathcal D_0,\mathcal D_1).
\end{aligned}
\]
\(\square\)

On a general measurable space, total variation is defined by
\[
\operatorname{TV}(\mathcal P_0,\mathcal P_1)=
\sup_{E\text{ measurable}}|\mathcal P_0(E)-\mathcal P_1(E)|.
\]
The data-processing inequality also holds for measurable maps, but the discrete point-mass sum above is not a formula for arbitrary continuous laws.

**Corollary 2.3.** Applying \(F_Q\) cannot increase total variation between two input distributions. This does **not** prove computational security, especially where public side information is present: the relevant object is the full joint transcript.

## 2.9 Conditional Min-Entropy and Secret Leakage

Let \(X,U\) be discrete random variables with finite supports. The average conditional min-entropy [Dodis et al. 2008] is
\[
\widetilde H_\infty(X\mid U)=
-\log_2\sum_{u:\Pr[U=u]>0}\Pr[U=u]
\max_x\Pr[X=x\mid U=u].
\]
Equivalently, the optimal information-theoretic guessing probability is
\[
P_{\rm guess}(X\mid U)=\sum_u\max_x\Pr[X=x,U=u]
=2^{-\widetilde H_\infty(X\mid U)}.
\]
When the adversary also observes a public ribbon \(A\), the relevant conditioning variable is the complete transcript, for example \((A,U)\), not merely \(U\).

Let \(q\) and \(d\) be positive integers, \(Q=2^q\), and let the coordinates of \(X\) be independent and uniform on the **integer set**
\(\{Q/2,Q/2+1,\ldots,Q-1\}\). Then
\[
H_\infty(X)=\log_2((Q/2)^d)=d(q-1).
\]
For \(q=1\), this entropy is zero. This is prior secret entropy, not a guarantee of computational security after public information is revealed.

## 2.10 Structured Linear Operators

For public ribbon \(A=(A_0,\ldots,A_{n+d-2})\),
\[
(H_{n,d}(A)X)_i=\sum_{j=0}^{d-1}A_{i+j}X_j,\quad
U_i=F_Q((H_{n,d}(A)X)_i+E_i).
\]
Distinct neighboring windows share public coefficient positions when \(d\ge2\); such shared inputs can generate dependencies but do not force dependence for every secret or distribution. Shared secret and shared public coefficients can generate joint dependencies. The exact Toeplitz/Hankel and polynomial relationships are studied in Chapter 3.

## 2.11 The Non-Divisible Case

If \(P=aQ+r\), \(0<r<Q\), the quotient takes values \(0,\ldots,a\). For uniform \(Z\bmod P\),
\[
\Pr[F_Q(Z)=u]=
\begin{cases}
Q/P,&0\le u<a,\\
r/P,&u=a.
\end{cases}
\]
If \(a\ge1\), the quotient distribution is nonuniform because the final fiber has \(r<Q\) elements. If \(a=0\) (equivalently \(P<Q\)), the quotient is identically zero and uniform on its singleton image. Equal-fiber lifting statements from the divisible case cannot be reused unchanged. Here \(a=\lfloor P/Q\rfloor\), and the quotient codomain is \(\{0,\ldots,a\}\), not \(\mathbb Z_H\).

## 2.12 What the Algebra Does Not Prove

The following implications are invalid without further assumptions:
\[
\text{information loss}\not\Rightarrow\text{computational hardness},
\]
\[
\text{nonlinearity}\not\Rightarrow\text{one-wayness},
\]
\[
\text{large secret space}\not\Rightarrow\text{128-bit security},
\]
\[
\text{structured noisy observations}\not\Rightarrow\text{standard LWE hardness}.
\]
A reduction to a newly specified structured problem is conditional on that problem's difficulty.

## 2.13 Summary and Conclusion

We proved exact quotient–remainder decomposition, uniform fiber sizes, randomized lifting, addition/multiplication carry identities, and data processing. The central lesson is that discarded remainders are deterministic functions of structured inputs and can preserve correlations. The next chapter develops these correlations algebraically.

**Status of Chapter 2:** The results are elementary or classical consequences of Euclidean division and elementary probability. No novelty or cryptographic hardness is claimed.

---




## Supplementary Material and Reproducibility — Chapter 2

The public supplementary material for this chapter is assigned to `supplementary/chapter-02/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 3 — Toeplitz and Hankel Operators, Polynomial Middle Products, and Structural Correlations {#ch3}

## 3.1 Introduction

Toeplitz and Hankel operators represent structured linear maps arising from convolution and polynomial multiplication. Toeplitz and Hankel matrices admit a representation by \(n+d-1\) coefficients. This is strictly smaller than an explicit \(nd\)-entry array when \(n,d\ge2\), and has the same size when \(n=1\) or \(d=1\). Their structure can matter for cryptanalysis. This chapter establishes exact algebraic relationships and investigates overlapping windows.

## 3.2 Toeplitz Matrices

In this chapter \(n,d,\ell\ge1\), indices begin at zero, and algebraic identities are over a commutative unital ring unless a field is explicitly required.

**Definition 3.1.** For a commutative ring \(R\), the \(n\times d\) Toeplitz matrix associated with coefficients \(t_{-(d-1)},\ldots,t_{n-1}\) is
\[
T_{n,d}(t)_{i,j}=t_{i-j},\qquad 0\le i<n,\ 0\le j<d.
\]

**Proposition 3.1 (Storage).** Such a matrix is specified by \(n+d-1\) ring elements rather than \(nd\).

*Proof.* The difference \(i-j\) ranges over precisely the \(n+d-1\) integers from \(-(d-1)\) to \(n-1\). \(\square\)

## 3.3 Hankel Matrices

**Definition 3.2.** For a ribbon \(a=(a_0,\ldots,a_{n+d-2})\), define
\[
H_{n,d}(a)_{i,j}=a_{i+j}.
\]
Then
\[
(H_{n,d}(a)x)_i=\sum_{j=0}^{d-1}a_{i+j}x_j.
\]

**Proposition 3.2.** A Hankel matrix is completely specified by \(n+d-1\) coefficients. Compared with an explicit \(nd\)-entry array, the saving is
\[
nd-(n+d-1)=(n-1)(d-1).
\]
It is strictly positive if and only if \(n,d\ge2\). For \(n=1\) or \(d=1\), there is no strict saving or forced repeated position. This concerns matrix representation, not necessarily the size of a full cryptographic public key.

## 3.4 Hankel–Toeplitz Equivalence

Let \(J_d\) reverse coordinate order: \((J_dx)_j=x_{d-1-j}\).

**Theorem 3.1.** For every \(H_{n,d}(a)\), \(T=H_{n,d}(a)J_d\) is Toeplitz, and
\[
H_{n,d}(a)=TJ_d.
\]

*Proof.* \(T_{i,j}=H_{i,d-1-j}=a_{i+d-1-j}\), which depends only on \(i-j\). Since \(J_d^2=I\), the claimed factorization follows. \(\square\)

**Corollary 3.1.** Over any field, \(\operatorname{rank}(H_{n,d}(a))=\operatorname{rank}(T)\), because \(J_d\) is invertible.

Algebraic equivalence of matrices does not automatically imply security equivalence of full schemes: distributions, errors, rounding, and public side information must also match.

## 3.5 Polynomial Multiplication and Middle Products

Let
\[
A(X)=\sum_{k=0}^{n+d-2}a_kX^k,\qquad
B^\star(X)=\sum_{j=0}^{d-1}b_jX^{d-1-j}.
\]

**Theorem 3.2 (Middle-product identity).**
\[
(H_{n,d}(a)b)_i=[X^{i+d-1}](A(X)B^\star(X)),\quad 0\le i<n.
\]

*Proof.* In the coefficient of \(X^{i+d-1}\), the monomial \(b_jX^{d-1-j}\) pairs with \(a_{i+j}X^{i+j}\). Summing gives \(\sum_{j=0}^{d-1}a_{i+j}b_j\). \(\square\)

This is an ordinary polynomial product with no cyclic wraparound.

## 3.6 Non-Cyclic, Cyclic, and Negacyclic Products

Ordinary polynomial multiplication has no coefficient wraparound. In \(R[X]/(X^m-1)\), high-degree coefficients wrap with positive sign; in \(R[X]/(X^m+1)\), they wrap with negative sign.

**Proposition 3.3.** With one multiplier polynomial fixed, ordinary, cyclic, and negacyclic multiplication generally define different linear maps into their respective output spaces; with both factors variable, the multiplication maps are bilinear. In characteristic two, cyclic and negacyclic quotient relations coincide. A theorem about one structure does not automatically apply to another.

*Justification.* Boundary coefficient identities differ because cyclic and negacyclic quotients introduce wraparound absent from the ordinary product. \(\square\)

## 3.7 Overlapping Windows

The \(i\)-th Hankel window uses \(A_i,\ldots,A_{i+d-1}\).

**Proposition 3.4.** For valid rows \(0\le i\le i+t<n\), windows starting at \(i\) and \(i+t\) share exactly
\[
\max(d-t,0)
\]
public coefficient positions.

*Proof.* For \(t<d\), the intersection is \(i+t,\ldots,i+d-1\), containing \(d-t\) positions; for \(t\ge d\), it is empty. \(\square\)

Overlap of the *sets of inputs* does not, by itself, prove statistical dependence of outputs for every secret.

## 3.8 Covariance of Hankel Outputs for a Fixed Secret

Assume \(A_k\) are iid real random variables with finite second moment, mean \(\mu_A\), and variance \(\sigma_A^2\). Fix \(x\in\mathbb R^d\), and define \(Z_i=\sum_{j=0}^{d-1}A_{i+j}x_j\).

**Theorem 3.3 (Covariance over the random public ribbon).** For valid row indices \(0\le i\le i+t<n\),
\[
\operatorname{Cov}_A(Z_i,Z_{i+t})=
\begin{cases}
\sigma_A^2\sum_{j=t}^{d-1}x_jx_{j-t},&0\le t<d,\\
0,&t\ge d.
\end{cases}
\]

*Proof.* Expand covariance:
\[
\sum_{j,k}x_jx_k\operatorname{Cov}(A_{i+j},A_{i+t+k}).
\]
Independence makes every term vanish except when \(j=t+k\); each surviving term has covariance \(\sigma_A^2\). \(\square\)

**Corollary 3.2.** If all \(x_j>0\) and \(\sigma_A^2>0\), the covariance over \(A\) is strictly positive for \(0\le t<d\) and valid rows.

**Scope.** These statements concern unreduced products and randomness in \(A\), with \(x\) fixed. They do not automatically survive modular reduction or quotient extraction. If the public ribbon and secret are both revealed, the products are deterministic.

## 3.9 Random Secrets and Unconditional Covariance

Now let \(X\in\mathbb R^d\) be random, independent of the public ribbon, with \(\mathbb E\|X\|_2^2<\infty\). Redefine \(Z_i=\sum_jA_{i+j}X_j\). Under the finite-second-moment assumption on \(A\), the law of total covariance gives
\[
\operatorname{Cov}(Z_i,Z_{i+t})
=\mathbb E[\operatorname{Cov}(Z_i,Z_{i+t}\mid X)]
+\operatorname{Cov}(\mathbb E[Z_i\mid X],\mathbb E[Z_{i+t}\mid X]).
\]
Because \(\mathbb E[Z_i\mid X]=\mu_A\sum_jX_j\), for valid rows and \(0\le t<d\),
\[
\operatorname{Cov}(Z_i,Z_{i+t})
=\sigma_A^2\sum_{j=t}^{d-1}\mathbb E[X_jX_{j-t}]
+\mu_A^2\operatorname{Var}\left(\sum_jX_j\right).
\]
For \(t\ge d\), the first sum is empty. Finite secret support suffices for the moment assumption. Disjoint windows are independent conditional on \(X\), but need not be independent after averaging over \(X\); zero covariance alone does not imply independence.

## 3.10 Joint Distributions Versus Marginals

For two discrete observations sharing a discrete secret \(X\),
\[
\Pr[U=u,V=v]=\sum_x\Pr[X=x]\Pr[U=u,V=v\mid X=x].
\]
Conditional independence, where valid, yields a mixture of products, not generally a product of marginals.

**Proposition 3.5.** Equal marginals do not imply equal joint laws.

*Proof.* Let \(B\) be a uniform bit. The pairs \((B,B)\) and \((B,1-B)\) have identical uniform coordinate marginals. The equality event has probabilities \(1\) and \(0\), respectively; the joint total variation distance is \(1\). \(\square\)

## 3.11 Double Hankel Product Identity

Let \(d,\ell\ge1\), \(n=d+\ell-1\), and \(A\) have length \(n+d-1=2d+\ell-2\). Let \(X,Y\) have length \(d\).

**Theorem 3.4 (Double-product commutativity).**
\[
H_{\ell,d}(H_{n,d}(A)X)Y
=
H_{\ell,d}(H_{n,d}(A)Y)X.
\]

*Proof.* The \(i\)-th coordinate on the left is
\[
\sum_{k=0}^{d-1}\sum_{j=0}^{d-1}A_{i+k+j}X_jY_k.
\]
In a commutative coefficient ring, interchange the finite sums and the factors \(X_j,Y_k\). The resulting expression is the \(i\)-th coordinate on the right. \(\square\)

This identity explains algebraic cancellation of principal terms but does not by itself establish correct rounded decryption.

## 3.12 Rounding Errors in Double Products

Retain \(d,\ell\ge1\), \(n=d+\ell-1\), and positive integers \(P=QH\). Use integer representatives \(A\in\mathbb Z^{n+d-1}\), \(X,Y\in\mathbb Z^d\), and \(E_0,E_1\in\mathbb Z^n\). Congruences and rounding are componentwise. Define \(z_0=H_{n,d}(A)X+E_0\), \(z_1=H_{n,d}(A)Y+E_1\), and exact remainders \(r_b=R_{P,Q}(z_b)\) with \(0\le(r_b)_i<Q\).

Set
\[
U=F_Q(H_{n,d}(A)X+E_0),\qquad
V=F_Q(H_{n,d}(A)Y+E_1).
\]
The exact remainder vectors satisfy
\[
QU\equiv H_{n,d}(A)X+E_0-r_0\pmod P,
\]
\[
QV\equiv H_{n,d}(A)Y+E_1-r_1\pmod P.
\]
Theorem 3.4 implies
\[
H_{\ell,d}(QU)Y-H_{\ell,d}(QV)X
\equiv H_{\ell,d}(E_0-r_0)Y-H_{\ell,d}(E_1-r_1)X\pmod P.
\]
This is exact; the remainders are actual deterministic residues, not independent surrogate errors. A complete encryption construction may introduce additional lifting and error terms, requiring its own correctness proof.

## 3.13 Rank of Structured Public Operators

**Proposition 3.6.** Over any field \(K\),
\[
\operatorname{rank}_K(H_{n,d}(a))\le\min(n,d).
\]

**Proposition 3.7 (Full-rank existence).** For any field \(K\), there exists an \(n\times d\) Hankel matrix of rank \(\min(n,d)\).

*Proof.* Let \(r=\min(n,d)\). Set \(a_{r-1}=1\) and all other ribbon coefficients to zero. The leading \(r\times r\) block is the reversal matrix, with determinant \(\pm1\). Hence the rank is at least \(r\), and the dimension bound gives equality. \(\square\)

Existence of full-rank examples does not establish a high-probability full-rank claim for a specified random distribution.

## 3.14 Structure and Cryptographic Hardness

Toeplitz/Hankel operators admit representation by \(n+d-1\) coefficients, a strict saving over an explicit \(nd\)-entry array when \(n,d\ge2\), and admit polynomial-convolution algorithms. They may also expose algebraic recurrences, short relations, or exploitable noise/secret correlations. These possibilities are neither proofs of insecurity nor security reductions. An analysis must specify the coefficient ring, public distribution, secret law, errors, and complete transcript.

## 3.15 Relationship to LWE and LWR

Standard LWE has observations \(b=As+e\bmod q\), with a suitably uniform matrix \(A\) [Regev 2009]. LWR uses rounded modular linear observations [Banerjee–Peikert–Rosen 2012]. MODDIV variants may differ in public Hankel/Toeplitz structure, restricted positive secrets, quotient convention, explicit errors, and overlapping windows. Formal resemblance does not establish hardness equivalence. Bai et al. study the computational MP-CLWR assumption and an associated public-key encryption construction. Their result must not be identified with the generic decisional Hankel observation problem of Section 3.16 without explicit comparison of distributions, dimensions, rounding conventions, and security games.

## 3.16 Open Problem: Rounded Hankel Hardness

For specified distributions of public ribbon \(A\), secret \(X\), and error \(E\), determine whether
\[
(A,F_Q(H_{n,d}(A)X+E))
\]
is computationally indistinguishable from
\[
(A,R)
\]
with independent uniform quotient vector \(R\). This is a **research template**, not a hardness assertion for arbitrary distributions. A formal decisional problem must specify efficiently samplable ensembles \((A_\lambda,X_\lambda,E_\lambda)\), dimensions \(n_\lambda,d_\lambda\), moduli \(P_\lambda=Q_\lambda H_\lambda\), all dependencies and public auxiliary information, and the adversary model (classical or quantum). It must define \(R_\lambda\) as independent uniform on \(\{0,\ldots,H_\lambda-1\}^{n_\lambda}\) and specify the number of samples and secret reuse. Possible outcomes include an exact reduction from an established hard problem, a structured conditional reduction, an efficient distinguisher, or a precise obstruction. The joint public-observation law is the object of study.

## 3.17 Summary

For fixed \(x\), iid public coefficients with finite second moment, and valid row indices, the following identities hold (the covariance is over \(A\), and equals zero when \(t\ge d\)):

\[
H_{n,d}(a)=TJ_d,
\]
\[
(H_{n,d}(a)b)_i=[X^{i+d-1}](A(X)B^\star(X)),
\]
\[
|\text{window overlap at displacement }t|=\max(d-t,0),
\]
\[
\operatorname{Cov}_A(Z_i,Z_{i+t})
=\sigma_A^2\sum_{j=t}^{d-1}x_jx_{j-t}\quad(0\le t<d),
\]
\[
H_{\ell,d}(H_{n,d}(A)X)Y
=H_{\ell,d}(H_{n,d}(A)Y)X.
\]

## 3.18 Conclusion

Toeplitz and Hankel operators offer exact compact representations of polynomial convolution, while shared coefficients and shared secrets complicate distributional analysis. The double-product identity provides a cancellation mechanism; cryptographic security requires additional probabilistic and computational arguments.

**Status of Chapter 3:** Algebraic identities and elementary covariance/rank statements are proved under the corrected explicit assumptions. No general Hankel-LWE hardness theorem is claimed.

---



## Supplementary Material and Reproducibility — Chapter 3

The public supplementary material for this chapter is assigned to `supplementary/chapter-03/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 4 — Historical Development of MODDIV {#ch4}
## Historical Development of MODDIV: Origins, Publications, Cryptanalysis, and Research Branches


### Abstract

This chapter reconstructs the documented evolution of MODDIV from publicly identifiable records and clearly labelled recollections. It separates the mathematical primitive from concrete protocols and examines the significance of the early cryptanalysis. The account does not infer cryptographic security, originality, or priority from the mere existence of publications. A notable historiographical issue is that publicly indexed MODDIV-related records predate the year 2022, which has also been used within the research program as a reference date for a particular historical disclosure. The 2014 archive record, 2015 arXiv version, 2016 cryptanalysis, 2017 study, and materially revised 2021 arXiv version are distinguished. The exact 2022 artifact remains unauthenticated, so no first-disclosure or priority conclusion is drawn.

## 4.1 Purpose, Scope, and Evidence Standards

A historical chapter in a cryptographic thesis must answer three distinct questions: what was conceived and implemented, what was made publicly available, and what has been mathematically or experimentally established. These questions have different evidentiary standards. A recollection may support a personal chronology, while a dated archival record supports a claim of public availability; neither establishes that a proposed security assumption is difficult.

For this chapter, evidence is assigned to one of four categories:

1. **Primary publication:** an identifiable public paper or archival record with date, title, and author.
2. **Independent cryptanalysis:** an identifiable attack or critique, with its actual target and assumptions.
3. **Documentary claim awaiting independent verification:** a manuscript, experiment, or reported development not yet independently verified against a public source.
4. **Open historical question:** a date, equivalence, priority claim, or construction relationship awaiting documentary verification.

The word *MODDIV* is used here for a family of related investigations. It must not be assumed that every version shares the same public-key distribution, decryption rule, or security assumption.

## 4.2 The Mathematical Core

The common arithmetic operation is

\[
F_{P,Q}(z)=\left\lfloor\frac{[z]_P}{Q}\right\rfloor,
\qquad P,Q\in\mathbb Z_{>0}.
\]

Here \(z,a,x\in\mathbb Z\) and \(H\in\mathbb Z_{>0}\) whenever \(P=QH\). The value \([z]_P\) is the canonical residue in \(\{0,\ldots,P-1\}\). When \(P=QH\), the output lies in \(\{0,\ldots,H-1\}\). For a public multiplier \(a\), a scalar observation may take the form

\[
U=F_{P,Q}(ax).
\]

The definition of this function is not itself a key-exchange protocol, an encryption algorithm, or a signature scheme. Each cryptographic construction requires a separate specification of parameter generation, key generation, transcript distributions, correctness, and adversarial security.

The earlier mathematical chapters establish exact identities for quotients, remainders, and carries. Those identities provide a language for reconstructing the historical proposals, but they do not retroactively prove the security of any earlier protocol.

## 4.3 Reported Early Exploration and Floating-Point Implementations

According to the researcher's account, an early experimental stage around 2013 used modular and division operations implemented with floating-point `double` values. This is a **reported development history**, not an independently verified publication date. It is important because floating-point modular arithmetic need not coincide bit-for-bit with exact integer arithmetic, especially beyond the representable integer precision of the mantissa.

Accordingly, one must not identify the behavior of a 2013 floating-point prototype with a later exact-integer protocol without comparing its input domains, rounding conventions, overflow behavior, and outputs. The original source code, dated files, or contemporaneous notes would be needed for a definitive reconstruction.

## 4.4 Public Records in 2014, 2015, and the 2021 arXiv Revision

The official IACR ePrint record 2014/946, *On a new fast public key cryptosystem*, names **Samir Bouftass and Abdelhak Azhari** and records receipt on **19 November 2014** and its latest recorded revision on **29 October 2015** ([B10](#bib-b10)). These dates are archive metadata, not independent certificates of invention priority. The earliest full ePrint file was not available for direct comparison; its exact relation to later manuscripts therefore remains unverified.

The arXiv record 1508.07756 has a **v1 submitted 31 August 2015** and a **v2 last revised 24 April 2021** ([B11](#bib-b11); [B12](#bib-b12)). The two versions must be treated as distinct documentary sources. Internal title-page dates do not substitute for version timestamps. The v1 scalar observations use modular multiplication followed by integer quotient extraction. Its reported experiments are not a universal agreement theorem.

The 2021 arXiv v2 materially revises the scalar formulation. Its Section 3.1.4 and Theorem 2 state different extraction maps: respectively \(\operatorname{mdv2}(p,p-q)\) and \(\operatorname{mdv2}(p-q,q)\). These need not coincide. For example, Section 4.13.1 evaluates the arithmetic instance \(p=33,q=16,A=2^{32}+1,X=2^{15},Y=2^{15}+1\), for which the two rules give different shared-output pairs. The discrepancy must be recorded rather than silently choosing one formula as the historical specification. Section 4.13.1 supplies the definitions and calculations.

These records establish MODDIV-related public work before 2022. Whether a *particular distinct revision* was first disclosed in 2022 remains a separate documentary question.

## 4.5 The 2016 Cryptanalytic Turning Point

Yang Zhang's *A practical attack to Bouftass's cryptosystem* (arXiv:1605.00987v1, submitted **3 May 2016**) presents a practical lattice-based attack on the early scalar key exchange ([B13](#bib-b13)). The PDF's internal title-page date must not be confused with its archive submission date. The target inverse problem is a modular linear relation, with \(P=2^p,Q=2^q\):

\[
zx\equiv Qu+y\pmod P,\qquad 0\le y<Q.
\]

Its solutions form the intersection of the admissible secret-and-remainder rectangle with the two-dimensional affine lattice

\[
(0,-Qu)+\mathbb Z(1,z)+\mathbb Z(0,P).
\]

The lattice formulation is exact. The paper uses two-dimensional lattice reduction and closest-vector reasoning; the correctness of every particular recovery step must nevertheless be checked separately.

The calculations in Sections 4.13.2–4.13.3 establish two qualifications. First, the worked numerical example contains a normalization error: a displayed quantity 708192 equals 32 times the appropriate quotient, not the quotient itself. After correction, the displayed recovery of the example secret remains valid. Second, a general minimum-norm assertion fails on an explicit affine-lattice counterexample, even when nearest-integer rounding replaces flooring. This refutes the printed unrestricted minimum claim, not every possible bounded-domain secret-recovery procedure. Section 4.13.3 gives the witness, reduction steps, parameter checks and scope limitation.

Thus Zhang's paper is a historically important *presented attack*, but its literal mathematical assertions require qualification. Errors in an attack paper do **not** establish security of the attacked scheme. Nor does an attack on an early scalar construction automatically transfer to a later multidimensional one; each requires its own analysis.

### 4.5.1 A Further Published Study in 2017

The publisher's record identifies a further study by **Barcau and coauthors**, published in 2017, relevant to the cryptanalysis and development of the Bouftass cryptosystem ([B16](#bib-b16)). Bibliographic metadata are established by the publisher's record; independent verification of the article's technical claims remains pending access to the complete text. Accordingly, this chapter records the study without endorsing an unverified theorem or attack-success claim. Verified bibliographic metadata do not mean that the technical proofs of this study have been independently verified here.

## 4.6 Multidimensional Developments

The public archival record for the multidimensional construction is Samir Bouftass, *Multidimentional ModDiv public key exchange protocol*, IACR Cryptology ePrint Archive 2021/701 ([B14](#bib-b14)). It replaces the scalar multiplication by selected coefficients of ordinary polynomial products and applies modular reduction followed by coefficientwise integer division. The public observation is therefore a structured Toeplitz/Hankel rounding map rather than an independently sampled LWR matrix.

The corrected mathematical treatment in this thesis uses explicit coefficient indices, a symmetric cross-product identity and the true deterministic rounding remainders. For power-of-two moduli, a small circular discrepancy between the parties' intermediate residues does not by itself determine the probability that a later low-bit deletion agrees: the position relative to the quotient-cell boundary must also be controlled.

The transition from scalar multiplication to vectors or polynomial operators is mathematically significant because the observations contain correlated coefficients, structured linear relations and nontrivial carry propagation. These changes affect both legitimate correctness and the adversary's available information. They do not establish a hardness reduction on their own, and the historical description of the public observation as LWR context is not treated as a proof of security.

## 4.7 The 2022 Reference Version: A Documentation Problem

For clarity, this thesis uses *historical MODDIV-2022* solely as a provisional editorial label for a designated baseline whose exact relationship to the public record remains unresolved. The label is not a claim that MODDIV-related work first became public in 2022. The primary manuscript, exact publication record, version identifier, and relation to the 2014, 2015, and 2021 documents have not yet been authenticated in this chapter.

A rigorous historical comparison must establish: (i) the exact mathematical function; (ii) public and secret distributions; (iii) the message or shared-key agreement procedure; (iv) parameter ranges; (v) treatment of disagreements or errors; and (vi) a dated, independently inspectable source. Until that comparison is complete, this chapter uses “MODDIV-2022” as a **research-program label**, not as a certified first-disclosure claim. Closing this provenance question requires a dated artifact, its cryptographic hash, full algorithms, parameter and secret distributions, and a line-by-line comparison with earlier versions.

## 4.8 Connections to LWE, LWR, and Middle Products

Later investigations compared MODDIV's integer quotient extraction with rounding operations in lattice-based cryptography. This comparison is motivated by the fact that both can reduce precision in modular observations, but a common rounding operator does not imply a common computational assumption.

Regev's Learning With Errors (LWE) framework studies noisy linear observations with carefully specified distributions. Learning With Rounding (LWR) replaces explicit error by deterministic rounding in certain constructions. Bai, Boudgoust, Das, Roux-Langlois, Wen, and Zhang studied *Middle-Product Learning with Rounding Problem and Its Applications* (ASIACRYPT 2019), including the computational MP-CLWR assumption and a public-key encryption application. Their assumptions and security results cannot be transferred to a generic Hankel-MODDIV observation without an explicit comparison of the full distributions, dimensions, rounding maps, and security games.

The historical value of this literature is methodological: it supplies examples of how to state assumptions, derive reductions, and identify the precise mathematical object to which a security theorem applies.

## 4.9 Recent Research Branches and Their Separation

Later chapters distinguish several mathematically different MODDIV directions. The following descriptions organize the thesis and do not constitute independent evidence of publication chronology, priority or cryptographic security.

**MODDIV-P** studies polynomial multiplication and quotient extraction, including middle-product interpretations. Its central obligation is to distinguish exact algebraic correspondences from security reductions.

**MODDIV-WC** explores structured rounding, masking, and public-key encryption mechanisms. Reported experiments, compact representations, and conditional proof routes must be checked against their own source code and formal games.

**MODDIV-NOISE** studies non-cyclic Hankel observations with explicitly specified noise, rounded values, and potential conditional security assumptions. It must not be represented as standard LWE unless a valid reduction is given.

**MODDIV-BLINDAGE** is a separate construction. Any correctness or CCA statement belongs to its own specification and cannot be imported into MODDIV-NOISE or a historical protocol.

These names refer to research branches, not to interchangeable versions of a single proven secure scheme. No claim of 128-bit security, IND-CPA, or IND-CCA follows from the present historical discussion.

## 4.10 Publication and Version-Control Principles

The research history should be maintained as a versioned archive. Each publication or implementation should have a stable identifier, separate submission and revision dates, author list, source file, SHA-256 checksum where available, and a clear statement of which construction it specifies. If a protocol changes, the change should be documented rather than attributed retrospectively to the earlier version.

Particular care is needed with negative results. A cryptanalysis should be linked to the exact construction attacked. A revised proposal should say which assumptions or algorithms were changed, and why those changes are expected to matter. Experiments are evidence about tested parameter families, not universal proofs of hardness.

## 4.11 Historical Claims That Remain Open

- Retrieve and compare every accessible revision of ePrint 2014/946 with arXiv 1508.07756v1 and v2, recording exact algorithms and archive timestamps.
- Identify the original code and date evidence for the reported 2013 floating-point prototype; no bitwise equivalence with exact integer arithmetic is presumed.
- Preserve the distinction between Zhang's valid affine-lattice formulation, the corrected numerical example, and the counterexample to its unrestricted minimum-norm claim.
- Retrieve the complete 2017 study before attributing any unverified technical theorem. For ePrint 2021/701, preserve the public archival record and document any revision-to-revision differences before attributing a correction to a particular version.
- Authenticate the designated MODDIV-2022 source by date, hash, full algorithms and distributions; only then compare its first disclosure with the pre-2022 public record.
- Identify dated, publicly citable specifications for each research branch before making chronology or priority claims. A branch label alone establishes neither security nor publication priority.

## 4.12 Conclusion

The documented MODDIV history begins no later than publicly indexed work in 2014, includes arXiv v1 in 2015, a significant but technically qualified 2016 cryptanalysis, a further 2017 published study, a materially revised arXiv v2 in 2021, and a multidimensional report indexed in 2021. The program subsequently expanded toward polynomial, structured, noisy, and security-reduction-oriented constructions. The main scientific lesson is methodological: exact arithmetic identities, concrete protocol correctness, distributional indistinguishability, computational hardness, and historical priority must be assessed separately.

This chapter is a **historical reconstruction with explicit documentary limitations**, not a priority certificate. The most urgent unresolved documentary issue is the precise relationship between the public pre-2022 papers and the construction referred to as MODDIV-2022.

---


## 4.13 Self-contained arithmetic checks of the historical sources

The following calculations qualify the literal historical formulas. They do not select an intended protocol, establish security, or invalidate every possible repair of an attack. They are included here so that the calculation can be verified directly from the three facts in Sections 4.4–4.5.

### 4.13.1 The two printed extraction maps

Use the definition

\[
\operatorname{mdv2}(p,q)(z)=\left\lfloor\frac{[z]_{2^p}}{2^q}\right\rfloor.
\]

Take

\[
p=33,\quad q=16,\quad A=4294967297,\quad X=32768,\quad Y=32769.
\]

The publications are

\[
U=\operatorname{mdv2}(33,16)(AX)=0,\qquad
V=\operatorname{mdv2}(33,16)(AY)=65536.
\]

Indeed, the two canonical product residues are 32768 and 4295000065. Thus \(XV=2147483648\) and \(YU=0\). The extraction printed in Section 3.1.4 of the 2021 arXiv revision gives

\[
\bigl(\operatorname{mdv2}(33,17)(XV),\operatorname{mdv2}(33,17)(YU)\bigr)=(16384,0),
\]

whereas the expression in its Theorem 2 gives

\[
\bigl(\operatorname{mdv2}(17,16)(XV),\operatorname{mdv2}(17,16)(YU)\bigr)=(0,0).
\]

The two printed expressions are not arithmetically interchangeable. This calculation does not decide which one represents the author's historical intention ([B12](#bib-b12)).

### 4.13.2 The numerical example in Zhang

For the public and secret values in the printed example ([B13](#bib-b13)), direct integer arithmetic gives

\[
12345\cdot6173\bmod 2^{22}=708213=32\cdot22131+21.
\]

The quotient is therefore 22131 and the discarded remainder is 21. The displayed number 708192 equals \(32\cdot22131\), not the quotient. The recovered secret 12345 still satisfies the corrected equation. This normalization correction does not remove that secret recovery and provides no evidence of security.

### 4.13.3 An affine minimum counterexample

Consider

\[
P=64,\quad Q=2,\quad z=10,\quad u=25,\quad x=5.
\]

The secret produces the stated quotient. The affine congruence is \(10x\equiv50+y\pmod{64}\). The algorithm in the source starts from \(v=(5,0)\) and the lattice basis \((5,-14),(6,-4)\). Its reduction yields

\[
b_1=(-7,-6),\qquad b_2=(6,-4),\qquad
v=-\frac5{16}b_1+\frac{15}{32}b_2.
\]

The determinant is 64. The scalar product is \(-18\), and the squared basis norms are 85 and 52; both further reduction coefficients round to zero. Rounding the displayed coordinates of \(v\) to nearest integers gives \((0,0)\), with no half-integer tie, and therefore returns \(v\). Yet

\[
\|v\|^2=25,\qquad v-b_2=(-1,4),\qquad \|v-b_2\|^2=17.
\]

Both vectors satisfy the same affine congruence. Using the floors printed in the algorithm instead gives \((-2,-6)\), whose squared norm is 40. Neither output is a minimum of the unrestricted affine class.

The small instance has \(l=4,m=3,p=6,q=1\), so \(l+m=p+q\) and \(p>m+q\). To meet also the source's conditions involving \(r\), multiply \(P,z,u\) and every second vector coordinate by \(2^{128}\), keeping \(Q=2\) and the secret \(x=5\). The new bit lengths and parameter may be taken as

\[
p=134,\quad q=1,\quad l=132,\quad m=3,\quad r=129.
\]

They satisfy \(l+m=p+q\), \(p>m+q+r\), and \(r>128\). Under the positive-definite scalar product

\[
\langle(x,y),(x',y')\rangle=xx'+2^{-256}yy',
\]

the scaling is an isometry: the reduction, final rounding coefficients and squared norms 25, 17 and 40 are unchanged. The source's unrestricted assertion permits an arbitrary scalar product ([B13](#bib-b13)).

**Scope.** This witness refutes the affine minimum rule without a rectangle constraint; it does not refute every distinct procedure searching for a preimage in the secret/remainder rectangle. In particular, the shorter witness vector lies outside that rectangle. An error in this minimum rule does not establish security of the attacked construction.



```{=latex}
\part*{\phantomsection\addcontentsline{toc}{part}{PART II — Exact Arithmetic and Distributional Theory}PART II — Exact Arithmetic and Distributional Theory}
```



## Supplementary Material and Reproducibility — Chapter 4

The public supplementary material for this chapter is assigned to `supplementary/chapter-04/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 5 — The Scalar MODDIV Construction {#ch5}
## Correctness, Exact Inversion, and Security Boundaries


**Scope.** The SCALAR-INTERVAL analysis does not establish security of that model or of polynomial, noisy, WC, NOISE or BLINDAGE constructions. No external peer review, proof-assistant certification or historical-priority finding is claimed.

### Abstract

This chapter studies an explicitly defined exact-integer scalar model underlying several MODDIV formulations. A public multiplier and a secret integer produce a modular quotient; two participants then apply a second quotient map to cross-products of their private values and the exchanged publications. We derive the exact discrepancy between the intermediate residues and show why small circular distance does not imply equality after a fixed final division. We then examine inversion on a publicly known integer interval. The inverse relation is an affine-lattice intersection, but it also admits a direct arithmetic solution: a Euclidean floor-sum recurrence counts compatible secrets in polynomial time in the binary input length, and prefix counts select any ranked preimage without enumeration. For uniform interval secrets this yields an exact posterior sampler. A replacement argument shows that, in the stated two-message scalar exchange model, an eavesdropper can predict Bob's key with exactly the honest agreement probability, even when the original secret is not uniquely determined. This conclusion is separate from the numerical and proof qualifications identified in earlier cryptanalysis. The chapter gives proofs, boundary cases, exact finite checks and reproducible code. Its conclusions do not transfer automatically to multidimensional, polynomial, noisy, or differently specified MODDIV constructions, and no claim of historical priority is made for these elementary algorithmic methods.

### Scope and attribution

Chapter 4 separated archival versions and documented unresolved provenance questions. This chapter is a mathematical analysis, not a retrospective repair of those sources. The normalized model below is named **SCALAR-INTERVAL** solely to identify the object being proved and tested. In particular, it is not a newly authenticated specification of “MODDIV-2022.” Equations with different final moduli or divisors remain different algorithms.

Classical ingredients include Euclidean division, affine congruence lattices, floor-sum reciprocity, Bayes' rule and counting-based selection. Their application is proved here; their invention is not claimed. The relevant earlier proposal, cryptanalysis, fixed-dimensional algorithms and floor-sum documentation are identified in the references ([B11](#bib-b11); [B12](#bib-b12); [B13](#bib-b13); [B16](#bib-b16); [B17](#bib-b17); [B18](#bib-b18)). The historical calculations relevant to this chapter are supplied directly in Section 4.13.

## 5.1. From historical descriptions to an analyzable model

An observation function does not completely specify a cryptographic protocol. One must additionally fix the secret domain and sampling law, the exchanged values, the final extraction rule, and the information available to an adversary. Agreement experiments are meaningful only after those choices have been made.

The arXiv record distinguishes a 2015 submission and a 2021 revision of the scalar proposal ([B11](#bib-b11); [B12](#bib-b12)). Section 4.13.1 exhibits inconsistent extraction formulas inside the latter revision. We therefore do not combine their parameter conventions or silently choose an intended correction. Zhang's description of the earlier scalar exchange supplies another explicitly identifiable target ([B13](#bib-b13); Section 2). The 2017 paper *On a Key Exchange Protocol* is relevant published context, but only its publisher metadata and abstract were available for this chapter; its technical theorems are not independently endorsed here ([B16](#bib-b16)).

The analysis proceeds in two layers. First, deterministic statements about exact integers apply to every input in their domains. Second, a security conclusion is made only for the explicitly stated probability model. A floating-point prototype, a nonuniform generator, a structured multidimensional secret, or an exchange with extra secret-dependent messages requires a separate analysis.

## 5.2. The SCALAR-INTERVAL specification

Throughout Sections 5.2–5.6, let
\[
P,Q,H,D,J\in\mathbb Z_{>0},\qquad P=QH,\qquad H=DJ.
\tag{5.1}
\]
The divisors are public and fixed before the secret values are sampled. For any integer \(z\), let \([z]_P\) be its canonical residue, and put
\[
F_{P,Q}(z)=\left\lfloor\frac{[z]_P}{Q}\right\rfloor.
\tag{5.2}
\]
The public multiplier \(a\) is an integer; it may be reduced modulo \(P\) without changing the observations.

Let the two private domains be nonempty, publicly specified integer intervals
\[
I_X=\{L_X,\ldots,R_X-1\},\qquad
I_Y=\{L_Y,\ldots,R_Y-1\}.
\tag{5.3}
\]
For the exchange model, these endpoints are nonnegative integers. Some counting results below allow signed intervals. A choice of exactly \(s\)-bit positive integers means \(I=\{2^{s-1},\ldots,2^s-1\}\), not \(\{0,\ldots,2^s-1\}\).

The participants publish
\[
U=F_{P,Q}(ax),\qquad V=F_{P,Q}(ay),
\tag{5.4}
\]
and compute intermediate residues and final candidate keys
\[
T_A=[xV]_H,\qquad T_B=[yU]_H,
\tag{5.5}
\]
\[
K_A=\left\lfloor T_A/D\right\rfloor,\qquad
K_B=\left\lfloor T_B/D\right\rfloor\in\{0,\ldots,J-1\}.
\tag{5.6}
\]
This is a two-message key-exchange testbed, not a public-key encryption scheme. There is no additional confirmation or reconciliation message in this specification.

Whenever probabilities are discussed, \(X\) and \(Y\) are independent uniform variables on their respective intervals, conditionally on all public parameters. The public multiplier may have any declared distribution independent of the private draws. All private randomness in this model is represented by \(X,Y\). For a single experiment the public parameters can simply be fixed.

The cases \(Q=1\), \(H=1\) and \(J=1\) are permitted mathematically. When \(J=1\), both candidate keys equal zero: perfect agreement is then devoid of key secrecy.

## 5.3. Exact cancellation and the true residual discrepancy

Set
\[
r_x=[ax]_Q,\qquad r_y=[ay]_Q.
\]
Because \(Q\mid P\), these are also the remainders of the canonical residues modulo \(P\) after division by \(Q\).

**Proposition 5.1 — Exact public decompositions.** There are integers \(k_x,k_y\) such that
\[
ax=Pk_x+QU+r_x,\qquad
ay=Pk_y+QV+r_y,
\qquad 0\le r_x,r_y<Q.
\tag{5.7}
\]

*Proof.* Apply Euclidean division first by \(P\) and then by \(Q\). Since \(P\) is a multiple of \(Q\), the last remainder is also the remainder modulo \(Q\) of the original integer. The proof includes negative multipliers. \(\square\)

**Theorem 5.2 — Cross-product discrepancy.** Define
\[
\delta=\frac{y r_x-x r_y}{Q}.
\tag{5.8}
\]
Then \(\delta\) is an integer and
\[
xV-yU=H(yk_x-xk_y)+\delta,
\qquad T_A-T_B\equiv\delta\pmod H.
\tag{5.9}
\]

*Proof.* Multiply the first identity in (5.7) by \(y\), the second by \(x\), and subtract. The terms \(axy\) cancel. Rearranging gives
\[
Q(xV-yU)=P(yk_x-xk_y)+yr_x-xr_y.
\]
The last difference is divisible by \(Q\), either from this equality or from \(r_x\equiv ax\) and \(r_y\equiv ay\pmod Q\). Dividing the integer equality by \(Q\) produces (5.9). The modulus after this division is \(H=P/Q\), not \(P\). \(\square\)

For canonical residues define
\[
d_H(u,v)=\min\bigl([u-v]_H,[v-u]_H\bigr).
\]
This also makes sense for \(H=1\), where the distance is zero.

**Corollary 5.3 — Circular proximity for nonnegative secrets.** If \(0\le x,y\le B\), where \(B\) is an integer, then
\[
d_H(T_A,T_B)\le |\delta|
\le\left\lfloor\frac{B(Q-1)}{Q}\right\rfloor.
\tag{5.10}
\]

*Proof.* The two nonnegative terms \(yr_x\) and \(xr_y\) are at most \(y(Q-1)\) and \(x(Q-1)\). Their difference in absolute value is at most \(\max(x,y)(Q-1)\), not necessarily the sum of these upper bounds. Divide by \(Q\), use integrality, and use (5.9) to bound circular distance by any integer representative of the difference. \(\square\)

An ordinary-distance bound \(|T_A-T_B|\le |\delta|\) does not follow, since the two canonical representatives can straddle the modular boundary. This is exactly why the modular identity should be retained until the last decoding step.

## 5.4. Final extraction: boundaries, agreement and a diagnostic dither

Write \(T_B=Dv+\rho\) with \(0\le\rho<D\). The remainder \(\rho\) is determined by the public values and the private secret. No independence or uniformity is presumed.

**Proposition 5.4 — Exact final-key relation.** With the definitions above,
\[
K_A-K_B\equiv
\left\lfloor\frac{\rho+\delta}{D}\right\rfloor\pmod J.
\tag{5.11}
\]
In particular,
\[
d_J(K_A,K_B)\le\left\lceil\frac{|\delta|}{D}\right\rceil.
\tag{5.12}
\]
If \(J\ge2\) and \(|\delta|<D\), disagreement can still occur, but the two keys are at circular distance at most one.

*Proof.* Substitute \(T_A\equiv T_B+\delta\pmod{DJ}\), apply Euclidean division of \(\rho+\delta\) by \(D\), and reduce the quotient modulo \(J\). For any integer \(\delta\) and \(0\le\rho<D\), the absolute value of the displayed floor is at most \(\lceil|\delta|/D\rceil\). Circular reduction can only reduce the minimum representative distance. \(\square\)

**A genuine exchange counterexample.** Take
\[
P=64,\ Q=4,\ H=16,\ D=4,\quad a=35,\ x=2,\ y=3.
\]
Then
\[
U=1,\quad V=10,\quad r_x=2,\quad r_y=1,\quad\delta=1,
\]
\[
T_A=4,\quad T_B=3,\quad K_A=1,\quad K_B=0.
\]
Thus even a discrepancy of one, smaller than the final divisor, can cross a division boundary. This example refutes a universal implication “small discrepancy implies equality,” not a separately established average-case agreement bound.

A public random displacement provides a useful control experiment, but changes the extraction procedure.

**Proposition 5.5 — Independent dither and an exact boundary probability.** Fix \(t\in\mathbb Z\), \(J\ge2\), \(H=DJ\), and an integer \(\delta\) with \(|\delta|<D\). If \(R\) is independently uniform on \(\{0,\ldots,D-1\}\), then
\[
\Pr\left[
 F_{H,D}(t+R)\ne F_{H,D}(t+\delta+R)
\right]=\frac{|\delta|}{D}.
\tag{5.13}
\]
For \(J=1\), the probability is zero instead.

*Proof.* The remainder \([t+R]_D\) is uniform on the \(D\) positions of a cell. For positive \(\delta<D\), exactly the last \(\delta\) positions cross to the next cell. For negative \(\delta\), exactly the first \(|\delta|\) positions cross to the previous cell. Distinct neighboring cells remain distinct modulo \(J\) when \(J\ge2\). A one-cell quotient is constant. \(\square\)

This proposition does not justify assigning a uniform boundary phase to the original undithered exchange. There the displacement and the position inside the cell can be correlated through \((a,X,Y)\). Nor does public dithering establish confidentiality. It is a deliberately separate diagnostic model, not a silent revision of any historical protocol.

## 5.5. Agreement probabilities and the need to specify all distributions

For finite public and secret domains, the undithered agreement probability is exactly
\[
\sum_a\Pr[A=a]
\sum_{x\in I_X}\sum_{y\in I_Y}
\frac{\mathbf 1\{K_A(a,x,y)=K_B(a,x,y)\}}
{|I_X|\,|I_Y|}.
\tag{5.14}
\]
Different supports, extraction divisors, and public distributions generally yield different values. A numeric constant observed for one model is not an identity for every version of MODDIV.

As an exact small example, let \(P=64,Q=4\), let \(a\) be uniform on \(\{32,\ldots,63\}\), and use the same secret interval for both parties:

| Final divisor \(D\) | Output alphabet \(J=16/D\) | Secrets in \(\{0,1,2,3\}\) | Secrets in \(\{2,3\}\) |
|---:|---:|---:|---:|
| 1 | 16 | \(13/16\) | \(3/4\) |
| 2 | 8 | \(59/64\) | \(7/8\) |
| 4 | 4 | \(123/128\) | \(15/16\) |
| 8 | 2 | \(251/256\) | \(31/32\) |
| 16 | 1 | \(1\) | \(1\) |

These are integer counts, with 512 or 128 triples per entry respectively. The last row illustrates that agreement can be made perfect by publishing no useful key entropy. No extrapolation to large parameters, no universal three-quarters law and no security level is inferred from this table. A theorem about another agreement model must state its own sampling law and final extraction rule.

## 5.6. The exact scalar inverse problem

The inverse task receives \(a,P,Q,u\) and a publicly known interval \(I=\{L,\ldots,R-1\}\). It asks for some \(x\in I\) satisfying
\[
F_{P,Q}(ax)=u.
\tag{5.15}
\]
Finding *some* compatible secret, recovering the *original* sampled secret, and predicting the *shared key* are different tasks. They will be related only under explicit hypotheses.

Assume initially \(P=QH\) and \(0\le u<H\).

**Theorem 5.6 — Affine-lattice description of the inverse set.** Equation (5.15) holds if and only if there exists an integer \(r\) such that
\[
ax\equiv Qu+r\pmod P,\qquad 0\le r<Q.
\tag{5.16}
\]
The unrestricted congruence solutions form
\[
(0,-Qu)+\mathbb Z(1,a)+\mathbb Z(0,P).
\tag{5.17}
\]
The admissible inverse set is the intersection with \(L\le x<R\) and \(0\le r<Q\). The homogeneous basis has determinant \(P\).

*Proof.* Euclidean division gives (5.16). Conversely, \(Qu+r\) belongs to \([0,P)\), so it is the canonical residue of \(ax\), establishing (5.15). A pair \((x,r)\) belongs to (5.17) exactly when \(r=-Qu+ax+kP\) for an integer \(k\). The two independent basis vectors have determinant \(P\). \(\square\)

This classical geometric representation underlies the early lattice attack ([B13](#bib-b13)). More generally, the feasibility conditions can be written with two integer unknowns \(x,k\):
\[
L\le x\le R-1,\qquad
Qu\le ax-Pk\le Q(u+1)-1.
\tag{5.18}
\]
Fixed-dimensional integer programming provides a polynomial-time approach in principle ([B17](#bib-b17)). Here we give a simpler explicit counting route, which does not rely on a nearest-vector heuristic or on a correctness claim from an attack paper.

## 5.7. A Euclidean floor-sum algorithm

Define, for \(n\ge0\), \(m>0\), and signed integers \(a,b\),
\[
S(n,m,a,b)=\sum_{i=0}^{n-1}
\left\lfloor\frac{ai+b}{m}\right\rfloor.
\tag{5.19}
\]
This is a classical arithmetic floor sum. Euclidean algorithms for it are documented, for example, in the AtCoder Library ([B18](#bib-b18)). The recurrence and its proof are supplied here to make the arbitrary-precision reference implementation independently reviewable; no algorithmic novelty is claimed.

**Lemma 5.7 — Normalization and reciprocity.** Write
\[
a=q_a m+a_0,\quad b=q_b m+b_0,\quad 0\le a_0,b_0<m.
\]
Then
\[
S(n,m,a,b)=q_a\frac{n(n-1)}2+q_b n+S(n,m,a_0,b_0).
\tag{5.20}
\]
For \(0<a<m\) and \(0\le b<m\), put
\[
Y=an+b=mT+c,\qquad 0\le c<m.
\]
Then
\[
S(n,m,a,b)=S(T,a,m,c).
\tag{5.21}
\]
If \(a=0\), the normalized sum is zero; if \(Y<m\), it is also zero.

*Proof.* Equation (5.20) follows by separating the integral multiples of \(m\) inside each floor. It remains valid for negative \(a,b\) because the quotients are Euclidean floors, not truncations toward zero.

For (5.21), count lattice points by horizontal level. The number of indices \(0\le i<n\) satisfying \(ai+b\ge mj\), for \(1\le j\le T\), is
\[
n-\left\lceil\frac{mj-b}{a}\right\rceil
=\left\lfloor\frac{an+b-mj}{a}\right\rfloor.
\]
Every such number is nonnegative: the largest level is at most \(an+b\). Terms of value zero are harmless. Summing over levels and substituting \(an+b=mT+c\) gives
\[
\sum_{j=1}^{T}\left\lfloor\frac{m(T-j)+c}{a}\right\rfloor
=S(T,a,m,c).
\]
The special cases are immediate from the normalized range. \(\square\)

After normalization, each nonterminal reciprocity step replaces the modulus \(m\) by \(a<m\); subsequent steps follow Euclidean remainders. There are \(O(1+\log m)\) such steps. The integers manipulated have bitlength polynomial in the input bitlengths, so exact arithmetic gives a polynomial bit-complexity algorithm. This statement does not treat unbounded integers as constant-time machine words.

The supplied Chapter 5 verification code implements the recurrence with arbitrary-precision integers: its loop maintains an accumulator for (5.20), applies (5.21), and terminates at a zero residual sum. Unlike a bounded-word implementation, it never reduces the answer modulo \(2^{64}\) on overflow.

## 5.8. Counting, selecting and sampling compatible secrets

This section allows arbitrary \(P,Q>0\), including \(Q\nmid P\), and signed endpoints \(L\le R\). Let \(n=R-L\). For any integer \(u\), the inverse set is empty if \(u<0\) or \(Qu\ge P\). Otherwise set
\[
\ell_u=Qu,\qquad h_u=\min\{Q(u+1),P\}.
\]

**Theorem 5.8 — Exact interval counting and polynomial-time selection.** The number \(N_I(a,u)\) of compatible secrets is
\[
\begin{aligned}
N_I(a,u)
={}&S(n,P,a,aL-\ell_u)\\
&-S(n,P,a,aL-h_u).
\end{aligned}
\tag{5.22}
\]
It can be calculated in polynomial time in the binary input length. If it is nonzero, a compatible secret, or the \(k\)-th compatible secret in increasing order for any \(1\le k\le N_I(a,u)\), can be found in polynomial time without enumerating the interval.

*Proof.* For every integer \(w\) and thresholds \(0\le\ell\le h\le P\),
\[
\mathbf1\{\ell\le[w]_P<h\}
=\left\lfloor\frac{w-\ell}{P}\right\rfloor
 -\left\lfloor\frac{w-h}{P}\right\rfloor.
\tag{5.23}
\]
To verify the identity, write \(w=Pj+r\), \(0\le r<P\). The two quotients differ by one exactly when \(r\) lies between the thresholds, and are otherwise equal. Substitute \(w=a(L+i)\) and sum over \(0\le i<n\), obtaining (5.22).

For selection, divide \([L,R)\) at its midpoint. Count compatible secrets in the left half. If this count is at least \(k\), retain that half; otherwise retain the right half and subtract the left count from \(k\). The invariant is that the retained interval contains the desired ranked element. After at most \(\lceil\log_2 n\rceil\) splits, one integer remains. Each step uses the Euclidean counting routine. Its final value can also be checked by direct modular multiplication. \(\square\)

Thus this particular **scalar, interval-constrained inverse problem is polynomial-time solvable**. Exponentially many candidate integers may fit inside the interval, but their number can be encoded in linearly many bits and counted without visiting them. Listing all preimages is a different, potentially output-exponential task. This result does not state that every multidimensional system of rounded equations is efficiently solvable.

**Corollary 5.9 — Exact posterior sampling for uniform interval secrets.** For fixed public parameters and \(X\) uniform on \(I\), the conditional law of \(X\) given \(U=F_{P,Q}(aX)=u\) is uniform on the \(N_I(a,u)\) compatible integers. It has an expected-polynomial-time exact sampler when the event has positive probability.

*Proof.* Every secret in \(I\) has prior mass \(1/|I|\), and publication is deterministic. Bayes' rule therefore assigns mass \(1/N_I(a,u)\) to each compatible secret. Choose a uniform rank in \(\{1,\ldots,N_I(a,u)\}\) and use Theorem 5.8. A uniform rank is generated from \(\lceil\log_2 N_I\rceil\) fair bits by rejecting values outside the range; each trial succeeds with probability greater than \(1/2\), unless \(N_I=1\), where no randomness is needed. \(\square\)

Capping the rejection process at \(t\) trials gives an implementation whose running time is polynomial in the binary input length and in \(t\), with failure probability at most \(2^{-t}\). In an asymptotic security formulation, choose \(t\) polynomially bounded in the security parameter, for example \(t=\lambda\). The corresponding failure probability is then at most \(2^{-\lambda}\). An explicit failure output or a designated valid fallback must be accounted for; the error is not silently declared zero.

## 5.9. Compatible secrets and passive shared-key prediction

A polynomial-time inverse does not always recover the original private integer. However, uniqueness is not necessary for a key-prediction conclusion in the probability model of Section 5.2.

Let the complete public transcript be
\[
\mathcal T=(\text{public parameters},a,U,V).
\]
Allow any efficiently computable deterministic extraction rules
\[
K_A=\mathcal A(\mathcal T,X),\qquad
K_B=\mathcal B(\mathcal T,Y).
\tag{5.24}
\]
Equation (5.6) is one instance. Suppose that these are the only messages and that the private values are independent uniform interval samples conditionally on the public parameters. Let
\[
\varepsilon_{\rm agr}=\Pr[K_A\ne K_B]
\]
under that specified honest distribution.

**Theorem 5.10 — Posterior replacement predicts the shared key.** Given only \(\mathcal T\), an eavesdropper can sample \(X^*\) from the posterior of \(X\) given \((a,U)\), and output
\[
K^*=\mathcal A(\mathcal T,X^*).
\]
The algorithm has expected polynomial time and satisfies
\[
\Pr[K^*=K_B]=1-\varepsilon_{\rm agr}.
\tag{5.25}
\]
A capped sampler loses at most its stated failure probability.

*Proof.* Condition on the public parameters and \(a\). The variables \(X,Y\) are independent, \(U\) is a deterministic function of \(X\), and \(V\) is a deterministic function of \(Y\). Consequently, after additionally conditioning on \(U\), the posterior of \(X\) is independent of \((Y,V)\). Corollary 5.9 samples exactly that posterior. Hence
\[
(\mathcal T,Y,X^*)\ \overset{d}{=}\ (\mathcal T,Y,X).
\tag{5.26}
\]
Apply the same event \(\mathcal A(\mathcal T,\cdot)=\mathcal B(\mathcal T,Y)\) to these equal joint distributions. The equality of success probabilities follows. No access to \(Y\), to the true \(X\), or to a secret oracle is used by the adversary. \(\square\)

This is a statement about the distribution of the complete experiment, not a claim that every selected preimage gives the same key. In particular, the success probability for an individual transcript need not equal the global average. Replacing the uniform posterior draw by “the smallest compatible secret” is not justified by this theorem.

**Corollary 5.11 — A real-key versus uniform-key test.** Suppose the keys take values in a fixed publicly known alphabet of size \(J\). Given \((\mathcal T,K)\), run the preceding predictor and accept when \(K=K^*\). Its acceptance gap between Bob's actual key and a uniform key independent of the transcript and predictor is
\[
(1-\varepsilon_{\rm agr})-\frac1J.
\tag{5.27}
\]
The absolute distinguishing advantage is at least the positive part of this quantity, minus any bounded-sampler failure allowance.

*Proof.* Real-world acceptance is (5.25). In the ideal experiment, a fresh uniform challenge key equals any independently computed valid candidate with probability \(1/J\). Subtraction gives (5.27). \(\square\)

Here distinguishing advantage denotes the absolute difference between the real and ideal acceptance probabilities. Under the alternative convention measuring success bias above one half in an equiprobable challenge-bit game, the corresponding quantity is divided by two.

High agreement therefore does not rescue secrecy in this exact scalar model; it makes the posterior predictor correspondingly reliable. The theorem is elementary once the posterior is efficiently samplable. It is not a new claim about the security games or private-state distributions of every historical implementation.

Additional messages can change the relevant posterior. A confirmation value or reconciliation hint depending on the original private state cannot simply be ignored in a proof of equality (5.26). No theorem here covers an unspecified extension containing such messages. Likewise, a public-key encryption layer with new independent noise and multidimensional secrets is outside this two-message deterministic-publication model.

## 5.10. Public distinguishability, multiplicities and degeneracies

Counting yields further diagnostics independently of the key-exchange extraction rule.

Assume again \(Q\mid P\), let \(H=P/Q\), and write \(B=|I|>0\). Given \(a,u\), define the public membership test
\[
\mathcal D_{\rm supp}(a,u)=\mathbf1\{N_I(a,u)>0\}.
\]

**Proposition 5.12 — An efficient support and likelihood test.** For the real scalar publication with uniform interval secret, this test accepts with probability one. If \(u\) is instead uniform on \(\{0,\ldots,H-1\}\), its acceptance probability is \(s_a/H\), where
\[
s_a=|\{u:N_I(a,u)>0\}|\le\min(B,H).
\]
For every fixed public multiplier its distinguishing gap is therefore at least
\[
\max\{0,1-B/H\}.
\tag{5.28}
\]
Moreover, the test \(HN_I(a,u)>B\) achieves the total-variation-optimal acceptance gap for this fixed public multiplier, and can itself be evaluated in polynomial time.

*Proof.* Real publications always have a preimage. At most one output value is contributed per secret, so the support has at most \(B\) elements. Under a uniform quotient the support event has probability \(s_a/H\). Finally, the real output mass is \(N_I(a,u)/B\); subtracting \(1/H\) gives a positive value exactly under the stated likelihood comparison. Summing the positive differences equals total variation. Theorem 5.8 evaluates the needed count. \(\square\)

Efficient exact counting in the one-dimensional interval model is the decisive property. This chapter supplies no analogous counting algorithm for a general multidimensional publication law; it also proves no lower bound requiring exhaustive enumeration in such models. If a public multiplier is random but revealed, the same scalar test is applied conditionally to it and the bound (5.28) survives averaging.

The count also detects degeneracies. If \(a=0\pmod P\), all secrets give quotient zero. If \(a\) and \(P\) have a common divisor, multiplication need not permute the residues.

**Proposition 5.13 — Full-period counts and the gcd.** On the full secret domain \(\{0,\ldots,P-1\}\), let \(g=\gcd(a,P)\). For \(0\le u<H\),
\[
N_{[0,P)}(a,u)
=g\left(
\left\lfloor\frac{Q(u+1)-1}{g}\right\rfloor
-\left\lfloor\frac{Qu-1}{g}\right\rfloor
\right).
\tag{5.29}
\]
In particular, if \(g=1\), every quotient has exactly \(Q\) preimages.

*Proof.* Multiplication by \(a\) on \(\mathbb Z_P\) has as its image precisely the multiples of \(g\), each with \(g\) preimages. Count these multiples in the half-open quotient cell \([Qu,Q(u+1))\). The formula also holds for \(a=0\), where \(g=P\). \(\square\)

For a short secret interval the gcd formula alone is insufficient, but (5.22) remains exact. For a uniform prior, knowing that the fiber has \(N\) elements leaves the original secret uniform among them; the best transcript-only probability of guessing that original value is \(1/N\). This fact does not contradict Theorem 5.10, which targets the shared key rather than the original secret.

## 5.11. Relationship with the earlier cryptanalysis

Zhang presents a scalar attack via a two-dimensional affine lattice and closest-vector reasoning ([B13](#bib-b13)). The exact geometric relation in Theorem 5.6 is consistent with that approach. Sections 4.5 and 4.13 distinguish this valid representation from two defects in the printed analysis.

For the worked parameters \(a=6173\), \(x=12345\), \(P=2^{22}\), \(Q=32\), direct arithmetic gives
\[
ax=76205685,\quad [ax]_P=708213,\quad U=22131,
\quad [ax]_P-QU=21.
\tag{5.30}
\]
The printed value \(708192\) is \(QU\), not \(U\). This correction does not invalidate the example's displayed recovery. Independently, the present floor-sum routine finds exactly one compatible secret in the 14-bit interval \([2^{13},2^{14})\), namely \(12345\).

Section 4.13.3 supplies a counterexample to an unrestricted minimum-norm assertion and distinguishes it from bounded-rectangle recovery. Theorems 5.8–5.11 do not depend on that disputed assertion. An error in one attack proof is not evidence of security, particularly when a separate exact algorithm solves the specified inverse problem.

The publisher confirms the 2017 study by Barcau, Paşol, Pleşca and Togan ([B16](#bib-b16)). Its full technical proof was not available in this session; no theorem of that paper is used as a hidden premise for the results above.

## 5.12. Extraction versions and reduction claims must remain distinct

The revised historical source ([B12](#bib-b12)) contains two different extraction maps in its algorithm and correctness discussion, as calculated in Section 4.13.1. To keep their meanings separate, label the two expressions
\[
\mathsf A(z)=F_{2^p,\,2^{p-q}}(z),\qquad
\mathsf B(z)=F_{2^{p-q},\,2^q}(z).
\tag{5.31}
\]
These have different moduli and generally different codomains. They are not rewritten as one protocol here.

The explicit witness from Section 4.13.1, \(p=33,q=16,a=2^{32}+1,x=2^{15},y=2^{15}+1\), gives \(U=0,V=65536\). Applying \(\mathsf A\) to \((xV,yU)\) gives \((16384,0)\); applying \(\mathsf B\) gives \((0,0)\). The verifier reproduces these integer values. This is a counterexample to equality of the two maps, not a statistical analysis of their honest agreement rates.

Separately, rewriting a scalar integer as a binary expansion can express its inverse equation using many bits, but does not remove the one-dimensional arithmetic progression exploited by (5.22). A reduction *from* an inverse problem *to* a general search problem is not a hardness proof for the inverse problem. For the interval model studied here, the explicit polynomial algorithm must be accounted for in any hardness claim.

No conclusion is drawn about arbitrary subsets of integers whose membership is specified by a hard circuit, about a secret with an unknown nonuniform prior, or about noisy publications with an unspecified error law. Those are different computational problems.

## 5.13. Why the polynomial article is a separate scientific task

A multidimensional secret \((x_0,\ldots,x_{d-1})\) produces sums such as
\[
\sum_{j=0}^{d-1}a_{i+j}x_j.
\]
There are now many independently selectable secret coordinates and several overlapping constraints. Replacing the vector by one large integer does not generally turn the prescribed secret support and convolution into the one-variable interval model above. Coefficient carries, base restrictions and cross-coordinate conditions must be retained.

Likewise, polynomial truncation by powers of the indeterminate extracts a window of coefficients, while scalar division by an integer discards low-order radix information. A proposed equivalence must specify which operation is meant and prove preservation of the full joint distribution.

The floor-sum algorithm in this chapter is consequently not claimed as an attack on MODDIV-P, NOISE-CPA-LIFT, WC or BLINDAGE. Their publication laws and security games require their own analyses. Conversely, a later conditional security proof cannot retroactively certify the scalar interval inverse problem as difficult.

The separately planned polynomial article remains responsible for its own specification, correctness, cryptanalysis and comparison with middle-product assumptions. This chapter provides the scalar baseline and the failure modes that such work must not obscure.

## 5.14. Reproducible verification and complexity accounting

The accompanying code uses Python arbitrary-precision integers and exact rational arithmetic. It contains no external cryptographic dependency, no floating-point probability calculation and no access to a private secret inside the inverse routines.

The generator for finite tests knows the planted secrets so that it can check results; `count_preimages`, `select_preimage` and `sample_preimage` receive only the public instance and the announced interval. Some tests enumerate small domains solely as an independent reference. Such enumeration is not part of the counting or selection algorithm.

| Verification family | Checks executed |
|---|---:|
| Floor sums, including negative slopes and offsets | 114,660 |
| Interval preimage counts, including nondivisible parameters | 61,480 |
| Ranked preimages compared with explicit sorted fibers | 55,400 |
| Full-period gcd formula | 36,547 |
| Cross-product, circular-distance and final-carry identities | 65,266 |
| Independent-dither boundary counts | 35,199 |
| Posterior-replacement models | 912 |
| Joint atoms compared within those posterior models | 24,120 |
| Support and optimal scalar likelihood tests | 2,256 |

These counts describe different kinds of checks and are not summed into a misleading number of independent cryptographic experiments. The posterior tests explicitly sum over the sampled rank; they are not Monte Carlo estimates.

Four additional synthetic spot checks use modulus exponents 128, 256, 512 and 1024, with secret intervals of respective cardinalities \(2^{63},2^{127},2^{255},2^{511}\). Each selected test has a single preimage, recovered exactly by counting and bisection. These are not certified security parameters or an exhaustive large-instance campaign. Their role is to check arbitrary-precision implementation behavior beyond toy machine words. The polynomial complexity statement comes from Lemma 5.7 and Theorem 5.8, not from timings on those examples.

The verifier also reproduces the boundary witness in Section 5.4, the corrected numerical example (5.30), the extraction discrepancy (5.31), and the agreement table. The deterministic seed for the large-integer spot checks is `20261107`. The distributed deterministic reference output is `supplementary/chapter-05/results.json`.

Reproduce the mathematical checks with:

```sh
python3 verify_ch5.py --output RESULTS_CH5.json
```

The supplementary verification checklist identifies the results covered by executable checks. Successful execution is not proof-assistant certification, external peer review or a determination of novelty.

## 5.15. Conclusions and obligations for the next chapters

The scalar model illustrates both the usefulness and the limits of modulo–division arithmetic. Exact cancellation gives a small *circular* discrepancy, not unconditional equality after a second division. A correct agreement calculation must include the distribution of cell positions and their correlation with the discrepancy.

More importantly, the inverse problem for a scalar multiplier and an interval secret has an elementary polynomial-time counting and selection algorithm. For uniform interval secrets, this algorithm samples the posterior exactly. In a two-message exchange whose only private variables are those scalars, posterior replacement predicts the other party's key with the honest agreement probability. Secret nonuniqueness therefore does not rescue that explicitly specified model.

These deductions are useful whether or not a particular earlier closest-vector proof is correct. They separate three tasks that are often conflated: finding a consistent preimage, recovering the originally sampled private value, and predicting a shared key. They also explain why a binary rewrite or a large numeric modulus does not by itself make the scalar problem hard.

The scope is deliberately narrow. Historical provenance remains governed by Chapter 4's evidence standards. Multidimensional, polynomial and noisy constructions are not treated as synonymous with the scalar testbed. Their analysis must identify the computational structure that survives after all dimensions and distributions are specified.

**Scope.** The SCALAR-INTERVAL analysis does not establish security of that model or of polynomial, noisy, WC, NOISE or BLINDAGE constructions. No external peer review, proof-assistant certification or historical-priority finding is claimed.



## Supplementary Material and Reproducibility — Chapter 5

The public supplementary material for this chapter is assigned to `supplementary/chapter-05/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 6 — Carries, Boundaries, and Exact Agreement {#ch6}
## A Three-Quarters Bound for the Full-Range Scalar Model


**Scope.** The argument concerns the stated full-range scalar model. It is not a security approval, external peer review, or proof-assistant certification.

### Abstract

This chapter studies agreement under modular quotient extraction without replacing correlated remainders by independent noise. It supplies the complete analytic argument and reproduces all eleven finite cases required by its computer-assisted closure. In the full-range scalar model, with independent uniform public multiplier and secrets, the agreement probability depends on the secret precision but not on the higher public precision. An exact conditional count is obtained on a residue class determined by the greatest common divisor of the secret product and the quotient divisor. A variance identity compares correlated remainders with an auxiliary independent experiment; a discrete–continuous calculation then yields an explicit analytic bound. The resulting uniform agreement probability is at least \(166397/221184>3/4\). This conclusion does not apply unchanged to secrets constrained to have exactly a prescribed bit length: an exhaustive seven-bit example has agreement below three quarters. Finally, the theorem is combined with the scalar analysis proved in Chapter 5. Good honest agreement and efficient passive prediction of the key coexist in that model. The chapter proves a correctness probability, not secrecy, negligible failure, a lattice hardness reduction, or a result for polynomial MODDIV.

### Scope and contribution boundary

The full analytic argument is included below. The finite counters reproduce the eleven small cases used to close the theorem and are provided in the public supplementary material for this chapter. The carry discussion also acknowledges the earlier project note on 2-adic channels.

Chapter 5, Theorem 5.10 and Corollaries 5.9 and 5.11, establishes the separate negative security result for SCALAR-INTERVAL under its own hypotheses. The present chapter does not modify those statements. All historical attribution questions remain separate from the arithmetic developed here.

## 6.1. Why an agreement chapter follows a scalar attack

A protocol can make two honest computations agree often and nevertheless allow an eavesdropper to calculate a related key efficiently. Chapter 5 separated finding a compatible secret, recovering the original secret, and predicting a shared key. It also showed why a small circular discrepancy does not ensure identical final quotients.

The present chapter asks a more specific question: under an exactly stated law of the public multiplier and the two secrets, how often does the original, undithered cell comparison agree? A proof must track the cell position together with its displacement. Their dependence is the principal issue, not a typographical detail in a rounding formula.

LWR and middle-product rounding provide relevant cryptographic context ([B02](#bib-b02); [B19](#bib-b19); [B09](#bib-b09)). Their published reductions concern specified distributions and security games; they are not premises for the agreement theorem below. The proof here uses Euclidean arithmetic, finite-group counting, a variance identity, and finite exact computations. No theorem of LWE or MP-CLWR hardness is invoked.

## 6.2. The full-range scalar model and its exact relation to Chapter 5

Let \(p,q\) be integers with \(q\ge1\) and \(p>2q\), and put
\[
Q=2^q,\qquad P=2^p,\qquad J=P/Q^2\ge2,\qquad H=P/Q=QJ.
\tag{6.1}
\]
For a positive integer \(m\), \([z]_m\) denotes the canonical residue in \(\{0,\ldots,m-1\}\). Every division below is Euclidean floor division, including when a displacement is negative. Sample independently
\[
A\leftarrow\operatorname{Unif}\{0,\ldots,P-1\},\qquad
X,Y\leftarrow\operatorname{Unif}\{0,\ldots,Q-1\}.
\tag{6.2}
\]
There is no additive error in the following public values:
\[
U=\left\lfloor\frac{[AX]_P}{Q}\right\rfloor,\qquad
V=\left\lfloor\frac{[AY]_P}{Q}\right\rfloor.
\tag{6.3}
\]
The two local outputs are
\[
W_A=\left\lfloor\frac{[QXV]_P}{Q^2}\right\rfloor,\qquad
W_B=\left\lfloor\frac{[QYU]_P}{Q^2}\right\rfloor.
\tag{6.4}
\]
Since \([Qz]_P=Q[z]_H\), equivalently
\[
W_A=\left\lfloor\frac{[XV]_H}{Q}\right\rfloor,\qquad
W_B=\left\lfloor\frac{[YU]_H}{Q}\right\rfloor.
\tag{6.5}
\]
Thus this is precisely the Chapter 5 interval model with \(I_X=I_Y=[0,Q)\cap\mathbb Z\), public multiplier uniform over a full period, and final divisor \(D=Q\). Each output lies in \(\{0,\ldots,J-1\}\).

The support in (6.2) includes zero. It is not the interval \([Q/2,Q)\cap\mathbb Z\) of integers with exactly \(q\) bits. The public distribution is not restricted to the upper half of its modulus. The distinction between the two secret supports is essential in Section 6.13. The public law in (6.2) remains the full-period uniform law throughout the stated theorem. The definition is a normalized mathematical experiment, not a claim that every historical document used these same conventions.

## 6.3. A local carry channel is not an independent-error model

Before studying agreement, it is useful to state exactly what a bitwise carry calculation does and does not provide.

**Lemma 6.1 — Signed binary carry propagation.** Let \(k\ge1\), \(0\le z<2^k\), and \(e\in\{-1,0,1\}\). Write the bits of \(z\) as \(z_j\), set \(c_0=e\), and recursively define
\[
b_j=[z_j+c_j]_2,\qquad
c_{j+1}=\left\lfloor\frac{z_j+c_j}{2}\right\rfloor,
\qquad 0\le j<k.
\tag{6.6}
\]
Every carry belongs to \(\{-1,0,1\}\), and
\[
z+e=\sum_{j=0}^{k-1}2^j b_j+2^k c_k.
\tag{6.7}
\]
In particular, the bits \(b_j\) represent \([z+e]_{2^k}\).

*Proof.* For \(z_j\in\{0,1\}\) and \(c_j\in\{-1,0,1\}\), the integer \(z_j+c_j\) lies between \(-1\) and \(2\). Its floor quotient by two is again in \(\{-1,0,1\}\). The identity \(z_j+c_j=b_j+2c_{j+1}\), multiplied by \(2^j\) and summed, telescopes to (6.7). Euclidean division handles the case \(z=0,e=-1\) without a special nonnegative-arithmetic convention. \(\square\)

For an illustrative perturbation \(E\) independent of the input \(z\), with probabilities \(1/4\), \(1/2\) and \(1/4\) at \(-1\), \(0\) and \(1\) respectively, each fixed least significant input bit \(r\) gives the following exact conditional distribution of the first output bit and carry:

| Input bit \(r\) | Output bit \(b_0\) | Carry \(c_1\) | Probability |
|---:|---:|---:|---:|
| 0 | 0 | 0 | \(1/2\) |
| 0 | 1 | 0 | \(1/4\) |
| 0 | 1 | \(-1\) | \(1/4\) |
| 1 | 1 | 0 | \(1/2\) |
| 1 | 0 | 0 | \(1/4\) |
| 1 | 0 | 1 | \(1/4\) |

The output bit is uniform conditional on either input bit, but its joint law with the carry depends on that bit. A small carry alphabet therefore does not make the global hidden-state distribution easy to sample. In a cryptographic observation, \(z_j\) can depend on an unknown secret. This table is a generative identity, not permission for a simulator to read that secret bit. The CBD1 example is not an error distribution added to the noiseless model (6.2)–(6.4).

## 6.4. Exact boundaries and a quantitative dependence check

For this section, allow any integers \(Q,J\ge1\), set \(H=QJ\), and define \(C(s)=\lfloor[s]_H/Q\rfloor\).

**Lemma 6.2 — Modular cell criterion.** Write a canonical input as \(s=Qk+t\), with \(0\le k<J\) and \(0\le t<Q\). For any integer displacement \(e\),
\[
C(s+e)=\left[k+\left\lfloor\frac{t+e}{Q}\right\rfloor\right]_J.
\tag{6.8}
\]
If \(J\ge2\) and \(|e|<Q\), then
\[
C(s+e)=C(s)\quad\Longleftrightarrow\quad 0\le t+e<Q.
\tag{6.9}
\]

*Proof.* Divide \(t+e\) into quotient and remainder by \(Q\). The remainder lies in \([0,Q)\), and reducing modulo \(QJ\) reduces its accompanying quotient modulo \(J\), proving (6.8). Under the additional bound the quotient change is in \(\{-1,0,1\}\). For \(J\ge2\), only zero leaves \(k\) unchanged modulo \(J\). This is exactly (6.9). \(\square\)

The restriction matters: for \(J=1\) the output is constant, while a displacement by \(H\) preserves a quotient despite leaving its original integer cell. Neither exception is removed by calling the computation “modular rounding.”

**Proposition 6.3 — Dependence budget for the uniform-phase heuristic.** Let \(T,E\) be jointly distributed integer variables with \(|E|<Q\) almost surely and \(J\ge2\). Put \(R=[T]_Q\), and define
\[
\eta=\operatorname{TV}\!\left(
\mathcal L(R,E),\ \operatorname{Unif}(\mathbb Z_Q)\otimes\mathcal L(E)
\right).
\tag{6.10}
\]
Then
\[
\left|\Pr[C(T+E)=C(T)]-
\left(1-\frac{\mathbb E|E|}{Q}\right)\right|\le\eta.
\tag{6.11}
\]

*Proof.* Agreement is the event \(0\le R+E<Q\) by Lemma 6.2. Under the product comparison law, conditioning on \(E=e\) gives exactly \(Q-|e|\) successful phases. Averaging gives \(1-\mathbb E|E|/Q\). The probabilities of any one event under two laws differ by at most their total variation distance. This proves (6.11). \(\square\)

Uniform phase marginals alone are insufficient. With \(Q=2,J=2\), place mass \(1/2\) on each of \((R,E)=(0,1),(1,-1)\). Agreement is certain. Place mass \(1/2\) instead on \((0,-1),(1,1)\); agreement is impossible. Both models have the same uniform phase marginal and the same displacement marginal. The independent-phase expression equals \(1/2\) in both cases.

Adding one fresh public dither \(D_0\), uniform on \(\{0,\ldots,Q-1\}\) and independent of \((T,E)\), to both arguments makes \([T+D_0]_Q\) uniform conditional on \((T,E)\). It therefore gives the exact averaged disagreement \(\mathbb E|E|/Q\) in this modified experiment. This is the diagnostic mechanism already identified in Chapter 5; it does not justify setting \(\eta=0\) for the undithered protocol, or establish secrecy of a publicly dithered key.

## 6.5. The dependence created by a common multiplier

The two remainders \([a x]_Q\) and \([a y]_Q\) come from the same \(a\). Their joint law can be described exactly before any rounding analysis.

**Lemma 6.4 — Image law of shared-multiplier remainders.** Fix integer coefficients \(x_1,\ldots,x_r\), with \(r\ge1\), and let \(a\) be uniform modulo a positive integer \(Q\). Put \(g=\gcd(Q,x_1,\ldots,x_r)\). The vector
\[
([a x_1]_Q,\ldots,[a x_r]_Q)
\tag{6.12}
\]
is uniform on an image of size \(Q/g\); every image vector has exactly \(g\) preimages.

*Proof.* The map from \(\mathbb Z_Q\) to \((\mathbb Z_Q)^r\) is a group homomorphism. Its kernel consists of the \(a\) for which \(Q\mid a x_j\) for every \(j\). Bezout's identity for \(Q,x_1,\ldots,x_r\) shows this is equivalent to \(Q\mid a g\), or \(Q/g\mid a\). Exactly \(g\) residues satisfy that condition. Every nonempty fiber is a kernel coset. \(\square\)

For example, if \(x=y=1\), both marginal remainders are uniform, but the pair lies on the diagonal. Its total variation distance from two independent uniform residues is \(1-1/Q\). This is an explicit reason not to replace shared-multiplier remainders by independent errors. The comparison introduced later is an inequality proved for a specific average, not an assertion of equality of these joint laws.

## 6.6. Reduction to two public digits

Return to the full-range experiment (6.1)–(6.4). Decompose the public multiplier uniquely as
\[
A=a+Qh+Q^2z,\qquad
0\le a,h<Q,\quad 0\le z<J.
\tag{6.13}
\]
The three digits are independent uniforms. For fixed \(a,x,y\), define
\[
f_a(x)=\lfloor ax/Q\rfloor,\qquad \rho_a(x)=[ax]_Q,
\]
\[
u=x f_a(y),\qquad v=y f_a(x),\qquad \Delta=v-u.
\tag{6.14}
\]
Here \(u\) is the ordinary letter denoting an integer auxiliary quantity, not the public random variable \(U\).

**Theorem 6.5 — Exact two-digit agreement event.** For the above quantities,
\[
Q\Delta=x\rho_a(y)-y\rho_a(x),\qquad |\Delta|<Q,
\tag{6.15}
\]
and, with \(T=[xyh+u]_Q\),
\[
W_A=W_B\quad\Longleftrightarrow\quad 0\le T+\Delta<Q.
\tag{6.16}
\]
Consequently, the agreement probability is independent of \(p\) for \(p>2q\). Denote it by \(\alpha_q\).

*Proof.* Subtract the two decompositions \(ax=Qf_a(x)+\rho_a(x)\) and \(ay=Qf_a(y)+\rho_a(y)\) after multiplication by \(y\) and \(x\). This gives (6.15), with absolute numerator at most \((Q-1)^2<Q^2\). The quotient identities from Chapter 2 give
\[
U\equiv f_a(x)+hx+Qxz\pmod H,\qquad
V\equiv f_a(y)+hy+Qyz\pmod H.
\tag{6.17}
\]
Thus \(YU-XV\equiv\Delta\pmod H\) and \([XV]_Q=[xyh+u]_Q\). Write \([XV]_H=QW_A+T\) and apply Lemma 6.2 to its displacement \(\Delta\). This proves (6.16), including modular wraparound. The event only involves \(a,h,x,y\), whose joint law does not depend on \(z,J,p\). \(\square\)

The orientation here is Bob-minus-Alice: \(\Delta\) is the negative of the discrepancy called \(\delta\) in Chapter 5. Both identities are retained with their own signs. Independence of \(p\) is a statement about agreement, not independence or uniformity of the keys themselves. The restriction \(J\ge2\) is essential: if \(p=2q\), both final outputs are constant and the agreement becomes one.

## 6.7. Exact counting on the reachable residue class

Fix \(a,x,y\), and put \(g=\gcd(xy,Q)\), \(m=Q/g\), with \(\gcd(0,Q)=Q\). As \(h\) varies uniformly, \(T=[xyh+u]_Q\) is uniform on one residue class modulo \(g\). This class is generally not all of \(\mathbb Z_Q\).

**Proposition 6.6 — Conditional disagreement count.** In the full-range experiment,
\[
\Pr[W_A\ne W_B\mid a,x,y]
=\frac gQ\left|\left\lfloor\frac vg\right\rfloor-
\left\lfloor\frac ug\right\rfloor\right|.
\tag{6.18}
\]
Moreover,
\[
\left|g\left|\lfloor v/g\rfloor-\lfloor u/g\rfloor\right|
-|v-u|\right|\le g-1.
\tag{6.19}
\]

*Proof.* Write \(u=gU_0+s\), \(v=gV_0+r\), with \(0\le s,r<g\). The possible phases are \(s+gj\), where \(j\) is uniform in \(\{0,\ldots,m-1\}\). Hence
\[
T+\Delta=g(j+V_0-U_0)+r.
\]
Agreement is equivalent to \(0\le j+c<m\), where \(c=V_0-U_0\). The bounds \(|\Delta|<gm\) and \(|r-s|\le g-1\) imply \(|c|\le m\). Exactly \(|c|\) indices fail. This proves (6.18). The reverse triangle inequality applied to \(v-u=gc+r-s\) proves (6.19). \(\square\)

Define the normalized correlated determinant
\[
\mathcal D_Q=\frac1{Q^2}\mathbb E_{a,X,Y}
\left|X\rho_a(Y)-Y\rho_a(X)\right|.
\tag{6.20}
\]
The notation \(\mathcal D_Q\) is distinct from the modular quotient map \(F_{P,Q}\). Averaging (6.19) and using (6.15) gives
\[
1-\alpha_q\le\mathcal D_Q+\frac{\mathbb E g-1}{Q}.
\tag{6.21}
\]
Zero secrets cause no singularity: then \(u=v=0\), the exact disagreement is zero, and the upper bound remains valid.

## 6.8. Exact two-adic averages

**Lemma 6.7 — Mean product gcd.** For independent uniforms \(X,Y\in\{0,\ldots,2^q-1\}\),
\[
\mathbb E\gcd(XY,2^q)=1+\frac{q(q+5)}8.
\tag{6.22}
\]
Also,
\[
\mathbb E\left[\gcd(X,2^q)\mathbf1_{\{X>0\}}\right]=\frac q2.
\tag{6.23}
\]

*Proof.* For \(1\le j\le q\), split according to the exact valuation \(v_2(X)=i<j\) and the event \(2^j\mid X\). Independence gives
\[
\Pr[2^j\mid XY]
=\sum_{i=0}^{j-1}2^{-i-1}2^{-(j-i)}+2^{-j}
=\frac{j+2}{2^{j+1}}.
\tag{6.24}
\]
The last event includes \(X=0\); no finite valuation of zero is assigned. Since \(g\) is a power of two,
\[
g=1+\sum_{j=1}^{q}2^{j-1}\mathbf1_{\{2^j\mid XY\}}.
\]
Taking expectations yields (6.22). For (6.23), exactly \(Q/2^{i+1}\) nonzero integers below \(Q=2^q\) have valuation \(i\), for \(0\le i<q\). Multiplying each count by \(2^i\), summing and dividing by \(Q\) gives \(q/2\). \(\square\)

Substitution into (6.21) yields
\[
1-\alpha_q\le\mathcal D_Q+\frac{q(q+5)}{8Q}.
\tag{6.25}
\]
This term quantifies the cost of counting on a gcd-spaced grid instead of assuming a uniform cell phase.

## 6.9. Decoupling the remainder average without changing the protocol

Introduce an auxiliary independent multiplier \(b\), uniform modulo \(Q\) and independent of \(a,X,Y\). Define
\[
\mathcal D_Q^{\rm ind}=\frac1{Q^2}
\mathbb E_{a,b,X,Y}
\left|X\rho_b(Y)-Y\rho_a(X)\right|.
\tag{6.26}
\]
Independence here belongs to a comparison experiment; it is not an assumption about the real remainders.

**Lemma 6.8 — Variance-based decoupling.** For every integer \(Q\ge2\),
\[
\mathcal D_Q\le\mathcal D_Q^{\rm ind}.
\tag{6.27}
\]
More precisely, for
\[
G_a(t)=\frac1Q\sum_{x=1}^{Q-1}x\mathbf1_{\{\rho_a(x)>tx\}},\quad t\ge0,
\]
one has
\[
\mathcal D_Q^{\rm ind}-\mathcal D_Q
=\frac2{Q^2}\int_0^\infty\operatorname{Var}_a(G_a(t))\,dt.
\tag{6.28}
\]

*Proof.* For positive \(x,y\), express the minimum as
\[
\min(x\rho_a(y),y\rho_a(x))
=xy\int_0^\infty
\mathbf1_{\{\rho_a(x)>tx\}}\mathbf1_{\{\rho_a(y)>ty\}}\,dt.
\]
Its average over independent \(X,Y\) is \(\int G_a(t)^2dt\). In the auxiliary experiment the corresponding average over \(a,b\) has integrand \((\mathbb E_a G_a(t))^2\). The linear terms in \(|r-s|=r+s-2\min(r,s)\) have the same expectations in both experiments, since the opposite secret is independent of each multiplier-and-secret remainder. Subtraction gives (6.28). Terms with a zero secret vanish, and the step functions vanish for \(t\ge Q-1\); every integral interchange is a finite-sum calculation. Variance is nonnegative. \(\square\)

The inequality controls this determinant average. It does not imply that the original joint remainder law is close in total variation to the independent law, nor that every function of the remainders can be bounded by making them independent.

## 6.10. Independent residue grids and a continuous comparison

For \(x>0\), set \(d_x=\gcd(x,Q)\). The variable \(\rho_a(x)\) is uniform on \(\{0,d_x,\ldots,Q-d_x\}\). If \(R\) is continuous uniform on \([0,Q)\), then
\[
\widetilde R_x=d_x\lfloor R/d_x\rfloor
\]
has exactly that discrete distribution and \(\mathbb E(R-\widetilde R_x)=d_x/2\). Taking independent \(R,S\) gives, for positive \(x,y\),
\[
\mathbb E|x\widetilde S_y-y\widetilde R_x|
\le\mathbb E|xS-yR|+\frac{x d_y+y d_x}{2}.
\tag{6.29}
\]
If either secret is zero, the discrete determinant is zero and already bounded by the nonnegative continuous term; no artificial cost \(\gcd(0,Q)=Q\) is charged there.

Let \(\xi,\eta\) be independent uniforms on \([0,1]\), independent of \(X,Y\), and set
\[
\mathcal J_Q=\mathbb E\left|\frac XQ\eta-\frac YQ\xi\right|.
\tag{6.30}
\]
Using (6.23) and \(\mathbb E X=(Q-1)/2\), averaging (6.29) gives
\[
\mathcal D_Q^{\rm ind}\le\mathcal J_Q+\frac{q(Q-1)}{4Q^2},
\qquad Q=2^q.
\tag{6.31}
\]

**Lemma 6.9 — Exact continuous–discrete average.** For every integer \(Q\ge2\),
\[
\mathcal J_Q=\frac{13}{54}-\frac1{9Q}-\frac1{54Q^2}-\frac1{9Q^3}
<\frac{13}{54}.
\tag{6.32}
\]

*Proof.* For \(0\le x\le y\), \(y>0\), integration first in one variable and then the other gives
\[
\int_0^1\int_0^1
\left|\frac xQ t-\frac yQ s\right|\,ds\,dt
=\frac{y-x}{2Q}+\frac{x^2}{3Qy}.
\]
The pair \((0,0)\) contributes zero. Combining the diagonal and the two symmetric off-diagonal halves yields
\[
\mathcal J_Q=\frac1{Q^3}\sum_{y=1}^{Q-1}
\left[\frac y3+\sum_{x=0}^{y-1}
\left(y-x+\frac{2x^2}{3y}\right)\right]
=\frac1{Q^3}\sum_{y=1}^{Q-1}
\left(\frac{13y^2}{18}+\frac y2+\frac19\right).
\tag{6.33}
\]
Use the elementary sums of the first \(Q-1\) integers and their squares, and simplify. This is exactly (6.32). \(\square\)

Combining the last two lemmas gives the convenient, slightly weaker inequality
\[
\mathcal D_Q\le\frac{13}{54}+\frac{q}{4Q}.
\tag{6.34}
\]
The continuous variables are only proof auxiliaries. They do not replace any integer arithmetic, sampling law, or output in the actual experiment.

## 6.11. The analytic range and the finite closure

**Theorem 6.10 — Analytic agreement bound.** In the full-range scalar model, for every \(q\ge1\),
\[
\alpha_q\ge\frac{41}{54}-\frac{q(q+7)}{8\,2^q}.
\tag{6.35}
\]
For \(q\ge12\), this implies
\[
\alpha_q\ge c_*:=\frac{166397}{221184}
=\frac34+\frac{509}{221184}>\frac34.
\tag{6.36}
\]

*Proof.* Add the two contributions in (6.25) and (6.34):
\[
1-\alpha_q\le\frac{13}{54}+\frac{q}{4Q}
+\frac{q(q+5)}{8Q}
=\frac{13}{54}+\frac{q(q+7)}{8Q}.
\]
For integers \(q\ge2\), the sequence \(q(q+7)/2^q\) decreases, since
\[
2q(q+7)-(q+1)(q+8)=q^2+5q-8>0.
\]
At \(q=12\), the correction in (6.35) is \(57/8192\). The rational identity \(41/54-57/8192=c_*\) proves the second statement. \(\square\)

For the remaining eleven cases, Proposition 6.6 gives an exact finite formula. Let
\[
\begin{split}
N_{\rm err}(q)=\sum_{a,x,y=0}^{Q-1}g_{x,y}
\left|\left\lfloor\frac{y\lfloor ax/Q\rfloor}{g_{x,y}}\right\rfloor
-\left\lfloor\frac{x\lfloor ay/Q\rfloor}{g_{x,y}}\right\rfloor\right|,
\quad g_{x,y}=\gcd(xy,Q).
\end{split}
\tag{6.37}
\]
Then \(\alpha_q=1-N_{\rm err}(q)/Q^4\). The denominator \(Q^4\) counts reduced quadruples \((a,h,x,y)\), not the original \(PQ^2\) triples \((A,x,y)\); their probabilities agree by Theorem 6.5.

| \(q\) | Exact \(\alpha_q\) | \(4N_{\rm agree}-3Q^4\) |
|---:|---:|---:|
| 1 | \(1\) | 16 |
| 2 | \(123/128\) | 216 |
| 3 | \(459/512\) | 2,400 |
| 4 | \(6901/8192\) | 24,224 |
| 5 | \(52809/65536\) | 234,048 |
| 6 | \(3289931/4194304\) | 2,307,248 |
| 7 | \(51841515/67108864\) | 24,157,872 |
| 8 | \(822654211/1073741824\) | 277,565,488 |
| 9 | \(3276319387/4294967296\) | 3,526,010,560 |
| 10 | \(209209404217/274877906944\) | 48,815,584,144 |
| 11 | \(3343422968633/4398046511104\) | 718,209,364,880 |

**Theorem 6.11 — Uniform three-quarters bound.** For every integer \(q\ge1\) and \(p>2q\), under exactly (6.2)–(6.4),
\[
\Pr[W_A=W_B]=\alpha_q\ge c_*>3/4.
\tag{6.38}
\]

*Proof, with finite computation.* Theorem 6.10 handles all \(q\ge12\). For \(1\le q\le11\), (6.37) is evaluated by the two exact counter modes supplied with this chapter. Both return the table above. Integer cross-multiplication verifies that each fraction is at least \(c_*\), not merely greater than \(3/4\). The counters omit zero and diagonal terms, which vanish, and double the terms with \(1\le x<y<Q\) by symmetry. All eleven runs were reproduced during this chapter's preparation. The complete finite data and the programs are included; the infinite range is justified analytically, not by extrapolation. \(\square\)

This proof is computer-assisted in its finite closure. It is not a completed Lean certification. The constant is not asserted optimal. The argument implies \(\liminf_{q\to\infty}\alpha_q\ge41/54\); it does not establish equality of the limit or monotonicity of the true probabilities. A lower bound exceeding three quarters is also not a negligible-failure guarantee.

## 6.12. Coarsening, dependence, and vector extensions

**Corollary 6.12 — Equality survives common deterministic coarsening.** For any fixed \(r\ge0\), define \(W_A^{(r)}=\lfloor W_A/2^r\rfloor\) and similarly for Bob. Then
\[
\Pr[W_A^{(r)}=W_B^{(r)}]\ge\alpha_q.
\tag{6.39}
\]

*Proof.* Whenever \(W_A=W_B\), applying the same deterministic map preserves equality. Take probabilities of this event inclusion. \(\square\)

This does not establish an exponential formula for the new disagreement probability. For example, deterministic values 1 and 2 disagree before and after division by 2. If \(2^r\ge J\), both coarsened outputs are zero; the agreement is then perfect for a trivial reason. The coarsening parameter is public and fixed, not selected secretly after observing a favorable boundary.

For a vector of comparisons, a union bound gives
\[
\Pr[\text{some coordinate disagrees}]
\le\sum_i\Pr[\text{coordinate }i\text{ disagrees}].
\tag{6.40}
\]
Independence is not needed for this upper bound. In contrast, replacing joint agreement by a product of marginal agreement probabilities requires a joint-law argument. Two coordinates can fail together, separately, or through a common secret even with identical marginal failure rates. The present scalar theorem therefore does not prove a polynomial or Hankel-vector analogue of (6.38).

## 6.13. A finite counterexample to a fixed-bit-length extension

Changing the support of the secrets changes the averages in Lemmas 6.7–6.9. The exact digit and conditional-grid identities remain available for \(0\le x,y<Q\), but their averaging law must be changed explicitly.

**Counterexample 6.13 — Exactly seven-bit secrets need not attain three-quarters agreement.** Set
\[
q=7,\quad p=15,\quad Q=128,\quad P=32768,
\]
retain \(A\) uniform on \(\{0,\ldots,P-1\}\), but draw independent \(X,Y\) uniformly from \(\{64,\ldots,127\}\). Using the same public and extraction formulas,
\[
\Pr[W_A=W_B]
=\frac{12540509}{16777216}
=\frac34-\frac{42403}{16777216}<\frac34.
\tag{6.41}
\]

*Exact finite verification.* Restricting (6.37) to the upper-half secrets produces the fraction in (6.41), with reduced denominator \(Q^2(Q/2)^2\) before cancellation. A separate C++ program evaluates the original modular-publication and key formulas directly over every one of the \(32768\cdot64^2=134217728\) triples. It finds exactly \(100324072\) agreements. Reduction of \(100324072/134217728\) gives (6.41). The program uses no gcd-grid formula for that direct check. Both computations were executed and their integer equality is verified in `verify_ch6.py`. \(\square\)

This does not refute Theorem 6.11, whose secret law is different. Nor is it an attack against a noisy or polynomial construction. It is a counterexample to transferring the full-range agreement constant by silently replacing the support. For orientation, the exact upper-half probabilities at \(q=1,\ldots,7\) are, respectively,
\[
1,\quad \frac{15}{16},\quad\frac{445}{512},\quad
\frac{1671}{2048},\quad\frac{3197}{4096},\quad
\frac{796099}{1048576},\quad\frac{12540509}{16777216}.
\tag{6.42}
\]
These are finite diagnostics, not evidence of a limiting law. The proof of two-digit reduction also explains their independence from higher public digits under the stated full-period public distribution, but no upper-half asymptotic bound is claimed here.

## 6.14. Agreement and passive prediction coexist

The full-range model of Section 6.2 satisfies the assumptions of Chapter 5's posterior-replacement theorem: independent uniform interval secrets, deterministic separate publications, public parameters, and no additional private state or reconciliation message. Its extraction maps are exactly those of Chapter 5 with \(D=Q\).

**Corollary 6.14 — The three-quarters guarantee is not secrecy.** In this same model, the Chapter 5 exact posterior sampler yields an expected-polynomial-time passive predictor \(W^*\) satisfying
\[
\Pr[W^*=W_B]=\alpha_q\ge c_*.
\tag{6.43}
\]
A test accepting a supplied candidate key when it equals \(W^*\) has real-versus-independent-uniform acceptance gap
\[
\alpha_q-\frac1J\ge c_*-\frac1J\ge c_*-\frac12>\frac14.
\tag{6.44}
\]

*Proof.* Sample \(X^*\) from the exact conditional law of \(X\) given \((A,U)\), using the interval counter and ranked selection of Chapter 5. Conditional on the public transcript, \((Y,X^*)\) has the same law as \((Y,X)\), so applying Alice's extraction with \(X^*\) yields exactly the honest agreement probability with Bob. Against a fresh uniform challenge key in an alphabet of size \(J\), an independent valid predictor equals it with probability \(1/J\). Subtract and apply Theorem 6.11 and \(J\ge2\). \(\square\)

The advantage convention in (6.44) is the absolute difference of acceptance probabilities, not the success bias of an equiprobable challenge-bit game; that bias is half as large. To obtain a strict polynomial running-time bound, cap the posterior sampler at \(t=\lambda\) trials as in Chapter 5 v1.1. A valid fallback gives a failure allowance at most \(2^{-\lambda}\), which is subtracted from the real acceptance lower bound. The time is polynomial in the binary input length and the numerical cap \(t\); no arbitrarily large binary-encoded cap is declared free.

The result does not require uniqueness of the sampled secret. It does not recover the original secret pointwise and does not cover an unspecified extra exchange message. It also does not transfer to a multidimensional posterior for which no efficient sampling algorithm has been supplied. High honest agreement is therefore compatible with the negative security conclusion proved for SCALAR-INTERVAL in Chapter 5.

## 6.15. Reproducibility, attribution, and transition to the next chapters

The accompanying package separates the analytic proof, the finite closure, and implementation checks. The Python verification layer uses arbitrary-precision integers and exact fractions; no Monte Carlo rate or floating-point comparison determines a theorem's acceptance.

The supplied exact C++ closure counter exposes two modes for the same proved conditional count. The `quotient` mode subtracts the two integer quotients in (6.18). The `crossing` mode counts the crossing interval on the grid \(s+gj\), using a floor for a positive displacement and a ceiling for a negative displacement. They are two implementations of one counting lemma, not two independent mathematical proofs. Direct checks of (6.3)–(6.4) supply an additional, differently organized comparison on small full-range profiles and the seven-bit upper-half example.

| Verification family | Extent executed in this chapter |
|---|---:|
| Signed carry inputs | 1,530 |
| Modular cell inputs | 144,170 |
| Independent-dither parameter cases | 55,300 |
| Joint remainder image cases | 1,495 |
| Conditional grid cases | 18,495 |
| Explicit grid atoms within those cases | 243,847 |
| Direct full-range protocol triples, \(q\le4\), two moduli per size | 419,424 |
| Product-gcd pairs, \(q=1,\ldots,10\) | 1,398,100 |
| Exact decoupling/variance identities | 11 |
| Exact continuous–discrete means | 63 |
| Finite-closure rows, each evaluated by both C++ modes | 11 |
| Direct upper-half protocol triples | 134,217,728 |

The categories count different mathematical objects and must not be added into a spurious number of independent cryptographic experiments. Additional scope and coarsening checks are recorded in `supplementary/chapter-06/results.json`. The full-range closure fractions are reproduced by the supplied exact counters; this is a verification of the stated theorem, not a claim of novelty for the counting method.

For \(q\le11\), \(Q\le2048\). Products in the counting summands are below \(Q^2\), the count is at most \(Q^4\le2^{44}\), and the fourfold comparison is at most \(2^{46}\). Unsigned 64-bit accumulators and explicitly signed differences suffice. The code rejects larger requested exponents rather than extending this range without a new bound. The direct upper-half checker has fixed, separately bounded seven-bit parameters. Neither counter is claimed polynomial in \(q\): enumeration in \(Q=2^q\) is exponential in its bit length. It is used for eleven fixed cases; the analytic proof covers all remaining parameters.

From `supplementary/chapter-06/`, run the delivered verification entry points:

```sh
python3 verify.py
python3 verify_independent.py
```

The primary closure requires a C++17 compiler because it recompiles the exact finite counter from source. SHA-256 hashes identify the delivered files. No proof-assistant certification, external peer review, or exhaustive novelty search is claimed. The public supplementary package records the executable checks and their expected outputs.

The methodological conclusion is not that all rounding is harmless or that agreement implies hardness. It is that a joint remainder law can be retained exactly, counted on its actual arithmetic support, and bounded through a justified comparison rather than an independence guess. The next mathematical chapters can use these tools when they explicitly establish their own sampling laws. The polynomial article remains a separate research task; no universal scalar constant or scalar inversion theorem is exported to it without a proved correspondence.



## Supplementary Material and Reproducibility — Chapter 6

The public supplementary material for this chapter is assigned to `supplementary/chapter-06/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 7 — General Moduli and Alignment {#ch7}
## Prime Divisors, Asymptotic Agreement, and Limits of the Three-Quarters Guarantee


**Scope.** The proofs and finite certificate apply only to the explicitly defined experiments and parameter conditions.

### Abstract

Chapter 6 established a three-quarters agreement guarantee for an exactly specified full-range scalar experiment with power-of-two parameters. This chapter examines what remains true when the moduli are general integers. The distinction between divisibility by the public quotient divisor and divisibility by its square is decisive. For the aligned family \(P=JQ^2\), \(J\ge2\), the agreement probability is independent of \(J\), admits an exact conditional count, and satisfies a lower bound expressed through two multiplicative gcd averages. A computer-assisted finite closure establishes the three-quarters guarantee for every prime divisor \(Q\); the binary result of Theorem 6.11 also extends to arbitrary aligned multipliers \(J\). A Fourier argument and a divisor bound prove that aligned agreement tends to \(41/54\) along all integer divisors tending to infinity. In contrast, an explicit nonaligned family has a limiting agreement strictly below three quarters. Exact finite counterexamples and reproducible arithmetic checks accompany the proofs. Weak equidistribution is not confused with statistical independence at finite parameters, and agreement is not confused with secrecy. The scalar posterior-sampling attack remains applicable. No security result for polynomial, noisy, WC, NOISE or BLINDAGE constructions is inferred.

### Scope and relationship to the thesis

This chapter gives the aligned and nonaligned arguments in full, states their relationship with Chapters 5 and 6, and regenerates the finite data used in its conclusions. No worldwide-priority claim is made for the elementary counting, Fourier or divisor-estimate tools.

A separate historical interpretation associated with a 2022 label is **not** authenticated or imported by this chapter. The documentary limitations identified in Chapter 4 remain distinct. Only the explicitly defined full-range experiment below is used for the numbered results. The prospective Hankel-LWE/MP-LWE investigation belongs to thesis V2, and the polynomial article remains a separate project.

## 7.1. A normalized extension, not an identification of historical versions

Let \(P>Q\ge2\) be integers. For every positive integer \(m\), \([z]_m\) denotes the canonical residue of an integer \(z\). Define
\[
F_{P,D}(z)=\left\lfloor\frac{[z]_P}{D}\right\rfloor,
\qquad D\in\mathbb Z_{>0}.
\tag{7.1}
\]
All divisions are Euclidean floor divisions. Sample independently
\[
A\leftarrow\operatorname{Unif}\{0,\ldots,P-1\},\qquad
X,Y\leftarrow\operatorname{Unif}\{0,\ldots,Q-1\}.
\tag{7.2}
\]
The publications and local outputs are
\[
U=F_{P,Q}(AX),\qquad V=F_{P,Q}(AY),
\tag{7.3}
\]
\[
W_A=F_{P,Q^2}(QXV),\qquad
W_B=F_{P,Q^2}(QYU).
\tag{7.4}
\]
Write \(\alpha(P,Q)=\Pr[W_A=W_B]\). These formulas define experiment **G** in this chapter. They include no explicit noise, confirmation message, reconciliation hint, or further removal of low-order output bits.

The final divisor in (7.4) is the integer square \(Q^2\). It is not a bit-length-based quantity \(2^{2q}\) unless \(Q=2^q\) is explicitly imposed. Likewise, (7.2) includes zero and is not a distribution on integers having exactly a prescribed positive bit length. These conventions must not be silently changed.

The quotient alphabet in (7.4) is contained in
\[
\{0,\ldots,J_0-1\},\qquad
J_0=\left\lceil\frac P{Q^2}\right\rceil.
\tag{7.5}
\]
If \(P\le Q^2\), both outputs are identically zero and agreement equals one. This is a degenerate comparison, not useful key agreement. If \(Q=1\) were allowed, both secrets would also be zero. The substantial statements below concern nonconstant output alphabets, but finite checks include degenerate cases to guard against incorrect generalizations.

When \(P=2^p\), \(Q=2^q\), \(q\ge1\), and \(p>2q\), this experiment is exactly that of Chapter 6. No new equivalence of historical protocols is asserted.

## 7.2. The identity that survives without divisibility

Removing the power-of-two hypothesis does not destroy Euclidean division. It does change which remainder must be used.

**Proposition 7.1 — Exact common-product cancellation for general moduli.** For any integer multiplier \(A\), with \(P,Q\) as above and \(0\le x,y<Q\), put
\[
r_x=[[Ax]_P]_Q,\qquad r_y=[[Ay]_P]_Q.
\tag{7.6}
\]
Then
\[
[QxV]_P=[Axy-xr_y]_P,\qquad
[QyU]_P=[Axy-yr_x]_P.
\tag{7.7}
\]
Consequently, an integer representative of their modular difference is
\(yr_x-xr_y\), whose absolute value is at most \((Q-1)^2\).

*Proof.* The two exact Euclidean decompositions are
\[
Ax=Pk_x+QU+r_x,\qquad Ay=Pk_y+QV+r_y.
\]
Multiply the second by \(x\), the first by \(y\), and reduce modulo \(P\). This gives (7.7). Both \(yr_x\) and \(xr_y\) lie in \([0,(Q-1)^2]\); their difference in absolute value is therefore at most \((Q-1)^2\), not twice that value. The associated bound is on circular distance modulo \(P\), not on the ordinary distance between canonical residues. \(\square\)

When \(Q\nmid P\), the replacement \(r_x=[Ax]_Q\) is generally false. For example, \(P=5,Q=3,A=3,x=2\) gives \([[Ax]_P]_Q=1\), whereas \([Ax]_Q=0\). Moreover, even if \(Q\mid P\), a quotient by \(Q^2\) can have an incomplete final cell. Small circular discrepancy alone then says even less about agreement.

The exact integer equation before any cancellation of \(Q\) is
\[
Q(xV-yU)=P(yk_x-xk_y)+yr_x-xr_y.
\tag{7.8}
\]
Only when \(Q\mid P\) can its division be interpreted immediately as a congruence modulo \(P/Q\) with the simple remainder structure of Chapters 5 and 6. Equation (7.7), however, needs no such divisibility.

## 7.3. Finite counterexamples delimit the extension

**Counterexample 7.2 — General moduli, separate primality, and single divisibility are insufficient.** In experiment (7.2)–(7.4), each of the following agreement probabilities is strictly below \(3/4\):

| \(P\) | \(Q\) | Agreements | Total triples | Exact probability |
|---:|---:|---:|---:|---:|
| 217 | 12 | 23,398 | 31,248 | \(11699/15624\) |
| 409 | 17 | 86,295 | 118,201 | \(86295/118201\) |
| 6,144 | 64 | 18,398,712 | 25,165,824 | \(766613/1048576\) |

*Exact finite verification.* The supplied `count_general_counterexamples.cpp`, invoked by `verify_general_counterexamples.py`, evaluates (7.3)–(7.4) for every \((A,x,y)\) in all three displayed product domains and checks the exact agreement numerators. The separately written Python path in `verify_independent.py` direct-enumerates the first two profiles. The third profile is also a member of the nonaligned family of Section 7.12 and is checked against its stored exact family row. All comparisons are integer comparisons; no decimal approximation determines acceptance. \(\square\)

Both 409 and 17 are prime, so separate primality does not suffice. In the third case, \(P=96Q=3Q^2/2\): \(Q\) is a power of two and divides \(P\), but \(Q^2\) does not divide \(P\). This refutes a single-divisibility extension of Chapter 6. It does not refute that chapter, whose parameters are different.

This chapter does **not** claim that the displayed counterexamples are minimal; their role is only to refute the explicitly stated universal implications.

## 7.4. Full alignment restores the two-digit reduction

Now assume
\[
P=JQ^2,\qquad Q\ge2,\quad J\ge2,
\tag{7.9}
\]
with no primality or power-of-two restriction. Decompose the uniform multiplier as
\[
A=a+Qh+Q^2z,\qquad
0\le a,h<Q,\quad 0\le z<J.
\tag{7.10}
\]
The three digits are independent uniforms. Define, for fixed \(a,x,y\),
\[
f_a(x)=\lfloor ax/Q\rfloor,\quad \rho_a(x)=[ax]_Q,
\quad u=xf_a(y),\quad v=yf_a(x),\quad \Delta=v-u.
\tag{7.11}
\]
The symbol \(u\) in (7.11) is an integer auxiliary quantity, not the publication \(U\).

**Theorem 7.3 — Alignment and independence of the upper multiplier.** Under (7.9),
\[
Q\Delta=x\rho_a(y)-y\rho_a(x),\qquad |\Delta|<Q,
\tag{7.12}
\]
and
\[
W_A=W_B\quad\Longleftrightarrow\quad
0\le [xyh+u]_Q+\Delta<Q.
\tag{7.13}
\]
In particular, \(\alpha(JQ^2,Q)\) is independent of \(J\ge2\). Denote this common value by \(\alpha_Q\).

*Proof.* Expand \(ax=Qf_a(x)+\rho_a(x)\) and \(ay=Qf_a(y)+\rho_a(y)\). Multiplication and subtraction give (7.12); the numerator has absolute value at most \((Q-1)^2<Q^2\). Put \(H=P/Q=JQ\). Since \([Qw]_P=Q[w]_H\), the outputs in (7.4) equal \(\lfloor[xV]_H/Q\rfloor\) and \(\lfloor[yU]_H/Q\rfloor\). Furthermore,
\[
U\equiv f_a(x)+hx+Qzx\pmod H,\qquad
V\equiv f_a(y)+hy+Qzy\pmod H.
\tag{7.14}
\]
Thus \(yU-xV\equiv\Delta\pmod H\), and the remainder of \(xV\) modulo \(Q\) is \([xyh+u]_Q\). Crossing from Alice's value to Bob's changes the quotient by
\(\lfloor([xyh+u]_Q+\Delta)/Q\rfloor\), modulo \(J\). This integer lies in \(\{-1,0,1\}\); only zero preserves the output when \(J\ge2\). This proves (7.13). The event depends only on the uniformly distributed \(a,h,x,y\), not on \(z\) or \(J\). \(\square\)

This theorem generalizes the arithmetic reduction in Chapter 6, not its averaging law by assertion. The excluded case \(J=1\) has constant output. Nor does independence of agreement from \(J\) imply independence or uniformity of the keys themselves.

## 7.5. Exact counting on the reachable phase grid

For fixed \(a,x,y\), let
\[
g=\gcd(xy,Q),\qquad m=Q/g,
\quad \gcd(0,Q)=Q.
\]
As \(h\) ranges uniformly modulo \(Q\), the phase \([xyh+u]_Q\) is uniform on a coset modulo \(g\), with \(m\) points.

**Proposition 7.4 — Conditional count and grid error.** In the aligned model,
\[
\Pr[W_A\ne W_B\mid a,x,y]
=\frac gQ\left|\left\lfloor\frac vg\right\rfloor-
                 \left\lfloor\frac ug\right\rfloor\right|.
\tag{7.15}
\]
Moreover,
\[
\left|g\left|\lfloor v/g\rfloor-\lfloor u/g\rfloor\right|-|v-u|\right|
\le g-1.
\tag{7.16}
\]

*Proof.* Write \(u=gU_0+s\) and \(v=gV_0+r\), with \(0\le s,r<g\). The accessible phase is \(s+gj\), with \(j\) uniform in \(\{0,\ldots,m-1\}\). Its displacement gives
\[
s+gj+\Delta=g(j+V_0-U_0)+r.
\]
Agreement is equivalent to \(0\le j+c<m\), where \(c=V_0-U_0\). Since \(|gc+r-s|<gm\), one has \(|c|\le m\). Exactly \(|c|\) of the \(m\) indices fall outside. This proves (7.15). Apply the reverse triangle inequality to \(v-u=gc+r-s\) to obtain (7.16). Zero secrets give \(u=v=0\) and zero disagreement. \(\square\)

The corresponding exact count is
\[
\begin{split}
N_{\rm err}(Q)&=\sum_{a,x,y=0}^{Q-1}
 g_{x,y}\left|\left\lfloor\frac{yf_a(x)}{g_{x,y}}\right\rfloor-
                \left\lfloor\frac{xf_a(y)}{g_{x,y}}\right\rfloor\right|,\\
\alpha_Q&=1-\frac{N_{\rm err}(Q)}{Q^4},\qquad
 g_{x,y}=\gcd(xy,Q).
\end{split}
\tag{7.17}
\]
Here \(Q^4\) counts reduced states \((a,h,x,y)\). The original experiment has \(PQ^2=JQ^4\) triples, with each reduced state repeated \(J\) times. Computing (7.17) by loops is exponential in \(\log Q\); it is used only for explicit finite ranges, not as a general efficient sampler.

## 7.6. Gcd averages for arbitrary integer divisors

For uniform independent \(X,Y\) modulo \(Q\), define
\[
G_1(Q)=\mathbb E\gcd(X,Q),\qquad
G_2(Q)=\mathbb E\gcd(XY,Q).
\tag{7.18}
\]
Both averages include zero. The convention \(\gcd(0,Q)=Q\) is important.

**Lemma 7.5 — Multiplicative formulas.** If
\(Q=\prod_{\ell^e\parallel Q}\ell^e\) is its prime factorization and
\(u_\ell=1-1/\ell\), then
\[
G_1(Q)=\prod_{\ell^e\parallel Q}(1+e u_\ell),
\tag{7.19}
\]
\[
G_2(Q)=\prod_{\ell^e\parallel Q}
\left(1+e u_\ell+\frac{e(e+1)}2u_\ell^2\right).
\tag{7.20}
\]
Also \(\mathbb E[\gcd(X,Q)\mathbf1_{X>0}]=G_1(Q)-1\).

*Proof.* First take \(Q=\ell^e\). For \(1\le j\le e\), splitting according to the valuation of \(X\) below \(j\), and separately the event \(\ell^j\mid X\), gives
\[
\Pr[\ell^j\mid XY]
=\sum_{i=0}^{j-1}(1-1/\ell)\ell^{-i}\ell^{-(j-i)}+\ell^{-j}
=\ell^{-j}(1+j u_\ell).
\tag{7.21}
\]
The last event includes zero; no finite valuation is assigned to zero. Use
\[
\gcd(XY,\ell^e)=1+\sum_{j=1}^e
 (\ell^j-\ell^{j-1})\mathbf1_{\ell^j\mid XY}
\]
and take expectations. Each summand contributes \(u_\ell(1+j u_\ell)\), yielding the local factor in (7.20). The same identity with \(X\) alone and probability \(\ell^{-j}\) yields \(1+e u_\ell\). The Chinese remainder bijection makes the prime-power coordinates of a uniform residue independent; gcd factors multiply across them. Finally, \(X=0\) contributes \(Q\cdot(1/Q)=1\) to \(G_1\). \(\square\)

For \(Q=2^q\), these formulas recover
\(G_1=1+q/2\) and \(G_2=1+q(q+5)/8\). For prime \(Q\),
\[
G_1(Q)-1=1-1/Q,\qquad
G_2(Q)-1=2-3/Q+1/Q^2.
\tag{7.22}
\]
The formulas are efficiently evaluable *given a factorization*. No polynomial-time integer factorization algorithm is claimed. Trial division in the reference code serves only its small verification domains.

## 7.7. A sufficient agreement bound for every aligned divisor

Let
\[
\mathcal D_Q=\frac1{Q^2}\mathbb E_{a,X,Y}
 |X\rho_a(Y)-Y\rho_a(X)|,
\tag{7.23}
\]
where \(a,X,Y\) are independent uniforms modulo \(Q\). Define
\[
\mathcal J_Q=\frac{13}{54}-\frac1{9Q}-\frac1{54Q^2}-\frac1{9Q^3}.
\tag{7.24}
\]

**Theorem 7.6 — General finite lower bound.** For every integer \(Q\ge2\),
\[
\boxed{\alpha_Q\ge
1-\mathcal J_Q-
\frac{Q-1}{2Q^2}\bigl(G_1(Q)-1\bigr)-
\frac{G_2(Q)-1}{Q}.}
\tag{7.25}
\]

*Proof.* Averaging (7.16) and using \(Q\Delta=x\rho_a(y)-y\rho_a(x)\) gives the two-sided comparison
\[
|1-\alpha_Q-\mathcal D_Q|\le\frac{G_2(Q)-1}{Q}.
\tag{7.26}
\]
Next introduce a second independent uniform multiplier \(b\) and define
\(\mathcal D_Q^{\rm ind}=Q^{-2}\mathbb E|X\rho_b(Y)-Y\rho_a(X)|\).
For \(t\ge0\), put
\[
L_a(t)=\frac1Q\sum_{x=1}^{Q-1}x\mathbf1_{\rho_a(x)>tx}.
\]
For positive \(x,y\),
\[
\min(x\rho_a(y),y\rho_a(x))
=xy\int_0^\infty\mathbf1_{\rho_a(x)>tx}\mathbf1_{\rho_a(y)>ty}\,dt.
\]
Averaging over independent identically distributed \(X,Y\) gives
\(\int L_a(t)^2dt\). With separate multipliers, the average is
\(\int(\mathbb E_a L_a(t))^2dt\). The linear terms in
\(|r-s|=r+s-2\min(r,s)\) have identical expectations. Hence
\[
\mathcal D_Q^{\rm ind}-\mathcal D_Q
=\frac2{Q^2}\int_0^\infty\operatorname{Var}_a L_a(t)\,dt\ge0.
\tag{7.27}
\]
This is a proved comparison of one average, not a replacement of the protocol's joint remainder law by independent noise.

For \(x>0\), put \(d_x=\gcd(x,Q)\). If \(R\) is uniform on \([0,Q)\), then \(d_x\lfloor R/d_x\rfloor\) has exactly the law of \(\rho_a(x)\), with mean rounding loss \(d_x/2\). Two independent continuous uniforms \(R,S\) therefore give
\[
\mathbb E|x\rho_b(y)-y\rho_a(x)|
\le\mathbb E|xS-yR|+\frac{x d_y+y d_x}{2}
\]
for positive secrets. When a secret is zero the discrete determinant is zero; it is bounded by the nonnegative continuous expression without charging a gcd cost at zero. Averaging over \(X,Y\), using \(\mathbb E X=(Q-1)/2\) and Lemma 7.5, yields
\[
\mathcal D_Q^{\rm ind}
\le\mathcal J_Q+\frac{Q-1}{2Q^2}\bigl(G_1(Q)-1\bigr).
\tag{7.28}
\]
For completeness, the continuous average is obtained by integrating at fixed \(0\le x\le y\), \(y>0\):
\[
\int_0^1\!\int_0^1
\left|\frac xQ t-\frac yQ s\right|ds\,dt
=\frac{y-x}{2Q}+\frac{x^2}{3Qy}.
\]
Include the zero pair, diagonal and both off-diagonal halves, then sum over the integers to obtain exactly (7.24). Combining (7.26)–(7.28) proves (7.25). \(\square\)

A value below \(3/4\) on the right side of (7.25) is inconclusive: it is not a counterexample to the actual probability. A negative right side can simply be replaced by the trivial lower bound zero. The analysis keeps the finite grid error and the continuous comparison error separate.

## 7.8. A nonbinary positive family: prime divisors

**Theorem 7.7 — Three-quarters agreement for prime aligned divisors.** In (7.2)–(7.4), if \(Q\) is prime and \(P=JQ^2\) with integer \(J\ge2\), then
\[
\alpha(P,Q)=\alpha_Q>3/4.
\tag{7.29}
\]

*Proof, including a finite computer-assisted part.* For prime \(Q\), (7.22) and \(\mathcal J_Q<13/54\) imply
\[
\alpha_Q>\frac{41}{54}-\frac{5}{2Q}.
\tag{7.30}
\]
For \(Q\ge271\),
\[
\frac{41}{54}-\frac5{542}
=\frac34+\frac1{29268}>\frac34.
\tag{7.31}
\]
The remaining primes are exactly the 57 primes from 2 through 269. The supplied Python generator `regenerate_prime_certificate.py` recomputes all 57 rows using exact integer arithmetic, and the separately organized direct protocol verifier checks the prime cases through \(Q=11\). For each row, the recorded integer margin \(4N_{\rm agree}-3Q^4\) is positive. The complete certificate is reproduced in Appendix A. Thus (7.30) handles every remaining prime and the finite certificate closes the argument. \(\square\)

The minimum in this **finite list**, not necessarily a globally minimal prime case, occurs at 269:
\[
\alpha_{269}=\frac{3998522585}{5236114321}>3/4.
\tag{7.32}
\]
The prime-certificate generator and the direct small-prime verifier are differently organized checks of the same finite statement, not two independent mathematical proofs. The generator covers all 57 primes through 269; the direct protocol enumeration covers the prime cases through 11.

For a nonbinary example outside the finite certificate, take \(Q=509\) and \(P=3\cdot509^2=777243\). The sharper bound (7.25) gives
\[
\alpha(777243,509)\ge\frac{895575053}{1186850061}>3/4.
\tag{7.33}
\]
This fraction is a lower bound, not an exact enumeration of that profile. Neither modulus is a power of two.

## 7.9. What the binary theorem already implies

**Corollary 7.8 — Power-of-two divisors with arbitrary aligned multipliers.** For \(Q=2^q\), \(q\ge1\), and every integer \(J\ge2\),
\[
\alpha(JQ^2,Q)\ge\frac{166397}{221184}>3/4.
\tag{7.34}
\]

*Proof.* Theorem 7.3 makes agreement independent of \(J\ge2\). Choose \(J=2\); then \(P=2^{2q+1}\), so Theorem 6.11 applies with exactly the same secret and public laws. Transfer its agreement value back using the same invariance. \(\square\)

No requirement that \(J\) itself be a power of two is needed. The eleven binary closure computations of Chapter 6 are inherited as an identified prior result; they are not rerun or counted as new experiments here. The present chapter does not claim a uniform \(3/4\) theorem for **every** finite composite \(Q\). It will establish an asymptotic statement that implies a guarantee for all sufficiently large integer \(Q\), without an explicit universal cutoff.

## 7.10. Equidistribution and the average grid defect

The following argument supplies an exact limit, stronger than the liminf conclusion obtained from the simpler bound in Chapter 6.  The Fourier criterion used to pass from characters to weak convergence is classical; ([B20](#bib-b20); Section 1, Proposition 1) gives its standard proof by density of trigonometric polynomials. We apply that density argument to a sequence of probability measures, not by asserting that our triangular array is a single polynomial orbit.

**Lemma 7.9 — Weak equidistribution of the four scaled coordinates.** With independent \(a,X,Y\) uniform modulo \(Q\), the vector
\[
Z_Q=\left(\frac XQ,\frac YQ,
          \frac{[aX]_Q}{Q},\frac{[aY]_Q}{Q}\right)
\tag{7.35}
\]
converges weakly, as the integer \(Q\to\infty\), to four independent uniforms on \([0,1]\).

*Proof.* Regard the vector first as a point of the torus \((\mathbb R/\mathbb Z)^4\). For fixed integers \((i,j,k,l)\), averaging its character over \(X,Y\) gives exactly
\[
\begin{split}
&\mathbb E\exp\bigl(2\pi\mathrm i(iZ_{Q,1}+jZ_{Q,2}+kZ_{Q,3}+lZ_{Q,4})\bigr)\\
&\qquad=\frac1Q\#\{a\bmod Q:i+ka\equiv0,\ j+la\equiv0\pmod Q\}.
\end{split}
\tag{7.36}
\]
Finite character orthogonality proves the equality. If \(k\ne0\), the first congruence has either no solutions or \(\gcd(k,Q)\le|k|\) solutions, so the coefficient is at most \(|k|/Q\). The same argument uses \(l\) when \(k=0,l\ne0\). If \(k=l=0\) and the frequency is nonzero, at least one of \(i,j\) is a fixed nonzero integer; the coefficient is zero for all sufficiently large \(Q\). Thus all nonconstant character expectations vanish in the limit, while the constant coefficient is one.

Linearity gives convergence against every trigonometric polynomial. Their uniform density among continuous torus functions gives weak convergence to Haar measure. Passing to canonical representatives in the cube creates discontinuities only on the coordinate faces, a set of Haar measure zero. One may exclude a small neighborhood of those faces, approximate continuously on the complement and let its measure tend to zero. This gives the claimed weak convergence on the cube. \(\square\)

**This is not finite-parameter independence or total-variation convergence.** Every law of \(Z_Q\) is discrete, whereas the limiting product law is continuous; their total variation distance is one. Weak convergence controls fixed bounded continuous functions, and bounded functions with discontinuities on a limiting null set. It does not justify dropping public side information, choosing a growing adversarial test, or claiming computational secrecy.

**Lemma 7.10 — Sublinear average gcd defect.** For every \(\varepsilon>0\),
\[
G_2(Q)=O_\varepsilon(Q^\varepsilon),
\qquad \frac{G_2(Q)-1}{Q}\longrightarrow0.
\tag{7.37}
\]

*Proof.* Every local factor in (7.20) is at most
\(1+e+e(e+1)/2=(e+1)(e+2)/2\). Hence
\[
G_2(Q)\le\prod_{\ell^e\parallel Q}\binom{e+2}{2}=d_3(Q),
\tag{7.38}
\]
where \(d_3\) counts ordered triples of positive integers whose product is \(Q\). For every integer \(e\ge0\), \(\binom{e+2}{2}\le3^e\), for instance by induction on \(e\). For primes \(\ell\) with \(\ell^\varepsilon\ge3\), the local factor is at most \(\ell^{\varepsilon e}\). There are finitely many other primes; for each of them, the ratio \(\binom{e+2}{2}/\ell^{\varepsilon e}\) is bounded over \(e\ge0\), since an exponential dominates a fixed polynomial. Multiplying those finitely many constants proves the first assertion uniformly in \(Q\). Choose \(0<\varepsilon<1\) for the second. \(\square\)

The proof does not require an efficiently computed factorization of an input integer. It is an analytic bound on all integers. Conversely, the elementary trial-division verification code does not constitute an efficient cryptographic factoring algorithm.

## 7.11. The exact aligned limit

**Theorem 7.11 — Agreement tends to \(41/54\) for all aligned divisors.** Along every sequence of integers \(Q\to\infty\), and with any integer-valued \(J(Q)\ge2\),
\[
\lim_{Q\to\infty}\alpha(J(Q)Q^2,Q)=\frac{41}{54}.
\tag{7.39}
\]

*Proof.* By Lemma 7.9, the expectation of the bounded cube-continuous function
\(|xv-yu|\) evaluated at (7.35) converges to its integral under four independent uniforms. This expectation is exactly \(\mathcal D_Q\). Let \(Z_1,Z_2\) be independent products of two independent uniform \([0,1]\) variables. For \(0<t<1\), integration gives
\[
\Pr[Z_1>t]=1-t+t\log t,\qquad \mathbb E Z_1=\frac14.
\tag{7.40}
\]
Thus
\[
\mathbb E\min(Z_1,Z_2)=\int_0^1(1-t+t\log t)^2dt=\frac7{54},
\]
\[
\mathbb E|Z_1-Z_2|=\frac12-2\cdot\frac7{54}=\frac{13}{54}.
\tag{7.41}
\]
The elementary integrals may be checked using
\(\int_0^1 t^a(\log t)^b dt=(-1)^b b!/(a+1)^{b+1}\) for \(a>-1\) and integer \(b\ge0\), obtained by differentiating \(1/(a+1)\). Hence \(\mathcal D_Q\to13/54\). The two-sided grid estimate (7.26), together with Lemma 7.10, implies \(1-\alpha_Q\to13/54\). Theorem 7.3 removes any dependence on \(J(Q)\). \(\square\)

Because \(41/54-3/4=1/108>0\), all sufficiently large aligned integer divisors, including composite ones, have agreement above \(3/4\). This is a qualitative eventual statement: no explicit cutoff for all composite divisors is supplied. Nor does the limit prove monotonicity of the probabilities or bound every smaller composite case. A finite lower bound such as (7.25) remains a distinct tool.

## 7.12. A nonaligned family with infinitely many violations

Return to experiment G, but choose
\[
Q=2^s,\quad s\ge1,\qquad
P=\frac32Q^2,\qquad H=P/Q=\frac32Q.
\tag{7.42}
\]
Here \(Q\mid P\) but \(Q^2\nmid P\). We have \(A=a+Qh\), with independent uniform \(a\in[0,Q)\) and \(h\in[0,H)\). Define \(u,v,\Delta\) as in (7.11), so \(|\Delta|<Q\). Direct quotient algebra gives
\[
W_A=\lfloor T/Q\rfloor,\qquad
W_B=\lfloor[T+\Delta]_H/Q\rfloor,
\quad T=[xyh+u]_H.
\tag{7.43}
\]
The two cells on this circle now have lengths \(Q\) and \(Q/2\), not two equal lengths.

**Lemma 7.12 — Unequal-cell phase comparison.** On the circle of length \(H=3Q/2\), let the cell label be \(C(t)=\lfloor[t]_H/Q\rfloor\). For a continuous uniform phase and integer \(|\delta|<Q\), its disagreement probability is
\[
\psi_Q(\delta)=\frac43\min\left(\frac{|\delta|}{Q},\frac12\right).
\tag{7.44}
\]
If instead the phase is uniform on any residue class modulo \(g\), where \(g\mid H\), the difference from (7.44) is at most \(4g/H\).

*Proof.* Label one denotes the short circular arc of length \(Q/2\). Disagreement is the symmetric difference between this arc and its translate by \(\delta\). Its total length is \(2\min(|\delta|,Q/2)\): for the specified shifts, the other circular direction has length at least \(Q/2\), and the short arc ceases overlapping once the shift reaches its length. Divide by \(H\) to obtain (7.44).

In canonical coordinates, that symmetric difference is a union of at most four half-open intervals, after splitting at the circular origin when necessary. For any one interval of length \(b\), the number of points from a \(g\)-spaced residue class differs from \(b/g\) by at most one. Dividing by its total number \(H/g\) bounds the probability error by \(g/H\) per interval. Sum the four bounds. Endpoint conventions are consistent with the half-open quotient cells. \(\square\)

**Theorem 7.13 — A nonaligned limiting agreement below three quarters.** For (7.42), the limit
\[
\beta=\lim_{s\to\infty}\alpha(3Q^2/2,Q)
\tag{7.45}
\]
exists and satisfies
\[
\beta=1-\frac43\mathbb E\min(|Z_1-Z_2|,1/2)
\le\frac{83}{162}+\frac{\log2}{3}
<\frac{241}{324}<\frac34,
\tag{7.46}
\]
where \(Z_1,Z_2\) are as in the proof of Theorem 7.11. Therefore all sufficiently large members of this nonaligned family violate the three-quarters bound.

*Proof.* Conditional on \(a,x,y\), \(T\) in (7.43) is uniform on a class modulo \(g=\gcd(xy,H)\). Its disagreement differs from (7.44) by at most \(4g/H\). Since the gcd is nonnegative and \([0,Q)^2\subset[0,H)^2\),
\[
\mathbb E_{x,y<Q}\gcd(xy,H)
\le\frac{H^2}{Q^2}G_2(H)=\frac94G_2(H).
\tag{7.47}
\]
For \(H=3\cdot2^{s-1}\), Lemma 7.5 gives
\[
G_2(H)=\frac{19}{9}
\left(1+\frac{s-1}{2}+\frac{s(s-1)}8\right)=O(s^2).
\tag{7.48}
\]
Thus the averaged phase error is at most \(9G_2(H)/H\), tending to zero. Also
\[
\frac{\Delta}{Q}=
\frac{x\rho_a(y)-y\rho_a(x)}{Q^2}.
\]
Lemma 7.9, applied modulo \(Q\), gives convergence of the expectation of its bounded clipped absolute value to \(\mathbb E\min(|Z_1-Z_2|,1/2)\). This proves the limit formula.

To bound that limit, the survival function (7.40) yields
\[
\mathbb E(Z_1-1/2)_+=\int_{1/2}^1(1-t+t\log t)dt
=-\frac1{16}+\frac{\log2}{8}.
\tag{7.49}
\]
For nonnegative \(z_1,z_2\),
\((|z_1-z_2|-1/2)_+\le(z_1-1/2)_++(z_2-1/2)_+\).
Using (7.41), therefore,
\[
\mathbb E\min(|Z_1-Z_2|,1/2)
\ge\frac{13}{54}+\frac18-\frac{\log2}{4}.
\tag{7.50}
\]
Substitution gives the nonrational upper bound in (7.46). To verify strictness without decimal arithmetic, expand
\[
\log2=2\sum_{j=0}^{\infty}\frac{3^{-(2j+1)}}{2j+1}
<\frac23+\frac23\sum_{j=1}^{\infty}3^{-(2j+1)}
=\frac{25}{36}.
\tag{7.51}
\]
The inequality is strict because terms beyond \(j=1\) have denominator greater than three. Since \(83/162+(25/36)/3=241/324<3/4\), the result follows. Convergence to a value strictly below \(3/4\) implies eventual strict violations; this proof does not provide an explicit universal threshold in \(s\). \(\square\)

The number \(83/162+\log2/3\) is an **upper bound**, not an evaluation of \(\beta\). Finite values do not replace this asymptotic argument:

| \(Q\) | \(P=3Q^2/2\) | Agreements | Total triples |
|---:|---:|---:|---:|
| 16 | 384 | 78,668 | 98,304 |
| 32 | 1,536 | 1,189,482 | 1,572,864 |
| 64 | 6,144 | 18,398,712 | 25,165,824 |
| 128 | 24,576 | 288,599,214 | 402,653,184 |

All four rows were directly recomputed. The first two exceed three quarters and the last two do not. This behavior illustrates why the theorem says “sufficiently large,” not “every member.”

## 7.13. General moduli do not evade the scalar posterior attack

Chapter 5's preimage-counting theorem was stated for arbitrary positive \(P,Q\), including \(Q\nmid P\). For a uniform interval secret, the posterior is uniform on the compatible integers and can be sampled exactly in expected polynomial time. The extraction rule in (7.4) is a publicly computable deterministic function of the transcript and one private scalar.

**Corollary 7.14 — Prediction with the honest agreement probability in experiment G.** For every fixed \(P>Q\ge2\), a passive algorithm using only \(\mathcal T=(P,Q,A,U,V)\) can produce \(W^*\) in expected polynomial time in the binary parameter lengths such that
\[
\Pr[W^*=W_B]=\alpha(P,Q).
\tag{7.52}
\]
If the challenge key is instead independent uniform on the alphabet of size \(J_0\) from (7.5), the equality test has real-minus-ideal acceptance gap
\[
\alpha(P,Q)-1/J_0.
\tag{7.53}
\]

*Proof.* Given \((A,U)\), sample \(X^*\) uniformly from the interval preimages of the first publication using Chapter 5's exact counting and rank-selection algorithm. Conditional on \((A,U,V)\), the original independent secrets have a product posterior: the first publication constrains only \(X\), the second only \(Y\). Thus \((\mathcal T,Y,X^*)\) has the same law as \((\mathcal T,Y,X)\). Set \(W^*=F_{P,Q^2}(QX^*V)\) and apply the agreement event to the two equal joint laws. This proves (7.52) without recovering the original secret pointwise. Against a fresh independent uniform key, any valid candidate equals it with probability \(1/J_0\), proving (7.53). \(\square\)

The absolute distinguishing advantage is the absolute value of the gap in (7.53); a positive lower bound follows from its positive part. A challenge-bit success-bias convention divides that advantage by two. A capped posterior sampler with \(t=\lambda\) rejection trials incurs a failure allowance at most \(2^{-\lambda}\); its running time is polynomial in the input length and the numerical cap \(t\). Failure or a valid fallback must be handled explicitly.

Aligned prime agreement above three quarters, or an aligned limit \(41/54\), therefore does not supply secrecy. In nonaligned cases the same prediction identity remains valid even when agreement is below three quarters. No proof here is an attack on a multidimensional posterior, an explicitly noisy publication, or an exchange with additional unmodeled secret-dependent messages. Those cases require their own algorithms and joint-distribution analysis.

## 7.14. Reproducibility and the exact scope of the computations

The finite prime closure used in this chapter is regenerated from first principles by `supplementary/chapter-07/regenerate_prime_certificate.py`. For every prime \(2\le Q\le269\), the program computes the exact agreement numerator by sorting the rational slopes of the integer quotient profile and summing pairwise determinant contributions with integer arithmetic. It then compares the regenerated numerator and denominator against every row of `prime_certificate.csv`; the stored margin is checked as a derived quantity, not treated as evidence.

`verify.py` regenerates and compares **all 57 prime rows exactly**. `verify_independent.py` uses a separately written direct protocol enumeration for the small prime cases through \(Q=11\), checks the nonaligned table and verifies every stored denominator and three-quarters margin. In particular, changing the \(Q=3\) numerator from the exact value \(79\) to \(81\) makes both local verification paths fail.

The three finite counterexamples in Section 7.3 are regenerated by the supplied C++ direct enumerator; an independent Python enumeration rechecks the first two. The four nonaligned-family rows are also checked from their exact supplied integer counts, while the asymptotic limits and general theorems remain justified by the proofs in the chapter rather than by extrapolation from finite data. The certificate generation is a finite computation and is not claimed to be polynomial in the binary encoding of an unbounded \(Q\).

From the chapter directory, run

```sh
python3 regenerate_prime_certificate.py --check prime_certificate.csv
python3 verify.py
python3 verify_independent.py
```

From the repository root, `python3 verify_repository.py --jobs 4` additionally checks the chapter manifest before executing both verification paths. No proof-assistant certificate, independent journal referee opinion or worldwide novelty determination is claimed.

## 7.15. Conclusions and transition

The correct extension of Chapter 6 is not “three quarters for all integer moduli.” Three distinct regimes have been established here. With complete alignment \(Q^2\mid P\) and at least two output cells, an exact phase grid controls agreement; prime divisors and power-of-two divisors admit the stated finite guarantees. Along all aligned integer divisors growing without bound, agreement tends to \(41/54\). With only \(Q\mid P\), unequal cells can instead produce infinitely many violations of three quarters.

The public and secret distributions, final divisor, and cell geometry all belong to the theorem statement. Primality alone is not a substitute for those conditions. Weak asymptotic equidistribution is also not independence of every finite collection of remainders, much less a security reduction.

Finally, the efficient posterior predictor from Chapter 5 remains compatible with every agreement result in this chapter's scalar experiment. These are results about correctness probabilities and their limitations, not a new secure scalar cryptosystem. The next mathematical chapters and the separate polynomial article must establish their own hypotheses and cannot inherit a scalar constant or attack without an exact correspondence.

**Scope.** The proofs and finite certificate apply only to the explicitly defined experiments and parameter conditions.


## Appendix 7.A — Complete finite certificate for prime divisors

The following 57 rows are regenerated by the supplied exact prime-certificate generator. They close only the finite range below the analytic cutoff of Theorem 7.7. The column headed “margin” is \(4N_{\rm agree}-3Q^4\), so positivity is an exact check of strict three-quarters agreement. Every denominator is the reduced-state count \(Q^4\), not a count of original triples for an unspecified upper multiplier.

\begingroup
\small

| Q | Agreements | Q^4 | Margin |
|---:|---:|---:|---:|
| 2 | 16 | 16 | 16 |
| 3 | 79 | 81 | 73 |
| 5 | 577 | 625 | 433 |
| 7 | 2135 | 2401 | 1337 |
| 11 | 12439 | 14641 | 5833 |
| 13 | 23929 | 28561 | 10033 |
| 17 | 68593 | 83521 | 23809 |
| 19 | 106255 | 130321 | 34057 |
| 23 | 225655 | 279841 | 63097 |
| 29 | 563913 | 707281 | 133809 |
| 31 | 734223 | 923521 | 166329 |
| 37 | 1479713 | 1874161 | 296369 |
| 41 | 2223033 | 2825761 | 414849 |
| 43 | 2685431 | 3418801 | 485321 |
| 47 | 3822527 | 4879681 | 651065 |
| 53 | 6160337 | 7890481 | 969905 |
| 59 | 9434967 | 12117361 | 1387785 |
| 61 | 10772105 | 13845841 | 1550897 |
| 67 | 15645119 | 20151121 | 2127113 |
| 71 | 19705879 | 25411681 | 2588473 |
| 73 | 22009113 | 28398241 | 2841729 |
| 79 | 30142207 | 38950081 | 3718585 |
| 83 | 36693663 | 47458321 | 4399689 |
| 89 | 48453545 | 62742241 | 5587457 |
| 97 | 68274913 | 88529281 | 7511809 |
| 101 | 80204705 | 104060401 | 8637617 |
| 103 | 86724455 | 112550881 | 9245177 |
| 107 | 100947751 | 131079601 | 10552201 |
| 109 | 108680825 | 141158161 | 11248817 |
| 113 | 125473041 | 163047361 | 12750081 |
| 127 | 199904911 | 260144641 | 19185721 |
| 131 | 226225103 | 294499921 | 21400649 |
| 137 | 270470169 | 352275361 | 25054593 |
| 139 | 286570631 | 373301041 | 26379401 |
| 149 | 378097201 | 492884401 | 33735601 |
| 151 | 398754663 | 519885601 | 35361849 |
| 157 | 465835145 | 607573201 | 40620977 |
| 163 | 541039615 | 705911761 | 46423177 |
| 167 | 596009287 | 777796321 | 50648185 |
| 173 | 686171545 | 895745041 | 57451057 |
| 179 | 786206591 | 1026625681 | 64949321 |
| 181 | 821852977 | 1073283121 | 67562545 |
| 191 | 1018651119 | 1330863361 | 82014393 |
| 193 | 1061898305 | 1387488001 | 85129217 |
| 197 | 1152529825 | 1506138481 | 91703857 |
| 199 | 1199956823 | 1568239201 | 95109689 |
| 211 | 1515974591 | 1982119441 | 117540041 |
| 223 | 1890675999 | 2472973441 | 143783673 |
| 227 | 2029776623 | 2655237841 | 153392969 |
| 229 | 2102138497 | 2750058481 | 158378545 |
| 233 | 2252648441 | 2947295521 | 168707201 |
| 239 | 2493398511 | 3262808641 | 185168121 |
| 241 | 2577752945 | 3373402561 | 190804097 |
| 251 | 3032231271 | 3969126001 | 221547081 |
| 257 | 3332231617 | 4362470401 | 241515265 |
| 263 | 3654007047 | 4784350561 | 262976505 |
| 269 | 3998522585 | 5236114321 | 285747377 |

\endgroup



## Supplementary Material and Reproducibility — Chapter 7

The public supplementary material for this chapter is assigned to `supplementary/chapter-07/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 8 — General Distributional Theory of MODDIV {#ch8}
## Remainders, Randomized Lifting, Noise, and Security-Transfer Obligations


**Scope.** The arithmetic and finite-space arguments do not establish IND-CPA, IND-CCA, concrete security or worldwide historical priority.

### Abstract

The previous chapters separated algebraic correctness, scalar agreement, and efficient key prediction. This chapter develops a general distributional framework for modular quotient observations, including structured vector observations. It distinguishes an exact additive representation of a discarded remainder from a law of independent noise. Uniform randomized lifting is characterized by the conditional distribution inside each quotient cell, with all public side information retained. A quotient-only universal simulator of a fixed additive-noise channel is shown to require uniform noise modulo the ambient modulus; approximate simulation with broader noise is nevertheless possible under an explicit loss. Subtractive dither illustrates why independence after discarding a variable need not survive its publication. For overlapping Hankel windows, a sequential conditioning argument bounds the exponentiated order-two Rényi divergence between deterministic rounded observations and independently perturbed rounded observations. Exact cell costs refine this bound. The resulting recovery-success transfer is distinguished from an additive decision guarantee and from a complete encryption-security proof. All arguments retain their declared distributions and are accompanied by exact finite verification. The chapter is self-contained and does not establish a new reduction from standard LWE or a new polynomial cryptosystem.

### Scope and contribution boundary

The mathematical model is stated afresh and the relevant proofs are supplied in full. The public supplementary material tests the formulas stated in this chapter. Historical terminology does not override the documentary qualifications of Chapter 4.

The finite-probability tools are classical. Rényi divergence is treated in ([B21](#bib-b21)), and its exponentiated order-two form and probability-preservation property occur in ([B09](#bib-b09); Definition 2 and Lemma 6). Dither has a separate signal-processing literature ([B22](#bib-b22)). These references identify antecedents; their cryptographic constructions and hardness assumptions are not imported. The comparison between standard or middle-product LWE and the specific MODDIV-NOISE source remains reserved for thesis V2. The polynomial article and the specification of Chapter 9 remain separate projects.

## 8.1. A finite model with an explicit public transcript

Let \(P,Q\) be positive integers. Unless a narrower condition is stated, the cell and lifting identities allow any such pair, including \(Q>P\). Define
\[
[z]_P=z-P\lfloor z/P\rfloor,\qquad
F(z)=F_{P,Q}(z)=\left\lfloor\frac{[z]_P}{Q}\right\rfloor,
\qquad J=\lceil P/Q\rceil.
\tag{8.1}
\]
Residues use canonical integer representatives. For \(0\le u<J\), put
\[
\omega_u=\min\{Q,P-Qu\},\qquad
I_u=\{Qu,\ldots,Qu+\omega_u-1\}.
\tag{8.2}
\]
All cells are nonempty. The last one may be shorter than \(Q\). Quotient and remainder maps apply componentwise to vectors.

Let \(A\) denote public information and \(X\) a secret, both with finite support. A deterministic, integer-valued map \(f\) gives
\[
Z=[f(A,X)]_P\in\mathbb Z_P^L,\qquad
U=F(Z),\qquad \rho=Z-QU,
\tag{8.3}
\]
where \(L\ge1\). This is a publication model, not yet an encryption algorithm. An auxiliary observation may be \([f(A,X)+E]_P\), with the joint law of \(E,A,X\) specified separately.

All statistical distances below are distances between finite laws. Integer noise with countable support is allowed when its residue distribution is well defined; the structured bounds additionally state positivity or moment hypotheses. A variable included for analysis need not be supplied to an adversary. In particular, comparing \((A,X,U)\) is useful for a true-secret recovery event, while a public distinguisher sees \((A,U)\), not \(X\).

For a randomized test \(D\), the distinguishing advantage is the absolute acceptance gap. In an equiprobable challenge-bit experiment the corresponding optimized success bias is half that gap. Any computational use of a probability kernel additionally requires an efficient implementation. Enumerating a finite distribution does not meet that requirement merely because the distribution exists.

## 8.2. The exact arithmetic error, including multiple wraparounds

The deterministic representation
\[
QU\equiv f(A,X)-\rho\pmod P,
\qquad 0\le\rho_i<\omega_{U_i}
\tag{8.4}
\]
is always correct. It does not assert that \(-\rho\) is independent of \(A,X\).

**Proposition 8.1 — General-modulus perturbation identity.** For a canonical scalar residue \(z=Qu+r\), write
\[
e=Qh+\delta,\quad P=aQ+b,\quad
0\le r<Q,\quad 0\le\delta,b<Q,
\qquad k=\lfloor(z+e)/P\rfloor.
\]
Then
\[
F(z+e)=u+h-ka+
\left\lfloor\frac{r+\delta-kb}{Q}\right\rfloor.
\tag{8.5}
\]
If \(Q\mid P\), the expression simplifies to
\[
F(z+e)=
\left[u+h+\left\lfloor\frac{r+\delta}{Q}\right\rfloor\right]_{P/Q}.
\tag{8.6}
\]

*Proof.* The canonical residue of \(z+e\) is \(z+e-kP\). Substitute the displayed Euclidean divisions and take its quotient by \(Q\). No restriction to one wraparound is used. If \(b=0\), reduction modulo \(P=Qa\) reduces the quotient modulo \(a\), proving (8.6). Negative errors are covered by floor division, not truncation toward zero. \(\square\)

When \(Q\nmid P\), the term \(-kb\) shifts the final cell boundaries. Omitting it can change the quotient. The proposition is an identity for given integers; it assigns no probability to a carry and gives no independence claim.

## 8.3. Marginal remainder laws and conditioning on the public

**Proposition 8.2 — Uniform-input cell laws.** Suppose \(Z\) is uniform on \(\mathbb Z_P\), and write \(P=aQ+b\), \(0\le b<Q\). For \(U=F(Z)\) and \(R=Z-QU\),
\[
\Pr[U=u]=\frac{\omega_u}{P},\qquad
\Pr[R=r\mid U=u]=\frac{\mathbf1_{0\le r<\omega_u}}{\omega_u},
\tag{8.7}
\]
\[
\Pr[R=r]=\frac{a+\mathbf1_{r<b}}P
\quad(0\le r<Q),\qquad
\operatorname{TV}(\mathcal L(R),\operatorname{Unif}(\mathbb Z_Q))
=\frac{b(Q-b)}{PQ}.
\tag{8.8}
\]
If \(b=0\), \(U,R\) are independent uniforms. If \(b>0\),
\[
\operatorname{TV}(\mathcal L(U),\operatorname{Unif}(\{0,\ldots,J-1\}))
=\frac{a(Q-b)}{PJ}.
\tag{8.9}
\]

*Proof.* Every canonical residue has a unique quotient and remainder. A cell has \(\omega_u\) equiprobable points, proving (8.7). Each remainder occurs in \(a\) complete blocks and once more exactly when \(r<b\). The positive deviations from \(1/Q\) occur at those \(b\) positions; their sum is (8.8). For \(b>0\), \(J=a+1\), each complete cell has mass \(Q/P\), and the short cell has mass \(b/P\). Sum the positive deviations from \(1/J\). If \(a=0\), there are no complete cells, and the quotient is constant, so (8.9) is zero. \(\square\)

Uniformity of \(Z\) is an assumption, not a consequence of writing a matrix product. Even under that assumption, independence from the quotient is not independence from all the public information. In (8.3), \(\rho\) is deterministic given \((A,X)\).

For a uniform finite secret set \(\mathcal X\) independent of \(A\), the conditional remainder law at a positive-probability publication is
\[
\Pr[\rho=r\mid A=a,U=u]
=\frac{\#\{x\in\mathcal X:F(f(a,x))=u,\ [f(a,x)]_P=Qu+r\}}
{\#\{x\in\mathcal X:F(f(a,x))=u\}}.
\tag{8.10}
\]
This is a counting identity, not an efficient multidimensional counting algorithm. Nonuniform secret priors require their corresponding weights in numerator and denominator.

**A correlated-remainder witness.** In the Hankel convention of Chapter 3, take \(P=257,Q=15,L=3,d=2\), ribbon
\[
a=(257,258,257,259),\qquad
\mathsf H_{3,2}(a)\bmod P=
\begin{pmatrix}0&1\\1&0\\0&2\end{pmatrix},
\]
and independent uniform \(X_0,X_1\in\{8,\ldots,15\}\). Conditional on \(U=(0,0,1)\), the compatible secrets are exactly \(\{8,\ldots,14\}^2\), and
\[
\rho=(X_1,X_0,2X_1-15).
\tag{8.11}
\]
There are 49 equally likely joint values, while the product of the three marginal laws has 343. Each marginal is uniform on seven points, but the first and third coordinates determine one another. Directly summing the masses gives distance \(6/7\) from that product law. This is the witness expressed with reversed secret coordinates; it is not evidence that such a public ribbon is typical, or a claimed attack on every structured construction.

## 8.4. Randomized lifting preserves cells, not arbitrary hidden residues

Given \(u\), the uniform lifting kernel samples a residue uniformly from \(I_u\). For a vector it samples the product cell \(I_{u_0}\times\cdots\times I_{u_{L-1}}\). It requires no knowledge of the original secret.

**Theorem 8.3 — Exact criterion for a cell-uniform lift.** Let \((C,Z)\) have any finite joint law, let \(U=F(Z)\), and, conditional on \((C,U)\), draw \(\widetilde Z\) uniformly from the product cell \(I_U\), independently of the old \(Z\). Then
\[
F(\widetilde Z)=U,
\]
\[
\operatorname{TV}(\mathcal L(C,Z),\mathcal L(C,\widetilde Z))
=\sum_{c,u}\Pr[C=c,U=u]\,
\operatorname{TV}\bigl(\mathcal L(Z\mid c,u),\operatorname{Unif}(I_u)\bigr).
\tag{8.12}
\]
Only pairs \((c,u)\) of positive probability are included. Consequently the lift reconstructs the joint law exactly if and only if all these conditional laws are uniform on their entire product cells. Lifting a second time has no further effect on its output law.

*Proof.* Both experiments have the same \((C,U)\) marginal, because their residues stay in the same cells. Distinct pairs \((c,u)\) have disjoint supports in \((c,z)\). Split the total-variation sum over these supports, factor out their common masses, and obtain (8.12). Every term is nonnegative, so equality to zero is equivalent to conditional uniformity on each positive-mass cell. The lifted law already has that property, proving idempotence. \(\square\)

For \(Q\mid P\), write \(H=P/Q\). If \(U\) is uniform on \(\mathbb Z_H^L\) independently of \(C\), lifting produces a uniform residue vector independently of \(C\). More generally, if \(C\)'s law is unchanged, the disjoint-cell calculation gives
\[
\operatorname{TV}\bigl((C,\widetilde Z),\mathcal L(C)\otimes\operatorname{Unif}(\mathbb Z_P^L)\bigr)
=\operatorname{TV}\bigl((C,U),\mathcal L(C)\otimes\operatorname{Unif}(\mathbb Z_H^L)\bigr).
\tag{8.13}
\]
This can justify a lift in an ideal game. It does not justify declaring the actual lifted product uniform in a real game. When \(Q\nmid P\), the correct quotient law of a uniform residue vector is the product of the size-weighted cell laws in (8.7), not a uniform quotient alphabet.

For a fixed scalar input \(z=Qu+r\), the integer error of a uniform lift is \(\widetilde Z-z=R'-r\), where \(R'\) is uniform on \(\{0,\ldots,\omega_u-1\}\). Its support depends on \(r\). Even when \(Z\) is uniform and \(Q\mid P\), the triangular marginal law
\[
\Pr[R'-R=e]=\frac{Q-|e|}{Q^2}\quad (|e|<Q)
\tag{8.14}
\]
does not make this integer error independent of \(Z\) when \(Q>1\): its conditional support shifts with the true remainder. For \(Q=1\), the error is identically zero and is independent in the degenerate sense. This formula concerns the integer difference of remainders, not an unrestricted reinterpretation of its reduction modulo \(P\).

## 8.5. A precisely scoped obstruction to universal dequantization

**Theorem 8.4 — Quotient-only simulation of an additive channel.** Let \(2\le Q\le P\). Suppose a single randomized kernel \(K\), receiving only \(F(z)\), must satisfy
\[
K(F(z))\overset d=[z+E]_P
\quad\text{for every }z\in\mathbb Z_P,
\tag{8.15}
\]
where the noise law modulo \(P\) is the same for every input. Then that noise law is uniform modulo \(P\). Conversely, a kernel returning a fresh uniform residue satisfies (8.15).

For any proposed approximate kernel and two residues \(z,z'\) in one cell,
\[
\max\{\operatorname{TV}(K(F(z)),\chi_z),
       \operatorname{TV}(K(F(z')),\chi_{z'})\}
\ge\tfrac12\operatorname{TV}(\chi_z,\chi_{z'}),
\tag{8.16}
\]
where \(\chi_z=\mathcal L([z+E]_P)\).

*Proof.* The residues 0 and 1 have the same quotient. Their output laws in (8.15) must therefore be equal. The noise law is invariant under translation by one, hence under every translation of the finite cyclic group, and must be uniform. Uniform output proves the converse. For (8.16), the two kernel laws are one and the same law. Apply the triangle inequality through it and bound the sum by twice its larger summand. \(\square\)

The quantifiers are essential. This theorem does not exclude a transport that also uses \(A\), other observations, or an input distribution; it does not exclude a change of dimensions or a reduction that transfers advantage rather than exact samples. It also does not require recovering the original input. For \(Q=1\), the quotient retains the entire residue and the obstruction does not apply. Uniform noise is a degenerate solution, not a useful confidentiality theorem.

## 8.6. Approximate simulation by a wider error distribution

Define the integer center of a cell by
\[
c(u)=Qu+\lfloor(\omega_u-1)/2\rfloor.
\tag{8.17}
\]
For a vector of quotient observations, independently sample \(E_i\) uniformly on \(\{-T,\ldots,T\}\), \(T\ge0\), and output \(\widetilde Y_i=[c(U_i)+E_i]_P\).

**Proposition 8.5 — Conditional smoothing bound.** For any joint law of \((C,Z)\), with \(U=F(Z)\), and product noise independent of \((C,Z)\),
\[
\operatorname{TV}\bigl((C,Z,\widetilde Y),(C,Z,[Z+E]_P)\bigr)
\le\mathbb E\min\left\{1,
\sum_{i=0}^{L-1}\frac{\lfloor\omega_{U_i}/2\rfloor}{2T+1}\right\}
\le\min\left\{1,\frac{L\lfloor Q/2\rfloor}{2T+1}\right\}.
\tag{8.18}
\]
The same bound holds after hiding \(Z\).

*Proof.* The maximum distance from an integer point of a cell to its chosen center is \(\lfloor\omega_u/2\rfloor\). Two integer uniform laws on intervals of common size \(2T+1\), shifted by \(s\), have total variation \(\min\{1,|s|/(2T+1)\}\), by counting the overlap of their supports. Modular reduction cannot increase this distance. Conditional on \((C,Z)\), couple each coordinate optimally; a union bound bounds the probability that any coordinate differs by the sum of the coordinate distances, capped at one. Average over the common conditioning variables. Finally, forgetting variables is a common deterministic map and contracts total variation. \(\square\)

**Corollary 8.6 — An exact scalar minimax value for an odd complete cell.** Suppose \(Q=2h+1\), \(T\ge h\), and \(P\ge2T+Q\). For a complete cell of \(Q\) points and noise uniform on \([-T,T]\cap\mathbb Z\), the smallest possible worst-input error of a quotient-only simulator is
\[
\inf_K\sup_{z\text{ in the cell}}
\operatorname{TV}(K(F(z)),[z+E]_P)=\frac{h}{2T+1}.
\tag{8.19}
\]

*Proof.* If \(h=0\), the cell is a singleton and exact simulation is possible, giving value zero. Assume now \(h\ge1\). Noise laws centered at the cell endpoints differ by \(2h\). The union of their integer support intervals has at most \(2T+Q\le P\) points, so reduction modulo \(P\) creates no additional overlaps. Their distance is \(2h/(2T+1)\). Theorem 8.4 gives half this value as a necessary worst-case error. The integer center realizes at most \(h/(2T+1)\) for every cell point by Proposition 8.5. \(\square\)

This simulator receives the quotient, not the secret or true remainder. Uniform integer sampling has an exact expected-polynomial implementation in the bit length of \(T\); a strict cap needs an explicit failure allowance. A large \(T\) can make the modular noise nearly uniform and can destroy useful information. The direction is also important: a solver for the broader-noise experiment, composed with this simulator, would solve a rounded instance approximately. This is not automatically the desired hardness reduction from an already founded source to MODDIV.

## 8.7. Subtractive dither and an observable residual relation

The classical dither literature motivates this calculation ([B22](#bib-b22)), but the following finite-modular statement is proved directly and its full transcript is kept explicit.

**Theorem 8.7 — Independence after forgetting dither is not full-transcript independence.** Suppose \(Q\mid P\). For any random residue \(Z\), independently sample \(T\) uniformly on \(\{0,\ldots,Q-1\}\), and set
\[
Y=[QF(Z+T)-T]_P.
\tag{8.20}
\]
Then \(Y=[Z-R]_P\), where \(R=[Z+T]_Q\) is uniform on \(\mathbb Z_Q\) independently of \(Z\). However, let \(R'\) instead be independent of \((Z,T)\), with that same uniform law, and put \(Y'=[Z-R']_P\). Then
\[
\operatorname{TV}((Z,T,Y),(Z,T,Y'))
=\operatorname{TV}((T,Y),(T,Y'))=1-\frac1Q.
\tag{8.21}
\]

*Proof.* Since \(Q\mid P\), the remainder of \([Z+T]_P\) modulo \(Q\) equals \([Z+T]_Q\). Quotient–remainder reconstruction gives (8.20) as \(Z-R\) modulo \(P\). At each fixed \(Z=z\), translation by \(z\) permutes the \(Q\) possible values of \(T\), proving uniformity and independence of \(R\) from \(Z\).

For each fixed \((z,t)\), the real \(Y\) is deterministic. The comparison law \(Y'\) is uniform on \(Q\) distinct residues and includes that deterministic value, so its conditional distance is \(1-1/Q\). Averaging proves the first equality in (8.21). The public event \([Y+T]_Q=0\) holds with probability one in the real experiment and \(1/Q\) in the comparison, because \(R'\) is independent uniform. It supplies the same lower bound after hiding \(Z\); data processing gives the upper bound. The statement also includes \(Q=1\), where the distance is zero. \(\square\)

This does not forbid using dither in an explicitly specified protocol. It forbids replacing its full public transcript by an independent-noise transcript without proving the replacement. Moreover, \(F(Z+T)\) cannot generally be computed from \(F(Z)\) and \(T\) alone. No dither is inserted into any existing MODDIV construction by this chapter.

## 8.8. The same efficient transformation must work in both worlds

For finite laws \(\mu,\nu\), use
\[
\operatorname{TV}(\mu,\nu)=\tfrac12\sum_z|\mu(z)-\nu(z)|.
\]
A probability kernel \(K(y\mid x)\) is nonnegative and each input row sums to one; \(\mu K\) denotes its output law.

**Lemma 8.8 — Kernel contraction and two-world transfer.** A common kernel satisfies
\[
\operatorname{TV}(\mu K,\nu K)\le\operatorname{TV}(\mu,\nu).
\tag{8.22}
\]
Suppose source laws \(\mathsf P_b\), target laws \(\mathsf Q_b\), and the same efficient kernel satisfy
\[
\operatorname{TV}(\mathsf P_bK,\mathsf Q_b)\le\varepsilon_b
\quad(b=0,1).
\]
Then every efficient target distinguisher \(D\) induces \(B=D\circ K\) with
\[
\operatorname{Adv}_{\mathsf Q}(D)
\le\operatorname{Adv}_{\mathsf P}(B)+\varepsilon_0+\varepsilon_1.
\tag{8.23}
\]

*Proof.* Expand the output masses and apply the triangle inequality to their difference. Summing each kernel row yields (8.22). For (8.23), the acceptance probabilities of \(D\), including its independent coins, differ by at most \(\varepsilon_b\) in each world. Apply the triangle inequality to their two gaps. The composed procedure cannot ask which world generated its input. \(\square\)

All public values are part of these laws. An argument comparing only hidden products or one-coordinate marginals cannot substitute for (8.23). If a noisy linear source is already justified and its public and secret distributions are exactly the required ones, applying the same rounding map gives a valid reduction to its rounded image. The rounded null distribution must also be the correct image: uniform quotients when \(Q\mid P\), size-weighted cells otherwise. This is not a proof that the required noisy source is difficult.

## 8.9. Rényi comparison: preservation of success rather than equality of laws

Define the **exponentiated** order-two divergence
\[
\mathcal R_2(\mu\Vert\nu)=\sum_{z:\mu(z)>0}\frac{\mu(z)^2}{\nu(z)},
\tag{8.24}
\]
with value \(+\infty\) if a denominator vanishes. It equals \(\exp(D_2(\mu\Vert\nu))\) under the natural-log convention of ([B21](#bib-b21)); it is the convention used in ([B09](#bib-b09); Definition 2). It is not itself a logarithm or a metric.

**Lemma 8.9 — Probability preservation and data processing.** If \(\mu\ll\nu\), then for every event \(S\),
\[
\nu(S)\ge\frac{\mu(S)^2}{\mathcal R_2(\mu\Vert\nu)}.
\tag{8.25}
\]
A common kernel satisfies
\[
\mathcal R_2(\mu K\Vert\nu K)\le\mathcal R_2(\mu\Vert\nu).
\tag{8.26}
\]
If the two laws have the same marginal \(\pi\) on \(C\), then
\[
\mathcal R_2(\mu_{C,Z}\Vert\nu_{C,Z})
=\sum_{c:\pi(c)>0}\pi(c)\,
\mathcal R_2(\mu_{Z\mid c}\Vert\nu_{Z\mid c}).
\tag{8.27}
\]

*Proof.* Cauchy–Schwarz applied to \(\sum_{z\in S}(\mu(z)/\sqrt{\nu(z)})\sqrt{\nu(z)}\) gives (8.25). For each output \(y\), apply the same inequality with weights \(\nu(x)K(y\mid x)\):
\[
\frac{(\sum_x\mu(x)K(y\mid x))^2}{\sum_x\nu(x)K(y\mid x)}
\le\sum_x\frac{\mu(x)^2K(y\mid x)}{\nu(x)}.
\]
Zero-mass terms are omitted. Sum over \(y\) to obtain (8.26). Equation (8.27) follows by substituting \(\mu(c,z)=\pi(c)\mu(z\mid c)\) and the analogous expression for \(\nu\). \(\square\)

Appending the same independent algorithm coins to both laws leaves \(\mathcal R_2\) unchanged; the lemma therefore applies to a randomized algorithm's success event. There is also the elementary estimate
\[
\operatorname{TV}(\mu,\nu)\le\tfrac12\sqrt{\mathcal R_2(\mu\Vert\nu)-1},
\tag{8.28}
\]
obtained by applying Cauchy–Schwarz to \(\sum_z\nu(z)|\mu(z)/\nu(z)-1|\). A constant divergence does not imply negligible distance. For example, \(\mu=(3/4,1/4)\) and \(\nu=(1/2,1/2)\) have \(\mathcal R_2=5/4\) and total variation \(1/4\).

The proofs above are elementary finite-space proofs. They do not depend on the general-measure arguments corrected in the 2024 errata to ([B21](#bib-b21)). No source's notation or rounding convention is silently substituted for (8.1).

## 8.10. The exact joint cost of keeping a rounded publication

For a scalar error law \(\chi\), define
\[
p_\chi(z)=\Pr_{e\leftarrow\chi}[F(z+e)=F(z)],\qquad
V_\chi=\sum_{z=0}^{P-1}\left(\frac1{p_\chi(z)}-1\right).
\tag{8.29}
\]
The latter is finite if every retention probability is positive; \(\Pr[e=0]>0\) is a sufficient condition.

**Theorem 8.10 — Joint divergence for deterministic and noisy rounding.** Let \((A,X)\) have the same law in two experiments, with \(Z=[f(A,X)]_P\). Write
\[
\mathsf D_0=(A,X,F(Z)),\qquad
\mathsf D_\chi=(A,X,F(Z+E)).
\]
If, conditional on \((A,X)\), the errors have independent coordinates of law \(\chi\), then
\[
\mathcal R_2(\mathsf D_0\Vert\mathsf D_\chi)
=\mathbb E_{A,X}\prod_{i=0}^{L-1}p_\chi(Z_i)^{-1}.
\tag{8.30}
\]
For a general conditional error law the correct expression is instead
\[
\mathbb E_{A,X}\frac1{\Pr[F(Z+E)=F(Z)\mid A,X]},
\tag{8.31}
\]
with infinity if this conditional probability vanishes on an event of positive probability.

*Proof.* At each fixed \((a,x)\), the noiseless output is a point mass at \(F(Z)\). Its divergence from the noisy conditional law is the reciprocal of that law's mass at the same point. Equation (8.27) gives (8.31). Conditional independence of the errors factorizes the mass into scalar retention probabilities and gives (8.30). It does not assert independence of the \(Z_i\). \(\square\)

**Why noise marginals are insufficient.** With \(P=19,Q=3\) and \(Z=(0,0,0)\), take \(E\) uniformly from
\[
(-1,0,1),\quad(0,1,-1),\quad(1,-1,0).
\tag{8.32}
\]
Each coordinate is uniform on \(\{-1,0,1\}\), and its individual retention probability is \(2/3\). Joint retention is zero because one coordinate always becomes \(18\) modulo \(19\), outside the zero cell. Thus (8.31) is infinite whereas the unjustified product would give \((3/2)^3\).

Support can fail even in one coordinate: with \(P=19,Q=3,z=18\) and error uniform on \(\{-1,1\}\), the quotient changes from 6 to either 5 or 0. Symmetry of a noise law alone therefore does not guarantee finite divergence. Neither example refutes the theorem under its actual hypotheses.

## 8.11. Overlapping Hankel windows and the fresh-coefficient argument

Let \(d,L,t\ge1\), and let each of \(t\) independent public ribbons have length \(L+d-1\). Its entries are independent uniforms on an integer interval
\[
\mathcal I=\{c,\ldots,c+M-1\},\qquad 1\le M\le P.
\tag{8.33}
\]
The secret vector \(X\in\mathbb Z^d\) has any finite law independent of all ribbons. The same secret is used for all of them. Define
\[
Z_{j,i}=\left[\sum_{k=0}^{d-1}A^{(j)}_{i+k}X_k\right]_P,
\quad 1\le j\le t,\quad0\le i<L.
\tag{8.34}
\]
Take a public bound
\[
\gamma\ge\max_{x\in\operatorname{supp}(X)}\gcd(x_{d-1},P),
\qquad 1\le\gamma\le P.
\tag{8.35}
\]
The endpoint is \(x_{d-1}\) in this Hankel convention. Reversing the secret gives the equivalent \(x_0\) Toeplitz convention.

**Theorem 8.11 — Structured joint Rényi bound.** If all \(tL\) errors are independent of each other and of \((\mathbf A,X)\), with common law \(\chi\) and finite \(V_\chi\), then
\[
\mathcal R_2(\mathsf D_0\Vert\mathsf D_\chi)
\le C_\chi:=\left(1+\frac{\gamma V_\chi}{M}\right)^{tL}.
\tag{8.36}
\]
Here the distributions include \(X\) and every public ribbon, as in Theorem 8.10.

*Proof.* Fix \(X=x\). Conditional on all coefficients before \(A_{i+d-1}\), a row has the form \(x_{d-1}A_{i+d-1}+c_i\) modulo \(P\). A linear congruence in the fresh coefficient has at most \(\gcd(x_{d-1},P)\) solutions in an interval of length at most \(P\), because its canonical solutions are equally spaced by \(P/\gcd(x_{d-1},P)\). Every row residue therefore has conditional mass at most \(\gamma/M\). This bound is still true, though weak, when that ratio exceeds one.

Set \(g(z)=p_\chi(z)^{-1}\ge1\). Then
\[
\mathbb E[g(Z_i)\mid x,\text{earlier coefficients}]
\le 1+\frac\gamma M\sum_z(g(z)-1).
\tag{8.37}
\]
In the product of \(L\) such factors, the last fresh coefficient appears only in the last factor. Integrate it out using (8.37), and repeat backwards. This gives the \(L\)-th power without assuming independent rows. Conditional on \(x\), the public ribbons are independent, so the same procedure applies to all \(t\) ribbons. Finally average over \(X\) and use (8.30). \(\square\)

When \(M=P\) and every supported endpoint secret is a unit modulo \(P\), each fresh row residue is exactly uniform conditional on the earlier coefficients. In that special case all the conditional inequalities are equalities and
\[
\mathcal R_2(\mathsf D_0\Vert\mathsf D_\chi)
=\left(1+\frac{V_\chi}{P}\right)^{tL}.
\tag{8.38}
\]
Uniformity here is over the random public ribbons while the secret is fixed. It does not mean that \(Z\) remains uniform after revealing those ribbons and the secret. Nor does it certify a difficulty assumption for this structured source.

## 8.12. Explicit cell costs for bounded independent noise

Let \(e\) be uniform on \(\{-B,\ldots,B\}\), \(B\ge0\). For a cell of width \(a\ge1\), the number of shifts that stay inside it on the integer line from position \(j\) is
\[
c_j=1+\min(B,j)+\min(B,a-1-j).
\]
Set
\[
g_B(a)=\sum_{j=0}^{a-1}\left(\frac{2B+1}{c_j}-1\right),\qquad
V_B^\sharp=(J-1)g_B(Q)+g_B(\omega_{J-1}).
\tag{8.39}
\]

**Proposition 8.12 — Cell-retention bound and its elementary envelope.** For \(1\le Q\le P\),
\[
V_B\le V_B^\sharp.
\tag{8.40}
\]
Equality holds if \(B\le P-Q\). Furthermore,
\[
g_B(a)=2B+1-a\quad(a\le B+1),\qquad
g_B(a)\le B\quad(a\ge B+1).
\tag{8.41}
\]
If \(a\ge2B+1\), then
\[
g_B(a)=\psi_B:=2\left((2B+1)\sum_{j=B+1}^{2B}\frac1j-B\right),
\tag{8.42}
\]
where the sum is empty and \(\psi_0=0\) for \(B=0\).

*Proof.* Every shift counted by \(c_j\) remains in the same modular cell. Wrapping can only add such shifts, so \(p_B(z)\ge c_j/(2B+1)\). Summing proves (8.40). To leave a cell of length \(a\le Q\), wrap around, and enter that cell again requires an integer shift of magnitude at least \(P-a+1>P-Q\). Under the equality condition no extra shift is possible.

For \(a\le B+1\), every point of the cell is reachable from every other and \(c_j=a\), proving the first identity. For \(a\ge B+1\), \(c_j\ge B+1\). The sum of the deficits \((2B+1)-c_j=(B-j)_++(B-a+1+j)_+\) is \(B(B+1)\). Dividing each deficit by at least \(B+1\) proves the envelope. When \(a\ge2B+1\), only the \(B\) positions at each end contribute; their denominators are \(B+1,\ldots,2B\). Summing both ends gives (8.42). \(\square\)

The case of one quotient cell is not overlooked: if \(Q=P\), \(V_B=0\) for every noise radius, even though the no-wrap upper bound may be positive. Exact equality in (8.40) is not asserted there for \(B>0\).

For a finite mixture \(\chi=\sum_B\lambda_B\operatorname{Unif}([-B,B]\cap\mathbb Z)\), convexity of \(1/x\) gives
\[
V_\chi\le\sum_B\lambda_B V_B^\sharp.
\tag{8.43}
\]
Every finitely supported symmetric unimodal integer law has this form, with \(\lambda_B=(2B+1)(\chi(B)-\chi(B+1))\); the weights telescope to the prescribed masses and sum to one. These finite-mixture assertions are the only mixture claims needed here.

Evaluating a harmonic sum up to \(2B\) can require \(O(B)\) additions. This is not polynomial in \(\log B\). In contrast, the envelope (8.41), combined with the two cell widths, can be evaluated with a fixed number of integer operations on the parameters. The chapter does not hide an exponential enumeration of a large cell or large noise support inside a purported efficient reduction.

## 8.13. What a recovery reduction actually obtains

**Theorem 8.13 — Conditional transfer of true-secret recovery.** In the setting of Theorem 8.11, let \(\mathcal A\) be an efficient algorithm defined on every public rounded input. Suppose its success in recovering the originally drawn secret from \((\mathbf A,F(Z))\) is \(\alpha\). The procedure receiving the raw noisy observation \((\mathbf A,Y=[Z+E]_P)\), computing \(F(Y)\), and running \(\mathcal A\) has success at least
\[
\beta\ge\frac{\alpha^2}{C_\chi}.
\tag{8.44}
\]
A larger explicitly justified upper bound on \(\mathcal R_2\), such as that using \(V_B^\sharp\), may replace \(C_\chi\).

*Proof.* Include \(X\) in both analytical laws and append \(\mathcal A\)'s independent random coins. The event that its output equals \(X\) has probability \(\alpha\) under \(\mathsf D_0\) and \(\beta\) under \(\mathsf D_\chi\). Lemma 8.9 and Theorem 8.11 give (8.44). The actual procedure receives only the public input; it neither knows \(X\) nor evaluates its own success event. Rounding and one oracle call give the computational overhead. \(\square\)

Thus a solver for rounded recovery can be used to solve a particular noisy recovery problem with the same public and secret laws. Difficulty would transfer in that direction only if that noisy problem were already founded and \(C_\chi\) had acceptable growth. A reduction between two easy problems is still a valid reduction. This chapter does not supply the missing external hardness premise.

The number \(tL\) is fixed before sampling and is part of the bound. If \(tL\gamma V_\chi/M\le c\log\lambda\) for a fixed constant \(c\), then \(\log C_\chi\le c\log\lambda\), so \(C_\chi\le\lambda^c\). This controls the analytical loss; all dimensions, encodings, and sampling costs must separately have the required polynomial bounds.

A compatible preimage is not automatically the originally drawn secret. If, in addition, the probability of a publication having more than one supported secret is at most \(\eta\), a solver returning any compatible secret with success \(\alpha_{\rm comp}\) has true-secret success at least \(\max\{0,\alpha_{\rm comp}-\eta\}\). Equation (8.44) then uses that lower bound. No collision bound or efficient inverse for general vector publications is proved here.

Likewise, event preservation can be used for a publicly generated verification task, provided the reduction can generate the target and check the answer with the allowed information. If its ideal success is \(\beta_0\), the resulting lower bound on an oriented decision gap is only \(\alpha^2/C_\chi-\beta_0\). This may be negative when \(\beta_0\) is near one half. One cannot replace it by \((\alpha-\beta_0)^2/C_\chi\) without a different proof.

**A loss illustration, not security parameters.** For full-period public coefficients, unit endpoint secrets, \(P=65536,Q=256,L=32,t=1\), and independent uniform errors in \(\{-1,0,1\}\), Proposition 8.12 gives \(V_B=256\). Hence
\[
C_\chi=(257/256)^{32}<8/7,
\qquad \beta>7\alpha^2/8\quad\text{when }\alpha>0.
\tag{8.45}
\]
The strict rational comparison is checked in the code. This example measures a reduction loss only; it makes no claim of 128-bit security or useful decoding parameters.

## 8.14. Decision transfer needs a separate additive estimate

**Proposition 8.14 — Boundary coupling under the structured public law.** Keep the public and secret hypotheses of Theorem 8.11, but allow correlations between error coordinates. Assume the entire error vector is independent of \((\mathbf A,X)\), with finite first absolute moments. Then
\[
\operatorname{TV}\bigl((\mathbf A,F(Z)),(\mathbf A,F(Z+E))\bigr)
\le\delta:=\min\left\{1,\frac{\gamma J}{M}\sum_{i=1}^{tL}\mathbb E|E_i|\right\}.
\tag{8.46}
\]

*Proof.* For a fixed integer shift \(e\), at most \(\min(P,J|e|)\) canonical residues change quotient. To see this, move one unit at a time around the residue cycle; each unit step has at most \(J\) quotient boundaries. A union bound over \(|e|\) steps gives the claim, including shifts exceeding a full period. For \(J=1\), there are no actual boundaries and the displayed bound is merely loose.

Conditional on the secret and previous public coefficients, a row residue has mass at most \(\gamma/M\). Independence of the full error vector from the public and secret permits applying this bound at each fixed error. Averaging and summing over coordinates bounds the probability that the coupled rounded vectors differ. The common-input coupling bounds total variation, proving (8.46). No product of retention probabilities is used. \(\square\)

Let the raw null source use a fresh uniform residue vector independently of the same public information. Define its rounded null law by actually applying \(F\), including short final cells. Rounding the raw source and composing a target distinguisher gives
\[
\operatorname{Adv}_{\rm rounded}(D)
\le \operatorname{Adv}_{\rm raw\ noisy}(D\circ F)+\delta.
\tag{8.47}
\]
The null simulation is exact; only the real-world discrepancy incurs \(\delta\). In the example (8.45), (8.46) yields \(\delta\le1/12\), a constant, not a negligible asymptotic guarantee. A favorable recovery-loss constant therefore does not by itself establish decisional LWR security or IND-CPA security. A full encryption proof must still include the complete ciphertext and any reconciliation, derivation, or confirmation data.

## 8.15. Public translations must be applied at the correct stage

A public change of secret origin can be exact before rounding. For a known vector \(c\), \(X=S+c\) implies
\[
f(A,X)=\mathsf H(A)S+\mathsf H(A)c
\]
when \(f(A,\cdot)\) is that linear map. Adding the known \(\mathsf H(A)c\) to an unrounded sample translates the secret law exactly. It does not turn a Gaussian law into a uniform box, change the secret dimension, or preserve an unspecified conditioning event.

**Proposition 8.15 — Exactly which scalar translations descend to the quotient.** Suppose \(P=QH\) with \(H\ge2\) and \(Q\ge1\). For an integer \(c\), a deterministic map \(g_c\) satisfying
\[
g_c(F(z))=F(z+c)\quad\text{for every integer }z
\tag{8.48}
\]
exists if and only if \(Q\mid c\). In that case,
\[
g_c(u)=[u+c/Q]_H.
\tag{8.49}
\]

*Proof.* The sufficient direction is the addition identity for a shift that is a multiple of \(Q\). For necessity write \(c=kQ+r\), \(0\le r<Q\). If \(r>0\), the inputs \(z_0=0\) and \(z_1=Q-r\) both have quotient zero. Their translated quotients are \([k]_H\) and \([k+1]_H\), distinct because \(H\ge2\). Thus one input to \(g_c\) would require two outputs. If \(Q=1\), every integer shift meets the divisibility condition. \(\square\)

When \(H=1\), every quotient is zero and every translation descends; that excluded case must not be folded into the necessity statement. For \(Q\nmid P\), (8.5) must be used rather than (8.49). This elementary criterion explains a recurrent simulation error: a correct translation of a full-modulus observation is not automatically implementable after its low-order information has been discarded.

## 8.16. Exact checks and reproducibility

The accompanying standard-library Python code uses integers and `Fraction`. It implements finite laws explicitly for testing; most such enumerations are exponential in bit-encoded dimensions and are not cryptanalytic algorithms. The only randomized generation in the verifier selects reproducible rational test laws with seed `2026110808`. It does not estimate probabilities by Monte Carlo or implement a production sampler.

| Verification family | Extent executed |
|---|---:|
| Signed perturbations and multiple modular wraparounds | 357,219 |
| Uniform quotient/remainder profiles, including incomplete cells | 1,600 |
| Joint lifting identities with public side information | 56 |
| Translation-invariance noise profiles | 350 |
| Scalar smoothing input cases | 14,756 |
| Odd-cell minimax equalities | 181 |
| Dither comparisons retaining the complete transcript | 35 |
| Kernel and Rényi profiles | 250 |
| Event inequalities inside those profiles | 4,000 |
| Modular retention-cost profiles | 5,740 |
| Harmonic cell-cost identities and envelopes | 1,260 |
| Finite noise mixtures | 80 |
| Quotient-translation characterizations | 1,260 |
| Public-ribbon/secret states in five structured profiles | 10,660 |

The correlated-remainder witness and the support-loss counterexamples are also checked exactly. Counts of states, events, and profiles describe different objects and must not be added into a total of independent experiments.

The five structured profiles use \(d=2\), public coefficients uniform on \([c,c+M)\cap\mathbb Z\), and independent uniform secret coordinates on the listed alphabet. “U1” means uniform integer noise on \(\{-1,0,1\}\); CBD1 has weights \(1,2,1\) out of 4. They are test profiles, not historical reconstructions or security recommendations.

\Needspace{12\baselineskip}

| \((P,Q)\) | \((c,M,L,t)\) | Secret alphabet / noise | Exact joint \(\mathcal R_2\) | Bound (8.36) |
|---|---|---|---:|---:|
| (7,3) | (4,4,2,1) | \(\{1,2\}\) / U1 | \(625/256\) | \(4\) |
| (8,4) | (0,8,2,1) | \(\{1,3\}\) / CBD1 | \(49/36\) | \(49/36\) |
| (11,4) | (5,6,3,1) | \(\{1,2\}\) / U1 | \(86569/41472\) | \(27/8\) |
| (5,2) | (3,3,2,2) | \(\{1,2\}\) / U1 | \(3281/288\) | \(2401/81\) |
| (8,3) | (6,4,2,1) | \(\{0,2\}\) / U1 | \(507/256\) | \(49\) |

The second profile attains the full-period equality (8.38). The fourth retains a shared secret across two independent ribbons. The fifth includes a nonunit or zero endpoint, giving a weak but valid bound. A finite lexicographic-preimage oracle is used only to check (8.44) numerically; it enumerates secrets and is not a new efficient vector recovery method. Exact recovery probabilities and public distances are stored in the distributed Chapter 8 result files, including `supplementary/chapter-08/results.json`.

A separate script, `verify_independent.py`, does not import the mathematical module. It evaluates structured products by full polynomial convolution with the secret reversed, then expands all noise vectors. Across the same five profiles it checks 399,204 noisy outcomes and reproduces every stored joint divergence, public divergence, public total variation, and recovery probability. This is a differently organized implementation check on the same states, not external peer review and not a second count of distinct cryptographic instances. It also checks 4,488 fresh-coefficient mass profiles, 19,900 boundary-cardinality profiles, and 15 exact unimodal-mixture reconstructions.

From `supplementary/chapter-08/`, run:

```sh
python3 verify.py
python3 verify_independent.py
```

The mathematical result files are deterministic; document compilation is outside this supplementary verification recipe. The manifest records byte lengths and SHA-256 digests. No third-party paper is redistributed. No Lean formalization, lattice-attack benchmark, asymptotic parameter certification, or exhaustive novelty search is claimed.

\Needspace{26\baselineskip}

## 8.17. What this framework contributes to the construction chapters

The chapter supplies a vocabulary of exact identities, statistical losses, and computational obligations. It does not add a new encryption scheme or change MODDIV-NOISE.

| Proposed step | What can be concluded | What must not be inferred |
|---|---|---|
| Write \(QU=f(A,X)-\rho\bmod P\) | Exact arithmetic relation | Independent LWE noise |
| Fill the quotient cell uniformly | Exact public quotient; criterion (8.12) | Restoration of an arbitrary original joint law |
| Add subtractive dither | Independent error after the stated marginalization | Independence from the published dither |
| Add broader noise to a cell center | Approximate channel with loss (8.18) | A useful hard source or the desired reduction direction |
| Bound joint \(\mathcal R_2\) | Recovery-success lower bound \(\alpha^2/C\) | Negligible statistical distance or a general CPA proof |
| Bound joint TV in both worlds | Additive distinguisher transfer | Difficulty of the underlying source without a premise |
| Reverse a secret or translate it before rounding | An exact algebraic and distributional change when specified | Equality of different secret dimensions or priors |

The scalar results of Chapters 5–7 remain intact: agreement and confidentiality are different questions, and a posterior-sampling attack requires an actually efficient sampler for the specified public law. Nothing here proves a general multidimensional sampler, a necessary enumeration lower bound, or security of a vector scheme.

Chapter 9 and the parallel polynomial article must first identify their precise coefficient ring, polynomial truncation or quotient operation, distributions, and transcript. They may invoke the present lemmas only after matching their hypotheses. The prospective Hankel-LWE/MP-LWE hardness investigation remains outside thesis V1. The correct endpoint of this chapter is a checked set of tools and explicit missing obligations, not a silently completed hardness reduction.

**Scope.** The arithmetic and finite-space arguments do not establish IND-CPA, IND-CCA, concrete security or worldwide historical priority.



```{=latex}
\part*{\phantomsection\addcontentsline{toc}{part}{PART III — Cryptographic Constructions}PART III — Cryptographic Constructions}
```



## Supplementary Material and Reproducibility — Chapter 8

The public supplementary material for this chapter is assigned to `supplementary/chapter-08/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 9 — Polynomial MODDIV {#ch9}
## Exact Windows, Rounded Publications, and a Published Reference Construction




### Abstract

Polynomial MODDIV mixes two distinct operations that must be kept separate: extraction of a coefficient window from an ordinary polynomial product, and coefficientwise modular quotient extraction. This chapter first formalizes an exact non-cyclic window model and proves a compatible-window identity for the common product. Over a finite field, the resulting unrounded exchange admits a polynomial-time passive predictor: any public solution of the linear window system suffices, even when it is not the planted secret. The rounded publication appearing in the public multidimensional ModDiv proposal is then analyzed with its true deterministic remainders, yielding an exact residual identity, a circular-distance bound and an explicit boundary criterion. The historical local trailing-bit counter is transcribed with its preliminary integer division by \(n\); exact counterexamples survive that normalization. Finally, the historical rounded construction is separated from a published middle-product learning-with-rounding reference construction. The positive reference theorem concerns only that attributed specialization under its computational MP-CLWR assumption and the classical random-oracle model. Algebraic similarity, Toeplitz/Hankel structure and the word *rounding* do not constitute a security reduction between the two distributions. No concrete security level or hardness theorem for historical polynomial MODDIV is claimed.

### Public record and scope

The public multidimensional ModDiv proposal is IACR ePrint 2021/701 ([B14](#bib-b14)). It defines a non-cyclic polynomial window followed by coefficientwise modular reduction and integer division, and its printed local trailing-bit procedure first applies integer division by \(2^{\log_2 n}=n\) to the intermediate integer before running the bit counter. Where the public text is asymmetric, the symmetric reconstruction used below is stated explicitly and is not presented as proof of historical intent.

The comparison construction is the middle-product learning-with-rounding public-key encryption of Bai, Boudgoust, Das, Roux-Langlois, Wen and Zhang ([B09](#bib-b09)), with notation cross-checked against Boudgoust's public thesis ([B23](#bib-b23)). The conditional encryption theorem in this chapter concerns only P-REF under its stated computational MP-CLWR assumption and the classical random-oracle model; it does not transfer to historical P-ROUND.

All mathematical claims needed below are stated in this thesis or supported by the public literature cited here.

## 9.1. Three objects that must not be conflated

The term *polynomial division* can refer to Euclidean division by a polynomial, whereas an integer division of each coefficient is a different operation. Their effects on algebra and distributions are different.

| Label used in this chapter | Publication | Scope |
|---|---|---|
| **P-WINDOW** | An exact coefficient window of an ordinary product, over a specified field | An algebraic testbed, without coefficient rounding |
| **P-ROUND** | The same non-cyclic window, then canonical reduction modulo an integer and coefficientwise floor division | The publication form analyzed from the public multidimensional proposal |
| **P-REF** | Nearest-rounded middle products with a long conditioned secret, plus a complete encryption mechanism | A reference specialization attributed to ([B09](#bib-b09)) |

These are organizational labels, not three newly claimed inventions. In particular, **P-WINDOW is not the historical publication with its integer rounding omitted from the explanation**: it is a deliberately different model used to show why window extraction alone cannot supply secrecy. P-ROUND does not become P-REF by renaming its factors.

We use fixed-length coefficient arrays in increasing degree order, with trailing zeros retained. The indeterminate is \(z\). In the first part, \(n,m\) specify degrees and window endpoints, \(P,Q\) are positive integer arithmetic parameters, and \(p,q\), when used for the historical conventions, are *bit lengths*. Section 9.11 introduces separate symbols \(p_0,q_0\) for the two moduli of P-REF; they are not those bit lengths.

## 9.2. Monomial division and the exact public window

Let \(R\) be a commutative ring with identity. For integers \(0\le n<m\), define
\[
 C_{m,n}(F)=\sum_{i=n}^{m-1}[z^i]F\,z^{i-n}.
 \tag{9.1}
\]
This equals the Euclidean quotient of \(F\bmod z^m\) by \(z^n\). Both divisors are monic, so the definition is meaningful over such a ring without requiring inverses of arbitrary coefficients. There is no real-valued floor operation on polynomials in (9.1).

Write \(X(z)=\sum_{j=0}^n x_jz^j\), allow a public polynomial \(A\) with coefficients \(a_i\), and set
\[
 d=n+1,\qquad L=m-n,\qquad M(A)_{ij}=a_{n+i-j},
 \quad 0\le i<L,\quad 0\le j<d.
 \tag{9.2}
\]

**Proposition 9.1 — Window, Toeplitz and Hankel representations.** The coefficient vector of \(C_{m,n}(AX)\) is \(M(A)x\). The matrix is Toeplitz. If \(J_d\) reverses a length-\(d\) vector and \(H(A)_{ij}=a_{i+j}\), then
\[
 M(A)=H(A)J_d.
 \tag{9.3}
\]
Only \(a_0,\ldots,a_{m-1}\) are used. A coefficient \(a_m\), even when nonzero and necessary to describe a polynomial of exact degree \(m\), is irrelevant to this window.

*Proof.* The coefficient of degree \(n+i\) in \(AX\) is \(\sum_{j=0}^n a_{n+i-j}x_j\). Its smallest possible public index is zero and its largest is \(m-1\). The entry depends on \(i-j\). Reversing the columns of \(H(A)\) gives \(a_{i+d-1-j}=a_{n+i-j}\), proving (9.3). \(\square\)

For example, when \(m=7,n=2\), the output consists of the five coefficients of degrees 2 through 6, shifted down by two. The public matrix has size \(5\times3\); its effective ribbon has seven coefficients, not fifteen independent entries.

The map \(C_{m,n}\) is linear. It does not identify high degrees with low degrees as multiplication modulo \(z^d-1\) or \(z^d+1\) would. An irreducible polynomial modulus likewise defines a different algebra, not a harmless notation change.

## 9.3. Compatible nested windows preserve the common product

Assume \(m>2n\), and put \(k=m-2n\). For a vector \(v\) of length \(L\), define
\[
 B_x(v)_i=\sum_{j=0}^n x_jv_{n+i-j},
 \qquad 0\le i<k.
 \tag{9.4}
\]
The relevant indices satisfy \(0\le n+i-j\le L-1\). In polynomial notation this is \(C_{m,2n}(z^nXv)\).

**Theorem 9.2 — Compatible-window identity.** For \(\deg X,\deg Y\le n\), over any commutative coefficient ring,
\[
 \begin{split}
 B_x\bigl(C_{m,n}(AY)\bigr)
 &= C_{m,2n}(AXY)\\
 &= B_y\bigl(C_{m,n}(AX)\bigr).
 \end{split}
 \tag{9.5}
\]

*Proof.* The \(i\)-th coefficient on the left is
\[
 \sum_{j=0}^n x_j[z^{2n+i-j}](AY).
\]
For \(0\le i<k\), all indices \(2n+i-j\) lie in \([n,m-1]\); these are exactly coefficients retained by the inner window. Hence the sum is \([z^{2n+i}](AXY)\). Commutativity exchanges \(X\) and \(Y\), proving the other equality. \(\square\)

This establishes the positive algebraic identity required here. It does not assert associativity for arbitrary windows. The shift \(z^n\), the change from cutoff \(n\) to \(2n\), and the output length \(k\) are part of the statement. The coefficient-index argument proves that every term needed by the final window survives the first extraction; it does not authorize other truncation patterns.

In the supplied algorithms all window dimensions are checked, including \(n=0\) in auxiliary algebra tests. The historical counter rules later in this chapter require \(n\ge1\).

## 9.4. Why the unrounded field exchange has a public predictor

In P-WINDOW, fix a known prime \(\pi\) and perform exact coefficient arithmetic in \(\mathbb F_\pi\). The parties publish
\[
 U=C_{m,n}(AX),\qquad V=C_{m,n}(AY),
 \tag{9.6}
\]
then compute the common vector in (9.5). No coefficientwise quotient or added noise occurs.

**Theorem 9.3 — Efficient passive prediction for P-WINDOW.** Given \(A,U,V\) from (9.6), an adversary can compute the common product vector in polynomial time in the input length. Full column rank is not required.

*Proof.* Solve \(M(A)x^*=U\) over \(\mathbb F_\pi\), choosing any solution by Gaussian elimination. A solution exists because the transcript is honestly generated. Its coefficient array defines a polynomial of degree at most \(n\). By Theorem 9.2,
\[
 B_{x^*}(V)=B_y\bigl(C_{m,n}(Ax^*)\bigr)=B_y(U).
 \tag{9.7}
\]
The right side is Bob's common value. Computing the left side uses only public data and \(x^*\). Gaussian elimination and the polynomial operations use polynomially many field operations, each computable in time polynomial in \(\log\pi\). The argument does not require recovering the original \(x\), or finding a solution in its original restricted sampling support. \(\square\)

A public deterministic derivation of that common vector is predictable as well. Extra secret-dependent state not specified in this model is not covered. The theorem does **not** permit solving the rounded equations by first pretending the missing remainders are zero.

Irreducibility alone does not rescue the corresponding *full, exact product*: over \(\mathbb F_\pi[z]/(f)\) with irreducible \(f\), a nonzero public multiplier is invertible, so an unrounded observation \(U=AX\bmod f\) gives \(X=A^{-1}U\). The polynomial Euclidean algorithm computes that inverse. This elementary statement is limited to the unrounded full product; it neither attacks a rounded window nor initiates the separate irreducible-polynomial research direction.

## 9.5. The rounded non-cyclic publication

Now return to integer coefficients. Fix \(n\ge1,m>2n\), \(P>Q\ge1\), and use the dimensions in (9.2). Define
\[
 Z_X=M(A)x,\qquad
 U_i=F_{P,Q}(Z_{X,i})=
 \left\lfloor\frac{[Z_{X,i}]_P}{Q}\right\rfloor,
 \tag{9.8}
\]
with the analogous definition of \(V\) for \(y\). This is P-ROUND. If \(J=\lceil P/Q\rceil\), its output alphabet is \(\{0,\ldots,J-1\}\). The last cell can be shorter than \(Q\); no output-ring structure of size \(P/Q\) is assumed when this quotient is not integral.

\[
 \begin{split}
 &2^{p-1}\le P,A_i<2^p,\\
 &2^{q-1}\le Q,X_j,Y_j<2^q.
 \end{split}
 \tag{9.9}
\]
Consequently, \(A_i\) can exceed \(P\), and \(X_j\) can exceed \(Q\). “Pseudorandom” in the source is not a complete probability law; uniform independent draws in these finite intervals are a declared testing convention, not a retrospective specification of an unknown generator.

**Proposition 9.4 — Coefficient-size bound.** Let \(p,q\) be positive integers. If \(0\le a_i<2^p\) and \(0\le x_j<2^q\), every retained ordinary product coefficient is at most
\[
 d(2^p-1)(2^q-1)<d\,2^{p+q}.
 \tag{9.10}
\]
It has at most \(p+q+\lceil\log_2d\rceil\) bits, with the bit length of zero taken to be zero. More generally, a sum of \(d\) nonnegative \(s\)-bit-bounded integers needs at most \(s+\lceil\log_2d\rceil\) bits.

*Proof.* Bound each nonnegative summand, sum the \(d\) bounds, and use \(d\le2^{\lceil\log_2d\rceil}\). Strict inequality with the next power of two gives the stated bit length. \(\square\)

Here \(d=n+1\), not \(n\). This is why replacing the bit length of a sum by a product such as \(s\log_2 n\) is not a valid general rule. No carry propagates between formal polynomial coefficients, but ordinary integer carries and the bound (9.10) still occur *within* each coefficient.

## 9.6. What cancellation leaves after coefficient rounding

Define true Euclidean remainders by
\[
 Z_X=Pz_X+QU+e_X,\qquad
 0\le e_{X,i}<\min(Q,P-QU_i),
 \tag{9.11}
\]
and similarly for \(Y\). These are deterministic functions of the original product; no independence assumption is introduced.

Set
\[
 R_A=B_x(V),\quad R_B=B_y(U),\qquad
 S_A=[QR_A]_P,\quad S_B=[QR_B]_P.
 \tag{9.12}
\]
All modular operations on vectors are componentwise.

**Theorem 9.5 — Rounded residual identity and circular bound.** For every \(0\le i<k\),
\[
 S_{A,i}-S_{B,i}\equiv
 \varepsilon_i:=
 \sum_{j=0}^n\bigl(y_je_{X,n+i-j}-x_je_{Y,n+i-j}\bigr)
 \pmod P.
 \tag{9.13}
\]
If the secret coefficients are nonnegative, then
\[
 d_P(S_{A,i},S_{B,i})\le |\varepsilon_i|
 \le (Q-1)\max(\|x\|_1,\|y\|_1).
 \tag{9.14}
\]
In particular, \(x_j,y_j\le b\) implies the upper bound \(d b(Q-1)\).

*Proof.* Substitute (9.11) into \(QB_x(V)\) and \(QB_y(U)\). The principal terms cancel by Theorem 9.2; the terms multiplied by \(P\) disappear modulo \(P\), leaving (9.13) with the displayed sign. Each of the nonnegative sums \(B_y(e_X)_i\) and \(B_x(e_Y)_i\) is bounded by \((Q-1)\|y\|_1\) and \((Q-1)\|x\|_1\), respectively. The absolute difference is bounded by their maximum. Circular distance is at most the magnitude of any congruent integer displacement. \(\square\)

This statement allows \(Q\nmid P\). In that case \(e_{X,i}\) cannot generally be replaced by \([Z_{X,i}]_Q\). It bounds circular distance between residues, not an ordinary difference of canonical representatives and not equality after a final quotient. The general principles developed in Chapters 5–8 apply, but their scalar probability constants are not automatically vector probability constants.

## 9.7. A public fixed divisor still needs a boundary argument

A later design may fix a public divisor \(D\) before the exchange. This is distinct from selecting separate local divisors. It is useful to isolate what such a choice proves. Let
\[
 K_{A,i}=\lfloor S_{A,i}/D\rfloor,\qquad
 K_{B,i}=\lfloor S_{B,i}/D\rfloor.
 \tag{9.15}
\]

**Proposition 9.6 — Exact common-divisor criterion when \(D\mid P\).** Write \(P=DJ\), \(S_{B,i}=Dv_i+\rho_i\), \(0\le\rho_i<D\), and use the displacement \(\varepsilon_i\) of (9.13). Then
\[
 K_{A,i}-K_{B,i}\equiv
 \left\lfloor\frac{\rho_i+\varepsilon_i}{D}\right\rfloor\pmod J.
 \tag{9.16}
\]
If \(J\ge2\) and \(|\varepsilon_i|<D\), equality holds exactly when \(0\le\rho_i+\varepsilon_i<D\).

*Proof.* Divide \(\rho_i+\varepsilon_i\) by \(D\), then reduce its quotient modulo \(J\); this gives (9.16). Under the additional displacement bound its quotient belongs to \(\{-1,0,1\}\). Only zero preserves a quotient modulo \(J\ge2\). \(\square\)

Without the divisibility assumption, the last quotient cell may be incomplete; equation (9.16) is not used. Small displacement alone does not suffice in that case either. A selected example in the original bit-size domain has
\[
 \begin{gathered}
 n=2,\ m=6,\ p=11,\ q=3,\ P=1543,\ Q=5,\ D=256,\\
 A=(1373,1276,1798,1379,1431,1938,1351),\\
 x=(4,6,6),\qquad y=(7,6,7).
 \end{gathered}
 \tag{9.17}
\]
Exact computation gives
\[
 \begin{aligned}
 U&=(296,163,19,293),&V&=(107,11,3,189),\\
 R_A&=(720,840),&R_B&=(3183,3306),\\
 S_A&=(514,1114),&S_B&=(485,1100),\\
 K_A&=(2,4),&K_B&=(1,4).
 \end{aligned}
 \tag{9.18}
\]
The first-coordinate circular separation is 29, much less than 256, but the boundary at 512 is crossed. This is a finite diagnostic of this common divisor, not a disproof of every fixed-public-\(r\) construction or of a separately proved probabilistic bound. We do not change the current program's public, preselected \(r\).

## 9.8. Historical local-counter readings: normalization, defects, and erasure

For documentary clarity, this section analyzes two exact symmetric readings of the local trailing-bit counter printed in the public proposal ([B14](#bib-b14)). They are historical rules, not a recommended reconciliation mechanism. The public proposal prints \(X\) in Bob's further computation, although Bob has \(Y\); H0/H1 therefore make the symmetric reconstruction explicit by using Bob's own secret.

The printed procedure also performs an integer division before the bit loop. Since \(2^{\log_2 n}=n\), define
\[
\widetilde R_i=\left\lfloor\frac{R_i}{n}\right\rfloor.
\]
For a positive integer \(w\), write \(\tau(w)\) for the length of its final run of identical binary digits. The printed scalar loop returns \(\tau(w)-1\), whereas the prose suggests \(\tau(w)\). On zero the unbounded-integer loop does not terminate. Hence the historical counter is defined only when every required \(\widetilde R_i>0\).

The two candidate outputs are
\[
 \begin{split}
 \widetilde K_i^{(0)}&=\left\lfloor\frac{[QR_i]_P}{n2^{2q+\tau(\widetilde R_i)}}\right\rfloor,\\
 \widetilde K_i^{(1)}&=\left\lfloor\frac{[QR_i]_P}{n2^{2q+\tau(\widetilde R_i)+1}}\right\rfloor.
 \end{split}
 \tag{9.19}
\]
Here H0 is the loop reading and H1 is the prose reading. The normalization affects only the counter input: the numerator remains the canonical residue \([QR_i]_P\).

**Counterexample 9.7 — Non-cyclic normalized-counter disagreement.** With the dimensions and moduli in (9.17), take
\[
 \begin{split}
 A&=(1580,1057,1283,1933,1248,1713,1749),\\
 x&=(4,4,5),\qquad y=(5,4,4).
 \end{split}
 \tag{9.20}
\]
The two historical readings both disagree, although \(P\) is prime, the public matrix has full column rank, and its effective ribbon is not \(d\)-periodic modulo \(P\).

*Exact verification.* The publications are \(U=(57,235,124,290)\) and \(V=(306,101,117,246)\). The intermediate values are
\[
 \begin{aligned}
 R_A&=(2402,1957),&R_B&=(1788,2886),\\
 S_A&=(1209,527),&S_B&=(1225,543).
 \end{aligned}
\]
The normalized counter inputs are \((1201,978)\) and \((894,1443)\), with terminal-run lengths \((1,1)\) and \((1,2)\). H0 gives \((4,2)\) and \((4,1)\); H1 gives \((2,1)\) and \((2,0)\). The leading \(3\times3\) minor has determinant 1211 modulo 1543. Trial division through the primes at most 37 verifies primality. Direct convolution verifies all outputs. \(\square\)

A second localized witness shows that the normalized local-counter output is not a function of the final residue alone. Keep the same public ribbon as in (9.20), but take
\[
x=(4,4,4),\qquad y=(4,5,7).
\tag{9.21}
\]
Exact computation gives
\[
 \begin{aligned}
 U&=(50,23,176,212),&V&=(283,297,98,78),\\
 R_A&=(2712,1892),&R_B&=(1169,1889),\\
 S_A&=(1216,202),&S_B&=(1216,187).
 \end{aligned}
\]
At the first coordinate the final residues are equal, but
\[
\tau(2712\operatorname{div}2)=\tau(1356)=2,
\qquad
\tau(1169\operatorname{div}2)=\tau(584)=3.
\]
Consequently H0 gives \((2,0)\) and \((1,0)\), while H1 gives \((1,0)\) and \((0,0)\). Thus equal final residues do not force equal local-counter outputs under the printed normalized rule.

**Proposition 9.8 — Every defined output is erased at the minimal precision.** For H0, if \(P\le n2^{2q+1}\), every defined output in (9.19) is zero. For H1 it suffices that \(P\le n2^{2q+2}\). If \(p\) is the least integer strictly exceeding \(2q+\log_2 n\) and \(P\) has \(p\) bits, both erasure conclusions apply to all defined outputs.

*Proof.* A defined counter requires \(\widetilde R_i=\lfloor R_i/n\rfloor\ge1\), hence \(\tau(\widetilde R_i)\ge1\), while \([QR_i]_P<P\). Each stated bound therefore places the numerator strictly below the denominator. The minimal bit length is \(p=2q+\lfloor\log_2 n\rfloor+1\), whence \(P<2^p\le n2^{2q+1}\). Inputs with \(0\le R_i<n\) give \(\widetilde R_i=0\), for which the printed unbounded loop is undefined; such a non-computation is never counted as agreement. \(\square\)

The zero-input issue occurs inside the historical bit-size domain. For example, with
\[
n=2,\quad m=6,\quad p=4,\quad q=1,\quad P=11,\quad Q=1,
\]
and
\[
A=(10,11,13,9,11,14,8),\qquad x=y=(1,1,1),
\]
one obtains \(U=V=(1,0,0,1)\) and \(R_A=R_B=(1,1)\). Thus \(\lfloor R_i/n\rfloor=0\), so the normalized historical counter is undefined even though \(R_i>0\).

For conditional finite checks, retain the public ribbon in (9.20) and
\[
A^{(2)}=(1810,1110,2023,1815,1926,1554,2031).
\]
Enumerating all \(64^2=4096\) secret pairs \(x,y\in\{4,5,6,7\}^3\) gives H0 agreement in 944 pairs and H1 agreement in 1600 pairs for the first ribbon, and H0 agreement in 986 pairs and H1 agreement in 1606 pairs for the second. No normalized counter is undefined in these two enumerations. These are conditional counts at deliberately selected public values, not averages over the full public-parameter law.

## 9.9. The rounded inverse problem and boundary projections

For a public vector \(u\) with every coordinate in \(\{0,\ldots,\lceil P/Q\rceil-1\}\) (reject other inputs), known integer bounds \(\ell\le x_j\le b\), and a fixed public matrix, the rounded inverse relation is exactly the existence of integer \(z_i\) such that
\[
 \begin{split}
 Q u_i\le\sum_j M(A)_{ij}x_j-Pz_i
 \le\min\{Q(u_i+1)-1,P-1\},\\
 \ell\le x_j\le b.
 \end{split}
 \tag{9.22}
\]
Indeed the middle expression is a canonical residue in precisely the requested cell. Conversely, any compatible secret supplies the integer quotients \(z_i\). This formulation distinguishes finding an admissible preimage from recovering the original sampled secret. Writing it as integer feasibility does not give a polynomial-time algorithm when the dimensions grow. The scalar interval algorithm from Chapter 5 is not invoked as a vector solver.

Non-cyclic structure also does not exclude every projection relation.

**Proposition 9.9 — Exact all-ones projection criterion.** Define column sums \(s_j=\sum_{i=0}^{L-1}M(A)_{ij}\). Then
\[
 s_j-s_{j+1}=a_{m-1-j}-a_{n-1-j},\qquad 0\le j<n.
 \tag{9.23}
\]
All column sums coincide modulo \(P\) exactly when the \(n\) displayed boundary differences vanish modulo \(P\). If the effective public coefficients are independent uniforms in an interval of \(H\le P\) consecutive integers, and \(m>2n\), the probability of these equalities is exactly \(H^{-n}\).

*Proof.* In the two column sums all common interior coefficients cancel, leaving their two endpoints. Under the dimension assumption the lower and upper endpoint index sets are disjoint, and all indices within each set are distinct. Reduction modulo \(P\) is injective on an interval of length at most \(P\). Each pair therefore matches with probability \(1/H\), independently of the other pairs. \(\square\)

This is a result about one predetermined projection weight vector, not about every relation chosen after observing \(A\), and not a claim of either general insecurity or security. Cryptanalytic experiments are treated only to the extent made reproducible in Chapter 14. No new LLL, BKZ or mixed-integer optimization benchmark is claimed in this chapter.

## 9.10. Why algebraic similarity does not identify the source distribution

**Proposition 9.10 — Two exact statistical distances.** Compare the following auxiliary public distributions.

First, sample a uniformly random Toeplitz \(L\times d\) matrix over \(\mathbb Z/P\mathbb Z\) through its \(m=L+d-1\) independent diagonal coefficients. Its distance from a matrix of \(Ld\) independent uniform entries is
\[
 1-P^{m-Ld}.
 \tag{9.24}
\]
Second, let \(P\) have \(p\) bits, put \(H=2^{p-1}\), and sample an effective ribbon of length \(m\) uniformly from \([H,2H)^m\cap\mathbb Z^m\). After reduction modulo \(P\), its distance from an independent full-modulus ribbon is
\[
 1-(H/P)^m.
 \tag{9.25}
\]

*Proof.* In the first comparison, the map from the diagonal ribbon to its matrix is injective, because every diagonal position occurs. The structured law is uniform on \(P^m\) of the \(P^{Ld}\) matrices. In the second, the interval has \(H\le P\) distinct residues, so the law is uniform on \(H^m\) of \(P^m\) ribbons. For a uniform law on a subset of size \(s\) of an ambient set of size \(N\), direct summation of total variation gives \(1-s/N\). \(\square\)

When \(L=1\) or \(d=1\), (9.24) is zero, as it should be. Neither expression is a cryptanalytic advantage against a correctly defined rounded-publication game: the public distribution must be the same in that game's real and ideal worlds. The distances instead prohibit a silent statistical replacement of the public matrix.

A similar issue affects the factors. In P-ROUND, the public factor is long and the private factor short; the published MP-CLWR source used below has a short public factor and a long conditioned secret. In the direct historical identification, assigning \(N=d\) and middle-product length \(D=L\) would even violate \(D\le N\) under \(L\ge d+1\). Commutativity does not change what an adversary knows. This rules out that simple identification, not every possible reduction. The new hardness research reserved for V2 is not resumed here.

## 9.11. Reference rounding, inverse sampling and reconciliation

We now describe **P-REF**, an even-modulus specialization of the published middle-product rounding framework ([B09](#bib-b09); [B23](#bib-b23)). All symbols in this section are separate from the historical bit lengths. Let
\[
 q_0=2^b,\quad p_0=2^a,\quad b>a\ge1,\quad b\ge3,
 \qquad B=q_0/p_0.
 \tag{9.26}
\]
In particular \(B\) is even and \(8\mid q_0\). Define nearest rounding with exact half-integers rounded upward:
\[
 \mathcal R(c)=
 \left[\left\lfloor\frac{p_0[c]_{q_0}}{q_0}+\frac12\right\rfloor\right]_{p_0}.
 \tag{9.27}
\]

**Proposition 9.11 — Shifted quotient and exact inverse fiber.** For all integers \(c\),
\[
 \mathcal R(c)=F_{q_0,B}(c+B/2).
 \tag{9.28}
\]
For \(y\in\{0,\ldots,p_0-1\}\), a uniform inverse-fiber sample is
\[
 \operatorname{INV}(y)=[By-B/2+e]_{q_0},
 \qquad e\leftarrow\operatorname{Unif}\{0,\ldots,B-1\}.
 \tag{9.29}
\]
Any two points in one fiber have circular distance at most \(B-1\).

*Proof.* Write \([c]_{q_0}=Bu+r\), \(0\le r<B\). Both rounding expressions give \([u+\mathbf1_{r\ge B/2}]_{p_0}\). Formula (9.29) lists exactly the \(B\) consecutive circular representatives belonging to a fiber, each once. Two lifts in that interval differ by at most \(B-1\). \(\square\)

Nearest rounding is not the unshifted floor in P-ROUND: \(q_0=16,p_0=4,c=2\) gives 1 here and 0 for the unshifted quotient. Boundary ties have positive probability. Replacing INV by \(By\) also changes the law.

For a canonical \(x\in\mathbb Z_{q_0}\), define
\[
 K(x)=\left[\left\lfloor\frac{2x}{q_0}+\frac12\right\rfloor\right]_2,
 \qquad C(x)=\left[\left\lfloor\frac{4x}{q_0}\right\rfloor\right]_2.
 \tag{9.30}
\]
Put
\[
 \begin{split}
 I_0&=\{0,\ldots,q_0/4-1\},\\
 I_1&=\{-q_0/4,\ldots,-1\},\\
 E&=\{-q_0/8,\ldots,q_0/8-1\}.
 \end{split}
\]
Define \(\operatorname{REC}(y,c)=0\) if \([y]_{q_0}\in I_c+E\pmod {q_0}\), and 1 otherwise. All intervals contain integers; the endpoints are part of the specification.

**Lemma 9.12 — Reconciliation and uniformity.** If \(d_{q_0}(x,y)<q_0/8\), then
\[
 \operatorname{REC}(y,C(x))=K(x).
 \tag{9.31}
\]
For uniform \(x\), the pair \((K(x),C(x))\) is uniform on four pairs.

*Proof.* The four successive quarters have pairs \((0,0),(1,1),(1,0),(0,1)\), each on exactly \(q_0/4\) integers. For correction, write \(q_0=8h\). For hint 0 the zero-decoding region is \([-h,3h-2]\pmod{8h}\), and for hint 1 it is \([-3h,h-2]\pmod{8h}\). The quarters with key bit zero, expanded by integer errors in \([-h+1,h-1]\), stay in their respective zero regions; the other two expanded quarters stay outside them. This also checks the modular endpoint and \(h=1\). \(\square\)

These operations are attributed to the reference construction and its reconciliation lineage. They are not added silently to the historical exchange.

## 9.12. Complete P-REF algorithms and perfect correctness

Use integers \(d_0,k_0\ge2\), \(N\ge d_0+k_0\), \(t\ge1\), and put \(D_0=d_0+k_0\). For fixed array lengths \(l_a,l_b\), define
\[
 \operatorname{MP}_D(a,b)_i=[z^{h+i}](ab),\qquad
 h=(l_a+l_b-1-D)/2,
 \tag{9.32}
\]
only when \(h\) is a nonnegative integer. Products are ordinary convolutions, not cyclic products. The random oracle is classical and has domain \(\{0,1\}^{d_0}\) and range \(\{0,1\}^{k_0}\).

**KeyGen.** Sample \(s\) uniformly from \(\mathbb Z_{q_0}^{N+D_0-1}\), rejecting until the \(D_0\times N\) Hankel matrix \((s_{i+j})\) is surjective. For each \(j=1,\ldots,t\), draw an independent uniform \(a_j\in\mathbb Z_{q_0}^N\), set
\[
 b_j=\mathcal R\bigl(\operatorname{MP}_{D_0}(a_j,s)\bigr),
 \tag{9.33}
\]
and return \(pk=((a_j,b_j))_j\), \(sk=s\).

Over \(\mathbb Z/2^b\mathbb Z\), surjectivity is equivalent to full row rank modulo 2. One direction follows by reduction. Conversely a full-rank binary minor has odd determinant, hence is invertible modulo \(2^b\), giving a right inverse on those columns. A nonzero determinant over the reals is insufficient; the matrix \([2]\) modulo 4 is the simplest counterexample. The published random-Hankel bound ([B23](#bib-b23); Lemma 4.1) gives acceptance probability at least \(1/2\) here. Thus exact rejection samples the required conditional law in expected polynomial time; a cap of \(\lambda\) trials causes an explicit abort of probability at most \(2^{-\lambda}\). The density bound is an attributed published input, not proved anew by the finite tests.

**Encrypt.** For each \(j\), draw independent uniform \(r_j\in\{0,1\}^{k_0+1}\) and independently lift each coefficient of \(b_j\) by (9.29), obtaining \(u_j\). Compute
\[
 c_1=\sum_j r_ja_j\pmod{q_0},\qquad
 v=\sum_j\operatorname{MP}_{d_0}(r_j,u_j)\pmod{q_0},
 \tag{9.34}
\]
then, for a \(k_0\)-bit message \(m\), return
\[
 (c_1,c_2,c_3)=\bigl(c_1,C(v),\mathcal H(K(v))\mathbin\oplus m\bigr).
 \tag{9.35}
\]
Here \(c_1\) has length \(N+k_0\), \(c_2\) length \(d_0\), and \(c_3\) length \(k_0\). The maps \(K,C,\mathcal R,\operatorname{INV}\) act coefficientwise.

**Decrypt.** Compute
\[
 w=\operatorname{MP}_{d_0}(c_1,s)\pmod{q_0},\qquad
 m'=c_3\mathbin\oplus\mathcal H(\operatorname{REC}(w,c_2)).
 \tag{9.36}
\]
The scheme is randomized even though its public-key rounding is deterministic. A real hash function is not silently identified with \(\mathcal H\).

**Lemma 9.13 — Reference weak associativity.** At these exact lengths,
\[
 \operatorname{MP}_{d_0}\bigl(r,\operatorname{MP}_{D_0}(a,s)\bigr)
 =\operatorname{MP}_{d_0}(ra,s).
 \tag{9.37}
\]

*Proof.* The inner product window starts at degree \(N-1\); the outer window starts at degree \(k_0\). Its \(i\)-th coefficient is \(\sum_{h=0}^{k_0}r_h[as]_{N+k_0-1+i-h}\). These indices all lie between \(N-1\) and \(N+D_0-2\), so no needed coefficient was discarded. They are exactly the coefficients selected from \((ra)s\). \(\square\)

**Theorem 9.14 — Perfect correctness of P-REF.** If
\[
 p_0>8t(k_0+1),
 \tag{9.38}
\]
then decryption returns every message for every honest key and every encryption randomness.

*Proof.* Let \(e_j\) be a signed circular lift of \(u_j-\operatorname{MP}_{D_0}(a_j,s)\) with every coefficient bounded in magnitude by \(B-1\). Such lifts exist by Proposition 9.11 because both vectors round to \(b_j\). By (9.37),
\[
 v-w\equiv\sum_j\operatorname{MP}_{d_0}(r_j,e_j)\pmod{q_0}.
 \tag{9.39}
\]
Each output is a sum of at most \(t(k_0+1)\) signed error terms, with binary multipliers. It has a representative of magnitude at most \(t(k_0+1)(B-1)<q_0/8\) under (9.38). Lemma 9.12 recovers \(K(v)\) exactly. The two oracle masks coincide and cancel. \(\square\)

This is a theorem about the specified reference, not a reconciliation theorem for H0/H1 or an automatic repair of P-ROUND.

## 9.13. The precise computational assumption

The source assumption for P-REF is \(\operatorname{MP\!\!-CLWR}_{p_0,q_0,N,D_0,t}\) in its computational, task-preservation formulation ([B09](#bib-b09); [B23](#bib-b23); Definition 4.3). The real source samples a single \(s\) from the conditioned law in KeyGen and then the \(t\) pairs in (9.33). The ideal source samples each \(a_j\) uniformly as before and sets \(b_j=\mathcal R(y_j)\) for independent uniform \(y_j\in\mathbb Z_{q_0}^{D_0}\). In this divisible-modulus specialization, \(b_j\) is uniform in \(\mathbb Z_{p_0}^{D_0}\).

For each polynomial-time challenger that maps its source and independent coins to an input and a target, the assumption says: if every polynomial-time adversary has negligible target-recovery probability under the ideal source, then every such adversary has negligible recovery probability under the real source. The challenger and adversary algorithms must be the same in both worlds. The source secret is not supplied to that challenger as extra information. The sample budget \(t\) and the full parameter family are fixed in advance.

This is not asserted to be ordinary decisional pseudorandomness of the public key. Nor is it an assumption that the encryption scheme is already secure. Section 9.14 exhibits the specific recovery task and proves its ideal-world bound. Public statements on MP-LWE hardness in ([B09](#bib-b09)) concern additional theorems with their own distributions and parameters; that harder source-justification chain is not reconstructed or extended to historical MODDIV in this chapter.

## 9.14. Conditional classical random-oracle security of the reference

This section gives the proof route for the attributed reference construction in explicit form, while keeping the attribution to the published construction. All dimensions and modulus bit lengths below are polynomial in a security parameter \(\lambda\), and all adversaries make polynomially many classical oracle queries.

**Lemma 9.15 — Universal hashing with the complete lift as seed.** Let the \(u_j\) be independent uniform vectors in \(\mathbb Z_{q_0}^{D_0}\). For binary arrays \(r=(r_1,\ldots,r_t)\), define
\[
 h_u(r)=\sum_j\operatorname{MP}_{d_0}(r_j,u_j)\pmod {q_0}.
 \tag{9.40}
\]
For every \(r\ne r'\), the difference \(h_u(r)-h_u(r')\) is uniform in \(\mathbb Z_{q_0}^{d_0}\). In particular its zero probability is \(q_0^{-d_0}\).

*Proof.* In one nonzero difference block \(\delta=r_j-r'_j\), let \(h\) be its last nonzero coefficient. It is \(1\) or \(-1\). In the \(i\)-th middle-product output it multiplies \(u_{k_0+i-h}\). Select these \(d_0\) coefficients as variables and fix all other coefficients and blocks. Solving outputs from the largest \(i\) to the smallest is triangular: earlier coefficients of \(\delta\) involve only larger selected indices or already fixed coefficients. The diagonal is \(\delta_h\), a unit even modulo a power of two. Each output has the same number of preimages, proving uniformity. \(\square\)

**Lemma 9.16 — Ideal lifted source with bounded leakage.** In the ideal source, generate each \(u_j\) first uniformly in \(\mathbb Z_{q_0}^{D_0}\) and set \(b_j=\mathcal R(u_j)\). This gives exactly the joint distribution obtained by sampling \(b_j\) and then applying INV. With independent uniform binary \(r_j\), define \(c_1,v\) by (9.34). If \(V_0\) is an independent uniform vector of length \(d_0\), then
\[
 \operatorname{TV}\bigl((a,u,c_1,v),(a,u,c_1,V_0)\bigr)
 \le\epsilon_{\rm ext}:=
 \frac12\sqrt{2^{-t(k_0+1)}q_0^{N+k_0+d_0}}.
 \tag{9.41}
\]

*Proof.* Proposition 9.11 shows that all fibers have size \(B\); sampling their label uniformly and then a uniform element of the fiber is equivalent to sampling the full element first. Thus the complete seed \(u\) is uniform and independent of \(a,r\).

Fix \(a\). The map \(r\mapsto c_1\) has at most \(q_0^{N+k_0}\) values. Conditional on a nonempty fiber of size \(s_c\), the binary array \(r\) is uniform on that fiber. Universality implies expected squared distance of its hashed distribution from uniform is at most \(1/s_c\): expand the collision probability over equal and unequal input pairs, using collision probability \(q_0^{-d_0}\) for the latter. Cauchy–Schwarz converts this into an average total variation bound \(\tfrac12\sqrt{q_0^{d_0}/s_c}\), with the seed included in the observation. If \(T=2^{t(k_0+1)}\), weighting by \(s_c/T\) and applying Cauchy–Schwarz once more gives
\[
 \frac{\sqrt{q_0^{d_0}}}{2T}\sum_c\sqrt{s_c}
 \le\frac12\sqrt{\frac{q_0^{d_0}q_0^{N+k_0}}T}.
\]
This holds for every fixed \(a\), so averaging proves (9.41). \(\square\)

Revealing the whole lift is stronger than revealing only \(b\). Apply \(b=\mathcal R(u)\), discard \(u\), and compute \((C(v),K(v))\); data processing does not increase the distance. In the comparison world, Lemma 9.12 makes \(K(V_0)\) uniform even given \(C(V_0)\). Hence every recovery strategy for \(z=K(v)\) from \((pk,c_1,c_2)\) has ideal-source success at most
\[
 2^{-d_0}+\epsilon_{\rm ext}.
 \tag{9.42}
\]

**Theorem 9.17 — Conditional IND-CPA in the classical ROM.** Suppose
\[
 \begin{gathered}
 d_0\ge\lambda,\qquad
 t(k_0+1)\ge2\lambda+(N+k_0+d_0)\log_2q_0,\\
 p_0>8t(k_0+1).
 \end{gathered}
 \tag{9.43}
\]
Under the computational source assumption of Section 9.13, P-REF is IND-CPA secure in the classical random-oracle model. Exact KeyGen has expected polynomial running time; capped KeyGen has an explicit negligible abort allowance.

*Proof.* The ideal recovery bound (9.42) is at most \(2^{-\lambda}+2^{-\lambda-1}\), hence negligible. The recovery challenger takes the source pairs, draws the same \(r_j\) and INV samples as Encrypt, outputs \((pk,c_1,c_2)\), and keeps target \(z=K(v)\). It is a valid challenger for the computational assumption: it uses no source secret and its procedure is identical in both worlds. The assumption therefore makes every polynomial-time real-source recovery probability negligible.

It remains to link IND-CPA advantage to this recovery task. Given \((pk,c_1,c_2)\), an extractor simulates an IND-CPA adversary, a lazy random-oracle table, and an independent challenge bit. The adversary sees \(pk\), chooses its two messages, and receives \((c_1,c_2,c_3)\) with \(c_3\) uniform and independent. The challenger may presample \(c_1,c_2,z\), because their law does not depend on the message. In this independent-mask game the transcript does not reveal the challenge bit.

Couple it to the real game until the first query on \(z\). Before that event, the real value \(\mathcal H(z)\) is an unused uniform mask and all observations have the same law. Thus the adversary's success bias \(\eta=|\Pr[\widehat\beta=\beta]-1/2|\) is at most the probability of querying \(z\). Record all distinct queries, including those made before the challenge. If their total is bounded by a public polynomial \(T_{\mathcal H}\ge1\), output a uniformly selected position among \(T_{\mathcal H}\) slots, using a fixed dummy candidate for an unused slot. Recovery then succeeds with probability at least \(\eta/T_{\mathcal H}\). The extractor does not recognize the correct query and does not identify it by a possibly colliding oracle output.

A nonnegligible IND-CPA bias would contradict real-source target hardness. This proves the claim for classical queries. The conditioned secret sampler uses polynomial-time rank tests; the published acceptance bound described in Section 9.12 gives expected polynomial time, or a negligible difference under the stated cap. Correctness follows separately from Theorem 9.14. \(\square\)

The explicit condition \(d_0\ge\lambda\) is sufficient to make guessing the oracle input negligible. The proof would not justify dropping that requirement while leaving \(d_0\) constant. This is a conditional theorem for an attributed reference scheme. It is not a proof for a concrete hash, the quantum random-oracle model, chosen-ciphertext security, or historical P-ROUND.

## 9.15. Nonempty parameter families and representation costs

The conditions are not merely a formal conjunction with no examples. The following conservative family satisfies the stated inequalities; it is not optimized for deployment.

**Proposition 9.18 — A polynomially describable family satisfying (9.43).** For integer \(\lambda\ge2\), let \(L_0=\lfloor\log_2\lambda\rfloor+1\), set
\[
 N=2\lambda,\quad d_0=k_0=\lambda,\quad t=64L_0,
 \tag{9.44}
\]
and choose \(p_0\) as the least power of two strictly greater than \(8t(\lambda+1)\), and \(q_0\) as the least power of two strictly greater than \(2p_0N^3t\). Then all the dimension, modulus, correctness and entropy inequalities above hold. This statement does not establish the source hardness assumption.

*Proof.* Strict powers give \(p_0>8t(\lambda+1)\), \(q_0>p_0\), and \(8\mid q_0\). Also \(D_0=N\). The upper bounds
\[
 p_0<32t\lambda,\qquad q_0<1024t^2\lambda^4
       =2^{22}L_0^2\lambda^4
 \tag{9.45}
\]
imply \(\log_2q_0<22+6L_0\). For \(L_0\ge3\),
\[
 2+4\log_2q_0<90+24L_0\le64L_0=t.
\]
Multiplying by \(\lambda\) proves the entropy inequality in (9.43), since \(t(\lambda+1)\ge t\lambda\). For \(L_0=2\), \(\lambda=2,3\); direct integer calculation gives respectively \((t,p_0,q_0)=(128,4096,134217728)\) and \((128,8192,536870912)\), both satisfying it. All dimensions, moduli and bit lengths have polynomial upper bounds. \(\square\)

Writing \(\lambda=128\) in this family is not an estimate of 128-bit resistance. Source hardness, reduction losses, best attacks and concrete parameters would still need a separate study. Here the extra size of \(q_0\) preserves the family defined in Proposition 9.18; it is not used to claim a new hardness reduction.

With fixed-length, bit-packed fields, P-REF has arithmetic payload sizes
\[
 \begin{split}
 |pk|&=t\bigl(N\log_2q_0+D_0\log_2p_0\bigr),\\
 |sk|&=(N+D_0-1)\log_2q_0,\\
 |ct|&=(N+k_0)\log_2q_0+d_0+k_0
 \end{split}
 \tag{9.46}
\]
in bits, excluding profile identifiers and formatting. These describe the explicitly listed public polynomials, not a seed-compressed variant. For historical P-ROUND, effective public data include \(m\) ribbon coefficients and \(L\) quotients; their sizes follow their own alphabets, not (9.46). An unused \(a_m\) may be omitted only from an explicitly documented representation, not from a claim about the original file format.

## 9.16. Reproducible checks and limits of the implementation

The package uses standard-library Python, arbitrary-precision integers, exact fractions where probabilities are computed, and deterministic test seeds. The mathematical reference exposes separate functions for windows, historical rounding, the bare finite-field solver and P-REF. The seeded generator and the lazy ideal-oracle table are testing facilities, not a deployable cryptographic implementation or a proof about a physical entropy source.

| Verification family | Extent executed |
|---|---:|
| Signed window, matrix and nested-product instances | 2,500 |
| Exact finite-field key predictions | 10,913 |
| Predictions among those with rank-deficient public matrices | 1,817 |
| Rounded residual and circular-bound instances | 4,000 |
| Column-sum boundary identities | 4,000 |
| Secret pairs at the two selected fixed public ribbons | 8,192 |
| Defined historical erasure checks | 7,425 |
| Normalized-zero undefined-counter checks | 50 |
| Coefficient bit-length bounds | 361 |
| Signed nearest-rounding inputs | 12,315 |
| Complete inverse-rounding fibers | 492 |
| Reconciliation inputs with all permitted small displacements | 21,336 |
| Binary rank versus exhaustive images modulo 4 | 64 |
| Reference weak-associativity instances | 1,200 |
| Nonzero binary-difference hash cases modulo 4 | 26 |
| Complete seeds examined in those hash cases | 6,656 |
| Reference encryptions | 132 |
| Additional extremal-lift encryptions | 2 |
| Parameter-family inequalities for \(2\le\lambda\le256\) | 255 |

The categories are not summed as independent cryptographic experiments. The 1,817 rank-deficient predictions are a subset of the 10,913, not additional trials. The statement about primes in the finite-field solver is an input assumption; that solver is not used over arbitrary composite moduli.

The 132 reference encryptions consist of 120 functionality tests at \((N,d_0,k_0,t,p_0,q_0)=(8,4,4,3,256,65536)\), which satisfies the correctness condition but not the security entropy bound, and four tests each for the Proposition 9.18 family at \(\lambda=2,8,16\). All messages are recovered. These finite labels do not confer security. The largest observed error at the functionality profile is 797, below the proved bound \(3\cdot5\cdot255=3825<8192\); a bound is justified by Theorem 9.14, not by this maximum.

A negative control uses \(q_0=32,p_0=2,N=4,d_0=k_0=2,t=1\), outside (9.38). With the distributed test-vector inputs, it yields \(v=(5,31)\), \(w=(11,1)\), target bits \((0,0)\) and decoded bits \((1,0)\). The true lift fibers are respected. This confirms that the tests can detect a violation rather than presuming agreement.

The independent verifier does not import the primary polynomial arithmetic module. It recomputes the 8,192 selected secret pairs through full convolutions and the normalized printed counter loop, reconstructs eight saved reference encryption traces, and checks 1,000 further signed window identities. It verifies 308 compatible field preimages in 250 sampled public experiments, 24 additional inverse fibers and 1,240 reconciliation cases using explicit sets. Recomputing the same fixtures is a consistency check, not an additional security benchmark.

From `supplementary/chapter-09/`, run the delivered deterministic entry points:

```sh
python3 verify.py
python3 verify_independent.py
```

These entry points regenerate the primary and independent exact result objects and compare them with the distributed references.

The two JSON result files contain exact outputs and counts; neither program runs a network request. The stored synthetic reference traces contain test secrets solely to permit independent validation. The passive field solver receives only its public system. No LLL/BKZ campaign, large-dimensional rounded-secret recovery, CCA evaluation or quantum attack estimate is performed. The code checks functionality and the stated finite identities, not the computational assumption of Section 9.13.

## 9.17. Consequences for the polynomial article and the thesis

The polynomial article should preserve the same distinctions. Its first contribution can be an exact specification and analysis of the historical non-cyclic windows. Its algebraic mechanism is sound when the two windows are compatible; its rounded key extraction requires a separate boundary or reconciliation proof. An analysis of H0/H1 is not permission to replace the current public fixed \(r\) with adaptive counters. Conversely, a new fixed divisor cannot be called a proof of universal agreement solely because the residual error is small.

The chapter's positive reference theorem belongs to P-REF: a fully specified, attributed specialization of an existing encryption scheme under its computational MP-CLWR assumption and the classical ROM. Its public factor lengths, secret law, rounding convention, lifting randomness and hints differ from P-ROUND. The presence of the words *polynomial*, *middle product*, or *rounding* in both descriptions is not a security reduction.

This chapter neither discards the historical polynomial research nor declares it secure. It supplies a stable mathematical separation on which an article can be written without mixing incompatible conclusions. The original manuscript and earlier chapters are left unchanged. The public supplementary material identifies the code, exact counterexamples and verification outputs used for this chapter. No external peer review, formal proof-assistant certification, worldwide novelty determination, or cryptographic deployment recommendation is implied.



## Supplementary Material and Reproducibility — Chapter 9

The public supplementary material for this chapter is assigned to `supplementary/chapter-09/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 10 — Unit-Anchored MODDIV-WC {#ch10}
## Exact Binary-LWE Embedding, One-Way Security, and Conditional CCA Composition




### Abstract

MODDIV-WC is a proof-oriented construction with an explicit change of secret distribution and dimensions relative to historical MODDIV. A secret coordinate fixed to one makes a widened Hankel map surjective for every permitted secret. A sparse embedding and an independently sampled parity mask then convert a binary-secret LWE instance into the exact noisy auxiliary public-key distribution required by the analysis. The actual base encryption scheme contains deterministic quotient publications, fresh random lifts at encryption, and reconciliation; it does not add that auxiliary LWE error during key generation. This chapter gives the complete algorithms, proves perfect correctness using signed modular discrepancy, and derives one-way chosen-plaintext security through residual hashing and a multiplicative order-two Rényi bound. It then states and explains the classical random-oracle, implicit-rejection Fujisaki–Okamoto composition with explicit query accounting. Exact FAST arithmetic and programmable-oracle public-key compression preserve their stated interfaces. A separate necessary-condition analysis shows why the current proof inequalities cannot certify a kilobyte-scale public key at a target bound of \(2^{-128}\): even a favorable relaxation requires 4,726,272 bytes. This is a limitation of the proof formula, not a universal key-size lower bound or an attack. All cryptographic conclusions remain conditional; no concrete security level, standard-model SHAKE256 theorem, quantum-random-oracle theorem, or historical security transfer is asserted.

### Scope and position in the thesis

This chapter treats the revised MODDIV-WC specification as a proof-oriented descendant of the ModDiv line. It changes the secret law and widens the public Hankel representation specifically so that exact source embeddings, exact correctness and a modular CCA route can be stated. It is not a retroactive security proof for the historical scalar or multidimensional constructions.

Four layers remain separate: BASE is the explicit-key encryption scheme; FAST is an exact evaluation identity; COMPACT replaces explicit uniform public Hankel inputs by a short seed only in a dedicated programmable classical random oracle; and the implicit-rejection KEM uses separate oracle domains and canonical encodings. A concrete SHAKE256 expander is only a functional instantiation unless an additional theorem justifies replacing the ideal oracle.

The constructions studied in Chapters 9, 11 and 12 are not renamed WC, and no result in this chapter is transferred to them by resemblance.

## 10.1. What changes relative to historical MODDIV

A multiplication window and integer division are not a complete cryptosystem. WC fixes a new secret law, a widened public representation, an encryption algorithm, and a security game. It is therefore a distinct descendant, not a retroactive proof for a historical exchange.

There are four layers in the present discussion. **BASE** is the explicit-key public-key encryption scheme. **FAST** is an algebraically exact evaluation method. **COMPACT** represents the public random blocks by a seed in a dedicated programmable random oracle. **FO** is a separately specified implicit-rejection key-encapsulation wrapper. Correctness of BASE, functional equivalence of FAST, distributional simulation of COMPACT, and chosen-ciphertext security of FO are different obligations.

The chapter-local executable tests distinguish the PKE interface from the later Encaps/Decaps wrapper. A filename or historical implementation snapshot is not used as evidence that a tested KEM interface existed; only the algorithms and tests delivered with this edition support the claims made here.

## 10.2. Parameters, notation, and security experiments

Let all dimensions and bit lengths be integers, with
\[
q\ge1,\quad p\ge q+3,\quad P=2^p,\quad Q=2^q,\quad H=P/Q,
\qquad h,L,t\ge1,\quad 1\le\kappa\le L.
\tag{10.1}
\]
Define
\[
d=(h-1)L+2,\qquad m=hL+1=d+L-1.
\tag{10.2}
\]
For \(z\in\mathbb Z\), \([z]_P\) is its canonical residue. The quotient map and the widened Hankel map are
\[
F_Q(z)=\left\lfloor\frac{[z]_P}{Q}\right\rfloor,
\qquad
T_x(a)_i=\left[\sum_{j=0}^{d-1}a_{i+j}x_j\right]_P,
\quad 0\le i<L.
\tag{10.3}
\]
Here \(a\in\mathbb Z_P^m\), \(x\in\mathbb Z_P^d\), and \(F_Q\) acts componentwise. Arrays have fixed lengths; leading or trailing zeros do not change them. These are non-cyclic windows, not multiplication modulo a polynomial such as \(z^L+1\).

The secret distribution is the product law
\[
X_0=1,\qquad
X_j\mathrel{\$\leftarrow}\{Q,\ldots,2Q-1\}\quad(1\le j<d),
\tag{10.4}
\]
with independent tail coordinates. This differs both from the historical positive-half interval and from a long secret sampled conditionally on a rank test. The same \(X\) is used for all \(t\) public blocks.

The binary-LWE source used below consists of \(tL\) rows grouped into \(t\) matrices \(A^{(b)}\in\mathbb Z_P^{L\times h}\). Their entries are mutually uniform and independent. A single secret \(s\) is uniform in \(\{0,1\}^h\). In the real experiment,
\[
b^{(b)}=A^{(b)}s+E^{(b)}\pmod P;
\tag{10.5}
\]
in the ideal experiment, the \(b^{(b)}\) are mutually uniform and independent of the matrices. For the principal theorem, integer errors are independently sampled from a specified symmetric law \(\chi\), independently of matrices and secret. Hardness of this **specified ensemble** is a premise, not a conclusion of the algebraic embedding.

Let \(\operatorname{Adv}_{\rm bin}\) denote an absolute difference of source acceptance probabilities. Let \(p_{\rm OW}\) denote success in recovering a uniformly sampled \(\kappa\)-bit message from a PKE public key and challenge ciphertext. For the KEM we use the **success-bias convention**
\[
\eta_{\rm CCA}=\left|\Pr[b'=b]-\tfrac12\right|.
\tag{10.6}
\]
An acceptance-gap convention for the KEM is twice this quantity. These conventions must not be interchanged inside a quantitative bound. All reductions are evaluated at their actual running times and sample/query budgets.

## 10.3. The unit anchor and what its uniformity does not say

**Proposition 10.1 — Surjectivity for every anchored secret.** For fixed \(x\) with \(x_0=1\), the map \(T_x:\mathbb Z_P^m\to\mathbb Z_P^L\) is surjective, and every output has exactly \(P^{d-1}\) preimages. Thus uniform \(a\) produces a jointly uniform vector \(T_x(a)\).

*Proof.* Fix a target \(y\) and arbitrary values for the \(d-1\) coordinates \(a_L,\ldots,a_{m-1}\). Solve, in descending order \(i=L-1,\ldots,0\),
\[
a_i=y_i-\sum_{j=1}^{d-1}a_{i+j}x_j\pmod P.
\tag{10.7}
\]
All terms on the right are already fixed. Each tail has exactly one completion, giving \(P^{d-1}\) preimages. Uniform counting measure therefore maps to uniform counting measure. No field assumption, random rank event, or inversion of a nonunit is needed. \(\square\)

In particular, conditioned on \(X=x\), output coordinates are independent uniforms before the public vector is disclosed. Across independent public blocks they remain jointly uniform conditioned on \(X\). This is useful inside an expectation over the public randomness.

It does **not** say that the pair \((a,T_X(a))\) is independent or pseudorandom. Once \(a,X\) are fixed, the output is deterministic. For example, modulo 4 with quotient divisor 2, \(a=(1,1)\) gives quotient 1 for \(x=(1,2)\), but quotient 0 for \(x=(1,3)\). Uniform marginal outputs are compatible with a public correlation. This small arithmetic example illustrates a logical distinction, not an attack estimate for a WC family.

## 10.4. Sparse embedding and the exact secret mask

For one \(L\times h\) matrix \(A\), choose an independent uniform \(a_0\) and set
\[
a_{1+vL+i}=A_{i,v},\qquad
0\le v<h,\quad0\le i<L.
\tag{10.8}
\]
These positions cover \(1,\ldots,hL\) exactly. Consequently the developed vector \(a\) is uniform on \(\mathbb Z_P^m\). Define a sparse vector of length \(d\) by
\[
\iota(s)_{1+vL}=s_v\quad(0\le v<h),
\qquad \iota(s)_j=0\text{ elsewhere}.
\tag{10.9}
\]
The last active position is \(1+(h-1)L=d-1\).

**Proposition 10.2 — Exact matrix embedding.** For every matrix and binary vector of these dimensions,
\[
T_{\iota(s)}(a)=As\pmod P.
\tag{10.10}
\]

*Proof.* Coordinate \(i\) is \(\sum_{v=0}^{h-1}a_{i+1+vL}s_v=\sum_vA_{i,v}s_v\). The additional coordinate \(a_0\) is multiplied by zero. Every index lies within \(a\). \(\square\)

To obtain the WC secret law, draw **one** mask \(R\), independently of \(s\) and all source samples. Set \(R_0=1\). At active positions draw uniformly from \(\{Q,Q+2,\ldots,2Q-2\}\); at other tail positions draw uniformly from \(\{Q,\ldots,2Q-1\}\). Put
\[
X=R+\iota(s).
\tag{10.11}
\]

**Proposition 10.3 — Exact masked source simulation.** The vector \(X\) in (10.11) has exactly (10.4). Using the same mask for all blocks, the public transformation
\[
y^{(b)}=b^{(b)}+T_R(a^{(b)})\pmod P
\tag{10.12}
\]
turns the real source into \(y^{(b)}=T_X(a^{(b)})+E^{(b)}\pmod P\). In the ideal source the \(y^{(b)}\) are uniform and independent of the public vectors.

*Proof.* Each integer in \([Q,2Q)\) has a unique decomposition into an even base in that interval plus a parity bit. Since the bits of the uniform \(s\) are independent and the mask coordinates are independent, all tail coordinates of \(X\) are independent uniforms. No modular wraparound occurs in (10.11). Proposition 10.2 and linearity prove (10.12). In the ideal experiment, condition on all masks and matrices: translation of independent uniform \(b^{(b)}\) preserves their joint uniformity. Forget the conditioned variables. \(\square\)

The simulator knows \(R\), not \(s\) or \(X\). It never outputs the mask as part of the key. The uniform binary-secret hypothesis is essential: a fixed bit at an active position restricts that coordinate of \(X\) to one parity class. Refreshing \(R\) separately for each block would generally create different secrets and would not simulate the specified common-secret experiment.

The widening pays for the embedding: \(h\) independent matrix columns become disjoint length-\(L\) pieces of the public vector. This is not a proof that an arbitrary short-secret Hankel problem is standard LWE.

## 10.5. Complete explicit-key PKE

Impose in addition the correctness condition
\[
t(Q-1)<P/8.
\tag{10.13}
\]
**KeyGen.** Draw \(X\) according to (10.4). Draw \(t\) independent public vectors \(a^{(b)}\) uniformly in \(\mathbb Z_P^m\), and compute
\[
Y^{(b)}=T_X(a^{(b)}),\qquad U^{(b)}=F_Q(Y^{(b)}).
\tag{10.14}
\]
Return \(pk=((a^{(b)},U^{(b)}))_{b=0}^{t-1}\), \(sk=X\). There is **no sampled additive error in this KeyGen**. The errors in (10.5) belong to a reduction experiment.

**Enc.** For a message \(M\in\{0,1\}^{\kappa}\), draw independent selection bits \(r_b\) and independent uniform remainders \(\rho_i^{(b)}\in\{0,\ldots,Q-1\}\). Define
\[
u^{(b)}=QU^{(b)}+\rho^{(b)},\qquad
c_1=\left[\sum_b r_ba^{(b)}\right]_P,\qquad
v=\left[\sum_b r_bu^{(b)}\right]_P.
\tag{10.15}
\]
For integer inputs define
\[
K_P(z)=\left\lfloor\frac{[z+P/4]_P}{P/2}\right\rfloor,
\qquad C_P(z)=\left\lfloor\frac{[z]_P}{P/4}\right\rfloor\bmod2.
\tag{10.16}
\]
Set \(c_2=C_P(v)\), and let \(c_3=M\oplus K_P(v)_{0:\kappa}\). The ciphertext is \((c_1,c_2,c_3)\), with lengths \(m,L,\kappa\). All \(tL\) lift values are drawn even when a selection bit is zero. The deterministic tape contains \(t(1+Lq)\) mathematical bits, not the unspecified internal bit consumption of a software PRNG.

**Dec.** Compute \(w=T_X(c_1)\) and use
\[
\operatorname{Rec}_P(y,b)=
\begin{cases}
0,&[y+(2b+1)P/8]_P\le P/2-2,\\
1,&\text{otherwise}.
\end{cases}
\tag{10.17}
\]
Output \(c_3\oplus\operatorname{Rec}_P(w,c_2)_{0:\kappa}\).

The PKE algorithms are total on the declared well-formed domains. Encryption remains defined for a syntactically valid public key drawn from a proof hybrid, even if that key does not have an honest decryption secret. This matters when the reduction generates a challenge and knows its message but not an underlying secret.

## 10.6. Perfect correctness uses a signed modular discrepancy

**Lemma 10.4 — Reconciliation and uniform key bits.** For \(P\) divisible by 8, if \(y\equiv z+e\pmod P\) for an integer \(|e|<P/8\), then
\[
\operatorname{Rec}_P(y,C_P(z))=K_P(z).
\tag{10.18}
\]
For uniform \(z\in\mathbb Z_P\), the pair \((K_P(z),C_P(z))\) is uniform on \(\{0,1\}^2\).

*Proof.* Write \(P=8a\) and \(z=2ak+u\), with \(0\le k<4\), \(0\le u<2a\). The helper bit is \(k\bmod2\), while \(K\) takes values \(0,1,1,0\) over the four quarters. Each pair therefore has \(P/4\) preimages. Since \(-a+1\le e\le a-1\), the shifted residue in (10.17) lies in \([1,4a-2]\) when \(K=0\), and in \([4a+1,8a-2]\) when \(K=1\). The stated threshold separates them, including wraparound. \(\square\)

The inequality is strict. For \(P=16,z=3,y=5\), the distance is \(P/8\), but \(K_P(z)=0\) and \(\operatorname{Rec}_P(y,C_P(z))=1\).

**Theorem 10.5 — Perfect correctness of BASE.** Under (10.13), every honestly generated ciphertext decrypts to its message, for every admissible key and every honest random tape.

*Proof.* Write canonical outputs as \(Y_i^{(b)}=QU_i^{(b)}+\tau_i^{(b)}\), with \(0\le\tau_i^{(b)}<Q\). These are the actual deterministic remainders, not fresh noise. By linearity and (10.15),
\[
v_i\equiv w_i+\delta_i\pmod P,
\qquad \delta_i=\sum_b r_b(\rho_i^{(b)}-\tau_i^{(b)}),
\qquad |\delta_i|\le t(Q-1)<P/8.
\tag{10.19}
\]
Apply Lemma 10.4 with its \(z=v_i\), \(y=w_i\), and displacement \(-\delta_i\). Every reconstructed bit equals the encryption bit, so the XOR cancels. \(\square\)

The claim \(|[v_i]_P-[w_i]_P|\le t(Q-1)\) would be false. The following honest witness uses \((P,Q,h,L,t,\kappa)=(32,2,1,1,2,1)\), \(X=(1,2)\), public vectors \((1,0),(31,0)\), selection \((1,1)\), and zero lifts. It gives \(v=30,w=0,\delta=-2\). Decryption is correct although the difference of canonical representatives is 30.

The unwrapped PKE is also algebraically malleable in its last component: changing \(c_3\) by a bit mask changes the decrypted message by the same mask. This observation motivates a complete CCA wrapper; it is not by itself a refutation of an OW-CPA statement.

## 10.7. Ideal keys, random lifting, and residual hashing

The ideal key distribution samples each \(a^{(b)}\) uniformly and each \(U^{(b)}\) uniformly in \(\mathbb Z_H^L\), independently. This is the ideal branch of Proposition 10.3 after quotient extraction.

**Proposition 10.6 — Exact ideal lift.** Under the ideal key law, fresh uniform \(\rho\) makes the full lifts \(u^{(b)}=QU^{(b)}+\rho^{(b)}\) independent uniform vectors in \(\mathbb Z_P^L\), independent of all \(a^{(b)}\). Moreover \(F_Q(u^{(b)})=U^{(b)}\).

*Proof.* For each coordinate, \((U,\rho)\mapsto QU+\rho\) is a bijection from \(\{0,\ldots,H-1\}\times\{0,\ldots,Q-1\}\) to \(\{0,\ldots,P-1\}\). Product measures give the claim. The deterministic relation to \(U\) must be retained; the lift is not independent of its own public quotient. \(\square\)

Replacing the lift with \(QU\) changes this law. In one coordinate it has support of size \(H\), and distance \(1-1/Q\) from a uniform residue. A proof that relies on full uniform lifts cannot use that deterministic replacement for free.

**Lemma 10.7 — Universal binary subsums.** For independent uniform \(u^{(b)}\in\mathbb Z_P^L\), the family
\[
h_u(r)=\sum_b r_bu^{(b)}\pmod P,\qquad r\in\{0,1\}^t,
\tag{10.20}
\]
is two-universal: for \(r\ne r'\), the collision probability is \(P^{-L}\).

*Proof.* Choose a position where \(r_b-r'_b=\pm1\). Condition on all other lift vectors. The difference of outputs is a fixed vector plus or minus the remaining uniform vector. Its law is uniform on \(\mathbb Z_P^L\). This argument works over the composite ring because \(\pm1\) is a unit. \(\square\)

**Lemma 10.8 — Residual extraction with the full public leakage.** In the ideal-key experiment, replacing \(v\) by a fresh uniform \(V\in\mathbb Z_P^L\), while retaining the full seed \(u\), all \(a\), and \(c_1\), changes the joint distribution by at most
\[
\epsilon_{\rm enc}=\frac12\sqrt{2^{-t}P^{m+L}}.
\tag{10.21}
\]
Consequently any adversary recovering an independent uniform \(\kappa\)-bit message from the ideal key and its challenge ciphertext succeeds with probability at most \(2^{-\kappa}+\epsilon_{\rm enc}\).

*Proof.* Fix \(a\). The map \(r\mapsto c_1\) has at most \(P^m\) images and is independent of the uniform hash seed \(u\). On any nonempty fiber of size \(s_c\), the selector is uniform. Let \(M_0=P^L\). Two-universality gives
\[
\mathbb E_u\sum_z\left(\Pr[h_u(r)=z\mid c_1=c]-1/M_0\right)^2
\le 1/s_c.
\tag{10.22}
\]
Cauchy–Schwarz bounds its mean total variation by \(\tfrac12\sqrt{M_0/s_c}\). Weight by \(s_c/2^t\), sum over fibers, and apply Cauchy–Schwarz again:
\[
\frac{\sqrt{M_0}}{2\,2^t}\sum_c\sqrt{s_c}
\le\frac12\sqrt{M_0P^m/2^t}.
\tag{10.23}
\]
Average over \(a\). The public \(U\) is a deterministic function of \(u\), so it is already covered by this stronger view. For fresh uniform \(V\), Lemma 10.4 makes the first \(\kappa\) bits of \(K_P(V)\) uniform independently of \(C_P(V)\) and the other retained data. They one-time-pad the independent message. Applying the ciphertext map cannot increase variation distance, proving the recovery bound. \(\square\)

The upper bound may exceed one on toy parameters; it can then be replaced by the trivial bound one. Successful arithmetic tests do not show that a profile satisfies the extraction budget.

## 10.8. Rényi transfer for clean and noisy rounded keys

For probability laws \(\mu,\nu\) on a finite set, define the multiplicative order-two divergence
\[
\mathcal R_2(\mu\Vert\nu)=\sum_{z:\mu(z)>0}\frac{\mu(z)^2}{\nu(z)},
\tag{10.24}
\]
with value infinity if a required denominator is zero. This is not the logarithmic Rényi divergence. Cauchy–Schwarz gives \(\mu(S)^2\le\mathcal R_2(\mu\Vert\nu)\nu(S)\). The same inequality holds after adding common independent algorithmic randomness or applying a common channel. This is the probability-preservation methodology of prior LWR work ([B09](#bib-b09); [B26](#bib-b26)) and Chapter 8.

Assume \(\chi\) is symmetric on the integers, with
\[
B\in\mathbb Z_{\ge0},\quad 2B<Q,\quad
\Pr_{E\leftarrow\chi}[|E|\le B]\ge\delta_E>0.
\tag{10.25}
\]
Errors at all positions and blocks are independent of one another, the public ribbons, the secret \(X\), and the source variables used to determine \(X\). More generally, one may condition on a latent variable \(\Lambda\) that is independent of the public ribbons, \(X\), and those source variables, provided that for every positive-probability value of \(\Lambda\) the error coordinates are conditionally independent and the symmetry and tail bounds above hold uniformly. In particular, the error law may not adapt to the realized Hankel residue. Let \(\mathcal C\) be the joint law of \((X,\mathbf a,F_Q(T_X(\mathbf a)))\), and let \(\mathcal N\) use \(F_Q(T_X(\mathbf a)+\mathbf E)\) instead, keeping the same laws of \(X,\mathbf a\).

**Theorem 10.9 — Anchored Rényi bound.** Under these assumptions,
\[
\mathcal R_2(\mathcal C\Vert\mathcal N)
\le \overline D_R:=\left(\frac{1+2B/Q}{\delta_E}\right)^{tL}.
\tag{10.26}
\]
The same bound applies after the secret is omitted from both observations.

*Proof.* Fix \(X=x\). A coordinate with remainder in \(\{B,\ldots,Q-B-1\}\) stays in its quotient cell for every \(|E|\le B\), giving retention at least \(\delta_E\). The remaining at most \(2B\) residues per cell are dangerous. At a lower boundary choose errors in \([0,B]\); at an upper boundary choose errors in \([-B,0]\). Symmetry gives mass at least \(\delta_E/2\) in either favorable half. The condition \(2B<Q\) prevents this inward move from crossing the opposite boundary.

For a full noiseless output \(Z\), let \(r(Z)\) count dangerous coordinates among all \(tL\) positions. Error independence gives retention at least \(\delta_E^{tL}2^{-r(Z)}\). Since the clean output is deterministic conditioned on \((X,\mathbf a)\), direct substitution in (10.24) yields
\[
\mathcal R_2(\mathcal C\Vert\mathcal N)
=\mathbb E_{X,\mathbf a}
\frac1{\Pr[\text{all quotient outputs retained}\mid X,\mathbf a]}.
\tag{10.27}
\]
Conditioned on any \(x\), Proposition 10.1 makes all \(tL\) coordinates of \(Z\) independent uniforms. Their dangerous probability is at most \(2B/Q\). Thus the expectation of \(2^{r(Z)}\) is at most \((1+2B/Q)^{tL}\). Average over \(X\); the bound is uniform in that secret. Omitting it is data processing. \(\square\)

The proof does not assert independence of observed Hankel rows after fixing the public vectors. It integrates the correct joint law. It also cannot discard error independence merely because every marginal looks harmless. For example, at \(Z=(0,0,0)\), \(P=16,Q=4\), choose uniformly among \((-1,0,1),(0,1,-1),(1,-1,0)\). Each error marginal is uniform on \(\{-1,0,1\}\), with scalar retention \(2/3\); joint retention is zero, not \(8/27\). Such a point can occur under an anchored key, for instance with a zero public vector. This invalidates the correlated-error extension, not Theorem 10.9.

The theorem's joint-law premise is therefore part of the security statement. If an external reduction introduces a latent noise width, conditioning is legitimate only when the required independence, symmetry and tail bounds hold uniformly after that conditioning. A public-dependent error rule is outside the theorem: marginal symmetry alone is insufficient.

## 10.9. The conditional one-way reduction

**Theorem 10.10 — OW-CPA from the specified binary-LWE source.** For every base-PKE one-way adversary, a binary-LWE distinguisher using \(tL\) source rows can be constructed such that
\[
p_{\rm OW}\le
\sqrt{\overline D_R\left(\operatorname{Adv}_{\rm bin}
+2^{-\kappa}+\epsilon_{\rm enc}\right)}.
\tag{10.28}
\]
All success probabilities refer to the declared algorithms, and the source advantage is measured at the resource usage of the constructed distinguisher.

*Proof.* Draw one parity mask, use Proposition 10.3 on all source blocks, and quotient the translated observations. This gives the noisy rounded-key experiment in the real source branch and the ideal-key experiment in the uniform branch. The distinguisher draws a uniform message, encrypts it with fresh honest coins under its constructed key, runs the one-way adversary, and checks equality with the message it knows. It need not know \(s\), \(X\), or any decryption key. Hence
\[
p_{\rm noisy}\le\operatorname{Adv}_{\rm bin}+2^{-\kappa}+\epsilon_{\rm enc}.
\tag{10.29}
\]
The challenge encryption and adversary are a common randomized channel on the clean and noisy key distributions. Theorem 10.9 and probability preservation give \(p_{\rm OW}^2\le\overline D_Rp_{\rm noisy}\). Combine the inequalities. \(\square\)

This is a one-way success reduction, not a claim that clean rounded keys and noisy keys have negligible total variation. In particular, it does not manufacture a generic decisional Hankel-LWR theorem. If the source advantage and ideal success are negligible, \(\overline D_R\) is polynomially bounded, and all dimensions and algorithms are polynomially bounded in a security parameter, the OW success is negligible.

The reduction applies to WC's deliberately widened, anchored distribution. It does not authenticate an LWE equivalence for the historical short-factor public-key law or for MODDIV-NOISE.

## 10.10. The implicit-rejection KEM and its exact interface

Fix a public parameter context \(\theta\), an injective canonical ciphertext encoding \(\operatorname{enc}\), and two independent classical random oracles:
\[
G:\{0,1\}^{\kappa}\to\{0,1\}^{t(1+Lq)},
\qquad
\mathcal H:\{0,1\}^{\kappa}\times\mathcal C_{\rm wire}
\to\{0,1\}^{\kappa_K}.
\tag{10.30}
\]
Distinct domains and length-delimited inputs incorporate \(\theta\). The notation \(\mathcal H\) is separate from \(H=P/Q\). The key-output length \(\kappa_K\) is distinct from the seed-message length \(\kappa\).

At KEM key generation, draw the BASE keys and one independent uniform fallback secret \(s_{\rm fb}\in\{0,1\}^{\kappa}\). Store it for the lifetime of this key; it is not resampled on each invalid ciphertext. Retain the public key or a reconstructible representation for re-encryption.

Encapsulation samples uniform \(\mu\), computes \(c=\operatorname{Enc}(pk,\mu;G(\mu))\), and returns
\[
(c_{\rm wire},K)=\bigl(\operatorname{enc}(c),\mathcal H(\mu,\operatorname{enc}(c))\bigr).
\tag{10.31}
\]
Decapsulation parses canonically. On a valid encoding, decrypt \(\mu'\), re-encrypt using \(G(\mu')\), and compare the complete bytes. If they match, return \(\mathcal H(\mu',c_{\rm wire})\); otherwise return \(\mathcal H(s_{\rm fb},c_{\rm wire})\). Malformed encodings take the latter branch. The API returns no validity flag. Constant-time behavior is a separate implementation obligation, not implied by this abstract definition.

**Lemma 10.11 — Public plaintext checking after re-encryption.** Define deterministic \(\operatorname{Enc}_1(pk,\mu)=\operatorname{Enc}(pk,\mu;G(\mu))\). Let \(\operatorname{Dec}_1\) accept only when decryption followed by that re-encryption reproduces the input bytes. For an honest key, canonical \(c\), and a candidate \(\mu\) in the message space,
\[
\operatorname{Dec}_1(sk,c)=\mu
\quad\Longleftrightarrow\quad
\operatorname{enc}(\operatorname{Enc}_1(pk,\mu))=c.
\tag{10.32}
\]
A valid ciphertext has only one accepted message.

*Proof.* The forward direction is the verification rule. In the reverse direction, perfect correctness of BASE implies that \(c\) decrypts to \(\mu\), so the check succeeds. Two accepted messages for one ciphertext would contradict that same deterministic decryption. Injectivity of the random-coin map is unnecessary. Malformed byte strings cannot equal an honest canonical encoding. \(\square\)

## 10.11. Classical CCA composition with all relevant queries counted

The principal game issues the public key, challenge ciphertext, and either its real KEM key or an independent uniform key before the adversary's oracle queries. It then permits adaptive decapsulation except on the exact challenge bytes. This chapter uses that principal challenge-first interface and does not claim a separate prechallenge-decapsulation extension for WC.

Let \(q_G\) be an upper bound on all \(G\)-oracle evaluations made explicitly or induced inside the deterministic-encryption stage of the reduction, and let \(q_H\) bound the adversary's \(\mathcal H\)-queries. The corrected HHK accounting yields
\[
N=q_G+q_H+1.
\tag{10.33}
\]
The \(+1\) covers the output/recovery step. Decapsulation queries \(q_D\) contribute to running time, table operations and the transformed adversary's resource budget, but they are not silently inserted as an additional term in the coefficient \(N\). Repeated queries may be cached; the conservative definition of \(q_G\) already includes the \(G\)-evaluations induced by plaintext checking unless a tighter distinct-query analysis is supplied.

**Theorem 10.12 — Explicit-key implicit-rejection bound.** Under perfect correctness, the single-user classical-ROM KEM satisfies
\[
\eta_{\rm CCA}\le q_H2^{-\kappa}+N p_{\rm OW}
\tag{10.34}
\]
for an appropriate BASE one-way adversary at the reduction's budget. There is no ciphertext-validity oracle supplied to the actual attacker.

*Proof and external theorem interface.* This is the \(U^{\not\perp}\circ T\) route of the corrected HHK analysis ([B24](#bib-b24)), not the message-only hashing variant. The following argument makes the WC query bookkeeping explicit. The essential simulations are as follows.

First hide the fallback row of \(\mathcal H\) behind a private random function of the ciphertext. Include both rejected ciphertexts and accepted ciphertexts whose message equals \(s_{\rm fb}\). Until a queried first argument exposes this hidden uniform message, the fallback can be coupled exactly; the event costs at most \(q_H2^{-\kappa}\).

Next simulate decapsulation by a table of random keys indexed by ciphertext. On a fresh hash query \((\mu,c)\), use a plaintext-checking oracle for \(\operatorname{Dec}_1\). If the check is true, connect the hash answer to the existing decapsulation-table answer, or create both simultaneously. If false, use a separate random answer. A fresh decapsulation answer can be fixed before the corresponding hash query; only an unqueried hash entry is then assigned, so no old answer is overwritten. Uniqueness from Lemma 10.11 gives identical views in either query order. Unless the challenge hash input is queried, its key remains uniform. A successful query yields a one-way adversary with plaintext checking and at most \(q_H\) checking calls.

Finally, implement each plaintext check by public re-encryption using (10.32). Couple the deterministic-coin challenge with an ordinary BASE one-way challenge until a call to \(G\) concerns the unknown challenge message. Such calls include those induced by plaintext checking. An extractor chooses uniformly among at most \(q_G+q_H\) candidate messages arriving at \(G\), plus the final guess. If the first target call occurs, its chosen slot extracts before the divergent response; if no target call occurs and the final guess succeeds, the final slot extracts. The resulting success loses at most the factor \(N\). The extractor does not know the target message or its encryption coins and does not program an unknown target input. This proves (10.34). \(\square\)

The corrected HHK bound includes plaintext-checking-induced \(G\)-queries in the extraction factor. Counting only externally issued \(G\)-queries would omit those calls. The theorem above needs neither a spread assumption nor a validity oracle, since the selected route uses plaintext checking only. Random-oracle output collisions are allowed and are not treated as invertible identifiers.

Decapsulation-query count remains part of the transformed adversary's resource budget. No additional WC theorem for a distinct prechallenge-decapsulation phase is claimed in this V1.1 statement.

## 10.12. FAST: an exact identity, not a new cryptographic distribution

Write \(x_j=Q+s_j\), \(0\le s_j<Q\), for \(j\ge1\). For each coordinate set
\[
A_i^{\rm hi}=\sum_{j=1}^{d-1}a_{i+j},\qquad
S_i=a_i+\sum_{j=1}^{d-1}a_{i+j}s_j.
\tag{10.36}
\]

**Theorem 10.13 — Exact FAST evaluation.** For every admissible anchored secret and integer public vector,
\[
F_Q(T_x(a)_i)
=\left[A_i^{\rm hi}+\left\lfloor S_i/Q\right\rfloor\right]_H,
\qquad
T_x(a)_i=[QA_i^{\rm hi}+S_i]_P.
\tag{10.37}
\]

*Proof.* The unreduced product is exactly \(QA_i^{\rm hi}+S_i\). Divide \(S_i=Qb_i+r_i\), \(0\le r_i<Q\). Reduction modulo \(P=QH\) gives \(Q[A_i^{\rm hi}+b_i]_H+r_i\); quotient extraction gives the first identity. The second is the original equality reduced modulo \(P\). Euclidean division makes the argument valid for signed inputs as well. \(\square\)

The complete low-part carry must be accumulated before discarding bits. For \(P=32,Q=4,a=(3,1),x=(1,5)\), the true quotient is 2. Truncating the low products separately gives 1. FAST is exact because it does not make that truncation.

Both identities are useful: KeyGen needs the rounded value, whereas decryption needs the unrounded modular product. Replacing only an evaluator, while preserving random tapes, gives zero functional loss. It does not prove a portable speed factor. The old secret tail already has only \(q+1\) bits, so the scalar decomposition reduces an operand by at most one bit. No performance benchmark is reported in this chapter.

## 10.13. COMPACT: an oracle-coupled representation

Introduce a third independent, domain-separated, programmable classical random oracle \(\mathcal A\). Let \(\sigma\in\{0,1\}^{\kappa_A}\) be a uniform public seed and let \(D(\theta,\sigma,b)\) be an injective encoding. Interpret the first \(mp\) bits of \(\mathcal A(D(\theta,\sigma,b))\) as \(m\) consecutive \(p\)-bit residues. This defines the public vector \(a^{(b)}\). No modulo-biased sampling occurs because \(P=2^p\).

The compact public key is \(pk_C=(\sigma,(U^{(b)})_b)\). Developing it reconstructs the explicit key. Algorithms then apply precisely the same BASE arithmetic.

**Theorem 10.14 — Exact fresh-context coupling.** In a fresh seed context, the developed public vectors have exactly the jointly uniform explicit-key law. A simulator given explicit uniformly distributed vectors may choose the seed and program their fresh oracle positions, preserving their full public correlation with the quotients. If \(q_A^{\rm pre}\) earlier queries may expose such positions before the seed is selected, the coupling loses at most
\[
\epsilon_A\le\min(1,q_A^{\rm pre}2^{-\kappa_A}).
\tag{10.38}
\]

*Proof.* Distinct encoded inputs produce independent uniform \(mp\)-bit prefixes, which are in bijection with the required residue vectors. Programming fresh positions with values having that same joint law is an exact coupling. For prequeries, let \(d_A\) be the number of distinct seed values already exposing a target-context block. A new independent uniform seed is one of them with probability \(d_A/2^{\kappa_A}\le q_A^{\rm pre}/2^{\kappa_A}\). Abort on that event; after publication all later queries are answered consistently at the already assigned positions. \(\square\)

This is not a standard-model theorem for a public-seed PRG. For a fixed deterministic function \(F:\{0,1\}^{\kappa_A}\to\{0,1\}^{N_A}\), the test \(y=F(\sigma)\) distinguishes \((\sigma,F(\sigma))\) from \((\sigma,U_{N_A})\) with acceptance gap \(1-2^{-N_A}\). That comparison is not the ROM game, where the oracle and seed are kept consistent. It explains why a hidden-seed PRG claim cannot replace the programming argument.

SHAKE256 can instantiate the functional expansion for tests, but is not an information-theoretically random or programmable oracle. The deterministic implementation, ideal-oracle theorem, and concrete-security question remain separate.

## 10.14. Combining the interfaces without double-counting losses

**Theorem 10.15 — Conditional compact FAST CCA route.** With independent \(\mathcal A,G,\mathcal H\), canonical encoding, and the hypotheses already stated,
\[
\eta_{\rm CCA}^{C,\rm FAST}
\le q_H2^{-\kappa}
+N\left[\sqrt{\overline D_R\left(
\operatorname{Adv}_{\rm bin}+2^{-\kappa}+\epsilon_{\rm enc}\right)}
+\epsilon_A\right].
\tag{10.39}
\]
In the principal fresh-context game, \(\epsilon_A=0\), and FAST introduces no loss.

*Proof.* Theorem 10.13 preserves every arithmetic result. Theorem 10.12 reduces the KEM game to an explicit-key OW challenge. Theorem 10.14 couples the explicit and compact public keys, losing at most \(\epsilon_A\) in the stated seed-prequery experiment. Substitute the one-way bound of Theorem 10.10 and use \(N=q_G+q_H+1\). \(\square\)

An alternative coupling of the entire KEM directly to the explicit game charges \(\epsilon_A\) only once outside the factor \(N\). The displayed expression deliberately uses the conservative OW factorization. These are alternative analyses; their programming losses must not be added together. All bounds may be capped by the trivial success-bias bound \(1/2\).

This statement is conditional on the specified binary-LWE source and the classical oracle model. It is not a QROM theorem, a multi-user theorem, a real-hash instantiation theorem, or a proof for the underlying historical ModDiv observations.

## 10.15. Serialization, entropy, and exact payload sizes

The chapter-local wire encoding lists coordinates in increasing index order, appends \(c_1\) in \(p\)-bit fields, then \(c_2\) and \(c_3\) as bits, and packs successive fields least-significant-bit first into little-endian bytes. The unused high bits of the last byte are zero. The parser requires the exact byte count and zero padding. There is no accepted normalization of alternative byte strings. Public parameters and algorithm identifiers are out-of-band context and are not included in the following payload formulas.

The accompanying FO test code uses length-delimited domains `A`, `G`, `H` and a chapter-local version tag. It is an explicit canonical realization of the abstract interface, **not a claim of byte-level interoperability with every earlier experimental encoding**. Semantic BASE equivalence to the original reference is checked with identical random streams.

**Proposition 10.16 — Payload accounting.** Tight bit packing gives
\[
\begin{aligned}
|pk_E|&=t\bigl(mp+L(p-q)\bigr),\\
|pk_C|&=\kappa_A+tL(p-q),\\
|c|&=mp+L+\kappa,\\
|X|_{\rm offset}&=(d-1)q.
\end{aligned}
\tag{10.40}
\]
The last line encodes \(X_j-Q\) and omits the fixed anchor. A KEM secret additionally stores the \(\kappa\)-bit fallback and sufficient public-key information for re-encryption. Byte sizes are ceilings of total bit sizes divided by eight.

*Proof.* Each public residue needs \(p\) bits, each quotient \(p-q\), and each tail offset \(q\). Sum the declared field counts. The canonical fixed-width packing is injective and uses only the final padding to complete a byte. \(\square\)

For the representation-only profile \((p,q,h,L,t,\kappa)=(256,128,16,32,64,32)\), \(m=513\) and a 256-bit seed give **1,083,392 explicit bytes** versus **32,800 compact bytes**. These figures are recomputed integer lengths, not secure parameters. In particular, a residual target \(2^{-128}\) alone would require \(t=139,774\) at those \(h,L,p\), instead of 64. The message length of 32 is also not a 128-bit claim.

Uniform private storage entropy and public-key byte length are not computational-security estimates. The theorem relies on a source problem, proof losses, and adversarial resources, not on counting the number of possible secret encodings.

## 10.16. Parameter thresholds and a size barrier for this proof formula

**Proposition 10.17 — Exact residual and correction thresholds.** For an integer residual target exponent \(s\ge1\), the expression in (10.21) is at most \(2^{-s}\) exactly when
\[
t\ge t_{\rm ext}:=((h+1)L+1)p+2(s-1).
\tag{10.41}
\]
The largest integer allowed by perfect correctness is
\[
t_{\rm cor}=\left\lfloor\frac{2^{p-3}-1}{2^q-1}\right\rfloor.
\tag{10.42}
\]

*Proof.* Square the nonnegative extraction inequality and compare powers of two. Use \(m+L=(h+1)L+1\). The strict integer correctness inequality is equivalent to \(t(2^q-1)\le2^{p-3}-1\). Division gives (10.42). \(\square\)

Thus a chosen proof budget requires \(t_{\rm ext}\le t_{\rm cor}\); a large nominal security parameter does not guarantee this. The obstruction proved below is a necessary condition for the **written numerical upper bound**, not for every conceivable proof.

**Theorem 10.18 — Relaxed proof-route payload lower bound.** Suppose the bound (10.39), using exactly (10.21), is required to certify a bias at most \(2^{-\tau}\), with integer \(\tau\ge1\). Even after relaxing to zero source advantage, \(\overline D_R=1\), \(N=1\), no guessing/programming/phase terms, free seed storage, and \(h=1\), its quotient payload must be at least
\[
K_{\min}(\tau)=2\tau g_*\bigl((4\tau+1)(g_*+1)+4\tau-2\bigr)
\quad\text{bits},
\tag{10.43}
\]
where \(g_*\) is the smallest integer \(g\ge3\) satisfying
\[
(4\tau+1)(g+1)+4\tau-2\le2^{g-2}-1.
\tag{10.44}
\]

*Proof.* Dropping nonnegative terms from the upper-bound expression supplies necessary, not sufficient, conditions. The message term forces \(\kappa\ge2\tau\); hence \(L\ge2\tau\). The residual term requires \(\epsilon_{\rm enc}\le2^{-2\tau}\). Set \(g=p-q\); since \(q\ge1\), \(p\ge g+1\). Equation (10.41) and \(h\ge1\) imply
\[
t\ge T_0(g):=(4\tau+1)(g+1)+4\tau-2.
\tag{10.45}
\]
Correctness gives
\[
t<\frac{2^{g-3}}{1-2^{-q}}\le2^{g-2}.
\tag{10.46}
\]
Integer feasibility therefore requires (10.44). In particular \(g\ge g_*\). The payload \(tLg\) is at least \(2\tau gT_0(g)\), and this expression increases for integer \(g\ge3\). This proves (10.43). \(\square\)

| Target exponent \(\tau\) | \(g_*\) | \(T_0(g_*)\) | Necessary payload bits | Necessary bytes |
|---:|---:|---:|---:|---:|
| 32 | 13 | 1,932 | 1,607,424 | 200,928 |
| 64 | 15 | 4,366 | 8,382,720 | 1,047,840 |
| 128 | 16 | 9,231 | 37,810,176 | 4,726,272 |
| 192 | 16 | 13,839 | 85,026,816 | 10,628,352 |
| 256 | 17 | 19,472 | 169,484,288 | 21,185,536 |

None of these rows gives a secure parameter set attaining its bound. Restoring a genuine source dimension, query budgets, error losses, and seed storage only strengthens the necessary restrictions. Conversely, a tighter extraction or security proof could invalidate this *particular proof-route barrier* without contradicting the theorem. It is not an information-theoretic lower bound on public-key cryptography or a claim that shorter WC keys have been broken.

## 10.17. Asymptotic compatibility and the external LWE obligation

The source reduction must keep distinct the lattice/source dimension \(n_0\), the binary-secret dimension \(h\), the source modulus \(q_0\), and the final WC modulus \(P\). For example, the binary-secret transformation of Brakerski et al. ([B25](#bib-b25); Theorem 4.1) requires a condition of the form
\[
h\ge(n_0+1)\log_2q_0+2\log_2(1/\delta_B),
\tag{10.47}
\]
along with its sample, noise, and statistical-loss conditions. Substituting \(\log_2P\) for \(\log_2q_0\) before modulus switching would change that premise. Its source is a precise LWE experiment, not an arbitrary error distribution renamed LWE.

To keep the scope explicit, the present chapter's cryptographic theorem stops at (10.5). The older manuscripts propose a longer classical worst-case route; that composition needs the external theorems, Gaussian conversion conventions, noise bounds, and adversarial budget losses at every stage. We do not infer a full finite-parameter worst-case certificate from (10.47) alone. Nearest-integer discretization of a continuous error is an additional distributional step, not an unnoticed replacement by an arbitrary bounded law.

**Corollary 10.19 — A conditional internally compatible family.** Let \(\lambda\ge2\) tend through the integers. Set
\[
\begin{aligned}
h&=(\lambda+1)\lceil\lambda/2\rceil+8\lambda,\quad L=\kappa=\lambda,\\
p&=\lceil16\log_2\lambda\rceil,\quad q=\lceil11\log_2\lambda\rceil,\\
t&=((h+1)L+1)p+2(\lambda-1),\quad \kappa_A=\lambda.
\end{aligned}
\tag{10.48}
\]
Suppose the chosen binary-LWE source is hard at the budgets of (10.39), and its independent symmetric integer error law obeys (10.25) with
\[
B=O\bigl(\lambda^5(\log\lambda)^{5/2}\bigr),
\qquad \delta_E\ge1-\lambda^{-6}.
\tag{10.49}
\]
Then for all sufficiently large \(\lambda\), BASE is perfectly correct, \(\epsilon_{\rm enc}=2^{-\lambda}\), \(\overline D_R=1+o(1)\), and the compact FAST FO KEM has negligible classical-ROM CCA bias for polynomial query budgets. The compact payload is \(\Theta(\lambda^4(\log\lambda)^2)\) bits.

*Proof.* The dimensions give \(h=\Theta(\lambda^2)\), \(m=\Theta(\lambda^3)\), and \(t=\Theta(\lambda^3\log\lambda)\). Since \(Q/P=O(\lambda^{-5})\), \(t(Q-1)/(P/8)=O(\lambda^{-2}\log\lambda)\to0\). Equation (10.41) gives the exact extraction value. Also \(2B<Q\) eventually and
\[
\frac{2BtL}{Q}=O\bigl(\lambda^{-2}(\log\lambda)^{7/2}\bigr)=o(1),
\qquad tL(1-\delta_E)=O(\lambda^{-2}\log\lambda)=o(1).
\tag{10.50}
\]
Use \(\log(1+x)\le x\) and \(-\log(1-u)\le2u\) for small nonnegative \(u\), obtaining \(\log\overline D_R=o(1)\). The assumed negligible source advantage, the extraction term and \(2^{-\kappa}\) remain negligible after a square root and polynomial query losses. Prequery terms with \(\kappa_A=\lambda\) and (10.35) are negligible as well. Finally \(p-q=\Theta(\log\lambda)\) in (10.40) gives the payload order. \(\square\)

This is explicitly conditional on both source hardness and the error-family bounds. It proves compatibility of the internal inequalities and the gain from selecting the exact residual minimum; it is not a new proof of the external LWE theorems. The real-valued logarithms in (10.48) can be evaluated exactly for these integer exponents using bit lengths of \(\lambda^{16}\) and \(\lambda^{11}\). Merely inserting \(\lambda=128\) does not verify all eventual statements, and no test profile below is assigned a security level.

## 10.18. Reproducibility, limitations, and transition

The public supplementary package contains the arithmetic module, a deterministic exact verifier, an independent checker and the expected results. The WC reference arithmetic and public verification artifacts belong under `supplementary/chapter-10/`. Its SHA-256 is recorded separately. Identical random streams compare BASE key generation, encryption, decryption, and post-call RNG state; the zero-selector case is retained.

| Verification family | Checks executed in this chapter |
|---|---:|
| Exhaustive FAST products on admissible small profiles | 12,800 |
| Signed-input FAST products | 2,000 |
| Public inputs in exact anchored-fiber enumerations | 16,384 |
| Constructed right-inverse targets | 500 |
| Exact parity-mask states, seven parameter profiles | 166 |
| Sparse embedding states | 4,096 |
| Shared-mask block identities | 2,000 |
| Reconciliation input/displacement pairs | 86,360 |
| Exhaustive honest PKE transcripts | 4,096 |
| Reference KeyGen comparisons | 200 |
| Reference encryption/decryption comparisons | 800 |
| Exact extraction seed/input pairs in four auxiliary profiles | 299,264 |
| Explicit noise atoms for hidden/revealed Rényi comparison | 3,072 |
| Programmed compact keys and KEM round trips | 100 keys; 400 round trips |
| Byte strings for baseline/FAST decapsulation comparison | 65,536 |
| Residual and strict-correctness threshold profiles | 1,152; 136 |

These counts describe different objects and are not summed as independent security experiments. Algebra-only profiles over smaller moduli are identified in the code and do not claim to satisfy every WC parameter constraint. The wire test exhausts all two-byte strings for one ten-bit ciphertext format: 1,024 canonical strings and 64,512 with invalid padding. Four additional malformed lengths are checked. Canonical but invalid ciphertexts are distinguished from malformed encodings; both receive the prescribed implicit fallback.

The second checker uses full polynomial convolution with a reversed secret, explicit interval sets for reconciliation, and atom-by-atom probability laws for Rényi. It independently checks 32 fiber profiles, 1,200 embeddings, 5,208 reconciliation pairs, the four recorded semantic traces, and all 256 target exponents in a bounded re-evaluation of the relaxed barrier. For the binary subsum lemma it examines 26 nonzero differences and 106,496 seeds. The repeated probability example and leakage profile are the same mathematical instances, not new security trials.

All arithmetic comparisons are exact integer or rational comparisons. The synthetic seed and the deterministic SHAKE implementation are test mechanisms. No Monte Carlo rate proves a theorem, no random-oracle implementation test proves the ideal-oracle model, and no successful decoding benchmark estimates LWE hardness. The 65,536-string check is finite and does not constitute a proof of adaptive CCA security; Theorems 10.12 and 10.15 carry that conditional obligation.

From `supplementary/chapter-10/`, run the verification programs for this chapter with:

```sh
python3 verify.py
python3 verify_independent.py
```

The public artifact also checks strict canonical wire parsing, persistent fallback behavior, functional KEM re-encryption and the proof-route barrier. The deterministic SHAKE256 expansion used by the code is a functional test instance of COMPACT; it is not a proof that SHAKE256 is a programmable random oracle. PDF building is separate. Hash checks validate file identity, not mathematical truth.

**Scientific conclusion.** WC provides an exact distributional embedding and an explicit conditional one-way-to-CCA route for its own redesigned secret law and widened dimensions. Its correctness is deterministic; FAST is an identity; COMPACT is an ideal-oracle representation result. The size obstruction belongs to the selected proof formula. None of these statements validates historical polynomial MODDIV, the NOISE construction, a BLINDAGE variant, a QROM theorem, a real-hash deployment, or a 128-bit parameter set. The next construction chapter must begin again from its own specification and distributions.



## Supplementary Material and Reproducibility — Chapter 10

The public supplementary material for this chapter is assigned to `supplementary/chapter-10/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 11 — MODDIV-NOISE {#ch11}
## Explicit Noise, Exact Joint Simulation, and Conditional IND-CPA Security


**Scope.** HB hardness, concrete security, formal certification, external peer review and historical priority remain separate obligations.

### Abstract

This chapter defines NOISE-CPA-LIFT, a public-key encryption construction built around a non-cyclic Hankel product with explicit integer noise, modular reduction and coefficientwise floor division. Secrets are uniform in a positive box and encryption uses an internal randomized lift plus two Hankel products sharing one ephemeral secret. Correctness retains the actual division remainders and uses circular distance. Confidentiality is reduced in the classical standard model to an explicitly defined decisional binary-secret Hankel-LWE source. The proof has two exact transitions: the second uses two disjoint public segments of one source sequence while preserving the common secret linking the ciphertext components. The source assumption itself is not derived from standard LWE, MP-LWE or worst-case lattice problems. The unwrapped encryption scheme is malleable and is not IND-CCA2 secure. No concrete security level or deployment parameter set is claimed.

### Scope and contribution boundary

The multidimensional public proposal ([B14](#bib-b14)) supplies historical non-cyclic modulo-division context, but no historical security theorem is inherited. The source experiment, error law, positive-secret mask, randomized lift and message encoding used here are specified explicitly.

The scalar analyses of Chapters 5–7, the distributional tools of Chapter 8, P-REF in Chapter 9 and WC in Chapter 10 have different distributions and proof interfaces. None is silently reused as a security theorem for NOISE. All arguments needed for the conditional CPA theorem are supplied below, while the hardness of the HB source remains a separate open obligation.

## 11.1. The three obligations: arithmetic, simulation, and hardness

An encryption claim has three distinct obligations. First, the honest algorithms must recover the message with a stated error probability. Second, an adversary against the encryption game must give an algorithm for an explicitly defined source problem. Third, that source problem must be justified as difficult for a useful family of parameters. Correctness and an exact reduction do not, by themselves, settle the third obligation.

Regev's LWE formulation uses independently uniform public vectors and independently sampled errors ([B01](#bib-b01)). A Hankel sequence reuses public coefficients across rows. The middle-product literature supplies a closely related algebraic language, but its roles, lengths, secret laws, and assumptions must not be changed by renaming symbols ([B27](#bib-b27); [B09](#bib-b09)). Only this contextual positioning is used here; no external hardness theorem is a hidden premise of the proofs.

NOISE-CPA-LIFT has an explicitly noisy public key. Its proof does not identify a discarded remainder with independent noise. Nor does it use an anchored coordinate, an ideal hash, or a seed-expansion oracle. The public sequence is stored in full, with a lossless encoding of its fixed high bits.

## 11.2. Dimensions and non-cyclic operators

Fix integers
\[
P=2^p=2M,\qquad Q=2^q,\qquad 3\le q<p,\qquad
H=P/Q,\qquad d,\ell\ge2.
\tag{11.1}
\]
Thus \(Q\mid M\), \(H\) is even, and both \(P/4\) and \(M/Q=H/2\) are integers. Define
\[
n=d+\ell-1,\qquad m=n+d-1=2d+\ell-2,\qquad N=2n.
\tag{11.2}
\]
The scalar \(H\) denotes the quotient alphabet size. It is not a matrix. All arrays have fixed lengths, including leading or trailing zero coefficients, and all index ranges are half-open unless stated otherwise.

For an integer sequence \(a\) of length \(r+d-1\), let
\[
\bigl(\mathcal H_{r,d}(a)x\bigr)_i
=\sum_{j=0}^{d-1}a_{i+j}x_j,\qquad 0\le i<r.
\tag{11.3}
\]
We abbreviate this to \(\mathcal H_r(a)x\) when the secret length \(d\) is fixed. No index wraps around. The product is computed over the integers before any explicitly indicated modular reduction. Reversing columns makes its matrix Toeplitz. If \(a(z)=\sum_k a_kz^k\) and \(x^\star(z)=\sum_jx_jz^{d-1-j}\), then
\[
\bigl(\mathcal H_r(a)x\bigr)_i
=[z^{d-1+i}]\bigl(a(z)x^\star(z)\bigr).
\tag{11.4}
\]
This is an ordinary polynomial product window, not multiplication in a cyclic or negacyclic quotient ring.

**Proposition 11.1 — Double-product identity with explicit dimensions.** For \(A\in\mathbb Z^m\) and \(X,Y\in\mathbb Z^d\),
\[
\mathcal H_{\ell,d}\bigl(\mathcal H_{n,d}(A)X\bigr)Y
=
\mathcal H_{\ell,d}\bigl(\mathcal H_{n,d}(A)Y\bigr)X.
\tag{11.5}
\]

*Proof.* Coordinate \(i\) of the left side is
\[
\sum_{k=0}^{d-1}\sum_{j=0}^{d-1}A_{i+k+j}X_jY_k.
\]
Interchanging the two finite sums gives the right side. Its largest public index is \(\ell-1+2d-2=m-1\). The inner output has length \(n=\ell+d-1\), precisely the length required by the outer map. Reduction modulo any positive integer preserves the equality. This restates the earlier Hankel identity with the dimensions used in this construction. \(\square\)

The public key will contain \(m\) coefficients of \(A\) and \(n\) quotients. The ciphertext has \(n\) coefficients in its first component and \(\ell\) in its second. The source reduction requires \(N=2n\) observations of a sequence of length \(N+d-1=m+n\).

## 11.3. Explicit noise and the binary Hankel source

Write \([z]_t\) for the canonical integer residue modulo \(t\). Define
\[
F_Q(z)=\left\lfloor\frac{[z]_P}{Q}\right\rfloor,
\qquad I_Q=\{Q/2,\ldots,Q-1\}.
\tag{11.6}
\]
Both operations act coordinatewise on vectors. Let \(\chi\) be a publicly specified integer error distribution. Every explicit error in the encryption scheme has law
\[
\chi'=\mathcal L(2e+\tau),\qquad e\leftarrow\chi,\qquad
\Pr[\tau=-1]=\Pr[\tau=1]=\tfrac14,\quad \Pr[\tau=0]=\tfrac12,
\tag{11.7}
\]
where \(e\) and \(\tau\) are independent. Distinct coordinates and error occurrences use independent draws. Neither symmetry nor Gaussianity of \(\chi\) is required for the simulations. Correctness will additionally require a support or tail bound. The specified implementation profile uses \(\chi=\mathrm{CBD}_1\), not arbitrary samplers.

**Lemma 11.2 — Lifted CBD1 law and its limited parity consequence.** For independent \(e,\tau\sim\mathrm{CBD}_1\), the integer error \(E'=2e+\tau\) has the following distribution.

| Value | \(-3\) | \(-2\) | \(-1\) | \(0\) | \(1\) | \(2\) | \(3\) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Weight out of 16 | 1 | 2 | 3 | 4 | 3 | 2 | 1 |

For any integer random variable \(Z\) independent of \((e,\tau)\), the least significant bit of \([Z+2e+\tau]_P\) is uniform conditionally on \(Z\). The same parity conclusion holds for an arbitrary independent \(e\sim\chi\).

*Proof.* Convolve the masses \((1,2,1)/4\) at \((-2,0,2)\) with the same masses at \((-1,0,1)\). For parity, \(2e\) and \(P\) are even, while \(\tau\bmod2\) is a fair bit. Translation by the fixed parity of \(Z\) preserves uniformity. \(\square\)

This is a statement about a raw noisy coefficient, not all its bits or its quotient. Conditioning additionally on the quotient can destroy parity independence. For instance, take \(P=16,Q=8,Z=0,e=0\). Given quotient one, the only possible perturbed residue is 15, which is odd. This elementary example is not a decryption or security profile.

The reduction's source is the following *definition*, not a claim that its hardness is established. For \(\mathsf{HB}(M,d,N,\chi)\), draw mutually independently
\[
a\leftarrow\operatorname{Unif}(\mathbb Z_M^{N+d-1}),\qquad
S\leftarrow\operatorname{Unif}(\{0,1\}^d),\qquad
 e\leftarrow\chi^{\otimes N}.
\tag{11.8}
\]
The real experiment returns
\[
\mathsf{HB}_1=(a,[\mathcal H_{N,d}(a)S+e]_M).
\tag{11.9}
\]
The null experiment returns \(\mathsf{HB}_0=(a,b)\), where \(b\) is uniform in \(\mathbb Z_M^N\) and independent of \(a\). For a distinguisher \(\mathcal B\), set
\[
\operatorname{Adv}_{\rm HB}(\mathcal B)
=\left|\Pr[\mathcal B(\mathsf{HB}_1)=1]-\Pr[\mathcal B(\mathsf{HB}_0)=1]\right|.
\tag{11.10}
\]
One secret is shared by all \(N\) windows. The challenger supplies one sequence and exactly those observations; it provides no adaptive public choices, additional sequences, or hidden-secret oracle. The conditional assumption says that (11.10) is negligible for every classical probabilistic polynomial-time distinguisher on a specified parameter family. Dimensions, modulus bit lengths, and sampler costs must be polynomially bounded. No assumption for fewer windows is substituted for the required \(N=2n\).

## 11.4. The NOISE-CPA-LIFT algorithms


**Key generation.** Sample
\[
A\leftarrow\operatorname{Unif}(\{M,\ldots,P-1\}^m),\quad
X\leftarrow\operatorname{Unif}(I_Q^d),\quad
E'_0\leftarrow(\chi')^{\otimes n}.
\]
Compute
\[
U=F_Q(\mathcal H_n(A)X+E'_0),\qquad pk=(A,U),\quad sk=X.
\tag{11.11}
\]
The key-generation errors are not part of the secret key and are not needed by decryption. The public sequence is sampled independently coefficient by coefficient; it is not generated from a short seed.

**Encryption of \(\mu\in\{0,1\}^{\ell}\).** Draw
\[
Y\leftarrow\operatorname{Unif}(I_Q^d),\quad
E'_1\leftarrow(\chi')^{\otimes n},\quad E'_2\leftarrow(\chi')^{\otimes\ell},\quad
\rho\leftarrow\operatorname{Unif}(\{0,\ldots,Q-1\}^n).
\]
Set
\[
\begin{aligned}
B&=QU+\rho,\\
V&=F_Q(\mathcal H_n(A)Y+E'_1),\\
W&=F_Q(\mathcal H_\ell(B)Y+E'_2+M\mu),\qquad ct=(V,W).
\end{aligned}
\tag{11.12}
\]
The vector \(B\) is an internal lift, not a public message. Both products use the *same* ephemeral secret \(Y\); the errors are independent. The actual lift is not asserted uniform in the real-key game.

**Decryption.** Reject invalid lengths or coefficient ranges. For canonical \(V\in\mathbb Z_H^n\), \(W\in\mathbb Z_H^{\ell}\), and \(X\in I_Q^d\), compute
\[
Z=[QW-\mathcal H_\ell(QV)X]_P.
\tag{11.13}
\]
Decode each coordinate by
\[
\mathsf{DecBit}(z)=\mathbf1\{P/4<[z]_P<3P/4\}.
\tag{11.14}
\]
This chooses the nearer of the centers 0 and \(M=P/2\); both distance ties are assigned zero. Parsing and the behavior at ties are part of the algorithm. They are not authentication mechanisms.

Since \(Q\mid M\), message insertion also satisfies
\[
F_Q(z+M\mu_i)=[F_Q(z)+(H/2)\mu_i]_H.
\tag{11.15}
\]
Consequently, the last division remainder does not depend on the message when all other coins are fixed. This elementary identity will also expose malleability.

## 11.5. Exact decryption error and a sufficient decoding margin

Define the remainders produced by the actual computations:
\[
r_0=[\mathcal H_n(A)X+E'_0]_Q,\quad
r_1=[\mathcal H_n(A)Y+E'_1]_Q,\quad
r_2=[\mathcal H_\ell(B)Y+E'_2]_Q.
\tag{11.16}
\]
Because \(Q\mid P\), these equal the remainders after canonical modular reduction. Because \(Q\mid M\), \(r_2\) is also the remainder when the message term is included. These are deterministic functions of the experiment, not independent surrogate errors.

**Lemma 11.3 — Exact signed error expansion.** For every honest set of inputs and coins,
\[
Z\equiv M\mu+\Delta\pmod P,
\tag{11.17}
\]
where the integer vector
\[
\Delta=
\mathcal H_\ell(E'_0-r_0+\rho)Y
-\mathcal H_\ell(E'_1-r_1)X+E'_2-r_2
\tag{11.18}
\]
is defined before reduction modulo \(P\).

*Proof.* Euclidean division yields
\[
QU\equiv\mathcal H_n(A)X+E'_0-r_0,\qquad
QV\equiv\mathcal H_n(A)Y+E'_1-r_1\pmod P,
\]
and \(QW\equiv\mathcal H_\ell(B)Y+E'_2+M\mu-r_2\pmod P\). Substitute \(B=QU+\rho\) into the last congruence and subtract \(\mathcal H_\ell(QV)X\). Proposition 11.1 cancels the two principal products. The remaining terms are exactly (11.18). No probability or independence of remainders is used. \(\square\)

**Theorem 11.4 — Perfect correctness under bounded source error.** If \(\operatorname{Supp}(\chi)\subseteq[-b,b]\cap\mathbb Z\), with integer \(b\ge0\), define
\[
T_b=[2d(Q-1)+1](Q+2b).
\tag{11.19}
\]
If \(T_b<P/4\), every honestly generated ciphertext decrypts correctly, for every admissible public sequence, secret, message, and encryption randomness.

*Proof.* Each \(E'_j\) lies in \([-2b-1,2b+1]\). Coordinates of \(r_0,r_1,r_2,\rho\) lie in \([0,Q)\). Thus
\[
\|E'_0-r_0+\rho\|_\infty,\quad
\|E'_1-r_1\|_\infty,\quad
\|E'_2-r_2\|_\infty\ \le Q+2b.
\tag{11.20}
\]
For the first term, use \(|\rho-r_0|\le Q-1\), not an unnecessary sum of two remainder bounds. Every coordinate of \(X,Y\) is at most \(Q-1\), and each product in (11.18) contains \(d\) terms. The triangle inequality gives \(\|\Delta\|_\infty\le T_b\). By (11.17), each decryption residue is at circular distance strictly below \(P/4\) from its intended center. Equation (11.14) therefore recovers every bit. The proof includes negative integer errors and modular wraparound. \(\square\)

The sufficient condition does not depend on \(\ell\) directly, because each decryption coordinate contains two products of \(d\) terms. It need not be tight. A profile failing this sufficient inequality is not thereby proved incorrect; a profile satisfying it is not thereby proved confidential. No public rank test is needed for this correctness statement.

## 11.6. Error tails, maximum over messages, and key reuse

Let \(\delta_b=\Pr_{e\sim\chi}[|e|>b]\). The algebraic proof remains valid on the event that all underlying source errors stay in \([-b,b]\), even when \(\chi\) has unbounded support.

**Corollary 11.5 — Average-key and repeated-encryption bounds.** If \(T_b<P/4\), then
\[
\mathbb E_{pk,sk}\!\left[
\max_{\mu\in\{0,1\}^{\ell}}
\Pr[\mathsf{Dec}(sk,\mathsf{Enc}(pk,\mu))\ne\mu\mid pk,sk]
\right]
\le\min\{1,(2n+\ell)\delta_b\}.
\tag{11.21}
\]
For \(r\ge1\) encryptions sharing one honestly generated key, the probability of at least one decryption failure is at most
\[
\min\{1,[n+r(n+\ell)]\delta_b\}.
\tag{11.22}
\]
The latter statement permits plaintexts selected from the previously visible transcript.

*Proof.* One key generation uses \(n\) source errors, and one encryption uses \(n+\ell\) fresh ones. When they are all bounded, Theorem 11.4 works simultaneously for all messages. Conditional on a fixed key, its latent key-generation errors can be averaged; the probability of an unbounded key error is independent of which message is subsequently selected. A union bound, followed by expectation over keys, gives (11.21). For (11.22), count the \(n\) key errors only once and the fresh errors for each encryption separately. The good-noise event again ensures correctness for every possible plaintext choice, so adaptivity of that choice does not invalidate the inclusion of events. \(\square\)

This is not a uniform per-key failure guarantee for arbitrary keys, and it is not a theorem about decryption-oracle attacks. Independence of the tail events is unnecessary for the union bounds; independence of the error draws remains part of the specified scheme and its security simulation. Implementing an unbounded law requires a stated efficient sampler or an explicit approximation allowance.

## 11.7. Exact binary-to-positive masking

The reduction must produce the declared positive secret law without seeing the source secret. Set
\[
\mathcal R_Q=
\{Q/2+4t+\epsilon:0\le t<Q/8,\ \epsilon\in\{0,1\}\}.
\tag{11.23}
\]
It has \(Q/4\) elements, whereas \(I_Q\) has \(Q/2\).

**Lemma 11.6 — Exact mask bijection.** If \(R\) is uniform on \(\mathcal R_Q^d\), \(S\) is uniform on \(\{0,1\}^d\), and they are independent, then
\[
X=R+2S
\tag{11.24}
\]
is exactly uniform on \(I_Q^d\).

*Proof.* Each scalar target value has the unique representation
\[
Q/2+4t+\epsilon+2s,\qquad 0\le t<Q/8,\quad \epsilon,s\in\{0,1\}.
\]
The pair \((\epsilon,s)\) enumerates the four positions in one block. This is a bijection between \(\mathcal R_Q\times\{0,1\}\) and \(I_Q\). Its product across coordinates proves the statement, including independence of the resulting coordinates. \(\square\)

The source bits must be uniform and independent; the mask is not a generic transformation of an arbitrary secret prior. For a shared source secret, the *same* mask must be used in all simultaneously simulated products. The simulator samples \(R\), but never receives or computes \(S\); (11.24) is the latent equality used in the proof.

## 11.8. Lifting the source modulus and the two worlds

Consider a source segment of \(r+d-1\) coefficients and \(r\) observations. Given \(a\in\mathbb Z_M^{r+d-1}\), choose high bits \(\sigma\in\{0,1\}^{r+d-1}\) using \(a\) and fresh coins, not the source response or secret, and set \(A=a+M\sigma\). Draw an independent mask \(R\) and fresh \(\tau\sim\mathrm{CBD}_1^{\otimes r}\).

**Lemma 11.7 — Exact real and null transports.** Compute
\[
C=[2b+\mathcal H_r(A)R+\tau]_P.
\tag{11.25}
\]
In the real source world,
\[
C=[\mathcal H_r(A)(R+2S)+2e+\tau]_P.
\tag{11.26}
\]
In the null world, \(C\) is uniform on \(\mathbb Z_P^r\), even conditionally on \((a,\sigma,R)\).

*Proof.* Since \(P=2M\), doubling a residue modulo \(M\) agrees modulo \(P\) with doubling any of its integer lifts. Also \(2\mathcal H_r(M\sigma)S\equiv0\pmod P\). These two facts give (11.26). Lemma 11.6 gives the exact positive secret law whenever the source bits have their declared distribution.

In the null world, \(2b_i\) is uniform on the even residues. For an even target value, the event \(\tau_i=0\) contributes \((1/2)/M=1/P\). For an odd target, \(\tau_i=1\) and \(-1\) together contribute \((1/4+1/4)/M=1/P\). Distinct coordinates use independent source responses and perturbations. Translation by the fixed vector \(\mathcal H_r(A)R\) preserves this joint uniform law. \(\square\)

The choice \(\sigma=\mathbf1\) gives the upper-half public law used for \(A\). Independent uniform high bits give a uniform vector over all \(\mathbb Z_P\), which will be used for \(B\). The real error remains exactly \(2e+\tau\) in either case. The same argument applies jointly to selected disjoint source observation coordinates with one common \(S,R\).

A qualification prevents overinterpreting the parity argument. Without \(\tau\), the raw null output lies in one parity class and has total variation distance \(1/2\) from uniform modulo \(P\). Nevertheless, an even-width floor cell has equally many residues of each parity, so rounding that particular null distribution can still be uniform. The raw-lift lemma therefore does not prove that every modified construction without \(\tau\) is insecure. This chapter retains the specified noise and does not propose such a modification.

## 11.9. Uniform quotient lifting and adaptive message selection

**Lemma 11.8 — Full joint law of the ideal lift.** Let \(B\) be uniform on \(\mathbb Z_P^n\), and put \(U=F_Q(B)\). Then \((U,B)\) has the same law as the experiment
\[
U\leftarrow\operatorname{Unif}(\mathbb Z_H^n),\quad
\rho\leftarrow\operatorname{Unif}(\{0,\ldots,Q-1\}^n),\quad
B=QU+\rho,
\tag{11.27}
\]
The two draws in (11.27) are independent. For the conditional statement, assume additionally that \(A\) is independent of \(B\). If an adversary sees only \((A,U)\) and uses coins independent of \((A,B)\) to choose messages and a state, preparing \(B\) before those choices is equivalent to drawing a fresh conditional lift \(QU+\rho\) afterwards. This additional independence holds in the second simulator because its two public coefficient segments and the added high bits are independent.

*Proof.* The map \(B\mapsto(F_Q(B),[B]_Q)\) is a bijection from \(\mathbb Z_P^n\) to \(\mathbb Z_H^n\times\mathbb Z_Q^n\). Uniform counting measure thus gives independent uniform quotient and remainder. Since \(A\) is independent of \(B\), conditioning on \((A,U)\) leaves \(\rho=[B]_Q\) uniform on \(\mathbb Z_Q^n\). In particular, each of the \(Q^n\) lifts has conditional probability \(Q^{-n}\). The messages and retained state are a randomized function of \((A,U)\) and independent adversary coins, so conditioning further on them does not change this conditional remainder law. This proves the deferred-sampling statement. \(\square\)

The lemma is applied only in the *ideal-public-key* game. It says neither that an actual key-generation quotient is uniform nor that key-generation remainders are independent of \(X\). Moreover, \(B\) is not independent of \(U\): their relation \(F_Q(B)=U\) is deterministic. A center-only lift \(QU\) violates (11.27).

## 11.10. First simulator: the public observation

Define game \(G_0\) as the real encryption experiment. Define \(G_1\) by sampling \(A\) with its upper-half law and \(U\) uniformly independently, then encrypting with the *unchanged* algorithm (11.12). Ideal keys need not possess a decryption secret because the CPA game has no decryption oracle.

**Proposition 11.9 — Exact first transition.** There is a public simulator \(\mathcal B_0\) taking one challenge from \(\mathsf{HB}(M,d,N,\chi)\), with \(N=2n\), whose output key is distributed as the real key on \(\mathsf{HB}_1\) and as the key of \(G_1\) on \(\mathsf{HB}_0\).

*Proof and algorithm.* Use the source prefix and set
\[
A=a_{0:m}+M\mathbf1,\qquad
U=F_Q(2b_{0:n}+\mathcal H_n(A)R+\tau_0),
\tag{11.28}
\]
where \(R\) is uniform in \(\mathcal R_Q^d\) and \(\tau_0\sim\mathrm{CBD}_1^{\otimes n}\). The first \(n\) source windows use exactly the prefix of length \(m=n+d-1\). Lemmas 11.6 and 11.7 identify the real joint law with (11.11), including its errors. In the null case the pre-rounded vector is uniform independently of \(A\); every quotient cell has \(Q\) points, giving independent uniform \(U\). All unused source data are discarded.

To simulate the complete CPA experiment, give this key to the adversary, receive its messages, choose the challenge bit, and run the ordinary public encryption algorithm. Return the indicator that the adversary guessed the challenge bit correctly. This requires no source secret, no inversion, and no ideal-key decryption. \(\square\)

The remaining source observations are not assumed independent of the prefix in the real world. They are simply unobserved by the simulated adversary and marginalized out.

## 11.11. Second simulator: two segments and one shared secret

The second transition must simulate \(V\) and \(W\) together. Separate marginal arguments would not suffice.

**Lemma 11.10 — Disjoint coefficient segments, distinct selected errors.** In a source of length \(N+d-1=m+n\), select
\[
 a^{(A)}=a_{0:m},\qquad a^{(B)}=a_{m:m+n},\qquad
 b^{(A)}=b_{0:n},\qquad b^{(B)}=b_{m:m+\ell}.
\tag{11.29}
\]
These are complete Hankel windows on disjoint public segments. There are exactly \(d-1\) discarded boundary observations, indexed \(n,\ldots,m-1\).

*Proof.* The last first-segment window ends at \((n-1)+(d-1)=m-1\). The next retained segment begins at coefficient \(m\), and its last retained observation starts at \(m+\ell-1=N-1\). It ends at \(N+d-2=m+n-1\). Its number of observations is \(N-m=\ell\), and its coefficient length is \(\ell+d-1=n\). The omitted count is \(m-n=d-1\). Source coefficients in the two segments are independent uniforms. Selected errors have distinct indices and hence are independent, but selected real observations share the same secret \(S\). \(\square\)

For example, \(d=3,\ell=2\) gives \(n=4,m=6,N=8\): the first public segment uses coefficients 0–5 and observations 0–3; observations 4 and 5 are discarded; the second uses coefficients 6–9 and observations 6 and 7. The split concerns coefficients and observation *starts*, which must not be confused.

Prepare an ideal public key before the adversary chooses its messages:
\[
A=a^{(A)}+M\mathbf1,\qquad
B=a^{(B)}+M\epsilon,\quad
\epsilon\leftarrow\operatorname{Unif}(\{0,1\}^n),\qquad U=F_Q(B).
\tag{11.30}
\]
Only \((A,U)\) is published. Retain \(B\) internally. After receiving \(\mu_0,\mu_1\), choose \(\beta\), one mask \(R\), and independent \(\tau_1,\tau_2\), then compute
\[
\begin{aligned}
C_1&=[2b^{(A)}+\mathcal H_n(A)R+\tau_1]_P,\\
C_2&=[2b^{(B)}+\mathcal H_\ell(B)R+\tau_2]_P,\\
V&=F_Q(C_1),\qquad W=F_Q(C_2+M\mu_\beta).
\end{aligned}
\tag{11.31}
\]

**Theorem 11.11 — Exact joint second transition.** This simulator \(\mathcal B_1\) reproduces game \(G_1\) on a real HB challenge. On a null challenge, it produces an ideal key and a jointly uniform ciphertext in \(\mathbb Z_H^n\times\mathbb Z_H^{\ell}\), independently of the challenge bit and the adversary's prior view. Call this last experiment \(G_2\).

*Proof.* First, the disjoint coefficients and independent high bits in (11.30) make \(A\) upper-half uniform and \(B\) full-range uniform independently. Lemma 11.8 gives the required joint law of \((U,B)\), even after adaptive message selection.

In the real world the selected equations are
\[
b^{(A)}=[\mathcal H_n(a^{(A)})S+e^{(A)}]_M,\qquad
b^{(B)}=[\mathcal H_\ell(a^{(B)})S+e^{(B)}]_M.
\]
Apply Lemma 11.7 simultaneously, using the same mask. With \(Y=R+2S\),
\[
C_1=[\mathcal H_n(A)Y+2e^{(A)}+\tau_1]_P,\qquad
C_2=[\mathcal H_\ell(B)Y+2e^{(B)}+\tau_2]_P.
\tag{11.32}
\]
The variable \(Y\) is exactly uniform in \(I_Q^d\), independent of \(A,B\). Both errors have law \(\chi'\), independently. These are equalities of the simultaneous experiment, not merely of the two marginals. Equations (11.27) and (11.32) identify the full challenge law with real encryption under the ideal key.

In the null world, \(b^{(A)}\) and \(b^{(B)}\) are jointly uniform and independent of the full source sequence. Conditional on \((A,B,R)\), independent perturbations \(\tau_1,\tau_2\) and Lemma 11.7 make \((C_1,C_2)\) jointly uniform modulo \(P\). Its conditional law does not depend on the conditioning values. Translation by the selected message and floor division therefore give a jointly uniform ciphertext independently of the key, messages, state, and challenge bit. \(\square\)

The discarded observations could help an algorithm attacking the HB assumption. Their omission from the simulator is not permission to weaken the source assumption from \(2n\) windows to \(n+\ell\), or to introduce independent secrets for the two retained segments.

A concrete finite warning illustrates this last point. At \(P=16,Q=8,d=\ell=2\), fix \(A=(8,8,8,8)\), \(B=(8,8,8)\), and \(\mu=(0,0)\), with the specified lifted CBD1 errors. The correct conditional law of \((V,W)\) and the law obtained using independent positive secrets for its two blocks have the same block marginals but total variation distance
\[
\frac{47}{1024}.
\tag{11.33}
\]
Both verifiers recompute this fraction exactly. An elementary derivation conditions on the fair parity of \(Y_0+Y_1\). Given that parity, all five output bits are independent Bernoulli variables with parameter \(3/8\) or \(5/8\). The total variation distances between these two product laws on three bits and on two bits are \(47/128\) and \(1/4\). The difference between the common mixture and the product of its two block marginals is one quarter of the tensor product of the two differences; its total variation is therefore \(\tfrac12(47/128)(1/4)=47/1024\). This profile tests distributional scope and fails the sufficient correctness margin; it is not a security parameter or a frequency claim over typical public keys.

## 11.12. Conditional IND-CPA theorem and advantage conventions

The adversary first receives an honestly generated public key and outputs two messages in \(\{0,1\}^{\ell}\). A fair bit \(\beta\) chooses the encrypted message. Define the CPA *success bias* by
\[
\operatorname{Adv}_{\rm CPA}(\mathcal A)
=\left|\Pr[\widehat\beta=\beta]-\tfrac12\right|.
\tag{11.34}
\]
This convention differs from the acceptance-gap convention (11.10). An equiprobable challenge-bit bias is one half of the corresponding acceptance gap.

**Theorem 11.12 — Two exact reductions to the declared HB source.** For every classical probabilistic polynomial-time CPA adversary against NOISE-CPA-LIFT, there are two distinguishers for the *same parameter family* \(\mathsf{HB}(M,d,2n,\chi)\) satisfying
\[
\operatorname{Adv}_{\rm CPA}(\mathcal A)
\le\operatorname{Adv}_{\rm HB}(\mathcal B_0)
+\operatorname{Adv}_{\rm HB}(\mathcal B_1).
\tag{11.35}
\]
The overhead is polynomial when the dimensions, modulus descriptions, and required error sampler are polynomially bounded. No random oracle is used. If this HB family is hard and correctness is perfect or has negligible failure, the specified family is an IND-CPA encryption family.

*Proof.* Let \(p_j\) be the probability that the adversary guesses the challenge bit correctly in \(G_j\), for \(j=0,1,2\). Proposition 11.9 supplies a source distinguisher returning the success indicator with
\[
|p_0-p_1|=\operatorname{Adv}_{\rm HB}(\mathcal B_0).
\]
Theorem 11.11 supplies another with \(|p_1-p_2|=\operatorname{Adv}_{\rm HB}(\mathcal B_1)\). In \(G_2\), the challenge ciphertext is independent of \(\beta\), conditional on the prior view; therefore \(p_2=1/2\). The triangle inequality yields (11.35). Each distinguisher knows the fair bit it selected and can evaluate its success indicator without a secret key. Subsequent or prior public encryptions can be performed locally with fresh coins, just as by the original adversary. \(\square\)

The theorem constructs two distinct reduction algorithms, each receiving one challenge. It does not presume an oracle that supplies the same hidden secret under arbitrary new public distributions. Correctness is separately needed for useful encryption; it is not used to make the final challenge independent of the bit.

If \(\varepsilon_{\rm HB}(T')\) bounds source advantages at the actual simulation resource budget, the displayed consequence is \(2\varepsilon_{\rm HB}(T')\). Replacing that bound by an estimate for a general random-matrix LWE instance is not justified here. The assumption, dimensions, errors, and number of windows remain part of the theorem.

## 11.13. Encrypted uniform keys, sampler errors, and resources

**Corollary 11.13 — Joint secrecy of an encrypted uniform key.** Let \(K\) be a uniform \(\ell\)-bit value and \(C=\mathsf{Enc}(pk,K)\). Distinguishing \((pk,C,K)\) from \((pk,C,R)\), where \(R\) is independent uniform and \(C\) still encrypts a uniform key, has acceptance gap at most
\[
2\bigl(\operatorname{Adv}_{\rm HB}(\mathcal B_0)
+\operatorname{Adv}_{\rm HB}(\mathcal B_1)\bigr)
\tag{11.36}
\]
for appropriate reductions.

*Proof.* Choose independent uniform \(K_0,K_1\) as the CPA messages. On receiving the challenge \(C=\mathsf{Enc}(pk,K_\beta)\), give the proposed distinguisher \((pk,C,K_0)\). When \(\beta=0\) this is the real-key distribution; when \(\beta=1\) the supplied key is independent. An acceptance gap \(a\) induces CPA success bias \(a/2\), up to reversing the output decision. Apply Theorem 11.12. \(\square\)

This construction simply encrypts a random key. It is neither a Fujisaki–Okamoto transformation nor a CCA-secure KEM. Its correctness and malleability are those of the base encryption.

**Proposition 11.14 — Explicit allowance for approximate honest samplers.** Suppose each public coefficient sampler, each positive-secret coordinate sampler, each raw error sampler, each CBD1 perturbation sampler, and each lift-remainder sampler is replaced by an independent sampler at total variation distance at most \(\epsilon_A,\epsilon_X,\epsilon_e,\epsilon_\tau,\epsilon_\rho\), respectively. All deterministic algorithms and formats remain unchanged. For one key and one challenge, the change in the CPA success bias is at most
\[
\epsilon_{\rm impl}=\min\!\left\{1,
 m\epsilon_A+2d\epsilon_X+(2n+\ell)(\epsilon_e+\epsilon_\tau)+n\epsilon_\rho
\right\}.
\tag{11.37}
\]

*Proof.* Couple each elementary draw to its exact version using a maximal coupling. Until the first mismatch, the key, adversary view, adaptively chosen messages, and challenge coincide when the adversary uses the same coins. A union bound over \(m\) public draws, \(2d\) secret draws, \(2n+\ell\) pairs of error draws, and \(n\) remainders bounds the probability of any mismatch. A common deterministic or randomized continuation cannot increase total variation. Its event of correct bit prediction thus changes by at most the bound. The map \(x\mapsto|x-1/2|\) is 1-Lipschitz. \(\square\)

This is a per-experiment accounting rule, not a statement that arbitrary correlated samplers can be assessed from their scalar marginals. Extra explicit encryption-oracle executions must add their own draws if their sampler laws are also changed. In the usual public-key game, local computations by the adversary belong to the adversary, not to an uncounted honest oracle. A multi-challenge claim requires a separate hybrid over challenges; the theorem above is stated for one challenge.

Naive arithmetic uses \(O(nd)\) integer products in KeyGen, \(O((n+\ell)d)\) in encryption, and \(O(\ell d)\) in decryption. The two simulators use the same polynomial orders plus the adversary's computation and sampler costs. This is an arithmetic-operation count; the bit costs depend on \(p\), dimensions, and raw error lengths. The verifiers enumerate tiny spaces to check equalities, but enumeration is not part of either reduction.

## 11.14. What remains to be established about the source

The HB assumption contains a binary secret, independent errors with the exact distribution \(\chi\), and overlapping non-cyclic windows. It is not merely the statement that the encryption scheme is secure: it contains no message, internal lift, or ciphertext. Nevertheless, defining it precisely does not make it true.

For comparison, a full \(N\)-by-\(d\) uniform matrix has \(M^{Nd}\) possibilities. A uniform Hankel sequence induces only \(M^{N+d-1}\) matrices, all distinct. The statistical distance of these *public matrix distributions* is
\[
1-M^{-(N-1)(d-1)}.
\tag{11.38}
\]
This follows by counting the support of the Hankel law inside the uniform matrix space. It is not a distinguisher between \(\mathsf{HB}_1\) and \(\mathsf{HB}_0\), since those worlds have exactly the same Hankel public law. It simply rules out identifying the two public sampling experiments without a transformation.

**Proposition 11.15 — An information-theoretic support diagnostic.** If \(\chi\bmod M\) has support of size at most \(K\), then
\[
\operatorname{TV}(\mathsf{HB}_1,\mathsf{HB}_0)
\ge\max\{0,1-2^d(K/M)^N\}.
\tag{11.39}
\]

*Proof.* For every fixed public sequence, a real output is determined by one of \(2^d\) secrets and at most \(K^N\) error vectors. Its support has at most \(2^dK^N\) points. The support-membership event has probability one under the real conditional law and at most \(2^dK^N/M^N\) under the null law. Average over the common public sequence. \(\square\)

The proposition does not provide an efficient membership algorithm at growing dimensions. Computational indistinguishability can coexist with large statistical distance. Conversely, a large support or a large encoded secret space is not evidence of hardness. Any source-hardness claim must specify a growing parameter family and confront attacks on that exact distribution.

The construction's code has no unit anchor, no widened embedding of an arbitrary independent-row matrix, and no WC proof module. The distinct role of these ingredients in Chapter 10 cannot be imported by calling both public operators Hankel. The possible correspondence with published MP-LWE variants remains outside the results of this chapter and outside the current thesis-V1 task.

## 11.15. Exact malleability and failure of CCA2 security

**Theorem 11.16 — One-query message recovery from a related ciphertext.** Under the strict bounded-error margin of Theorem 11.4, let \((V,W)\) be an honest ciphertext. For any coordinate \(j\), define
\[
V'=V,\qquad W'_j=[W_j+H/2]_H,\qquad W'_i=W_i\ (i\ne j).
\tag{11.40}
\]
The modified ciphertext is distinct and canonical, and its decryption is the original message with exactly bit \(j\) complemented. The unwrapped construction is not IND-CCA2 secure.

*Proof.* Since \(QH/2=P/2=M\), (11.40) adds \(M\) to precisely one decryption residue modulo \(P\). In a strict \(P/4\) neighborhood of either center, this swaps the decoded bit. All other coordinates are unchanged. Because \(H\ge2\), adding \(H/2\) changes that quotient, so the new ciphertext is not the challenge. A CCA2 adversary submits this legal modified ciphertext to its decryption oracle and reverses the known bit flip to recover the entire challenged plaintext. It can therefore distinguish any two distinct challenge messages perfectly under the perfect-correctness hypotheses. \(\square\)

For noise with tails, this attack succeeds on the *strict-margin good-noise event*, with probability at least \(1-\min\{1,(2n+\ell)\delta_b\}\). For negligible tail failure this still gives an overwhelming-success attack. The argument is not asserted for every ciphertext on which the original decoder merely happens to be correct: ties need care. For example, residues \(P/4\) and \(3P/4\) both decode as zero under the prescribed tie rule. The present wording makes that distinction explicit rather than equating the correctness event with a strict-margin event.

Canonical encoding does not block this attack; it uses a different valid ciphertext, not a malformed alias. The result does not contradict the CPA theorem, which supplies no decryption oracle. No CCA wrapper is added here, and the WC wrapper of Chapter 10 is not reused without a new specification and proof.

## 11.16. Exact payload sizes and functional parameter families

Parameters and distribution identifiers are external to the following payloads. Each coefficient of \(A\in[M,P)\) is represented by \(A_i-M\) in \(p-1\) bits. Quotients use \(p-q\) bits. Each secret coefficient is represented by \(X_j-Q/2\) in \(q-1\) bits. Fields are concatenated with no intermediate byte alignment; only the final byte can have zero padding.

**Proposition 11.17 — Reversible encodings and exact sizes.** The payload bit lengths are
\[
\begin{aligned}
B_{pk}&=m(p-1)+n(p-q),\\
B_{sk}&=d(q-1),\\
B_{ct}&=(n+\ell)(p-q).
\end{aligned}
\tag{11.41}
\]
The corresponding byte lengths are \(\lceil B/8\rceil\). The stated encoding is injective; its canonical decoder rejects incorrect lengths and nonzero padding.

*Proof.* All stored fields range over exactly the powers-of-two alphabets indicated above. Subtracting the fixed endpoints is a bijection. Concatenation preserves the product of these bijections; requiring zero padding removes extra representations of the same object. Counting the \(m+n\), \(d\), and \(n+\ell\) fields gives (11.41). \(\square\)

The canonical byte order used by the reference implementation is: coefficients in increasing index, least significant bit first within each field, and the total bit string stored little-endian. This is lossless packing, not generation of the public sequence from a short seed. An encoded-view adversary can be simulated by applying the same deterministic encoder; no additional computational assumption is introduced.

| \(d\) | \(\ell\) | \(p\) | \(q\) | pk bytes | sk bytes | ct bytes | \(T_1\) | \(P/4\) |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 4 | 2 | 12 | 3 | 17 | 1 | 8 | 570 | 1024 |
| 16 | 16 | 14 | 3 | 118 | 4 | 65 | 2250 | 4096 |
| 16 | 8 | 16 | 4 | 106 | 6 | 47 | 8658 | 16384 |
| 128 | 128 | 17 | 3 | 1211 | 32 | 671 | 17930 | 32768 |
| 256 | 256 | 18 | 3 | 2586 | 64 | 1439 | 35850 | 65536 |

These rows reproduce the article's illustrative sizes, recalculated in this chapter. Every row satisfies the sufficient CBD1 correctness bound. **None is certified as a secure parameter set.** In particular, the labels 128 and 256 in dimension columns are not security levels. The encoded secret length, and the public-key size of 1211 bytes in one row, are not substitutes for an HB hardness analysis.

**Proposition 11.18 — A nonempty family of correct polynomial-size profiles.** Let \(d=\ell=\lambda\ge2\), \(Q=8\), and \(\chi=\mathrm{CBD}_1\). Choose the smallest power of two \(P\) strictly greater than \(4T_1\). Then all structural and sufficient-correctness conditions hold, \(P=O(\lambda)\), and the public and ciphertext payloads are \(O(\lambda\log\lambda)\) bits.

*Proof.* Here \(T_1=(14\lambda+1)10=140\lambda+10\). By construction,
\[
4T_1<P\le8T_1.
\tag{11.42}
\]
This gives \(p>3=q\) and the strict decoding margin. Moreover \(m=3\lambda-2\), \(n=2\lambda-1\), and \(p=O(\log\lambda)\), so (11.41) has the claimed growth. \(\square\)

This proves feasibility of correctness and storage only. It does not prove the HB assumption for this family, select deployment parameters, or estimate any attack cost. The functions of \(\lambda\) need not be the ones in a future justified hardness family.

## 11.17. Reproducible checks and negative controls

The public reproducibility layer uses a Python reference implementation with no external dependencies for the CBD1 profile. Generation functions use a system randomness source by default, while deterministic generators are reserved for reproducibility. The implementation is research code and is not constant-time.

The primary verifier checks the reference arithmetic and exact finite distributions. A separately written independent verifier reconstructs selected laws without importing the reference arithmetic module. A deterministic encoding regression, `verify_a5_encoding.py`, supplies the codec coverage below; the distributed deterministic reference is `encoding_results.json`.

| Verification family | Scope and result |
|---|---|
| Binary-to-positive mask | Six finite bijections; exact multiplicity one |
| Scalar and uniform lifts | Five pairs \((M,Q)\), with every offset in the tested domains |
| Complete scalar games | Two messages; exact real-world equality and uniform null world over 64 transcripts |
| Conditional rectangular games | 24 fixed publics, four messages each; 96 joint laws over 32 outputs, compared exactly |
| Double product | 4,096 exhaustive integer identities |
| Simulators in dimensions 2, 3, 4, 8 | 1,000 identity couplings; not an enumeration of every distribution |
| Functional correctness | 3,000 cases and 300 encryptions with a reused key; margins satisfied |
| Decoding and malleability | 4,454 points within the margin; 100 ciphertext modifications tested |
| Canonical encoding regression | 1,500 round trips; 2,500 noncanonical-format rejections; 60 encoded encryption/decryption cycles |

The encoding row is reproduced by `verify_a5_encoding.py`; its regenerated output is compared with the distributed `encoding_results.json` by the chapter verification layer.

Two negative controls delimit the proof. On the scalar profile \((d,\ell,P,Q)=(1,1,16,8)\), removing randomized lifting from the ideal game gives exact distance \(2295/32768\) from the required law, while removing the final noise gives distance \(153/8192\). These witnesses do not attack every neighboring construction; they show only that those steps cannot be deleted while citing the present simulation unchanged.

Run from the public package directory:

```sh
python3 verify_a5.py --output A5_RESULTS_RECHECK.json
python3 verify_a5_independent.py --output A5_INDEPENDENT_RECHECK.json
python3 verify_a5_encoding.py --output A5_ENCODING_RESULTS_RECHECK.json
python3 a5_kat.py
```

The full package wrapper may run the same regressions and compare deterministic outputs. Exact probability outputs use integer counters or rational fractions. Synthetic test vectors deliberately expose their secrets and coins and have no confidentiality value. Successful execution checks the specification; it does not establish HB hardness, IND-CCA2 security, external peer review or formal verification.

## 11.18. Synthesis and obligations for the thesis

NOISE-CPA-LIFT has a complete specification and a correctness proof based on the actual remainder vector. Its positive cryptographic result is an adversary transformation to a precisely declared binary Hankel source: the public-key transition uses a prefix, and the ciphertext transition uses two independent public segments with a shared secret. The latter distinction is essential. Independent public coordinates do not authorize replacing two secret-linked observations by independent marginal samples.

The established implication is
\[
\begin{gathered}
\text{hardness of the specified HB family}\\
+\ \text{the stated correctness condition}\\
\Longrightarrow\ \text{IND-CPA security of NOISE-CPA-LIFT}.
\end{gathered}
\tag{11.43}
\]
The chapter does not establish the antecedent from standard LWE, MP-LWE, or worst-case lattice problems. Nor does it assign a concrete security level to the small encodings. Its negative result is equally explicit: the unwrapped scheme admits a one-query CCA2 message-recovery attack under the strict margin.

The retained tasks for independent review are the complete joint simulation, the source's exact window count, the conditional lift after message selection, the domains of the error and decoder arguments, and the distinction between proof games and the real key law. Research on founding the HB assumption remains separate from this consolidation. Other MODDIV branches and the deferred thesis-V2 investigations are not modified.

**Scope.** HB hardness, concrete security, formal certification, external peer review and historical priority remain separate obligations.



## Supplementary Material and Reproducibility — Chapter 11

The public supplementary material for this chapter is assigned to `supplementary/chapter-11/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 12 — MODDIV-BLINDAGE C1 {#ch12}
## Module Rounding, Dependent-Remainder Correctness, and Conditional CCA Security




### Abstract

This chapter studies the C1-P12-CBD1 profile of MODDIV-BLINDAGE over the negacyclic ring \(R=\mathbb Z_{4096}[x]/(x^{256}+1)\) with module rank three, explicit centered-binomial errors, coefficientwise modular division, randomized quotient lifting and an implicit-rejection KEM wrapper. The correctness proof retains the actual dependent rounding remainders rather than replacing them by fictitious independent noise. An ordered exponential-moment argument gives an exact rational certificate for the averaged worst-message failure probability, \(\delta<2^{-282}\), while a legal event of probability \(2^{-6400}\) proves that perfect correctness is false. Confidentiality is reduced by two distribution-preserving transitions to two precisely specified small-secret Module-LWE source problems with three and four rows. Seeded matrix generation is handled by programmable-oracle simulation of the full raw response, including discarded high bits. Applying the modular Fujisaki–Okamoto analysis yields a conditional single-user IND-CCA bound in the classical random-oracle model with explicit correctness and query terms. The public-key and ciphertext payloads are 993 and 1408 bytes. These sizes and exact certificates do not establish concrete security; the two source-hardness assumptions remain external obligations.

### Relationship to prior work and scope

Module-LWE encryption, coefficient compression and Fujisaki–Okamoto transformations are established techniques, as illustrated by Kyber ([B28](#bib-b28)). Power-of-two module rounding and CCA-secure KEM composition are also prior in Saber ([B29](#bib-b29)), while randomized preimage lifting appears in the middle-product rounding literature ([B09](#bib-b09)). The contribution studied here is the exact C1 combination: its dependent-remainder correctness certificate, two source simulations, oracle-programmed seeded representation and resulting conditional bound.

The CRYPTO 2026 work of Hou, Jiang and Ogilvie ([B35](#bib-b35)) studies concrete hardness gaps between LWE and MLWE and merges the earlier ePrint records 2026/279 and 2026/366. It reinforces the need to preserve exact module structure in any concrete analysis; it does not provide a security estimate for C1.

The C1 results are not transferred to a CBD2 profile or any other later BLINDAGE branch. The chapter proves only the statements for the exact C1-P12-CBD1 specification below.

## 12.1. What the BLINDAGE claim consists of

Four distinct questions must remain visible: whether the algorithms recover an honest message; whether an adversary is transformed into a solver for an exact source problem; whether that source is hard at the stated parameters; and whether a concrete byte implementation realizes the proof's model. A small failure bound answers the first question, not the other three.

The C1 profile has degree 256, module rank 3, coefficient modulus 4096, public-key divisor 4, ciphertext divisor 2, and centered-binomial parameter one for every secret and explicit error. Its seeded public-key payload has 993 bytes and its ciphertext 1408 bytes. These are format facts, not bit-security levels. The description uses an ideal matrix-expansion oracle when discussing seeded public-key security. Abstract full-matrix encryption requires no such oracle.

Module encryption, coefficient compression, short errors and FO transforms have established precedents, including Kyber and Saber ([B28](#bib-b28); [B29](#bib-b29)). Randomized preimage lifting also appears in middle-product rounding encryption ([B09](#bib-b09)). The present results concern the exact combination and distributions specified below. They do not establish a new invention of these ingredients, and no exhaustive priority search is claimed.

## 12.2. Negacyclic algebra and the public matrix

Set
\[
R=\mathbb Z_P[x]/(x^n+1),\qquad
n=256,\ k=3,\ P=4096,\ Q=4,\ C=2.
\tag{12.1}
\]
Every polynomial is a fixed array of \(n\) coefficients, ordered by increasing degree, including zeros. All modular residues use canonical representatives. For a positive divisor \(D\mid P\), put
\[
F_D(z)=\left\lfloor\frac{[z]_P}{D}\right\rfloor.
\tag{12.2}
\]
This is a coefficient map, not division by a polynomial. The ring multiplication reduces degrees using \(x^n=-1\); it is different from the ordinary middle-product windows of Chapter 11.

**Proposition 12.1 — Signed Toeplitz representation and cancellation.** For polynomials \(a,b\) of length \(n\), their integer negacyclic product has coefficients
\[
(a\star b)_i=
\sum_{j=0}^{i}a_jb_{i-j}
-\sum_{j=i+1}^{n-1}a_jb_{n+i-j}.
\tag{12.3}
\]
Multiplication by \(a\) is represented by a signed negacyclic Toeplitz matrix. For \(A\in R^{k\times k}\), \(s,r\in R^k\),
\[
(As)^Tr=(A^Tr)^Ts.
\tag{12.4}
\]

*Proof.* A degree \(i+n\) term of the ordinary product contributes with a minus sign to degree \(i\), giving (12.3). Each matrix entry is \(a_{i-j}\) for \(i\ge j\), and \(-a_{n+i-j}\) otherwise. For (12.4), expand the left side as \(\sum_{u,v}A_{uv}s_vr_u\) and commute scalar ring factors. The right side is the same double sum. This uses neither matrix symmetry nor invertibility. The integer identity reduces modulo \(P\). \(\square\)

The abstract public matrix has **nine independent uniform ring elements**, hence 2304 independent coefficients modulo \(P\). Its expanded coefficient matrix has signed repeated entries within each block. Those repetitions do not turn it into the single overlapping Hankel ribbon of HB. A theorem for one public distribution is not a theorem for the other.

## 12.3. Exact laws and the base encryption scheme

Let \(\chi=\mathrm{CBD}_1\), the difference of two independent fair bits:
\[
\Pr[E=-1]=\Pr[E=1]=\tfrac14,\qquad \Pr[E=0]=\tfrac12.
\tag{12.5}
\]
Every displayed product of sampling laws means independent sampling of all its coefficients. Key-generation, encryption and lifting randomness are independent unless a dependency is explicitly specified.

**KeyGen.** Choose \(A\) uniformly in \(R^{k\times k}\). Draw \(s,e_0\leftarrow\chi^{kn}\), and set
\[
b=F_Q(As+e_0),\qquad pk=(A,b),\quad sk=s.
\tag{12.6}
\]
Here \(b\) is stored as \(kn\) integers in \([0,P/Q)\), not as an independently sampled noise vector.

**Encrypt.** For a message \(\mu\in\{0,1\}^n\), draw \(r,e_1\leftarrow\chi^{kn}\), \(e_2\leftarrow\chi^n\), and \(\rho\leftarrow\operatorname{Unif}(\{0,\ldots,Q-1\}^{kn})\). Define
\[
\begin{aligned}
v&=Qb+\rho,\\
c_1&=F_C(A^Tr+e_1),\\
c_2&=F_C(v^Tr+e_2+(P/2)\mu).
\end{aligned}
\tag{12.7}
\]
The ciphertext is \(c=(c_1,c_2)\). The lifted vector \(v\) is internal and is not transmitted. Both ciphertext components use the same \(r\).

**Decrypt.** Validate lengths and coefficient ranges, compute
\[
z=[Cc_2-(Cc_1)^Ts]_P,
\tag{12.8}
\]
and decode each coefficient by
\[
\operatorname{DecBit}(z)=\mathbf1_{\{P/4<[z]_P<3P/4\}}.
\tag{12.9}
\]
Both distance ties are assigned zero. This defines a deterministic decryption result even when the ciphertext is dishonest. Invalid formats are rejected at the base-PKE interface. In the KEM interface they invoke a specified implicit-rejection branch.

In the actual key law \(v\) need not be uniform. The useful uniform-lifting identity belongs to an ideal-public-key game, not to real key generation by declaration. In particular, replacing \(v\) by \(Qb\) changes the encryption distribution and removes an ingredient of the later proof.

## 12.4. Exact residues and the decoding event

Let the actual coefficient remainders be
\[
r_0=[As+e_0]_Q,\quad
r_1=[A^Tr+e_1]_C,\quad
r_2=[v^Tr+e_2]_C.
\tag{12.10}
\]
Because \(Q,C\mid P\), these are also the remainders after reduction modulo \(P\). Since \(C\mid P/2\), \(r_2\) is independent of the message **at fixed coins**. This statement does not assert probabilistic independence of \(r_2\) and \(e_2\).

**Lemma 12.2 — Signed error identity.** For every honest choice of the algorithms' variables,
\[
z\equiv(P/2)\mu+\varepsilon\pmod P,
\quad
\varepsilon=(e_0+\rho-r_0)^Tr+(r_1-e_1)^Ts+e_2-r_2.
\tag{12.11}
\]
The right side can be evaluated using ordinary integer negacyclic products to obtain an integer lift of each error coefficient.

*Proof.* Euclidean division gives \(Qb\equiv As+e_0-r_0\), \(Cc_1\equiv A^Tr+e_1-r_1\), and \(Cc_2\equiv v^Tr+e_2+(P/2)\mu-r_2\). Substitute \(v=Qb+\rho\) into (12.8). The two main products cancel by (12.4). The remaining terms give (12.11) with the stated signs. No random-variable independence is used in this identity. \(\square\)

**Lemma 12.3 — Strict decoding margin.** If \(z\equiv(P/2)\mu+e\pmod P\) for a bit \(\mu\) and an integer \(e\) satisfying \(|e|<P/4\), then \(\operatorname{DecBit}(z)=\mu\). Thus every honest failure is contained in
\[
\mathcal F=\{\max_i|\varepsilon_i|\ge P/4\}.
\tag{12.12}
\]

*Proof.* On the circle of circumference \(P\), the centers 0 and \(P/2\) are separated by \(P/2\). The strict bound makes the correct center strictly nearer. Equivalently, its two possible neighborhoods are precisely those specified by (12.9). Apply this argument to each coefficient. The event \(\mathcal F\) is a sufficient containing event, not an equivalent characterization of failure: a large integer lift can wrap back to a correctly decoded residue. \(\square\)

Ordinary distance between canonical representatives is not the distance used here. Nor can one replace the true remainders by independent uniforms. For example, \(r_1\) depends on both \(r\) and \(e_1\), and \(r_0\) depends on \(s,e_0,A\). The proof below integrates in an order that retains these dependencies.

## 12.5. The correctness notion and conditioning order

For a generated key define its worst-message failure probability over fresh encryption coins. The quantity to be bounded is
\[
\delta=\mathbb E_{pk,sk}\left[
\max_{\mu\in\{0,1\}^n}
\Pr[\operatorname{Dec}(sk,\operatorname{Enc}(pk,\mu))\ne\mu\mid pk,sk]
\right].
\tag{12.13}
\]
The expectation includes the randomness that generated the key. This is the averaged maximum used by the external FO correctness definition ([B24](#bib-b24)); it is not a maximum over every key.

The event (12.12) is the same for all messages when their encryptions are coupled with the same coins, because \(C\mid P/2\). For every latent key-generation draw it contains all possible message failures. Taking the maximum over messages therefore occurs before the final average without multiplying by the number of messages. If several latent draws yield the same \((pk,sk)\), condition on that key and average those latent draws; the containing-event argument still applies.

The proof works for any fixed matrix \(A\), or any random matrix independent of \(s,e_0\). Uniformity or nonsingularity of \(A\) is not a premise of correctness. Uniformity will be a separate premise of the source assumptions in the confidentiality proof.

## 12.6. Exponential moments without independent rounding errors

For \(u>1\), independent scalar variables \(E,R,S\sim\chi\), and \(T\) uniform in \(\{0,\ldots,Q-1\}\), define
\[
\begin{aligned}
a(u)&=\mathbb E_{E,R,T}u^{(|E|+T)R},\\
b(u)&=\mathbb E_S\max_{0\le c<C}\mathbb E_E
 u^{S([c+E]_C-E)},\\
c(u)&=\mathbb E_Eu^E.
\end{aligned}
\tag{12.14}
\]
The maximum is inside the expectation over \(S\). Exchanging these operations would give a different quantity. The source letter \(c\) inside the maximum denotes an integer residue, not a ciphertext.

**Lemma 12.4 — Pointwise domination of a hidden remainder.** For fixed integer \(e\), any \(t\in[0,Q-1]\), and symmetric \(R\) independent of uniform \(T\),
\[
\mathbb E_{R,T}u^{(e+T-t)R}
\le \mathbb E_{R,T}u^{(|e|+T)R}.
\tag{12.15}
\]
The same bound holds when the exponent is negated.

*Proof.* The function \(f(y)=\mathbb E_Ru^{yR}\) is even and convex. After averaging over the uniform interval for \(T\), the resulting function of \(e+(Q-1)/2-t\) is again even and convex: reflect \(T\) about its midpoint. Its maximum for \(0\le t\le Q-1\) is at an endpoint. The endpoint farthest from its symmetry center is \(t=0\) for \(e\ge0\), and \(t=Q-1\) for \(e\le0\). Reflecting \(T\) in the latter case gives the right side. Symmetry of \(R\) absorbs a minus sign. This is pointwise in \(t\); it remains valid when that remainder depends on other variables fixed during conditioning. \(\square\)

**Theorem 12.5 — Joint-error Chernoff bound.** For the C1 laws and any matrix independent of key secrets and errors,
\[
\mathbb E u^{\varepsilon_i}\le (a(u)b(u))^{kn}c(u),
\qquad
\mathbb E u^{-\varepsilon_i}\le
u^{C-1}(a(u)b(u))^{kn}c(u).
\tag{12.16}
\]
Consequently,
\[
\delta\le n(1+u^{C-1})(a(u)b(u))^{kn}c(u)u^{-P/4}.
\tag{12.17}
\]

*Proof.* Fix one output index. In each negacyclic inner product, the coefficient formula pairs every input coordinate with exactly one coordinate of the opposite factor, with a fixed sign \(\sigma\in\{-1,1\}\). Thus there are exactly \(kn\) pairs, not \((kn)^2\).

For the positive exponential, first use \(-r_{2,i}\le0\); for the negative exponential use \(r_{2,i}\le C-1\). This introduces the factor 1 or \(u^{C-1}\) and allows \(e_{2,i}\) to be averaged separately. By symmetry its moment in either direction is \(c(u)\). No independence of \(r_2,e_2\) is asserted.

Now fix \(A,s,e_0,r,\rho\). For every coefficient of \(e_1\), the relevant residue has the form \([c_j+e_{1,j}]_C\), with \(c_j=[(A^Tr)_j]_C\). The \(e_{1,j}\)'s are mutually independent and each appears once in the selected output. Integrate them first and bound each factor by
\(B_u(\sigma s_j)=\max_c\mathbb E_Eu^{\sigma s_j([c+E]_C-E)}\).
These upper bounds no longer depend on \(r\). The signs may differ, but the indexing is a permutation of all coordinates of \(s\).

With \(A,s,e_0\) now fixed, \(r_0\) is fixed. Every \(r_j\) and its paired \(\rho_j\) occur once in the first product, so independence of the *actual sampled* \(r,\rho\), together with Lemma 12.4, bounds their moment by a product of factors depending only on the corresponding \(|e_{0,j}|\). This removes all dependence on \(r_0\) without assigning a law to it. Only then average over the independent coefficients of \(e_0\) and \(s\). The first product gives \(a(u)^{kn}\); symmetry of \(S\) absorbs each sign in the second and gives \(b(u)^{kn}\). The argument with all signs reversed is identical.

Markov's inequality bounds the upper and lower tails by the two quantities in (12.16) multiplied by \(u^{-P/4}\). Sum them and use a union bound over \(n\) outputs. Output coordinates need not be independent. Section 12.5 justifies taking the maximum over messages inside the average. \(\square\)

The complete proof uses finite expectations for C1. A replacement noise law would require recomputing all three functions and checking the same symmetry and independence premises.

## 12.7. A rational certificate and a genuine failure event

**Corollary 12.6 — C1 failure certificate.** At \(u=3/2\),
\[
a=\frac{52261}{41472},\qquad b=\frac{67}{64},\qquad c=\frac{25}{24},
\tag{12.18}
\]
and the C1 profile obeys
\[
\delta\le 256\,\frac52
\left(\frac{52261}{41472}\frac{67}{64}\right)^{768}
\frac{25}{24}\left(\frac23\right)^{1024}<2^{-282}.
\tag{12.19}
\]

*Proof with a finite rational certificate.* Substitute the three-point law (12.5) and the four possible values of \(T\) into (12.14). These finite rational sums give (12.18). If the positive rational right side of (12.19) is reduced to \(N/D\), the accompanying two independently written checks verify the integer inequality \(2^{282}N<D\). The logarithm approximately \(-282.661702381374\) is only a display value, not the acceptance criterion. The general probability argument is Theorem 12.5; a sampled failure rate is not used. \(\square\)

**Counterexample 12.7 — Correctness is not perfect.** For every matrix \(A\), the C1 support contains an event of probability \(2^{-6400}\) on which the all-zero message is decoded incorrectly. Therefore
\[
2^{-6400}\le\delta<2^{-282}.
\tag{12.20}
\]

*Proof.* Set every coefficient of \(s\) to 0, of \(e_0\) to \(-1\), and of \(r\) to 1; set \(e_1,e_2,\rho\) to zero. Then \(r_0=3\), \(Qb=4092\), and the first lifted error coefficient is
\[
\varepsilon_0=-4\cdot3(1-255)=3048\equiv-1048\pmod{4096}.
\tag{12.21}
\]
It lies strictly between 1024 and 3072 as a canonical residue, so it decodes to 1 although \(\mu_0=0\). The event probabilities multiply to
\(2^{-768}2^{-1536}2^{-1536}2^{-768}2^{-256}2^{-1536}=2^{-6400}\).
The maximum in (12.13) is at least the failure probability for the zero message. Since the witness works for every \(A\), no matrix-generation probability is charged. \(\square\)

This event rules out setting the FO correctness error to zero. Its existence is not an efficient attack, and its extremely small probability does not justify ignoring it in a theorem that claims perfection.

**Corollary 12.8 — Bad keys and reuse.** If \(d(pk,sk)\) is the conditional maximum in (12.13), then for every \(\theta>0\),
\[
\Pr[d(pk,sk)>\theta]\le\min(1,2^{-282}/\theta).
\tag{12.22}
\]
For at most \(r\) honest encryptions with fresh coins under a single generated key, including adaptively chosen messages, the probability of any decryption failure is at most \(\min(1,r2^{-282})\).

*Proof.* The first claim is Markov's inequality applied to the nonnegative random variable \(d\). Given a key, each fresh encryption has conditional failure probability at most \(d\), regardless of the selected message. A conditional union bound gives \(rd\), and averaging gives the second statement. No new key-generation randomness is attributed to each reuse. \(\square\)

These are finite bounds for this fixed profile, not an asymptotic negligibility theorem for an unstated family. In particular, a bound on averaged keys is not a uniform bound for every adversarially selected key.

## 12.8. Two exact Module-LWE source problems

For \(j\in\{3,4\}\), define \(\mathsf{DMLWE}_{3,j}^{\chi}\) by the two experiments
\[
\begin{array}{ll}
\text{real:}&B\leftarrow\operatorname{Unif}(R^{j\times3}),\quad
 t\leftarrow\chi^{3n},\quad e\leftarrow\chi^{jn},\quad (B,Bt+e),\\
\text{ideal:}&B\leftarrow\operatorname{Unif}(R^{j\times3}),\quad
 y\leftarrow\operatorname{Unif}(R^j),\quad (B,y).
\end{array}
\tag{12.23}
\]
All initial draws are independent. The public matrix has independent ring elements; each coefficient of every secret and error is CBD1. Write \(\epsilon_{3,j}(\mathcal B)\) for the absolute difference of a distinguisher's acceptance probabilities. The secret is shared across the \(j\) module equations. The three- and four-row problems are separate source interfaces.

Neither a generic LWE matrix nor the HB source of Chapter 11 has this distribution. The modulus is a power of two, and the exact small secret and error law is part of the assumption. No standard worst-case lattice theorem is declared to cover (12.23) merely because its name contains LWE.

**Lemma 12.9 — Uniform lifting with the whole public view.** If \(V\) is uniform in \(R^3\) and independent of \(A\), then the joint law of \((A,F_Q(V),V)\) equals that of
\[
A,\quad b\leftarrow\operatorname{Unif}(\mathbb Z_{P/Q}^{3n}),\quad
\rho\leftarrow\operatorname{Unif}(\mathbb Z_Q^{3n}),\quad V=Qb+\rho,
\tag{12.24}
\]
with the new draws independent. Conditional on \((A,b)\), it remains a uniform lift after an adversary chooses messages and a state using independent coins and only that public view.

*Proof.* Coordinatewise quotient and remainder give a bijection from \(\mathbb Z_P\) to \(\mathbb Z_{P/Q}\times\mathbb Z_Q\). Apply it independently to all coefficients. Independence of \(A,V\) makes the remainder independent of \((A,b)\), not only of \(b\). Further conditioning on a randomized function of this public view and independent adversary coins preserves the conditional remainder law on every positive-probability fiber. \(\square\)

The independence qualification is intentional: Chapter 11's corrected lemma showed why independence of \(A\) and the quotient alone would not suffice. The simulation below satisfies the stronger premise because its matrix rows are independently sampled.

## 12.9. Conditional CPA through two joint simulations

Use \(\operatorname{Adv}_{CPA}=|\Pr[\widehat\beta=\beta]-1/2|\). The adversary receives an honest public key, chooses two messages and then receives one challenge. Public encryption queries can be generated locally; there is no decryption oracle.

**Theorem 12.10 — Abstract full-matrix CPA reduction.** For every classical adversary \(\mathcal A\), two distinguishers at its augmented simulation budget satisfy
\[
\operatorname{Adv}_{CPA}(\mathcal A)
\le\epsilon_{3,3}(\mathcal B_1)+\epsilon_{3,4}(\mathcal B_2).
\tag{12.25}
\]

*Proof.* In game \(G_0\), generate the real key and ciphertext. In \(G_1\), keep a uniform matrix \(A\) but make \(b\) independently uniform in the quotient space; encrypt with the unchanged algorithm. A distinguisher given \((A,y)\) from (12.23) with three rows publishes \((A,F_Q(y))\), runs the adversary, selects the challenge bit and publicly encrypts. It returns the success indicator. Real and ideal source branches reproduce \(G_0,G_1\) exactly. It does not need the source secret.

For the second transition receive \((B,y)\) with four rows. Write its first three rows as \(A^T\) and its last row as \(V^T\). Publish \(pk=(A,F_Q(V))\), retaining \(V\). The matrix \(A\) and the uniform \(V\) are independent. Once the adversary chooses messages, select \(\beta\) and return
\[
c_1=F_C(y_{0:3}),\qquad
c_2=F_C(y_3+(P/2)\mu_\beta).
\tag{12.26}
\]
In the real source, all four responses use the same secret \(t\); take it as the encryption secret \(r\). The first three errors give \(e_1\), and the fourth gives \(e_2\), with their required independence. Lemma 12.9 gives the full conditional law of \(V=Qb+\rho\), even after message selection. Thus the output is precisely the challenge distribution in \(G_1\). Other local encryptions use their own fresh lifts, not the retained \(V\).

In the ideal source, the four outputs are jointly uniform and independent of the complete matrix. Translation by the message preserves uniformity, and equal-width floor cells preserve uniform quotients. This is game \(G_2\), in which the challenge is independent of \(\beta\) even given the key and chosen messages. Its success probability is \(1/2\). The two absolute differences of game-success probabilities are exactly the two source advantages, proving (12.25) by the triangle inequality. \(\square\)

This is a reduction, not a proof that either source advantage is small. It uses one challenge of each stated kind in two different reductions, not an oracle supplying unlimited equations under a hidden secret. Ideal games need no decryption secret. Correctness and secrecy are established by different arguments.

## 12.10. Seeded matrix generation and programming

The seeded representation uses a 256-bit seed and an independent oracle \(\mathcal A\). Each entry is obtained at an injective input identifying the seed and its row and column. A response contains 512 bytes, interpreted as 256 little-endian 16-bit words. Keep each word modulo 4096. Distinct matrix-entry inputs have independent responses.

**Proposition 12.11 — Exact matrix expansion in the ideal-oracle model.** This procedure produces the required independent uniform matrix for a fresh seed. A simulator that is given a uniform matrix can program it at a fresh seed with an exactly matching raw-byte distribution. With at most \(q_A^{pre}\) prior matrix-oracle queries, the conflict probability is at most
\[
\epsilon_A=\min(1,q_A^{pre}2^{-256}).
\tag{12.27}
\]
The seeded CPA reduction consequently has the conservative bound
\[
\operatorname{Adv}_{CPA}^{seed}\le
\epsilon_{3,3}+\epsilon_{3,4}+2\epsilon_A.
\tag{12.28}
\]

*Proof.* Every 12-bit value has exactly 16 preimages among 16-bit words. To program a supplied coefficient, append an independent uniform four-bit high part; this samples its full conditional raw-word fiber. Repeat independently across all coefficients and entries. A prior query can involve at most one seed at the prescribed domain. The number of previously exposed distinct seeds is therefore at most the query count. A fresh uniform seed hits that set with probability at most (12.27). Abort on a conflict rather than resampling until success; otherwise the seed law would be silently conditioned. Outside the bad event, the programmed oracle and the public quotient have the required joint law. Apply this construction separately in the two reductions of Theorem 12.10 and add the two allowances. \(\square\)

The raw 512-byte responses matter: programming only their low bits without sampling the discarded bits would not simulate an adversary who queries the entire oracle response. Unused matrix-oracle inputs are answered independently and consistently. This proof is not a claim that a short public seed and fixed SHAKE256 output are statistically identical to an explicitly sampled long matrix. Concrete hash instantiation is a separate modeling obligation.

## 12.11. Random tapes, deterministic encryption and implicit rejection

The C1 allocation specified here uses a 2176-byte encryption tape. The first 1792 bytes produce the \(7n\) CBD1 coefficients of \(r,e_1,e_2\): use the difference of the two low bits of each byte. The last 384 bytes produce 768 nibbles, each reduced modulo four, for \(\rho\).

**Proposition 12.12 — Exact coin law.** Uniform bytes under this allocation give precisely the independent distributions in (12.7).

*Proof.* Two independent fair bits have difference law (12.5). Different bytes use independent bit pairs. The two nibbles of one uniform byte are independent uniform four-bit values; reducing each modulo four leaves independent uniform two-bit values. All remainder bytes are disjoint from the CBD bytes. The counts are \(3n+3n+n=1792\) CBD coefficients and \(3n=768\) remainders. Ignoring unused bits changes neither law. \(\square\)

Use independent classical random oracles \(G,H\), separate also from \(\mathcal A\). Let \(G(pk,\mu)\) give the tape and \(H(pk,\mu,c)\) give a 256-bit key. Set
\[
\operatorname{Enc}_1(pk,\mu)=\operatorname{Enc}(pk,\mu;G(pk,\mu)).
\tag{12.29}
\]
KEM key generation additionally draws one fallback secret \(z_0\) uniform on \(\{0,1\}^{256}\), independently. Encapsulation samples uniform \(\mu\), returns \(c=\operatorname{Enc}_1(pk,\mu)\) and \(K=H(pk,\mu,c)\). Decapsulation decrypts to \(\mu'\), re-encrypts with \(G(pk,\mu')\), and returns
\[
\begin{cases}
H(pk,\mu',c),&\text{canonical parsing succeeds and }\operatorname{Enc}_1(pk,\mu')=c,\\
H(pk,z_0,c),&\text{otherwise}.
\end{cases}
\tag{12.30}
\]
The equality is byte-exact. No accepted alias is normalized into the challenge encoding. Wrong lengths take the fallback branch. The fallback is drawn once per key, not afresh per rejection. These rules preserve repeat-query consistency. Hashing the actual ciphertext inside \(H\) is part of this chosen transform.

At the abstract level the oracle names provide domain separation; raw strings must implement injective encodings of the tuples. Public-key and message lengths are fixed and the ciphertext is the final field. The verification code checks tape allocation, arithmetic and canonical fields. Concrete domain-separation strings for a production implementation are not specified here.

## 12.12. CCA composition with a nonzero correctness term

The external ingredient is the corrected classical-ROM analysis of HHK ([B24](#bib-b24)), using transformation \(T\) followed by implicit-rejection \(U^{\not\perp}\), with the ciphertext included in \(H\). The corrected Theorem 3.2 counts plaintext-checking queries in its correctness term. With no ciphertext-validity oracle, the OW-PCA route does not require spreadness. Theorem 3.4 then gives the KEM step. These are imported published results, not newly invented transforms.

Let \(q_G,q_H\) count explicit adversarial queries and \(q_D\) count decapsulations. For an implementation that evaluates both candidate hashes, conservative totals are
\[
Q_G=q_G+q_D+1,\quad
Q_H=q_H+2q_D+1,\quad
Q_{RO}=Q_G+Q_H=q_G+q_H+3q_D+2.
\tag{12.31}
\]
The additions cover internal calls and the honest challenge. Counting repeated inputs only increases this upper bound. An invalid length needs at most the fallback hash, which is already covered. Oracle input length and arithmetic work also count toward the reduction's resources.

**Theorem 12.13 — Conditional single-user CCA bound.** In the ideal classical oracles, for the challenge-first KEM experiment of the cited composition, appropriate source distinguishers satisfy
\[
\begin{aligned}
\operatorname{Adv}_{CCA}\le{}&
3\epsilon_{3,3}(\mathcal B_1)+3\epsilon_{3,4}(\mathcal B_2)+6\epsilon_A\\
&+Q_{RO}2^{-282}+3Q_{RO}2^{-256}.
\end{aligned}
\tag{12.32}
\]
The KEM advantage is success bias from \(1/2\); source advantages are acceptance gaps.

*Proof by application of the identified external theorem.* The base PKE has exactly the averaged worst-message correctness notion (12.13), with \(\delta<2^{-282}\). The random tape has its required uniform law by Proposition 12.12. Re-encryption implements \(T\), and a single independent fallback with (12.30) implements the chosen implicit-rejection \(U\). For a fixed single-user public key, prefixing \(pk\) restricts the independent random functions to an injectively encoded domain.

The corrected HHK composition bounds the bias by
\(Q_{RO}\delta+3Q_{RO}/|\mathcal M|+3\operatorname{Adv}_{CPA}\), where \(|\mathcal M|=2^{256}\). Its proof covers the faulty-decryption events; none are assumed absent here. The interface uses plaintext checking, not an unprovided validity oracle. Substitute (12.28), use (12.19), and retain the total query budgets (12.31). All source distinguishers are evaluated at the actual augmented simulation time and query budget. This proves the displayed specialization of the imported theorem. \(\square\)

The source article's explicit-call shorthand is insufficient unless implicit calls are included. Likewise, writing \(\delta=0\) would contradict Counterexample 12.7. No QROM theorem, multi-user guarantee, implementation leakage guarantee or concrete SHAKE theorem follows from (12.32).

**Proposition 12.14 — An allowance for decapsulation before the challenge.** To extend the challenge-first experiment to a phase with at most \(d_{pre}\) decapsulation queries before a fresh uniform encapsulation message is selected, a sufficient additional allowance is
\[
\epsilon_{phase}\le\min(1,d_{pre}2^{-256}+\delta).
\tag{12.33}
\]

*Proof.* Presample the challenge with its message hidden during the preliminary phase, using the same fixed oracle functions. Its disclosure may be delayed because the phase receives no challenge information. Abort only if a preliminary query equals the hidden challenge ciphertext. For fixed keys and oracles, any ciphertext has at most one **successfully decrypting** message preimage under \(\operatorname{Enc}_1\): deterministic decryption cannot equal two different messages. Thus the union of \(d_{pre}\) queried ciphertexts accounts for at most \(d_{pre}\) good messages. All remaining collisions require a message whose deterministic encryption decrypts incorrectly. The expected fraction of such messages, over keys and independent \(G\), is at most \(\delta\): for each message its oracle tape is uniform and its average failure is bounded by (12.13). A fresh uniform message is independent of the preliminary phase when the functions and key are fixed. Averaging gives (12.33), including adaptive preliminary queries. Outside this event the challenger can relay the phase exactly. \(\square\)

This extra allowance is stated separately from the imported main-game bound. Perfect correctness, which could remove its final \(\delta\), is unavailable. It is also separate from matrix-seed prequeries. The argument is about an honestly generated single key, not arbitrary related-key or malicious-key interfaces.

## 12.13. Encodings, storage, and the meaning of “under one kilobyte”

**Proposition 12.15 — C1 payload sizes.** With a one-byte profile identifier and a 32-byte matrix seed, the public key has 993 bytes; the ciphertext has 1408 bytes:
\[
\begin{aligned}
|pk|&=1+32+3\cdot256\cdot10/8=993,\\
|c|&=(3+1)\cdot256\cdot11/8=1408.
\end{aligned}
\tag{12.34}
\]

*Proof.* Each public quotient is in \([0,4096/4)\), requiring ten bits. Each ciphertext quotient is in \([0,4096/2)\), requiring eleven bits. There are 768 public quotients and 1024 ciphertext coefficients. Concatenate fixed-width fields coefficient-first and little-endian within the bit stream. The two totals are byte-aligned, so there are no padding aliases. The seed and identifier contribute 33 bytes only to the public key. \(\square\)

The mathematical full-matrix representation would require 3456 bytes for the nine polynomials alone, plus 960 bytes for \(b\), or 4416 bytes before metadata. The reduction to 993 bytes uses the seeded generation model, not a lossless compression of every arbitrary independent full matrix into 32 bytes. A KEM secret key must retain enough public data to re-encrypt, as well as the fallback and secret vector; its complete byte format is not specified by the two public payload numbers.

The local test encoder does not claim to reproduce the historical profile identifier or literal oracle-domain strings. Both need checking against the original byte specification before a release. Generic parsers in the tests reject wrong lengths and nonzero padding on auxiliary profiles; C1's ciphertext itself has no unused bits. Parameters and profile negotiation remain outside the payload count except for the declared identifier.

A raw PKE ciphertext remains malleable: translating one \(c_{2,i}\) by \(P/(2C)\) adds \(P/2\) to the corresponding decryption residue. Away from ties this complements its decoded bit. In the KEM, such a valid-format change is subjected to the re-encryption check; merely remaining a canonical ciphertext is not acceptance. The FO proof, not a format check or a handful of rejected modifications, supplies the conditional CCA claim.

## 12.14. Concrete resources are additional hypotheses

Suppose, only for illustration, that both exact source problems satisfy a quantitative envelope
\[
\epsilon_{3,j}(\mathcal B)\le T_{\mathcal B}2^{-s_*},\qquad
T_{\mathcal B}\le\kappa_*T,
\tag{12.35}
\]
in one explicitly chosen work unit. Let \(T\ge1\), \(q_G+q_H+q_D\le T\), and \(q_A^{pre}\le T\). Neither this envelope nor a concrete value of \(\kappa_*\) is proved by a lattice-cost estimate.

**Proposition 12.16 — Conditional work/advantage calculation.** For the main game of Theorem 12.13 and normalized advantage \(a_{CCA}=2\operatorname{Adv}_{CCA}\),
\[
\frac{a_{CCA}}{T}\le
12\kappa_*2^{-s_*}+10\cdot2^{-282}+42\cdot2^{-256}.
\tag{12.36}
\]

*Proof.* Since \(Q_{RO}\le3T+2\le5T\), substitute (12.35) into (12.32). The two source terms give \(6\kappa_*T2^{-s_*}\) before normalization. The matrix-programming term contributes at most \(6T2^{-256}\), and the hash-guessing term at most \(15T2^{-256}\). Multiply the complete inequality by two and divide by \(T\). The correctness term becomes at most \(10\cdot2^{-282}\). \(\square\)

| Assumed \(\log_2\kappa_*\) | 0 | 10 | 16 | 20 | 24 |
|---|---:|---:|---:|---:|---:|
| Required integer \(s_*\) | 132 | 142 | 148 | 152 | 156 |

The table gives the smallest integer \(s_*\) making (12.36) strictly smaller than \(2^{-128}\). It is verified by exact rational comparisons, including failure at the preceding integer. It is conditional arithmetic, not a security certificate. A cost for one known attack at a particular success probability is not an upper bound on the advantage of **every** adversary. Source attack work, bit operations, preprocessing, oracle traffic and Python time are not interchangeable. Applying Proposition 12.14 adds its phase allowance; the table does not silently include it.

No estimator output is used here as a universal security bound for the exact C1 sources. Current primary metadata for structured cryptanalysis ([B30](#bib-b30)) supports the need to preserve module symmetries, but does not evaluate the exact C1 scheme or certify any concrete level.

## 12.15. Exact CBD1 guessing and a fixed-character calculation

**Proposition 12.17 — Optimal prior guessing in the CBD1 law.** For a vector of \(\zeta\) independent CBD1 coefficients, every particular vector of nonzero weight \(w\) has probability \(2^{-(\zeta+w)}\), and there are \(\binom\zeta w2^w\) such vectors. Consequently,
\[
\Pr[W\le w]=2^{-\zeta}\sum_{j=0}^{w}\binom\zeta j,
\qquad
N_{\le w}=\sum_{j=0}^{w}\binom\zeta j2^j.
\tag{12.37}
\]
To reach target prior probability \(\theta\), order weights increasingly. If \(\theta\) enters shell \(w\), the smallest number of guesses is
\[
N_{<w}+\left\lceil
(\theta-\Pr[W<w])2^{\zeta+w}
\right\rceil.
\tag{12.38}
\]

*Proof.* Zero has mass \(1/2\), each sign has mass \(1/4\). Multiply coefficient probabilities and count the supports and signs. All vectors in a lighter shell have strictly greater individual probability. Exchanging a lower-probability guess for an unguessed higher-probability vector cannot decrease the covered mass, so a prefix of this order is optimal. The last shell has constant individual mass, giving the ceiling. \(\square\)

This is a prior-distribution calculation with no public-key information. It is not the cost of an optimal public-key attack. In particular, the exact Shannon entropy \(1.5\zeta\) and min-entropy \(\zeta\) do not replace the cost/success curve or account for conditioning on a public observation.

For a fixed integer frequency \(h\), direct averaging gives
\[
\mathbb E_{E\sim\chi}\exp(2\pi i hE/P)
=\cos^2(\pi h/P).
\tag{12.39}
\]
For a centered representative \(|h|\le P/2\), this is at most \(\exp(-\pi^2h^2/P^2)\). Indeed, \(\log\cos x\le-x^2/2\) for \(|x|<\pi/2\), as follows by differentiating and using \(\tan x\ge x\) for \(x\ge0\); the endpoints give zero directly. This controls one fixed character. It does not price the search for a useful dual vector, a decoding step or an adaptive family of tests.

## 12.16. Module symmetries and overlapping cyclic events

Multiplication by \(x^t\) in \(R\) is a signed permutation of coefficients. Thus the marginal CBD1 laws are preserved, and
\[
x^t(Bs+e)=B(x^ts)+x^te.
\tag{12.40}
\]
All these observations come from one instance; they are not new independent source samples. For sign-insensitive events there are \(n\), not \(kn\), simultaneous cyclic positions supplied by this operation. Independent rotation of module components would require a different transformation of the public matrix and its analysis.

If \(J\) events each have marginal probability \(p\), then \(p\le\Pr[\text{at least one}]\le\min(1,Jp)\). No formula \(1-(1-p)^J\) follows without independence, and no universal \(\log_2J\) attack saving follows from the union bound. Shared preprocessing and dependence must be part of a specific attack analysis.

**Proposition 12.18 — Exact cyclic zero-run probability.** For a length-\(N\) CBD1 polynomial and \(1\le\zeta\le N\), define the integer transition matrix \(T_\zeta\) on states \(0,\ldots,\zeta-1\): every state has one transition to 0 for a nonzero coefficient, and state \(j\) has one transition to \(j+1\) for a zero if \(j+1<\zeta\). Then
\[
\Pr[\text{some cyclic run of }\zeta\text{ zeros}]
=1-2^{-N}\operatorname{tr}(T_\zeta^N).
\tag{12.41}
\]

*Proof.* The zero/nonzero indicators are independent fair bits. For an indexed cyclic word containing a nonzero symbol and no forbidden run, the state before each symbol is uniquely determined by its number of immediately preceding zeros. It gives exactly one compatible closed walk at that indexed starting position. Conversely every counted walk gives such a word. The all-zero word is forbidden because \(\zeta\le N\). The trace counts all permitted indexed words; divide by \(2^N\) and take the complement. \(\square\)

For \(N=256,\zeta=16\), the exact rational probability is approximately 0.0019514643. The independent-window expression is almost twice as large. Both are computed for this explicitly defined event; no claim is made that it models every primal or dual hybrid strategy. The accompanying two implementations use matrix exponentiation and dynamic closed-walk counting, respectively, and agree with exhaustive enumeration on small domains.

## 12.17. Ramified projections and explicit-noise boundaries

**Proposition 12.19 — Low ramified quotients carry uniform CBD1 error.** In the C1 ring, put \(w=x+1\). Then \((w^{256})=(2)\) and \(w^{3072}=0\). For \(1\le t\le256\),
\[
R/(w^t)\simeq\mathbb F_2[w]/(w^t),
\tag{12.42}
\]
and the image of an independently sampled CBD1 polynomial is uniform on this quotient. For an unrounded source in (12.23), its projected noisy responses are consequently uniform independently of the secret, conditional on the public matrix.

*Proof.* Expand \((w-1)^{256}+1\). Every intermediate binomial coefficient is even, so the defining relation gives \(w^{256}=-2g(w)\), where \(g(0)=1\). First \(w^{256}\in2R\) implies \(w^{3072}=0\). Thus \(w\) is nilpotent, and \(g(w)=1+w h(w)\) is a unit by a finite geometric series. This proves equality of the ideals. For \(t\le256\), \((w^{256})\subseteq(w^t)\), so 2 vanishes in the quotient. The resulting presentation is exactly (12.42).

The parity of each CBD1 coefficient is a fair bit. The change of polynomial coordinates from \(x\) to \(w-1\), modulo two, is an invertible triangular transformation on 256 coefficients. A uniform vector remains uniform; projecting to its first \(t\) coordinates is uniform on \(\mathbb F_2^t\). Independent error polynomials remain independent. Adding any fixed projected \(Bs\) preserves this uniformity. \(\square\)

This proves a property of these **unrounded low quotients**, not secrecy of the entire source. Floor division is not a ring homomorphism. For instance, the integers 0 and 4 have the same parity but distinct quotients after division by 4. High-bit or carry-based attacks are not excluded by Proposition 12.19.

**Proposition 12.20 — Explicit noise cannot simply be deleted.** For \(2\le Q<P\), \(Q\mid P\), a fixed integer \(z\) and \(E\sim\mathrm{CBD}_1\),
\[
\Pr[F_Q(z+E)\ne F_Q(z)]
=\tfrac14\left(\mathbf1_{[z]_Q=0}
+\mathbf1_{[z]_Q=Q-1}\right).
\tag{12.43}
\]
If \([z]_Q\) is uniform, its mean is \(1/(2Q)\).

*Proof.* The zero error preserves the cell. A displacement \(-1\) changes the quotient exactly at a cell's first point; a displacement \(+1\) does so exactly at its last point. Since there are at least two cells, a wrap at 0 or \(P-1\) changes the output as well. Each nonzero error has probability \(1/4\). Averaging over the \(Q\) possible phases proves the mean. \(\square\)

At \(Q=4\) that mean is \(1/8\), but no uniform-phase claim about \(As\) is used. A low-noise scheme can still be amenable to Boolean methods; a distribution mismatch with a noiseless analysis is not a defense theorem. This chapter supplies no new attack-cost estimate or source-hardness proof.

## 12.18. Reproducibility, evidence limits, and synthesis

The public package contains the mathematical reference implementation `a6_blindage.py` and two verification paths. The primary implementation uses direct signed negacyclic multiplication with arbitrary-precision integers. The independent verifier imports neither it nor the main verifier: it reconstructs modular products by carry-separated packed-integer convolution, signed errors by a separately written full convolution, and ciphertext encoding by an explicit bit stream. Its finite probability calculations use individual Bernoulli atoms rather than the primary distribution dictionary.

| Verification family | Extent executed |
|---|---:|
| Module double-product cancellation | 200 cases |
| Strict decoder inputs | 238 |
| Signed error and all-message checks on small fixtures | 6,672 encryptions |
| Pointwise hidden-remainder moment inequalities | 1,232 |
| C1-dimensional functional encryptions | 12 |
| Uniform-lift atoms | 328 |
| Complete auxiliary second-hybrid laws | 64 laws; 3,456 weighted states |
| Public-quotient encoding round trips | 100 |
| Auxiliary canonical byte containers | 256 |
| Decoder complement residues at \(P=4096\) | 4,096 |
| Cyclic run comparisons | 55 profiles; 18,434 words across tests |
| Exact prior-guess quantiles versus full enumeration | 24 |
| Low-quotient uniformity | 14 profiles; 2,120 bit vectors |
| Scalar explicit-noise boundary cases | 240 |

The independent verifier additionally reconstructs one complete C1-dimensional synthetic transcript, its 256 signed error coordinates and 1408 encoded ciphertext bytes. It checks the rational certificate independently and fully enumerates 81,920 scalar latent states for whole-joint moment bounds on 24 fixed-public profiles. Those scalar experiments are auxiliary checks, not C1 security profiles. It also rechecks 64 second-hybrid laws and 45 cyclic profiles; overlapping domains are not counted as new independent cryptographic instances.

The certificate, rather than the twelve functional encryptions, proves the tiny failure bound. All transcripts intentionally expose their synthetic secrets and randomness. The scripts do not implement a production KEM, verify adaptive CCA security by testing, establish a quantum guarantee, or run lattice reduction at security-scale dimensions. No numerical estimator output is regenerated in this chapter.

From `supplementary/chapter-12/`, run the delivered verification entry points:

```sh
python3 verify.py
python3 verify_independent.py
```

The JSON files omit timing and environment-dependent version fields. Mathematical acceptance uses exact integer or rational comparisons. The finite checks support the stated identities, formats, certificate arithmetic and small-domain distribution claims; they are not a substitute for the two Module-LWE hardness assumptions or for the adaptive CCA proof.

The security statements in this chapter rely only on the mathematical specification given here and on public literature. All theorem premises are stated in this chapter or supported by public literature.

**Scientific conclusion.** The C1 profile has an explicit nonzero correctness bound and a conditional classical-ROM route to a CCA KEM. It does not have an unconditional confidentiality theorem, a concrete 128-bit certificate, a complete worst-case reduction for these exact source laws, or a deployment recommendation. The compact public representation and the full matrix are related only in the stated oracle model. Other BLINDAGE profiles require their own distributions, certificates, byte specifications and source-hardness analysis.

## Supplementary Material and Reproducibility — Chapter 12

The public supplementary material for this chapter is assigned to `supplementary/chapter-12/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

```{=latex}
\part*{\phantomsection\addcontentsline{toc}{part}{PART IV — Security, Cryptanalysis and Deployment}PART IV — Security, Cryptanalysis and Deployment}
```

# Chapter 13 — Security Games and Reduction Architecture {#ch13}
## Agreement, Search, CPA, CCA, and the Exact Scope of MODDIV Proofs

**Scope.** The FO theorems used in this chapter are imported with their stated hypotheses. Finite checks do not establish computational hardness, external peer review, formal certification, worldwide novelty or institutional thesis validation.

### Abstract

This chapter organizes the security conclusions of the preceding constructions without changing any construction. It distinguishes agreement, recovery of an original or compatible secret, message one-wayness, chosen-plaintext indistinguishability, and chosen-ciphertext security. Elementary finite-probability lemmas make explicit which joint distributions a reduction must preserve, when deferred quotient lifting remains valid after public information and adaptive messages, and why a bounded Rényi loss is not interchangeable with negligible statistical distance. The chapter gives a common ledger for hybrid, sampling, correctness, oracle, representation, and resource losses. It records the different proof routes of P-REF, unit-anchored WC, NOISE-CPA-LIFT, and BLINDAGE C1, with their distinct source assumptions and models. Classical query extraction, prechallenge collisions, and canonical ciphertext encodings are treated as separate interfaces. Exact finite countermodels and independently written verification programs accompany the exposition. No new hardness reduction, parameter certification, construction, or extension to CBD2 is claimed.

### Scope and role of this chapter

Chapters 9–12 specify different encryption systems. Their formulas are not interchangeable implementations of one security experiment. This chapter states precisely what the existing proofs imply and what additional evidence would be needed for stronger claims. Cross-references to Chapters 5 and 8–12 identify the mathematical source of each construction-specific statement; the local lemmas below are classical probability or elementary specializations.

The independence qualification in Chapter 11 is retained. Chapter 12 is used only as the C1-P12-CBD1 profile described there. Later BLINDAGE profiles and a future connection between HB and established lattice assumptions are not silently incorporated. The verification programs in the public supplementary material check proof interfaces rather than rerun every arithmetic suite from the construction chapters.

## 13.1. A security statement is an experiment with a resource budget

An equation such as \(U=F_Q(M(A)X+E)\) does not specify a security claim. It omits the public distribution, secret distribution, sample count, available queries, challenge target, and observation of auxiliary data. The same equation can describe easy and difficult problems, depending on those choices.

For this chapter, a *security contract* consists of a versioned algorithm specification, a parameter family, the complete joint sampling law, the public interface, a success event, an advantage convention, an adversary model, and a resource bound. This is a documentary device, not a new security definition. A reduction must name its input contract and output contract, supply an executable adversary transformation, and quantify the loss at the transformed resource budget.

The parameter family is indexed by \(\lambda\). Dimensions, bit lengths, oracle input lengths, and the running times of the required samplers must be polynomially bounded when an asymptotic polynomial-time claim is made. A finite profile is not itself an asymptotic family. Conversely, existence of a sufficiently large family says nothing immediate about a small row in a parameter table.

Write \(\mathcal P\preceq\mathcal Q\) when an algorithm for \(\mathcal Q\) gives, through the stated reduction, an algorithm for \(\mathcal P\). Hardness is transported from the problem on the left to the problem on the right, not the reverse. A displayed identity of bilinear maps supplies only an algebraic interface until the two source worlds, their correlations, and their simulation have been identified. Regev's public-vector distribution ([B01](#bib-b01)), for example, is not the overlapping-ribbon distribution of Chapter 11.

## 13.2. Games, success probabilities, and the factor of two

For a distinguisher \(D\) between experiments \(\mathsf E_0,\mathsf E_1\), use the acceptance-gap convention
\[
 \epsilon_D=\left|\Pr[D(\mathsf E_1)=1]-\Pr[D(\mathsf E_0)=1]\right|.
 \tag{13.1}
\]
For a fair hidden-bit game use the success bias
\[
 \eta_A=\left|\Pr[\widehat b=b]-\tfrac12\right|.
 \tag{13.2}
\]
One-way success is instead the probability of recovering the specified target. It is not centered at one half. Its unavoidable uniform-message guessing baseline is \(1/|\mathcal M|\).

**Proposition 13.1 — Acceptance gap and success bias.** If the adversary guesses one precisely when \(D\) returns one, with the challenge world selected by a fair bit, then its success bias is \(\epsilon_D/2\).

*Proof.* Put \(a_i=\Pr[D(\mathsf E_i)=1]\). The success probability is \((a_1+1-a_0)/2\). Subtracting one half and taking absolute values gives \(|a_1-a_0|/2\). Reversing the guess changes the sign but not the bias. The identity holds for randomized distinguishers by including their coins in the experiment. \(\square\)

In the CPA game, an honest public key is provided before the adversary chooses two equal-length messages. The challenger encrypts one under a fresh fair bit. The adversary has no decryption oracle; encryption is a public algorithm. In the KEM CCA game, the challenge consists of an honest encapsulation ciphertext and either its key or an independent uniform key. Decapsulation queries exclude the exact challenge ciphertext. Whether queries are allowed before the challenge is delivered is part of the contract, not a typographical detail.

The standard model, a classical random-oracle model, and the quantum random-oracle model provide different interfaces. A proof that records and selects classical queries does not thereby handle superposition queries. The rest of this chapter is classical. It does not import a QROM theorem from a paper merely because that paper also contains one.

## 13.3. Agreement and a posterior predictor are different from secrecy

Consider a two-publication experiment. Conditional on public \(A=a\), let private variables \(X,Y\) be independent. Let \(U=f_a(X)\), \(V=g_a(Y)\), and let the transcript be \(T=(A,U,V)\). Allow arbitrary finite secret laws; they need not be uniform. The private outputs have the form
\[
 K_A=k_A(T,X),\qquad K_B=k_B(T,Y).
 \tag{13.3}
\]
Additional private coins can be included in \(X,Y\), provided the conditional independence and the specified publication functions still hold.

**Theorem 13.2 — Conditional replacement and the agreement identity.** Draw \(X^*\) from \(\mathcal L(X\mid T)\), independently of the original private variables conditional on \(T\), and put \(K^*=k_A(T,X^*)\). Then
\[
 \Pr[K^*=K_B]=\Pr[K_A=K_B]
 \le \mathbb E_T\max_k\Pr[K_B=k\mid T].
 \tag{13.4}
\]
No efficient implementation of the conditional sampler is implied.

*Proof.* Fix a transcript of positive probability. Its likelihood factors into an \(X\)-constraint and a \(Y\)-constraint. Bayes' rule therefore gives
\[
 \Pr[X=x,Y=y\mid T]=\Pr[X=x\mid T]\Pr[Y=y\mid T].
 \tag{13.5}
\]
Replacing \(X\) by an independent sample from that posterior preserves the joint law of \((T,X,Y)\), after the renamed variable is substituted. This proves the equality. If \(p_T(k)\) and \(q_T(k)\) are the two conditional output laws, their agreement is \(\sum_k p_T(k)q_T(k)\), at most \(\max_k q_T(k)\). Average over \(T\). \(\square\)

For the scalar interval model of Chapter 5, the posterior sampler has a separately proved efficient implementation. That algorithmic fact makes the equality an effective passive prediction result there. In a general multidimensional system, computing the posterior can be expensive; the equality by itself is not a polynomial-time attack. Nor does it cover protocols with unmodeled secret-dependent interaction that destroys the factorization.

Agreement one is compatible with complete insecurity: take both outputs to be the public constant zero. Hashing a public constant with a public function does not make its value secret. More generally, output length, marginal entropy, and conditional computational unpredictability are different properties. Chapter 6's three-quarters theorem is an agreement theorem, not a lower bound on the work required by an adversary.

## 13.4. Original-secret search, compatible search, and message one-wayness

Let a deterministic observation be \(U=f_A(X)\), and let \(\mathcal S_A\) be the specified admissible secret set. A solver succeeds in *compatible search* when it returns \(x'\in\mathcal S_A\) with \(f_A(x')=U\). It succeeds in *original-secret search* when it returns the actual \(X\). The two events coincide only under an additional condition.

**Proposition 13.3 — Collision allowance.** If
\[
 \Pr\bigl[\exists x'\in\mathcal S_A\setminus\{X\}:f_A(x')=f_A(X)\bigr]\le\zeta,
 \tag{13.6}
\]
then every compatible solver of success \(\alpha\) recovers the original secret with success at least \(\max(0,\alpha-\zeta)\).

*Proof.* Outside the event in (13.6), any valid compatible answer is \(X\). The compatible-success event minus the collision event is contained in original-secret success. Subtracting the probabilities proves the bound. No independence between solver success and collisions is needed. \(\square\)

If four secrets have the same publication and are equiprobable, always returning the first is perfectly compatible but recovers the original with probability only \(1/4\). Conversely, an efficiently computable shared value may be determined by any compatible secret even when the original is not identifiable; Chapter 9's unrounded finite-field construction is such a case. Recovering a private key, recovering a message, and predicting a shared value must therefore be named separately.

**Proposition 13.4 — A conservative CPA-to-message-recovery reduction.** Fix a message length \(\ell\) and a nonempty finite message space \(\mathcal M\subseteq\{0,1\}^{\ell}\), with \(|\mathcal M|=J\). Let a recovery algorithm, returning an element of \(\mathcal M\), recover a uniformly sampled encrypted message with probability \(p_{\rm rec}\). There is a CPA adversary with success bias \(\eta\) such that
\[
 p_{\rm rec}\le J^{-1}+2\eta.
 \tag{13.7}
\]
For a polynomial-time reduction, assume that uniform sampling from \(\mathcal M\) is efficient, and include its cost in the reduction budget. Perfect decryption correctness is not required.

*Proof.* Choose independent uniform \(m_0,m_1\in\mathcal M\). They have the same length, so they form a legal CPA challenge pair. Give the challenge ciphertext to the recovery algorithm and test whether its answer equals \(m_0\). In the world encrypting \(m_0\), acceptance is \(p_{\rm rec}\). In the world encrypting \(m_1\), the algorithm's view is independent of \(m_0\), so acceptance is \(1/J\). Proposition 13.1 gives bias \(|p_{\rm rec}-1/J|/2\). This yields (13.7), including when recovery performs worse than guessing. A failure output can first be mapped to a fixed message without decreasing successful recovery. \(\square\)

**Why the fixed-length premise is necessary.** For \(\mathcal M=\{0,00\}\), take empty keys and identity encryption and decryption. Uniform-message recovery succeeds with probability one. Every legal equal-length CPA pair is \((m,m)\), so every CPA adversary has bias zero. Without the premise, (13.7) would assert \(1\le1/2\). This is a counterexample to the former unrestricted statement, not to the fixed-length schemes in the ledger. The negative case is self-contained in the argument above; the construction-specific statements are unchanged.

**Counterexample 13.5 — One-wayness does not itself give indistinguishability.** Given any one-way encryption family for uniformly sampled \(k\)-bit messages, define encryption of \((b,m)\in\{0,1\}\times\{0,1\}^k\) by
\[
 \mathsf{Enc}'(pk,(b,m))=(b,\mathsf{Enc}(pk,m)).
 \tag{13.8}
\]
This family remains one-way for uniform whole messages, but has a CPA adversary of bias \(1/2\).

*Proof.* A successful full-message recovery algorithm recovers \(m\). On a challenge for the base scheme, append an independent fair bit and run that algorithm; returning its message component does not decrease its recovery probability. Thus base one-wayness implies whole-message one-wayness for the new family. For CPA, choose \((0,m)\) and \((1,m)\); the first ciphertext field reveals the challenge bit exactly. Correctness, if possessed by the base, is preserved. The construction is an implication counterexample conditioned on the base one-way family, not a hardness assertion about a finite toy. \(\square\)

This separation is why WC's Rényi-based one-way route is not renamed a standalone decisional rounded-key theorem. Its later CCA conclusion requires a transformation with the appropriate one-way premise.

## 13.5. Preserve the complete view, not only its marginals

For finite laws \(\mu,\nu\), use
\[
 \operatorname{TV}(\mu,\nu)=\tfrac12\sum_x|\mu(x)-\nu(x)|.
 \tag{13.9}
\]
A randomized channel \(K\) is a conditional law \(K(y\mid x)\) used in the same way in both experiments. Appending adversary coins, computing ciphertexts, choosing messages from a received public key, or evaluating a final event can be modeled as such a channel when the required input and oracle interface are actually available.

**Lemma 13.6 — Common-channel transport.** For a common channel,
\[
 \operatorname{TV}(\mu K,\nu K)\le\operatorname{TV}(\mu,\nu).
 \tag{13.10}
\]
Consequently the difference of probabilities of any common output event is at most the right-hand side.

*Proof.* For each output \(y\), expand \((\mu K)(y)-(\nu K)(y)=\sum_x(\mu(x)-\nu(x))K(y\mid x)\). Apply the triangle inequality, sum over \(y\), and use \(\sum_yK(y\mid x)=1\). The event bound follows by summing the positive and negative parts of the signed difference, each of total mass equal to TV. \(\square\)

The premise is joint equality or closeness at the input. Let \(S\) be uniform on a set of \(J\) elements. The pairs \((S,S)\) and \((S_1,S_2)\), for independent uniform \(S_1,S_2\), have identical individual marginals but
\[
 \operatorname{TV}\bigl((S,S),(S_1,S_2)\bigr)=1-J^{-1}.
 \tag{13.11}
\]
The diagonal event proves the lower bound, and direct summation proves equality. A shared-secret ciphertext cannot be replaced by independent components simply because each component has a correct marginal.

Latent secrets may be added to both laws to prove a stronger statistical estimate and then omitted by data processing. This is an analytic device. It does not authorize a reduction to call a challenger with a secret that its actual input does not contain. Similarly, a secret-dependent success predicate may be legitimate for an inequality of probabilities without being efficiently testable by a source distinguisher. The WC reduction checks a message it selected; a source-secret equality test would be a different obligation.

## 13.6. Deferred lifting after the full public information is revealed

Let \(P=HQ\) and \(B\in\mathbb Z_P^n\). Put \(U=F_Q(B)\), and let \(W\) denote any additional public information. The operation of generating \(B\) early and later regenerating it from \(U\) is not automatically harmless.

**Lemma 13.7 — Exact criterion for a fresh conditional lift.** Replacing the conditional law of \(B\), after observing \((W,U)\), by \(QU+R\) with fresh uniform \(R\in\mathbb Z_Q^n\) preserves the joint law of \((W,U,B)\) if and only if, on every positive-probability public fiber,
\[
 \Pr[[B]_Q=r\mid W,U]=Q^{-n}\qquad(r\in\mathbb Z_Q^n).
 \tag{13.12}
\]
Uniform \(B\) independent of \(W\) is a sufficient premise. Under this premise, further conditioning on messages and state computed from \((W,U)\) and coins independent of \((W,B)\) preserves (13.12).

*Proof.* The map \(b\mapsto(F_Q(b),[b]_Q)\) is a bijection. Equality of the two joint laws is therefore equivalent, on every public fiber, to equality between the original remainder law and the new uniform law. This proves necessity and sufficiency. For the sufficient premise, uniform \(B\) gives independent uniform quotient and remainder, and independence from \(W\) keeps the remainder independent of \((W,U)\). Independent adversary coins can be adjoined without changing this fact. Messages and state are functions of those variables, so conditioning further on them leaves the same law. \(\square\)

The distinction between \(W\perp B\) and merely \(W\perp U\) is substantive. Consider the following witness to the conditional-lifting distinction: \(P=16,Q=8,n=3\), uniform \(B\), \(\rho=[B]_8\), and independent uniform \(J\in\{0,\ldots,7\}\). Set
\[
 A=(8+\rho_0,8+\rho_1,8+\rho_2,8+J).
 \tag{13.13}
\]
The coefficients of \(A\) are independent upper-half uniforms and \(A\perp U\). Nevertheless, \((A,U)\) determines \(B\). Its remainder is a point mass instead of a uniform law on 512 values; the conditional and joint TV distances to fresh resampling are \(511/512\). The real second simulator of NOISE satisfies the stronger independence, as does the independent last-row lift in BLINDAGE's second transition. This counterexample does not invalidate those corrected applications (Chapter 11; Chapter 12).

## 13.7. Rényi preservation transports success, not arbitrary advantage

Define the multiplicative order-two Rényi divergence by
\[
 \mathcal R_2(\mu\Vert\nu)=\sum_{x:\mu(x)>0}\frac{\mu(x)^2}{\nu(x)},
 \tag{13.14}
\]
with value infinity if a required denominator vanishes. This is not its logarithm.

**Lemma 13.8 — Event preservation and data processing for Rényi.** If \(\mathcal R_2(\mu\Vert\nu)\le D<\infty\), then for every event \(E\),
\[
 \nu(E)\ge\frac{\mu(E)^2}{D}.
 \tag{13.15}
\]
A common randomized channel does not increase \(\mathcal R_2\).

*Proof.* On \(E\), write \(\mu(x)=\mu(x)\nu(x)^{-1/2}\nu(x)^{1/2}\) and apply Cauchy–Schwarz. The resulting factors are bounded by \(D\) and \(\nu(E)\). For a channel, Cauchy–Schwarz at each output gives
\[
 \frac{(\sum_x\mu(x)K(y\mid x))^2}{\sum_x\nu(x)K(y\mid x)}
 \le\sum_x\frac{\mu(x)^2}{\nu(x)}K(y\mid x).
 \tag{13.16}
\]
Terms of zero mass are omitted. Summing over outputs proves the claim. Independent random coins are a special case of this argument. \(\square\)

This is the finite probability-preservation mechanism used in Chapters 8 and 10. It does not add independent noise to a protocol whose publications are deterministic. The two compared experiments, and the channel applied after them, must be identified separately.

**Proposition 13.9 — Bounded Rényi is not negligible statistical distance.** The laws \(\mu=(3/4,1/4)\), \(\nu=(1/2,1/2)\) satisfy
\[
 \mathcal R_2(\mu\Vert\nu)=5/4,
 \qquad \operatorname{TV}(\mu,\nu)=1/4.
 \tag{13.17}
\]
Moreover \(\mathcal R_2((1,0)\Vert(1/2,1/2))=2\), whereas the reverse divergence is infinite.

*Proof.* Substitute into (13.9) and (13.14). The reverse direction has a positive numerator over a zero denominator. \(\square\)

For a recovery task, ideal success can be negligible, so the squared-success lower bound is useful. For a general distinguisher whose ideal acceptance is near one half, subtracting that baseline from \(\mu(E)^2/D\) may give no positive advantage. One cannot replace an additive hybrid loss by \(D\) and keep the same proof. A factor \(D=1+o(1)\) is also not a declaration that \(D-1\) is negligible; for example, \(1/\lambda\) tends to zero but is not negligible in the cryptographic sense.

## 13.8. A hybrid ledger with explicit endpoint errors

The sequence-of-games organization is classical ([B31](#bib-b31)). The following formulation specifies exactly what must be simulated. Let \(G_0,\ldots,G_s\) be games with a common terminal success predicate and probabilities \(p_0,\ldots,p_s\). For transition \(i\), suppose a source pair \((\mathsf S_{i,0},\mathsf S_{i,1})\) is processed by a public, efficient simulator \(K_i\) and the adversary. Its two full experiments are at TV distance at most \(\alpha_i,\beta_i\) from \(G_{i-1},G_i\), respectively. The simulator must be able to evaluate the terminal indicator without unavailable secret information.

**Theorem 13.10 — Hybrid composition with approximate endpoints.** There are source distinguishers \(D_i\), implemented by the stated simulators and terminal test, such that if \(|p_s-1/2|\le\nu\), then
\[
 |p_0-\tfrac12|\le\nu+
 \sum_{i=1}^s\bigl(\operatorname{Adv}_{\mathsf S_i}(D_i)+\alpha_i+\beta_i\bigr).
 \tag{13.18}
\]
Each source advantage is evaluated at the time, memory, samples, query counts, and total query length of its actual reduction.

*Proof.* The simulated terminal probabilities differ by exactly the acceptance gap of \(D_i\). Lemma 13.6 bounds each endpoint perturbation by its stated TV allowance. Thus \(|p_{i-1}-p_i|\le\operatorname{Adv}_{\mathsf S_i}(D_i)+\alpha_i+\beta_i\). Sum these inequalities and the final deviation \(\nu\). \(\square\)

The source calls of different reductions are separate experiments in this proof. Their existence does not supply a single attacker with adaptively chosen equations under a shared hidden secret. No mutual independence of the reductions is needed for the triangle inequality. When a hybrid sequence has polynomial length, its losses and resources must be summed at that length; a constant-length proof cannot be copied unchanged to an unlimited-challenge interface.

For NOISE, both endpoint errors are zero under the exact samplers, and the two reductions use the same declared HB family but distinct challenges. For seeded BLINDAGE, the two programming-conflict allowances are attached to the two transitions. For WC, the clean-to-noisy link is instead a success-preservation inequality; it is not one of the indistinguishability transitions in (13.18).

## 13.9. Approximate samplers require conditional, not marginal, control

Implementation changes are often local in code but global in the experiment. A program that repeats one fair bit has correct one-bit marginals and an incorrect vector law. Likewise, an oracle queried adaptively must be compared after conditioning on the previously exposed transcript.

**Theorem 13.11 — Sequential conditional coupling.** Suppose two experiments use the same deterministic control flow and at most \(r\) sampling stages. Whenever their histories still agree, the next conditional sampling laws are at TV distance at most \(\epsilon_i\), uniformly over that common history. Couple their adversary coins identically. Then their complete output laws satisfy
\[
 \operatorname{TV}(\mathsf E,\widetilde{\mathsf E})
 \le\min\left(1,\sum_{i=1}^r\epsilon_i\right).
 \tag{13.19}
\]
Independent component samplers with uniform individual error guarantees are a sufficient special case.

*Proof.* At each common history use a maximal coupling of the two next-step laws. The probability that the first mismatch occurs at stage \(i\) is at most \(\epsilon_i\), since this conditional bound holds on all histories without an earlier mismatch. If no mismatch occurs, the common continuation and adversary coins produce identical transcripts and outputs. A union bound and the coupling characterization of TV give (13.19). An early stopping stage can be padded with identical dummy draws. \(\square\)

This theorem does not assume independent observations once adaptive control flow has selected them. Its premise is instead a bound on the correct conditional kernels. Without that premise, four repeats of one uniform value on \(\mathbb Z_8\) have exact marginals but TV distance \(1-8^{-3}=511/512\) from four independent draws. Scalar sampler error zero therefore does not imply vector sampler error zero.

For one NOISE key and one honest challenge, Chapter 11's independent-sampler allowance is
\[
 m\epsilon_A+2d\epsilon_X+(2n+\ell)(\epsilon_e+\epsilon_\tau)+n\epsilon_\rho,
 \tag{13.20}
\]
clipped at one. Its coefficients count actual draws. Additional honest oracle executions require their own fresh-draw budget; local adversarial computations are already part of the adversary. Substituting a numerical error bound for one Gaussian sample into a whole experiment without this multiplicity would change the claim.

Truncating a rejection sampler is another such change. If independent trials succeed with probability at least one half, a cap of \(r\) trials has abort probability at most \(2^{-r}\). A time bound is polynomial in the input bit length and the numerical cap, not necessarily in the binary encoding length of an arbitrarily large cap. An abort must be represented in the game, rather than silently conditioned away.

## 13.10. Correctness quantifiers and repeated use of one key

Let \(K=(pk,sk)\) denote an honestly generated key pair. Define
\[
 f(K)=\max_{m\in\mathcal M}
 \Pr_{\rm fresh}\bigl[\mathsf{Dec}(sk,\mathsf{Enc}(pk,m))\ne m\mid K\bigr],
 \qquad \delta=\mathbb E_K f(K).
 \tag{13.21}
\]
The maximum is taken before averaging over keys. This is stronger than averaging over a uniformly sampled message, but weaker than requiring \(f(K)\le\delta\) for every key.

**Theorem 13.12 — Average correctness, bad keys, and honest reuse.** For \(a>0\),
\[
 \Pr_K[f(K)>a]\le\min(1,\delta/a).
 \tag{13.22}
\]
For at most \(r\) honest encryptions with this same key and fresh independent encryption coins, messages may be chosen adaptively from past observations. The probability of at least one decryption failure is at most \(\min(1,r\delta)\).

*Proof.* Markov's inequality applied to the nonnegative random variable \(f(K)\) gives (13.22). Conditional on a key and any past history, the next message is fixed or randomized, but its fresh coins have the prescribed law independent of that history. Its failure probability is at most \(f(K)\), since the definition takes the maximum over all messages. A union bound gives at most \(r f(K)\) conditional on the key. Average over keys. Independence of the failure events themselves is neither claimed nor required. \(\square\)

The fresh-coin premise matters. Deterministic encryption using a random oracle has a separate query-dependent analysis; a repeated oracle input does not give fresh coins. For NOISE's raw-error tail bound, generation errors are sampled once per key. With \(r\) encryptions, the relevant count is \(n+r(n+\ell)\), not a fictional resampling of the key noise every time. This sharper count is available because the same favorable error event ensures correctness for all messages (Chapter 11).

A population in which an \(\epsilon\) fraction of keys always fails and every other key never fails has \(\delta=\epsilon\). It disproves a universal per-key reading of the average bound. Similarly, a single carefully selected failing message per key may have tiny uniform-message failure but \(f(K)=1\). These examples explain why an average empirical success rate does not replace (13.21).

For WC, Chapter 10 proves perfect correctness under its strict inequality, so \(\delta=0\) in that interface. For BLINDAGE C1, Chapter 12 proves
\[
 2^{-6400}\le\delta_{C1}<2^{-282}.
 \tag{13.23}
\]
Its positive-probability legal failure excludes perfect correctness. The upper bound is a rational certificate for the average worst-message notion, not a frequency estimated from successful tests.

## 13.11. Classical oracle-query extraction without recognizing the target

A proof using a hash mask must explain how its reduction obtains the hidden input. Equality of hash outputs is not an input-recognition procedure: collisions are allowed in a random function.

**Lemma 13.13 — Uniform query extraction.** Consider a classical experiment with a hidden target \(Z\) and a public auxiliary view generated independently of the initially random oracle \(\mathcal H\). Suppose the real and comparison games can be coupled to agree until the adversary first queries \(Z\); the comparison challenge is independent of the hidden bit and has success probability \(1/2\). Suppose the reduction can simulate that comparison game from its given input without knowing \(Z\), and there are at most \(q\ge1\) distinct admissible queries. If the real adversary has bias \(\eta\), selecting uniformly among \(q\) query slots gives target-recovery probability at least \(\eta/q\).

*Proof.* Let \(E\) be the event that the target is queried. The coupled games have identical transcripts and decisions outside \(E\), so the real success deviation is at most the comparison probability of \(E\). Record all distinct queries, including prechallenge queries, and pad the list to \(q\) positions with a failure marker outside the target space. Conditional on \(E\), exactly one recorded position equals \(Z\). Uniform selection therefore succeeds with probability \(\Pr[E]/q\ge\eta/q\). The reduction need not identify that position. \(\square\)

A standard application has a challenge field \(\mathcal H(Z)\oplus m_b\), with all other challenge components independent of the choice of message. The comparison replaces that field by a fresh uniform string. Any target query before the challenge is already a bad event for the coupling and is included in the recorded list. It is incorrect to reset the query table when messages are chosen.

P-REF uses exactly this form after proving the target hard to recover under its computational source assumption (Chapter 9). The present lemma abstracts the extraction interface, not that source assumption. If \(Z\) is generated from oracle answers in an unmodeled way, if another interface reveals \(\mathcal H(Z)\), or if the comparison game cannot be simulated from the given source, its premises have not been established.

The supplementary release does not execute an exhaustive random-function oracle experiment for this lemma. Its local verifiers check the query-accounting identities used elsewhere in the chapter; the extraction lemma itself is justified by the proof above.

## 13.12. Re-encryption checking and two different FO interfaces

Freeze a deterministic coin function \(G\), and put
\[
 \mathsf{Enc}_1(pk,m)=\mathsf{Enc}(pk,m;G(m)).
 \tag{13.24}
\]
Define \(\mathsf{Dec}_1\) to decrypt and then accept its message only if re-encryption reproduces the complete input ciphertext. All equalities below concern canonical representations.

**Proposition 13.14 — Perfect correctness makes plaintext checking public.** If the base PKE decrypts correctly for every honest key, message, and allowed tape, then
\[
 \mathsf{Dec}_1(sk,c)=m
 \quad\Longleftrightarrow\quad
 c=\mathsf{Enc}_1(pk,m).
 \tag{13.25}
\]
There is at most one accepted message for a ciphertext. Injectivity in the encryption coins is unnecessary.

*Proof.* Acceptance includes the equality on the right. Conversely, a ciphertext equal to \(\mathsf{Enc}_1(pk,m)\) decrypts to \(m\) by perfect correctness and passes the check. If two distinct messages produced the same ciphertext, deterministic decryption would have to return both, a contradiction. This argument makes no claim that two different tapes for the same message produce different ciphertexts. \(\square\)

The reverse implication can fail when a legitimate message/tape pair decrypts incorrectly. Such errors must be paid in the selected theorem, not erased by calling the wrapper “FO.” WC uses the perfect-correctness, one-way route. BLINDAGE C1 uses a route starting from CPA and retains a nonzero correctness term.

**Imported theorem interface, not a new proof of FO.** The corrected classical analysis of Hofheinz–Hövelmanns–Kiltz ([B24](#bib-b24)), for the implicit-rejection transform hashing message and ciphertext, supplies the following interfaces used in Chapters 10 and 12. With perfect correctness, the former has
\[
 \eta_{CCA}\le q_H/|\mathcal M|+(q_G+q_H+1)p_{OW}.
 \tag{13.26}
\]
The latter uses the CPA interface
\[
 \eta_{CCA}\le Q_{RO}\delta+3Q_{RO}/|\mathcal M|+3\eta_{CPA}.
 \tag{13.27}
\]
The quantities refer to the identified transformed adversaries. These are imported bounds with specific interfaces, not universal statements for every scheme called a Fujisaki–Okamoto transform. This chapter does not reproduce the complete external theorem proofs.

The fallback message is sampled once per secret key. In the implicit-rejection simulation, repeated rejected ciphertexts require consistent responses; sampling an unrelated new fallback on each rejection changes that law. Public plaintext checking is not a ciphertext-validity oracle.

For WC, \(q_G\) already counts all explicit and plaintext-checking-induced evaluations of the deterministic-coin oracle, \(q_H\) bounds the key-oracle queries/plaintext checks, and
\[
N=q_G+q_H+1.
\]
WC decapsulation queries contribute to the transformed adversary's resource budget, but the WC interface specified in Section 10.11 does not add a separate prechallenge-decapsulation loss.

For C1, which has a different imperfect-correctness interface and computes both candidate hashes, let \(q_G,q_H\) denote explicit adversarial oracle queries and \(q_D\) decapsulations. The conservative totals are
\[
Q_G=q_G+q_D+1,\qquad
Q_H=q_H+2q_D+1,\qquad
Q_{RO}=Q_G+Q_H=q_G+q_H+3q_D+2.
\]
A different implementation may justify smaller totals only after its oracle interface is specified and analyzed.

The source and output-message notions in an imported one-way experiment must also be checked when correctness is imperfect. For WC's perfect base they coincide. C1's chosen CPA route avoids silently identifying them in an imperfect one-way reduction. These details, together with raw ciphertext hashing and fixed domains, are why a generic “CPA therefore CCA” sentence is not a proof.

## 13.13. A prechallenge phase requires its own collision allowance

A challenge-first KEM experiment already gives the adversary \((pk,c^*,K^*)\) before its oracle queries. A two-stage experiment permits queries while \(c^*\) is still unknown. One can hide a presampled challenge during the first stage, but a query might accidentally equal that hidden ciphertext. The probability must be bounded rather than forbidden retroactively.

**Proposition 13.15 — Prechallenge collision bound with imperfect correctness.** Fix keys and deterministic encryption coins, and let \(f:\mathcal M\to\mathcal C\) be the resulting deterministic encryption map with decoder \(d\). Let \(b\) be the fraction of messages with \(d(f(m))\ne m\). For any set \(S\) of at most \(q\) ciphertexts and an independent uniform message \(M\),
\[
 \Pr[f(M)\in S]\le\min(1,q/|\mathcal M|+b).
 \tag{13.28}
\]
After averaging over honest keys and ideal coin oracles, \(\mathbb E b\le\delta\) under (13.21). Thus \(q/|\mathcal M|+\delta\), clipped at one, is a sufficient collision allowance for the delayed-challenge simulation.

*Proof.* Any ciphertext has at most one preimage that decodes correctly: the decoder has a single value. The set \(S\) therefore contains images of at most \(q\) good messages. All its other message preimages are among the \(b|\mathcal M|\) bad messages. Divide by \(|\mathcal M|\). For the averaged claim, fix the complete oracle functions and preliminary transcript; the fresh message remains independent and uniform. The adaptive query set is then fixed. For each message, its ideal coin tape has the specified uniform marginal law. Averaging the bad fraction first over that oracle and then over keys is bounded by \(\mathbb E f(K)\). No independence among the failures for different messages is needed. \(\square\)

The error term cannot generally be omitted. On four messages, let every deterministic encryption equal \(c_0\) and let \(d(c_0)=0\). A preliminary query on \(c_0\) collides with probability one. The term \(q/|\mathcal M|\) is only \(1/4\), and the bad-message fraction is \(3/4\), giving equality in (13.28). This is a countermodel to an interface claim, not an attack on BLINDAGE.

Proposition 13.15 applies to a distinct delayed-challenge, two-stage interface. It is **not** an additional term in the final WC theorem selected in Chapter 10, whose query factor remains \(N=q_G+q_H+1\). For C1, when the delayed-challenge interface is used, imperfect correctness contributes the additional \(\delta\) term stated above. These allowances are separate from seed-programming prequeries and must not be charged twice through alternative couplings.

## 13.14. Canonical encoding is part of a CCA experiment

A mathematical ciphertext and its transmitted bytes need an explicit relation. In CPA, a reversible representation is usually harmless. In CCA, the exact challenge-exclusion rule makes accepted aliases dangerous.

**Proposition 13.16 — Security transport by an injective codec.** Suppose valid public keys and ciphertexts have efficient injective encoders and efficient inverse decoders on their images. For a PKE wire interface that rejects every non-image ciphertext with a public constant failure symbol, and otherwise runs the unchanged algorithms, CPA and CCA advantages transport exactly between the abstract and encoded schemes, up to encoding and parsing resources.

*Proof.* Simulate a wire adversary by encoding its abstract public key and challenge. Parse a decryption query. A non-image string receives the prescribed public failure. An image string is decoded and relayed unless it is the challenge. By injectivity, equality to the decoded challenge is equivalent to equality of the original canonical byte strings. Consequently the relay obeys exactly the oracle exclusion and returns the same answers. The reverse simulation uses the inverse codec. All algorithmic coins can be shared, giving equality of complete views and success events. \(\square\)

For an implicit-rejection KEM, invalid inputs receive a keyed fallback value, not a public failure symbol. Proposition 13.16 is not a license to replace that interface. The KEM proof must preserve the invalid-string domain and its consistent hash inputs, as specified separately in Chapters 10 and 12.

**Counterexample 13.17 — Ignored aliases bypass byte-level challenge exclusion.** Let a perfectly correct PKE transmit honest ciphertexts as \((0,c)\). Suppose a decoder accepts both \((0,c)\) and \((1,c)\), ignores the first bit, and decrypts \(c\). If the CCA game excludes only the honest challenge byte string \((0,c^*)\), a single query on \((1,c^*)\) reveals its plaintext.

*Proof.* The modified bytes differ from the forbidden string, so the query is allowed. Their decoded mathematical ciphertext is still \(c^*\), and perfect correctness gives the challenge message. Choosing distinct CPA messages then determines the hidden bit. The underlying PKE may otherwise be arbitrarily strong; the new interface is what breaks the game. \(\square\)

For KEMs, a similar attack requires that both checking and key derivation identify the alias with the challenge. Hashing the actual received bytes can change the attack, so no universal assertion about every permissive parser is made. The safe proof obligation is nevertheless explicit: either accept one canonical representation or prove the alternative equivalence relation and challenge restriction in the actual security game.

## 13.15. A public seed is not an information-theoretic compressor

Seeded matrix generation has two different interpretations: a fixed deterministic expansion function, or a random oracle that the reduction may program on fresh inputs. They should not be conflated.

**Proposition 13.18 — Revealed deterministic expansion versus independent output.** For any fixed public function \(F:\{0,1\}^s\to\{0,1\}^b\), uniform seed \(S\), and independent uniform \(U_b\),
\[
 \operatorname{TV}\bigl((S,F(S)),(S,U_b)\bigr)=1-2^{-b}.
 \tag{13.29}
\]
If \(F\) is efficiently computable, this difference has an efficient equality test.

*Proof.* The event \(y=F(s)\) always holds in the first law and holds with probability \(2^{-b}\) in the second. For each fixed seed, a point mass has distance \(1-2^{-b}\) from the uniform output law; averaging gives equality. \(\square\)

This does not attack a seed-based scheme. The two distributions are simply not the correct pair of worlds for its ROM proof. A hidden-seed pseudorandom-generator theorem likewise does not assert pseudorandomness after the seed has been published. Lossless compression of an arbitrary matrix and computational expansion from a seed are different tasks.

**Proposition 13.19 — Fresh-seed programming with full response fibers.** Suppose a source supplies a packet consisting of a public vector and its associated data. The complete packet is independent of prior expansion-oracle history and of a new uniform \(s\)-bit seed. Its public vector has the exact target jointly uniform law; the associated data retain their specified correlations with that vector. Suppose all expansion inputs identify the seed injectively, and there are at most \(q_{pre}\) prior queried seed prefixes. If the simulator aborts on a previously exposed seed, then it may otherwise program the fresh expansion consistently with the source vector, paying at most
\[
 \epsilon_{prog}\le\min(1,q_{pre}2^{-s}).
 \tag{13.30}
\]
When the exposed raw oracle response has more bits than the parsed value, the simulator must sample its conditional preimage law, not only set the parsed bits.

*Proof.* The seed hits the fixed set of exposed prefixes with probability at most its size divided by \(2^s\), even when that set arose adaptively before this independent seed. Outside the event, all target oracle entries are unqueried. Assigning their prescribed uniform source values is equivalent to revealing newly sampled oracle outputs; correlated source data are kept together with them. If parsing is many-to-one, generate the unused raw information conditionally with the correct law. Future reads use the same assignments and all other fresh entries are answered normally. Coupling the experiments outside the conflict event gives (13.30). Resampling seeds until no conflict occurs would instead condition their law and is not this construction. \(\square\)

For C1, each 12-bit coefficient is parsed from a 16-bit word. A fixed low part has sixteen equally likely raw preimages. The four high bits must be sampled independently. Setting them all to zero is visibly wrong to an adversary reading the entire response, with TV distance \(15/16\) for one word. A programmable ideal oracle can supply the required conditional law; a concrete SHAKE invocation is not a function the reduction may rewrite. No standard-model or real-hash theorem follows from (13.30).

## 13.16. The construction-specific reduction ledger

The following ledger records the interfaces actually used in the earlier chapters. It does not assign the same hardness source to all objects bearing the MODDIV name. Every entry preserves the parameter restrictions, distributions, formats, and correctness conditions of its cited specification.

| Object | Source or mechanism | Conclusion retained here |
|---|---|---|
| Scalar interval model, Chapters 5–7 | Efficient interval posterior sampling | Passive prediction with the honest agreement probability; not confidentiality. |
| P-WINDOW over a prime field | Public linear-system solving | Polynomial-time computation of the common value. |
| Historical P-ROUND | Rounded non-cyclic windows and actual remainders | No confidentiality theorem imported from the other rows. |
| P-REF, Chapter 9 | Computational MP-CLWR task preservation | Conditional CPA in the classical ROM. |
| WC and its stated compact FAST interface, Chapter 10 | Exact binary-LWE embedding, Rényi, one-way reduction, selected FO route | Conditional CCA in classical programmable-oracle interfaces. |
| NOISE-CPA-LIFT, Chapter 11 v1.1 | Decisional binary Hankel source HB with \(2n\) windows | Conditional CPA in the standard model; unwrapped CCA2 attack retained. |
| BLINDAGE C1-P12-CBD1, Chapter 12 | Two exact CBD1 Module-LWE source interfaces | Conditional classical-ROM CCA with nonzero correctness error. |

### P-REF: task preservation, not a substituted decisional assumption

The source has a long secret conditioned on a surjective structured map, the specified full-range public polynomials, and the nearest-rounding convention with uniform inverse fibers. In this P-REF paragraph, \(N_0\) denotes the parameter \(N\) of Chapter 9; \(q_0,d_0,k_0,t\) retain their Chapter 9 meanings. The subscript on \(N_0\) only distinguishes this parameter from the HB sample count introduced below. Chapter 9 proves the ideal recovery bound
\[
 p_{id}\le2^{-d_0}+\tfrac12
 \sqrt{2^{-t(k_0+1)}q_0^{N_0+k_0+d_0}}.
 \tag{13.31}
\]
Its computational assumption transfers negligible recovery of this concrete target from the ideal source to the real source; classical query extraction then gives CPA. This is not an assertion that arbitrary real-source acceptance probabilities are negligibly close to ideal ones. The published construction is attributed to Bai and coauthors ([B09](#bib-b09)); the historical short-secret rounded exchange does not acquire its theorem by commutativity.

### WC: the square-root one-way loss is retained

In this WC paragraph and in Proposition 13.20, use the Chapter 10 parameters \(P=2^p\), \(Q=2^q\), \(m=hL+1\), and \(d=(h-1)L+2\); these dimensions are local to WC.

WC embeds \(tL\) independent general binary-LWE rows with one shared binary secret into widened Hankel blocks. The single common parity mask produces the anchored box law exactly. Its explicit source noise is part of the reduction, not extra noise added to the clean WC key-generation algorithm. Under the independence, symmetry, and tail premises in Chapter 10,
\[
 \overline D_R=\left(\frac{1+2B/Q}{\delta_E}\right)^{tL},
 \qquad
 \epsilon_{enc}=\tfrac12\sqrt{2^{-t}P^{m+L}},
 \tag{13.32}
\]
\[
 p_{OW}\le\sqrt{\overline D_R
 (\epsilon_{bin}+2^{-\kappa}+\epsilon_{enc})}.
 \tag{13.33}
\]
Writing \(J_{FO}=N=q_G+q_H+1\), its conservative compact-route statement is
\[
 \eta_{CCA}^{WC}\le q_H2^{-\kappa}
 +J_{FO}\left[
 \sqrt{\overline D_R(\epsilon_{bin}+2^{-\kappa}+\epsilon_{enc})}
 +\epsilon_A\right].
 \tag{13.34}
\]
Here \(\epsilon_A\) is solely the compact-key seed-programming allowance in the stated prequery experiment; it is not a decapsulation-phase loss. FAST has zero functional loss because exact arithmetic equivalence has been proved for the stated domain. The CCA theorem is single-user and classical programmable-ROM only; no QROM, multi-user, concrete-SHAKE or historical-security transfer is asserted.

### NOISE: one long ribbon, two selected segments

Write \(M=P/2\), \(n=d+\ell-1\), and \(N=2n\). The HB experiment supplies one uniform coefficient sequence of length \(N+d-1\), one shared uniform binary secret of length \(d\), and \(N\) independently sampled errors from \(\chi\). Actual NOISE publications use the positive-box law, upper-half coefficients, and explicit noise \(2e+\tau\). Chapter 11 gives
\[
 \eta_{CPA}^{NOISE}\le\epsilon_{HB}(\mathcal B_0)+\epsilon_{HB}(\mathcal B_1).
 \tag{13.35}
\]
The second retained response segment begins at \(m=n+d-1\), not at \(n\); \(d-1\) boundary observations are discarded. The source still supplies all \(2n\) observations. Its hardness is an explicit premise, not a consequence of the existence of these exact simulators. The public valid-format bit-flip attack on the unwrapped ciphertext remains a negative CCA2 result, consistent with conditional CPA (Chapter 11).

### BLINDAGE C1: two module sources and an averaged failure bound

C1 uses \(R=\mathbb Z_{4096}[x]/(x^{256}+1)\), rank three, and independent CBD1 coefficients in its secrets and explicit errors. Its sources have respectively three and four independent module-matrix rows, with one shared secret in each experiment. Denote their acceptance gaps by \(\epsilon_{3,3},\epsilon_{3,4}\). In the ideal seeded model,
\[
 \eta_{CPA}^{C1}\le\epsilon_{3,3}+\epsilon_{3,4}+2\epsilon_A.
 \tag{13.36}
\]
Its challenge-first KEM bound is
\[
 \eta_{CCA}^{C1}\le
 3\epsilon_{3,3}+3\epsilon_{3,4}+6\epsilon_A
 +Q_{RO}2^{-282}+3Q_{RO}2^{-256}.
 \tag{13.37}
\]
The prechallenge extension adds its separately proved allowance. Its 993-byte public key uses a seeded-oracle model; it is not a 993-byte arbitrary full matrix. The corresponding ciphertext payload is 1408 bytes. These payloads and the strong failure bound do not prove either source hard. None of these statements is transferred to CBD2, WC, HB, or a short-seed standard-model realization (Chapter 12).

## 13.17. Reduction losses constrain a certificate, not all possible security

For a concrete claim, first choose a work unit and an adversary budget. The source quantity must be a bound on all relevant adversaries at the transformed budget, not merely the running time of one known attack. A hypothetical relation \(\epsilon_{src}(T')\le T'2^{-s}\), together with a proved overhead bound for \(T'\), would be usable. An estimator output for one heuristic algorithm is not that universally quantified premise.

**Proposition 13.20 — Necessary budgets for the displayed WC formula.** Let the nonnegative right-hand side of (13.34) be required to be at most \(2^{-\tau}\), with \(\tau\ge1\), \(D=\overline D_R\ge1\), and \(J=J_{FO}\ge1\). Even if all outer allowances are dropped, necessary conditions are
\[
 2^{-\kappa},\ \epsilon_{bin},\ \epsilon_{enc}
 \le\frac{2^{-2\tau}}{J^2D},
 \tag{13.38}
\]
\[
 \begin{aligned}
 \kappa&\ge\left\lceil2\tau+2\log_2J+\log_2D\right\rceil,\\
 t&\ge\left\lceil p(m+L)+4\tau-2+4\log_2J+2\log_2D\right\rceil.
 \end{aligned}
 \tag{13.39}
\]
They are necessary for certification by this bound, not sufficient, and not attack lower bounds.

*Proof.* The retained square-root term cannot exceed the full nonnegative right-hand side. Squaring gives \(J^2D(\epsilon_{bin}+2^{-\kappa}+\epsilon_{enc})\le2^{-2\tau}\). Each summand is nonnegative, giving (13.38). The first logarithmic inequality follows from its message-guessing term. Substituting \(\epsilon_{enc}=2^{-1}2^{(p(m+L)-t)/2}\), taking base-two logarithms, and rearranging gives the second. Integer variables require the displayed ceilings. \(\square\)

The retained term \(2^{-\kappa}\) *inside* the square root is essential. Dropping the outer fallback-guessing term does not drop it. This preserves the distinction between the two guessing terms in Chapter 10.

For \(\tau=128\) and the favorable choice \(D=1\), the arithmetic reads:

| Assumed \(\log_2J\) | Necessary \(\kappa\) | Necessary \(t-p(m+L)\) |
|---:|---:|---:|
| 0 | 256 | 510 |
| 4 | 264 | 526 |
| 8 | 272 | 542 |
| 16 | 288 | 574 |

These rows are not proposed parameter sets. Setting both the message term and extraction term equal to their separate upper limits would make their sum twice the allowed total; this already proves that the individual necessary tests do not suffice. Sufficient certification must evaluate the complete bound with every resource and error term retained.

Asymptotically, a polynomial factor multiplying the square root of a negligible function remains negligible. To see this, dominate the prefactor by \(\lambda^a\); for any requested exponent \(c\), negligibility of the inner function gives an eventual upper bound \(\lambda^{-2(a+c)}\). This is an eventual-family argument. It does not allow insertion of \(\lambda=128\) and an automatic announcement of 128-bit work security.

The C1 arithmetic of Chapter 12 similarly remains conditional. Under its explicitly hypothetical source envelope and overhead \(\kappa_*\), it obtains
\[
 \frac{2\eta_{CCA}}T\le
 12\kappa_*2^{-s_*}+10\cdot2^{-282}+42\cdot2^{-256}.
 \tag{13.40}
\]
The respective smallest integer \(s_*\) values at \(\log_2\kappa_*=0,10,16,20,24\) are \(132,142,148,152,156\). The verifier checks both sides of each strict threshold. It neither proves the source envelope nor equates bit operations, lattice-estimator costs, oracle traffic, and elapsed Python time.

## 13.18. Verification artifact and limits of finite evidence

The delivered Chapter 13 package contains two small deterministic verification programs. `verify.py` checks 5,103 exact Rényi event inequalities on positive three-point laws, 121 acceptance-gap/success-bias identities, the WC/C1 query-budget formulas over 125 small budget profiles, and an explicit enumeration of the fixed-length-premise counterexample from Section 13.4. `verify_independent.py` separately checks 8,000 query-accounting profiles and reconstructs the same message-space counterexample without importing the primary verifier. In both paths, equal-length legal challenges have maximum CPA bias zero while identity recovery is perfect; two negative controls each attain bias \(1/2\).

These programs do **not** reproduce the broader posterior, deferred-lifting, oracle-collision or message-channel campaigns discussed as mathematical examples elsewhere in the chapter. Those arguments stand or fall on the proofs and explicit counterexamples in the text; this release makes no claim that they were exhaustively re-enumerated by Chapter 13's supplementary code. The package also does not prove source hardness or execute a cryptographic implementation.

Run locally with

```sh
python3 verify.py
python3 verify_independent.py
```

and run the repository-wide manifest and chapter checks from the repository root with

```sh
python3 verify_repository.py --jobs 4
```

A successful finite check establishes only the enumerated identity or inequality. It is not a failure-rate estimate, a concrete security certificate, or a substitute for the hypotheses of the security reductions.

## 13.19. Synthesis: what a stronger claim would have to add

The positive conclusion of this chapter is a coherent account of already specified security interfaces. Agreement requires an honest-output statement. A recovery theorem requires a named target. A hybrid requires complete joint distributions and an implementable terminal test. A Rényi argument requires its support direction and success baseline. A CCA theorem requires the chosen transform, its correctness notion, its queries, encodings, and oracle model. A concrete estimate requires the augmented resource budget and an explicit source-advantage premise.

The preceding constructions satisfy different subsets of these obligations. P-REF retains its attributed computational assumption and classical ROM. WC retains its anchored distribution, exact embedding, square-root one-way bound, and selected CCA interface. NOISE retains its exact HB-dependent CPA reduction and its negative unwrapped CCA2 result. BLINDAGE C1 retains its two CBD1 module-source assumptions, nonzero average correctness term, and classical-ROM composition. One row cannot fill a missing premise in another row without a new reduction.

This separation is constructive: it localizes the missing work instead of claiming either universal security or universal failure. The source-hardness questions reserved for thesis V2, the later CBD2 profile, full concrete cryptanalysis, implementation leakage, and external validation remain distinct tasks. This chapter starts none of them automatically.

**Scope.** The FO theorems remain imported modules with identified hypotheses. Finite checks do not establish computational hardness, external peer review, formal certification, worldwide novelty or institutional thesis validation.


## Supplementary Material and Reproducibility — Chapter 13

The public supplementary material for this chapter is assigned to `supplementary/chapter-13/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 14 — Cryptanalysis and Attack Models {#ch14}
## Exact Feasibility, Lattice Geometry, and Structural Limits




### Abstract

This chapter studies the attack side of the security contracts established in Chapter 13. It places modular quotient inversion in an exact bounded-integer model, distinguishes feasible secrets from their posterior probabilities, and constructs an integer graph lattice that retains both the secret box and the actual quotient cells. A public Gram–Schmidt certificate gives a sufficient condition for unique decoding by nearest plane; without that certificate, a reduced basis and a plausible vector remain search outputs requiring exact verification. Prefix reconstruction is separated from central-window inversion. Dual relations are analyzed first for independent explicit errors and then for actual rounding remainders, whose correlations cannot be discarded. A finite Fourier identity describes how a quotient observation combines input frequencies without supplying a hardness reduction. Nonuniform guessing, shared preprocessing, dependent ring rotations, valid-format chosen-ciphertext changes and the interpretation of failed experiments complete the comparison. Calibration experiments are attributed and not counted as new runs. A deliberately small calibration contains 38 deterministic graph-lattice fixtures with exact finite reference fibers and three deterministic dimension-16 compatibility fixtures; the release verifier rechecks the fibers, secret-box membership and publication compatibility of the stored candidates. No secret-recovery timing claim is made from these fixtures. No full cryptanalytic campaign, security-scale attack, new reduction from standard LWE, concrete bit-security certificate, or extension of a previous construction is claimed.

### Scope and contribution boundary


Chapters 5, 9, 10, 11 v1.1, 12 C1 and 13 v1.1 supply the previously specified targets (Chapter 5; Chapter 9; Chapter 10; Chapter 11; Chapter 12; Chapter 13). The scalar agreement result, the field-window attack, the four conditional security routes and their source distributions remain separate. This chapter consolidates elementary attack interfaces and performs bounded calibration; it does not initiate the deferred thesis-V2 source-hardness investigation, a CBD2 study, or a comprehensive new large-parameter campaign. The classic lattice, probability and Fourier tools are not claimed as inventions.

## 14.1. What an attack must actually produce

A cryptanalytic result must specify an input distribution, an observable transcript, a target, permitted queries, a success event and a resource budget. A solver that finds any compatible secret has solved a different task from one that recovers the planted secret. Even recovery of a party's local output is not automatically recovery of an agreed session key when honest agreement is unreliable. Chapter 13 supplies these distinctions; here they govern every algorithm and experiment.

The basic public observation used for the first part is
\[
 U_i=F_{P,Q}((Bx)_i+E_i),\qquad
 F_{P,Q}(z)=\left\lfloor\frac{[z]_P}{Q}\right\rfloor,
 \quad B\in\mathbb Z^{L\times d}.
 \tag{14.1}
\]
Here \(L,d\) are positive integers, \(P\ge2\), \(Q\ge1\), and \([z]_P\) is the canonical representative. The integer coordinates satisfy declared inclusive bounds \(\ell_j\le x_j\le u_j\). The noiseless model has \(E=0\). A noisy model must additionally specify the full law of \(E\), including its dependence on all public and secret variables. Different choices of \(B\), bounds, or noise define different experiments.

An independent-entry matrix, a non-cyclic Hankel ribbon, a polynomial window, and a matrix of negacyclic module operators can each be represented linearly. That shared representation is useful for validation but does not equate their generation laws or their hardness. In particular, our small matrix controls are not automatically instances of a standard LWE security assumption.

## 14.2. Exact quotient cells and integer wrap variables

Put \(J=\lceil P/Q\rceil\). A valid output label satisfies \(0\le U_i<J\), and define
\[
 a_i=QU_i,\qquad b_i=\min\{QU_i+Q-1,P-1\},\qquad c_i=b_i-a_i.
 \tag{14.2}
\]
The interval has \(c_i+1\) integers. The final cell need not have width \(Q\). If \(Q>P\), there is just one label and its cell is the entire residue space. Invalid labels are rejected rather than passed to an optimizer.

**Proposition 14.1 — Exact bounded-integer feasibility.** In the noiseless model, a vector \(x\) in the secret box produces \(U\) if and only if there are integers \(k_i,r_i\) satisfying
\[
 Bx-Pk=QU+r,\qquad 0\le r_i\le c_i.
 \tag{14.3}
\]
For every such \(x\), the vectors \(k,r\) are unique.

*Proof.* Apply Euclidean division to each integer \((Bx)_i\): \((Bx)_i=Pk_i+z_i\), with \(0\le z_i<P\). Its published quotient is \(U_i\) precisely when \(a_i\le z_i\le b_i\); then \(r_i=z_i-a_i\). Conversely (14.3) places \(QU_i+r_i\) inside that canonical cell and therefore yields the required publication. Uniqueness follows from uniqueness of the canonical residue and the Euclidean quotient. The argument permits signed matrix entries and signed secret bounds. \(\square\)

**Proposition 14.2 — Safe bounds for signed wrap variables.** Set
\[
 v_i^- =\sum_j\min(B_{ij}\ell_j,B_{ij}u_j),\qquad
 v_i^+ =\sum_j\max(B_{ij}\ell_j,B_{ij}u_j).
 \tag{14.4}
\]
Every feasible wrap variable obeys
\[
 \left\lceil\frac{v_i^- -b_i}{P}\right\rceil
 \le k_i\le
 \left\lfloor\frac{v_i^+-a_i}{P}\right\rfloor.
 \tag{14.5}
\]

*Proof.* The secret box gives \(v_i^-\le(Bx)_i\le v_i^+\). Subtract \(Pk_i\in[(Bx)_i-b_i,(Bx)_i-a_i]\), divide by positive \(P\), and take the appropriate integer endpoints. These are necessary bounds, not a claim that every integer inside them is attainable. \(\square\)

A feasibility MILP can use these constraints with a zero objective. A Boolean or SAT encoding can instead represent all involved integers and carries at sufficient bit widths. Both are exact *formulations* only when signs, ranges and overflow conventions match (14.3). Neither formulation is a polynomial-time algorithm merely because its description is short. SciPy's `milp` interface converts coefficient data to double precision ([B33](#bib-b33)); a returned vector must therefore be rechecked with exact integers. A timeout, an approximate violation, or a numerical infeasibility report is not an exact certificate that an honestly planted solution does not exist.

## 14.3. Feasibility is not a posterior probability

Suppose the prior of the secret is \(\pi(x\mid B)\), and the error coordinates are independent of the secret and public matrix, with integer law \(\chi\). Write
\[
 \overline\chi_P(t)=\sum_{k\in\mathbb Z}\Pr[E=t+kP].
 \tag{14.6}
\]
This is the induced law on residues. The sum is well-defined even for unbounded errors. Efficient evaluation is a separate algorithmic issue.

**Proposition 14.3 — Exact likelihood of a rounded noisy publication.** Conditional on \(B,x\),
\[
 \Pr[U\mid B,x]
 =\prod_{i=0}^{L-1}\left(\sum_{r=0}^{c_i}
 \overline\chi_P(QU_i+r-(Bx)_i)\right).
 \tag{14.7}
\]
On every positive-probability observation, the posterior is this likelihood times \(\pi(x\mid B)\), divided by its sum over the allowed secrets.

*Proof.* Coordinate \(i\) has label \(U_i\) precisely when its noisy residue equals one of the distinct values \(QU_i+r\). The corresponding error residues are distinct, so their probabilities add. Independent error coordinates conditional on \(B,x\) make the events multiply. Bayes' formula gives the final statement. If errors are correlated, their joint probability replaces the product; equal one-coordinate marginals do not justify (14.7). \(\square\)

For \(P=8,Q=2,B=(1)\), a uniform secret in \(\{1,2\}\), and CBD1 error, observation \(U=1\) has likelihoods \(1/4\) and \(3/4\). Both secrets are compatible with the error support, but their conditional probabilities are not equal. Uniformly choosing a feasible noisy secret is therefore not generally posterior sampling. Likewise, a minimum-norm candidate is not automatically maximum likelihood.

## 14.4. Established easy cases are references, not universal attacks

Chapter 5 gives polynomial-time counting and ranked selection for one noiseless scalar publication on a known integer interval. Its elementary counting identity can be seen directly: for any integer \(z\) and \(0\le a\le b<P\),
\[
 \mathbf1_{a\le[z]_P\le b}
 =\left\lfloor\frac{z-a}{P}\right\rfloor
  -\left\lfloor\frac{z-b-1}{P}\right\rfloor.
 \tag{14.8}
\]
The two floors differ by one exactly on the cell. Summing (14.8) over \(z=ax+c\) on an interval reduces counting to Euclidean floor sums. The polynomial-time recurrence and posterior key-prediction consequence are already proved in Chapter 5 (Chapter 5); this chapter rechecks the indicator, not the complete original campaign. The scalar CVP/Gauss attack in Zhang ([B13](#bib-b13)) is earlier published context, not a proof that every polynomial construction is broken.

For exact, unrounded polynomial windows over a prime field, Chapter 9 proves that any solution of the public linear system is sufficient to compute the common product. Gaussian elimination works even if the original secret is nonunique (Chapter 9). This does not authorize replacing the missing remainders in a rounded publication by zero. Over a composite modulus, a nonzero pivot need not be invertible; ordinary field elimination must not be applied with that premise omitted.

These references serve two purposes. They calibrate an attack implementation against known solvable objects, and they identify precisely what added uncertainty a more general model introduces. Failure to attack a more general model with the scalar routine does not prove it hard; success on the scalar model does not establish an attack on the general one.

## 14.5. A graph lattice retains the secret box

For the noiseless model choose positive integer weights \(s_x,s_y\). All bases below use **row vectors**. Define
\[
 \mathcal B_0=
 \begin{pmatrix}
 2s_xI_d&2s_yB^T\\
 0&2s_yP I_L
 \end{pmatrix}.
 \tag{14.9}
\]
The upper-right block has size \(d\times L\). This orientation matters: using \(B\) instead of \(B^T\) would change dimensions or encode a different lattice.

**Proposition 14.4 — Exact graph lattice and covolume.** The rows of (14.9) generate exactly
\[
 \Lambda=\{(2s_xx,\ 2s_y(Bx-Pk)):x\in\mathbb Z^d,\ k\in\mathbb Z^L\},
 \qquad
 \det\Lambda=(2s_x)^d(2s_yP)^L.
 \tag{14.10}
\]
Replacing matrix entries by congruent residues modulo \(P\) does not change this lattice.

*Proof.* Integer combinations of the first \(d\) rows choose \(x\); combinations of the last \(L\) rows add arbitrary multiples of \(2s_yP\) in the output block. Their sign absorbs \(-k\). The basis is block triangular with the stated positive determinant. Replacing \(B\) by \(B+PC\) only replaces \(k\) by \(k-Cx\), an integer vector, and hence preserves the set. \(\square\)

Define an integer target and squared radius by
\[
 t_0=\bigl((s_x(\ell_j+u_j))_j,\ (s_y(a_i+b_i))_i\bigr),
 \tag{14.11}
\]
\[
 R_{\mathrm{box}}^2=
 s_x^2\sum_j(u_j-\ell_j)^2+s_y^2\sum_i(b_i-a_i)^2.
 \tag{14.12}
\]
The common factor two avoids introducing half-integer centers.

**Proposition 14.5 — The enclosing ball is necessary, not sufficient.** Every feasible secret yields a lattice point at squared distance at most \(R_{\mathrm{box}}^2\) from \(t_0\). A lattice point in that ball need not satisfy the box and cell constraints.

*Proof.* In a feasible point, its first-block displacement is \(s_x(2x_j-\ell_j-u_j)\), whose absolute value is at most \(s_x(u_j-\ell_j)\). The same calculation for a residue in \([a_i,b_i]\) bounds the output-block displacement by \(s_y(b_i-a_i)\). Square and sum. For the converse failure take \(B=(1),P=10,Q=5,U=0\), secret interval \([0,1]\), and both weights one. The target is \((1,4)\) and the squared radius is 17. The lattice point \((4,4)\), representing \(x=2\), has squared distance 9 but violates the secret interval. \(\square\)

Weights change the Euclidean shape used by the decoder; they do not change public feasibility. Choosing weights from the widths is a heuristic design choice until a decoding guarantee is proved. Our calibration fixes \(s_x=Q/g\), \(s_y=4/g\), \(g=\gcd(Q,4)\), for the four-element secret alphabet. It does not optimize a hidden secret-dependent objective.

## 14.6. A public certificate for unique nearest-plane decoding

Let \(b_1,\ldots,b_D\) be any full-rank row basis of \(\Lambda\), with \(D=d+L\), and let \(b_i^*\) be its Gram–Schmidt vectors. The basis need not be LLL-reduced for the next theorem. The reduction algorithm is a means of obtaining a useful basis, not a premise of the certificate.

**Theorem 14.6 — Sufficient public decoding certificate.** If the bounded publication is feasible and
\[
 4R_{\mathrm{box}}^2<\min_{1\le i\le D}\|b_i^*\|^2,
 \tag{14.13}
\]
then it has exactly one feasible secret, and Babai's nearest-plane algorithm on this basis and target \(t_0\) returns its graph-lattice point.

*Proof.* Let \(v\) be a feasible lattice point and write \(t_0=v+e\), with \(\|e\|\le R_{\mathrm{box}}\). Express \(v\) in the basis with integer coefficients. In the last Gram–Schmidt direction, all earlier basis vectors have zero projection. The fractional displacement of the last integer coefficient is
\[
 \frac{\langle e,b_D^*\rangle}{\|b_D^*\|^2},
 \quad\text{of absolute value at most }\frac{R_{\mathrm{box}}}{\|b_D^*\|}<\tfrac12.
 \tag{14.14}
\]
Nearest-integer rounding therefore chooses the correct coefficient. Subtract it and repeat backwards; the same error vector remains, so every step is correct. For uniqueness, take a nonzero lattice vector and its last nonzero integer coefficient in the basis. Its projection onto that Gram–Schmidt direction has magnitude at least \(\|b_i^*\|\). Thus every nonzero lattice vector has norm at least \(\min_i\|b_i^*\|>2R_{\mathrm{box}}\). Two feasible points in the enclosing ball would have distance at most \(2R_{\mathrm{box}}\), a contradiction. Finally the first block uniquely identifies the secret. \(\square\)

This is a sufficient, exact certificate proved above with general coordinate bounds; its derivation is given above. Its failure says neither that two secrets exist nor that decoding is hard. The strict inequality is intentional. Exact rational Gram–Schmidt norms avoid a borderline decision based on floating-point error.

For every returned reduced basis, one must also prove it spans the original lattice. A verified integer transformation \(T\) with \(\mathcal B=T\mathcal B_0\) and \(|\det T|=1\) suffices. Another exact route checks membership of every row and equality of covolumes. Merely observing that some rows satisfy modular equations would prove only containment, not equality of lattices. The present supplementary release does not certify a transformation matrix or determinant for the historical reduced bases; it instead rechecks exact finite fibers and the box/publication compatibility of the stored candidates, as stated in Section 14.19.

## 14.7. What explicit bounded noise changes

If each coordinate error is known only to lie in \([-b_i',b_i']\cap\mathbb Z\), it can be absorbed into enlarged cells for the purpose of **support feasibility**, not for the purpose of a probability model.

**Proposition 14.7 — Exact interval thickening with full interval support.** For fixed integer \(z\), a cell \([a_i,b_i]\), and \(b_i'\ge0\), there exist \(e\in[-b_i',b_i']\cap\mathbb Z\) and \(k\in\mathbb Z\) with \(z+e-Pk\in[a_i,b_i]\) if and only if
\[
 z-Pk\in[a_i-b_i',b_i+b_i']\quad\text{for some integer }k.
 \tag{14.15}
\]
For an error law supported on only a subset of the interval, (14.15) remains necessary but need not be sufficient.

*Proof.* Subtracting \(e\) gives the inclusion. Conversely any integer in the expanded interval is within integer distance at most \(b_i'\) of an integer in the original cell; choose the correcting \(e\). That choice may be absent from a smaller support, which explains the qualification. \(\square\)

The existence test can be evaluated without iterating over all errors:
\[
 \left\lceil\frac{z-(b_i+b_i')}{P}\right\rceil
 \le\left\lfloor\frac{z-(a_i-b_i')}{P}\right\rfloor.
 \tag{14.16}
\]
For independent full interval supports this test can be applied coordinatewise. Correlated error supports require their joint restrictions as well. Large tail errors cannot be silently excluded: either retain their exact law, or quantify the probability discarded by truncation. For WC, NOISE and C1 the actual errors, auxiliary source errors and discarded remainders play different roles. A single generic variance does not capture these distinctions.

## 14.8. Prefix exposure is not a central-window theorem

Consider a deliberately different publication: a rounded noisy **prefix** of ordinary convolution,
\[
 U_k=F_{P,Q}\left(\sum_{j=0}^{k}a_{k-j}x_j+e_k\right),
 \quad 0\le k<d,\quad x_j\in S,\quad |e_k|\le b.
 \tag{14.17}
\]
Here \(S\) is a nonempty finite explicitly enumerable alphabet and \(b\) is a nonnegative integer. Assume \(Q\le P\). Define circular distance by \(\operatorname{dist}_P(z,0)=\min_{k\in\mathbb Z}|z-kP|\).

**Theorem 14.8 — A sufficient triangular reconstruction condition.** If
\[
 \min_{s\ne s'\in S}\operatorname{dist}_P(a_0(s-s'),0)>Q-1+2b,
 \tag{14.18}
\]
with the minimum condition vacuous for a singleton alphabet, every honest prefix in (14.17) has a unique secret and can be recovered successively using \(O(d|S|+d^2)\) integer arithmetic operations and cell-membership tests. Polynomial time in the input bit length additionally requires the alphabet enumeration and these operations to have polynomial total cost.

*Proof.* Suppose \(x_0,\ldots,x_{k-1}\) have been recovered. Their contribution to coefficient \(k\) is known. Test each \(s\in S\) by (14.16). The true value passes. If two different values passed, there would be canonical residues in the same cell, differing by at most \(Q-1\), and two allowed errors differing by at most \(2b\). Their congruence would force \(\operatorname{dist}_P(a_0(s-s'),0)\le Q-1+2b\), contradicting (14.18). Induct from \(k=0\). Direct computation of all known contributions costs \(O(d^2)\); there are \(d|S|\) tests. \(\square\)

This proves a conditional prefix attack, not a theorem about all Toeplitz windows. In a central Hankel observation \(\sum_{j=0}^{d-1}a_{i+j}x_j\), the first retained equation already includes every secret coordinate. The induction's initial isolated variable is absent. For example \(B=((1,1),(1,2)),P=17,Q=2\) gives the same first quotient for secrets \((1,2)\) and \((2,1)\), although their second quotients differ. A globally solvable central system may exist; it requires an argument other than the prefix induction. Likewise an alphabet of \(2^{q-1}\) elements is not polynomially enumerable merely because each coefficient has \(q\) bits.

## 14.9. Extra observations and subset attacks

Let \(T_L\) be a prefix of an honest transcript \(T_{L'}\), with \(L'\ge L\), generated from the same secret and public data. This coupling is essential; comparing separately generated instances would not establish the following fact.

**Proposition 14.9 — Nested fibers and retained information.** The feasible-secret set for all \(L'\) observations is contained in the set for the first \(L\). For recovery of the actual secret, any algorithm using the smaller transcript can be run on the larger transcript by discarding its extra fields, with the same success probability and the cost of projection. Thus the optimal success probability at a matched, projection-adjusted budget cannot decrease merely because extra observations are revealed.

*Proof.* Every constraint in the smaller system is also a constraint of the larger system. This proves fiber inclusion. The algorithmic statement follows by composing the smaller-input algorithm with the deterministic prefix map. The resulting joint law of its input and the secret is unchanged. \(\square\)

The conclusion is not that every particular solver becomes faster as rows are added. A larger graph lattice can make a chosen reduction slower; an attacker may instead solve a subset and validate a candidate against all observations. Nor does a compatible solution to the subset automatically solve the full system. Actual-secret recovery, compatible search and subsequent full validation must still be recorded separately. The paired-window calibration discussed in Section 14.17 illustrates this distinction.

## 14.10. Dual relations for an unrounded noisy source

For an unrounded observation \(y=Bx+E\pmod P\), define the integer left-kernel lattice
\[
 \Lambda_P^\perp(B)=\{w\in\mathbb Z^L:w^TB\equiv0\pmod P\}.
 \tag{14.19}
\]
A useful dual attack must find a suitable relation, evaluate a statistic and specify its null distribution. An algebraic cancellation alone supplies none of the search cost, sample amplification, or attack success analysis.

**Proposition 14.10 — Exact dual law and its composite-modulus null.** Fix \(B\) and choose \(w\) from \(B\) and independent auxiliary coins, not from the response. If \(w\in\Lambda_P^\perp(B)\), then
\[
 w^Ty\equiv w^TE\pmod P.
 \tag{14.20}
\]
If errors are independent of \(B,x,w\) with independent coordinate law \(\chi\), then, for integer frequency \(h\),
\[
 \mathbb E\!\left[\exp(2\pi i h w^Ty/P)\mid B,w\right]
 =\prod_{j=0}^{L-1}\varphi_\chi(hw_j),\qquad
 \varphi_\chi(a)=\mathbb E\exp(2\pi i aE/P).
 \tag{14.21}
\]
In the null world with \(y\) uniform independently of \(B,w\), \(w^Ty\) is uniform on the subgroup \(g\mathbb Z_P\), where \(g=\gcd(P,w_0,\ldots,w_{L-1})\). Its frequency-\(h\) expectation is zero unless \(hw_j\equiv0\pmod P\) for every \(j\), in which case it is one.

*Proof.* Multiply the observation by \(w^T\) to eliminate the secret term. Independence factors the character expectation. For the null world, the map \(\mathbb Z_P^L\to\mathbb Z_P\), \(y\mapsto w^Ty\), is a group homomorphism with image exactly the subgroup generated by the coefficients and hence \(g\mathbb Z_P\). Equal fiber sizes make the image uniform. Averaging a character over this subgroup is zero unless the character is trivial there; equivalently all its coefficients \(hw_j\) vanish modulo \(P\). \(\square\)

For example \(P=8,w=(2,0)\) gives a uniform null on the four even residues, not on all eight. Choosing a threshold against the wrong null distribution can manufacture an apparent distinguishing advantage. When \(w\) is selected using the responses, the conditioning must be reconsidered; the fixed-response-independent calculation cannot simply be reused after selecting the most favorable statistic.

## 14.11. Rounded observations retain a different dual uncertainty

In the noiseless case, write the actual remainders as in (14.3). They are functions of the secret and the public matrix, not fresh samples. In the explicitly noisy case write \(Bx+E=Pk+QU+r\), with the canonical quotient-cell remainder.

**Proposition 14.11 — The dual relation with actual remainders.** For any \(w\in\Lambda_P^\perp(B)\),
\[
 Qw^TU\equiv-w^Tr\pmod P\quad(E=0),
 \qquad
 Qw^TU\equiv w^T(E-r)\pmod P\quad\text{in general}.
 \tag{14.22}
\]
Neither identity implies that the entries of \(r\), or of \(E-r\), are independent.

*Proof.* Multiply the exact decomposition by \(w^T\) and remove multiples of \(P\). For a concrete independence counterexample, take \(P=8,Q=2,B=(1,1)^T\) and \(x\) uniform modulo eight. The actual remainders are \((x\bmod2,x\bmod2)\). For \(w=(1,-1)\), their difference is always zero. Replacing them by two independent uniform bits changes its residue law to masses \(1/2,1/4,1/4\) at \(0,1,7\). Its total variation distance from the true point mass is exactly \(1/2\). Both one-coordinate remainder marginals were correct. \(\square\)

Division by \(Q\) in (14.22) is not an invertible operation modulo \(P\) when \(Q\mid P\) and \(Q>1\). A method that divides the congruence must state the resulting smaller modulus and all divisibility conditions. Treating the right-hand side as an independent Gaussian because it is bounded changes both its shape and its dependencies. The equation remains an exact starting point for a dual or constraint method, but its success must be established for that law.

## 14.12. Exact short-error spectra and the quotient filter

Let \(\mathrm{CBD}_\eta\) be the sum of \(\eta\) independent differences of independent fair bits, for a positive integer \(\eta\).

**Proposition 14.12 — Characters of the stated error laws.** For any integer frequency \(h\),
\[
 \varphi_{\mathrm{CBD}_\eta}(h)=\cos^{2\eta}(\pi h/P).
 \tag{14.23}
\]
For independent \(e\sim\chi\) and \(\tau\sim\mathrm{CBD}_1\), the law \(E'=2e+\tau\) used by NOISE satisfies
\[
 \varphi_{E'}(h)=\varphi_\chi(2h)\cos^2(\pi h/P).
 \tag{14.24}
\]

*Proof.* A fair bit has character \((1+\exp(2\pi i h/P))/2\). Multiplying this by its complex conjugate gives the squared cosine for a difference of bits. Independent summation takes powers. Scaling the first summand by two changes its frequency to \(2h\), and independence of the added CBD1 term gives the product. \(\square\)

These are exact scalar identities, not Gaussian approximations and not costs for locating a useful dual vector. A very small character at one frequency does not prove all efficient tests fail; a large character does not pay for generating suitable relations or obtaining sufficiently many observations in the actual game.

Now suppose \(Q\mid P\) and write \(H=P/Q\). For \(k\in\{0,\ldots,H-1\}\) define the quotient character
\[
 f_k(z)=\exp\left(2\pi i k\lfloor[z]_P/Q\rfloor/H\right).
 \tag{14.25}
\]

**Proposition 14.13 — Exact Fourier pullback of a quotient character.** For every residue \(z\),
\[
 f_k(z)=\sum_{j=0}^{Q-1}\alpha_{k+jH}
          \exp\bigl(2\pi i(k+jH)z/P\bigr),
 \qquad
 \alpha_h=\frac1Q\sum_{r=0}^{Q-1}\exp(-2\pi i h r/P).
 \tag{14.26}
\]
Thus the expectation of a quotient character combines exactly those input frequencies congruent to \(k\) modulo \(H\).

*Proof.* Expand \(f_k\) in the \(P\)-point discrete Fourier basis. Write each residue uniquely as \(Qu+r\), with \(0\le u<H\), \(0\le r<Q\). Its frequency-\(h\) coefficient is
\[
 \frac1P\sum_{u=0}^{H-1}\exp(2\pi i(k-h)u/H)
          \sum_{r=0}^{Q-1}\exp(-2\pi i h r/P).
 \tag{14.27}
\]
The first sum is zero unless \(h\equiv k\pmod H\); otherwise it is \(H\). The coefficient then equals \(\alpha_h\). Fourier inversion gives (14.26). The finite geometric-sum orthogonality follows by multiplying the sum by its nontrivial ratio and subtracting. The cases \(Q=1\) or \(H=1\) follow from the same calculation. \(\square\)

For a vector of quotients, one multiplies these finite expansions and takes expectations of the **joint** input characters. Products of expectations are permitted only under the required joint independence. An overlapping Hankel source usually requires retaining the full common-secret law. This elementary filter description consolidates the exact distributional discipline of the thesis; it is not the deferred reduction from a known lattice-hardness problem to HB.

## 14.13. Choose the correct null experiment

Even before considering structured secrets, a uniform residue need not produce a uniform label when the last quotient cell is shorter.

**Proposition 14.14 — Null labels with a truncated last cell.** Let \(Z\) be uniform modulo \(P\), let \(P=aQ+r\), \(0\le r<Q\), and compare \(F_{P,Q}(Z)\) with a uniform variable on its actual label alphabet. If \(r=0\), the laws coincide. If \(r>0\), there are \(a\) labels of mass \(Q/P\) and one of mass \(r/P\), and their distance from uniform is
\[
 \operatorname{TV}=\frac{a(Q-r)}{P(a+1)}.
 \tag{14.28}
\]
This includes \(Q>P\), where \(a=0\) and both laws are the same singleton.

*Proof.* Count preimages in each cell. For \(r>0\), the first \(a\) probabilities are at least \(1/(a+1)\), while the last is at most it. The sum of the positive differences is \(a(Q/P-1/(a+1))\), giving (14.28). The exact-divisibility case has equal cell sizes. \(\square\)

For \(P=5,Q=2\), the null label law is \((2/5,2/5,1/5)\), not uniform on three labels. Detecting that difference does not break an experiment whose null already uses rounded uniform residues. Likewise, detecting the repeated entries of a Hankel public matrix does not distinguish the real and null worlds of HB, because both worlds use that same matrix distribution. Every reported distinguisher must identify the two actual laws it separates.

## 14.14. Ring symmetries do not create independent samples

For a negacyclic ring \(R=\mathbb Z_P[z]/(z^n+1)\), multiplication by \(z^t\) permutes coefficients and changes some signs. This algebra is not the non-cyclic window operation used by NOISE.

**Proposition 14.15 — Isometric marginal transport and dependent opportunities.** If the coefficients are independent and identically distributed with a symmetric law, multiplication by \(z^t\) preserves their marginal vector law. For an unrounded module observation \(y=Bs+e\),
\[
 z^t y=B(z^t s)+z^t e.
 \tag{14.29}
\]
The public matrix is unchanged. The orbit observations are functions of one instance and need not be independent. If \(J\) success events in such an orbit each have probability \(p\), then
\[
 p\le\Pr[\text{at least one succeeds}]\le\min(1,Jp).
 \tag{14.30}
\]

*Proof.* Signed coefficient permutation preserves a product of identical symmetric laws. Commutativity of the coefficient ring gives (14.29). The union contains every individual event, and the union bound gives the upper estimate. If all events coincide, its probability is exactly \(p\), not \(1-(1-p)^J\). \(\square\)

Shared preprocessing can make these correlated opportunities useful, but the gain requires analysis of the full attack. A universal subtraction of \(\log_2J\) from an attack exponent is not implied by (14.30). The published CRYPTO 2026 work of Hou, Jiang and Ogilvie ([B35](#bib-b35)) studies structure-aware primal and dual hybrids. Its publisher explicitly identifies the merger of ePrint 2026/279 and 2026/366. This establishes the bibliographic relationship between the cited records; it does not transfer numerical estimates from those papers to C1, WC or HB. We cite the publisher's metadata and abstract, not a new complete verification of its algorithms.

Nor does uniform noise in a low quotient prove the entire response is pseudorandom. Chapter 12's low ramified-quotient result has its specified range and unrounded interface. Floor division is not a ring homomorphism: 0 and 4 have the same parity but different quotients under division by 4. Any higher-bit or carry attack needs the actual observation map rather than a low-bit surrogate.

## 14.15. Nonuniform guessing and hybrid branch costs

A large support size is not a direct work factor. With nonuniform secrets, the chance covered by a guess list depends on which elements it contains and on the information already observed.

**Proposition 14.16 — Optimal guessing before public observations.** For a known finite prior \(\pi\), the largest success probability of a list of \(g\) distinct guesses is the sum of its \(g\) largest point probabilities. For \(\zeta\) independent CBD1 coefficients, every particular vector of nonzero weight \(w\) has mass \(2^{-(\zeta+w)}\), and the complete shells through weight \(w\) contain
\[
 N_{\le w}=\sum_{j=0}^{w}\binom\zeta j2^j,
 \qquad
 \Pr[W\le w]=2^{-\zeta}\sum_{j=0}^{w}\binom\zeta j.
 \tag{14.31}
\]

*Proof.* If a selected guess has smaller probability than an unselected one, exchanging them cannot lower success. Repeated exchanges give the sorted prefix. In CBD1, a zero has mass \(1/2\), each sign has mass \(1/4\), and there are \(\binom\zeta w2^w\) vectors in a shell. Multiply their point masses and sum. \(\square\)

This is a prior calculation, already used in Chapter 12, not the optimal attack after a public key has been seen. The latter uses posterior masses such as (14.7), and computing or searching them may itself be expensive. Shannon entropy, min-entropy, support size and the cost of recovering a conditioned secret are not interchangeable quantities.

**Proposition 14.17 — Success accounting for a fixed guess-and-solve procedure.** Split the secret as \((G,X')\). Fix a list \(\mathcal G\) before observing the instance, and a branch procedure that guesses \(g\), solves for \(X'\), and validates its output. Let \(p_g\) be the conditional probability that the complete procedure outputs the true secret, given \(G=g\). Then its true-secret success is
\[
 \Pr[\text{success}]=\sum_{g\in\mathcal G}\Pr[G=g]p_g,
 \tag{14.32}
\]
provided success is impossible when \(G\notin\mathcal G\). A public preprocessing cost plus the sum of all branch budgets bounds the worst-case work; charging only the successful branch generally does not.

*Proof.* Partition the success event by the true value of \(G\). Correctness of the partition does not require branch independence. A run that can visit every listed branch can incur every branch cost, whereas an early-stopping rule only reduces this upper budget. Its success probabilities must reflect that actual stopping rule, including a possible early compatible but incorrect answer. \(\square\)

For a list selected from the public transcript, condition first on that transcript and use the corresponding conditional masses before averaging. Meet-in-the-middle methods similarly require a declared table, memory cost, matching predicate and validation. Exact output equality is a different matching problem from meeting a vector of modular intervals. This chapter executes neither a large hybrid search nor a BKW, Gröbner-basis or optimized BKZ campaign. Their absence is an explicit coverage gap, not evidence of resistance.

## 14.16. A valid-format ciphertext attack is not a lattice attack

For the unwrapped two-center schemes in Chapters 11 and 12, decryption computes a residue vector of the form
\[
 z=[D c_2-g(c_1,sk)]_P,
 \tag{14.33}
\]
with a canonical quotient alphabet of size \(P/D\), and decodes by circular proximity to 0 and \(P/2\). Assume \(D\mid P/2\). These conditions hold for the stated raw schemes, not for every construction using a quotient.

**Theorem 14.18 — One-query recovery by a half-modulus translation.** On an honest challenge whose every residue lies strictly within distance \(P/4\) of its encoded center, replacing one coordinate by
\[
 c'_{2,j}=[c_{2,j}+P/(2D)]_{P/D}
 \tag{14.34}
\]
changes exactly the corresponding decrypted bit. The modified ciphertext is different and canonical. A raw PKE decryption oracle therefore returns enough information to recover the entire challenged message in one allowed query.

*Proof.* The change adds \(P/2\) to precisely one coordinate of (14.33). This swaps the two open decoding neighborhoods, complementing that bit and leaving all others unchanged. The translation is nonzero in the quotient alphabet, so the query is not the excluded challenge. The attacker complements the known returned bit. The strict-neighborhood assumption excludes ties; when ties both decode to zero, complementing a boundary residue need not complement its decoded bit. \(\square\)

This is the retained negative CCA2 result of NOISE and of an unwrapped two-center PKE. It is consistent with CPA security, whose game has no decryption oracle. It is not an attack against the specified FO KEM: decapsulation re-encrypts and checks the exact ciphertext, and a changed canonical object need not pass. Format checks alone do not stop the raw attack; conversely a few rejected modifications do not prove the adaptive KEM theorem. The formal wrapper, its nonzero failure allowance where relevant, and its oracle model remain necessary.

## 14.17. Bounded public calibration

The reproducible calibration used by this chapter is deliberately small and public. The generator fixes the following grid: \(d=2,3,4\); \(L=d+1\) or \(2d\); \((P,Q)=(257,4),(4096,8),(65537,8)\); and either a Hankel matrix or an independent-entry control. All public residues are uniform in \([0,P)\), and secret coordinates are uniform in \(\{4,5,6,7\}\). This gives 36 fixtures. Two further fixtures deliberately use zero or repeated rows and colliding secrets. They are diagnostic cases, not samples from a purported secure profile.

For these 38 small fixtures, the release enumerates every secret in the declared box and recomputes the public quotient vector. All 38 fibers are nonempty and 36 are singletons. This is an exact finite calibration of compatibility and uniqueness; it is not a success-rate estimate for a lattice attack.

A separate deterministic compatibility profile uses
\[
P=536870923,\qquad Q=511,\qquad d=16,\qquad L=17,
\]
with secret coordinates in \([256,511]\), so its nominal secret box contains \(256^{16}=2^{128}\) points. The supplementary data include three public fixtures and one stored in-box compatible candidate for each. The release recomputes the public quotient vector from each candidate and checks the box constraint. It does **not** reproduce a secret-recovery algorithm, an LLL/Babai run, a reduced-basis certificate, or a recovery running time. Accordingly, these three fixtures are used only as compatibility regressions and not as evidence for an attack-cost claim.

| Fixture type | Cases | Nonempty compatible fiber | Unique fiber |
|---|---:|---:|---:|
| Hankel | 18 | 18 | 18 |
| Independent controls | 18 | 18 | 18 |
| Collision fixtures | 2 | 2 | 0 |
| Total | 38 | 38 | 36 |

All 4,064 candidate secrets across the 38 small boxes are enumerated. In the deliberate collisions, compatibility alone does not identify a unique secret. No claim about statistical superiority of Hankel or independent matrices follows from these uniformly small fixtures.

## 14.18. Evidence, censored runs and the direction of cost bounds

For reproducibility, each experiment must distinguish success, exact incompatibility, a completed unsuccessful heuristic, a timeout, memory exhaustion, numerical trouble and an unimplemented algorithm. A solver's time cap is not a bound on the best adversary. A parameter search that enlarges inputs until one solver stops succeeding has optimized against that solver, not established cryptographic hardness. This separation is required by the attack model used throughout the chapter.

**Proposition 14.19 — What zero successes can bound under an iid model.** Suppose a fixed algorithm and fixed resource budget have a common success probability \(p\) on independently sampled instances and independent algorithm coins. The probability of zero successes in \(r\ge1\) trials is \((1-p)^r\). Inverting the one-sided zero-success test at level \(\alpha\in(0,1)\) gives
\[
 p\le 1-\alpha^{1/r}
 \tag{14.35}
\]
as the corresponding upper confidence endpoint, not a deterministic implication from the observed data.

*Proof.* Independence multiplies the failure probabilities. The probability of observing zero successes is less than \(\alpha\) exactly when \(p>1-\alpha^{1/r}\). The stated endpoint is the boundary of the parameters not rejected by that event at the chosen level. It describes a procedure-specific frequency model, not a probability that the cryptosystem is secure. \(\square\)

Nested windows, reused keys and multiple rotations of one secret are not independent instance draws. Fixed deterministic fixtures are exact regression cases, not an iid statistical study. Even in the iid model, (14.35) says nothing about an untested algorithm or larger budget. Censored timings should not be discarded before reporting a median of successful runs as if it were the unconditional attack cost.

**Proposition 14.20 — A known attack gives an upper work bound.** Fix a target experiment, a work unit and a required success \(\theta>0\). Let
\[
 W_\theta=\inf\{T:\exists\mathcal A,\ \operatorname{Work}(\mathcal A)\le T,
                    \ \Pr[\mathcal A\text{ succeeds}]\ge\theta\}.
 \tag{14.36}
\]
The quantifier ranges over the admissible algorithms for the fixed experiment. Any algorithm whose work and success meet these conditions establishes \(W_\theta\le T\). Failure of one algorithm to meet them does not establish \(W_\theta>T\).

*Proof.* In the successful case the algorithm is an element of the set being minimized. In the unsuccessful case it is not such a witness, but removing one potential witness does not exclude the existence of any other. A lower bound requires a statement covering all algorithms in the specified class. \(\square\)

The Lattice Estimator documentation describes models of known attacks and heuristic lattice-reduction costs and shapes, and notes version dependence ([B34](#bib-b34)). Its output is not automatically an upper bound on every source adversary's advantage. To use a concrete security-reduction formula, one still needs the exact input distributions, sample count, success convention, preprocessing and online costs, memory, and the transformed adversary budget. No estimator is run in this chapter, and no fictional commit or parameter estimate is supplied.

For the same reason, a small decryption-failure certificate and a small public key do not certify confidentiality. C1's accepted bound is about correction; WC's large proof-route payload lower bound is a constraint on a particular proof formula; NOISE's exact simulations are conditional on HB. These are meaningful mathematical results, but none fills the missing source-hardness premise of another branch.

## 14.19. Verification package, comparison ledger and conclusion

The delivered verifier checks the exact floor-indicator identity on a finite signed range, the CBD1 likelihood witness, the exact fibers of 38 deterministic small graph-lattice calibration fixtures, and the stored candidates of three deterministic dimension-16 Hankel fixtures. For each stored candidate, compatibility now means **both** that every coordinate lies in the declared secret box and that recomputation of the public quotient vector equals the supplied public vector. A dedicated negative regression uses \(B=(1),P=4,Q=2,U=0\), box \(\{0\}\), candidate \(x=1\): the publication matches but the candidate is correctly rejected as out of box.

For the 38 small fixtures, exhaustive enumeration supplies the compatible-secret counts and uniqueness flags. For the three dimension-16 fixtures, the delivered public fixtures and stored candidates are checked for box membership and exact publication compatibility. The planted secrets remain scoring metadata, not verifier inputs for compatibility. The package does **not** claim that the stored candidates were recovered by the release code, does not provide a reduced-basis certificate, and does not turn these calibration cases into a security estimate.

`verify_independent.py` independently re-enumerates the small boxes and recomputes public outputs for the stored dimension-16 candidates, including the box constraints. Run the two local checks with `python3 verify.py` and `python3 verify_independent.py`; the repository-wide command is `python3 verify_repository.py --jobs 4`.

| Target retained in this thesis | What the evidence establishes | What is not inferred |
|---|---|---|
| Noiseless scalar interval | Efficient exact inverse/posterior method and passive key prediction in its model | An attack on arbitrary multidimensional distributions |
| Exact prime-field polynomial window | Public computation of the common value | A solution of rounded equations with absent remainders |
| Rounded central publication | Exact constraints; public small-instance recovery evidence | A general polynomial-time algorithm or security at untested dimensions |
| P-REF | Its attributed conditional CPA theorem and exact interface | Historical P-ROUND security or a new source-hardness proof |
| WC | Its stated binary-LWE, OW and conditional CCA interfaces | A generic HB theorem or a practical parameter certificate |
| NOISE-CPA-LIFT | Conditional HB-based CPA; explicit raw CCA2 attack | Difficulty of HB or CCA security without a new wrapper |
| BLINDAGE C1 | Named Module-LWE assumptions, nonzero correction bound, conditional ROM KEM | CBD2 security, QROM security or a concrete 128-bit certificate |


## Supplementary Material and Reproducibility — Chapter 14

The public supplementary material for this chapter is assigned to `supplementary/chapter-14/` in the repository release associated with this thesis. The associated release contains the public calibration fixtures, stored candidates, exact finite fiber checks, negative compatibility regression, chapter-local `README.md`, and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and checking rather than replace the mathematical argument.

# Chapter 15 — Parameters, Efficiency, and Implementation {#ch15}
## Exact Payloads, Correctness Budgets, and the Absence of a Certified Deployment Profile




### Abstract

This chapter converts the algebraic and security statements of Chapters 9–14 into an implementation and parameter-selection ledger. It deliberately does not create a new MODDIV construction. Exact fixed-width serialization is separated from entropy, seeded representation is separated from a standard-model replacement of a random public object, correctness probabilities are separated from confidentiality, and executed attacks are separated from lower bounds on unknown attacks. For P-REF, WC, NOISE and the C1 snapshot of BLINDAGE, the chapter recomputes the payload formulas and representative arithmetic costs from the already specified algorithms. A conservative P-REF family at the label \(\lambda=128\) has a 1,228,800-byte public key, but that label is not a 128-bit security estimate. The WC representation profile defined in Chapter 10 has a 32,800-byte compact public key, while the current proof formula alone imposes a necessary quotient payload of 4,726,272 bytes at target exponent 128 under an extremely favorable relaxation; this is a limitation of that proof route, not a universal lower bound. NOISE has compact illustrative encodings, but its HB source hardness is not established and its raw construction is CCA2-malleable. BLINDAGE C1 has a 993-byte seeded public key and a 1408-byte ciphertext together with an averaged worst-message failure bound below \(2^{-282}\), but its exact Module-LWE source assumptions do not yet carry a concrete hardness certificate. A format-only comparison with FIPS 203 ML-KEM is included to calibrate byte counts, never to transfer security. The resulting deployment ledger has no MODDIV thesis-V1 row satisfying all required columns. Thus the chapter recommends no deployment parameter set. It supplies deterministic arithmetic checks, an independent verifier, and a reproducible package for adversarial review; production codec and serialization testing is outside the executed Chapter 15 suite.

### Scope and contribution boundary

This chapter is a synthesis of the exact constructions and attack models already fixed in Chapters 9–14 (Chapter 9; Chapter 10; Chapter 11; Chapter 12; Chapter 13; Chapter 14). It does not alter P-REF, WC, NOISE, BLINDAGE C1, or historical P-ROUND. In particular, it does not import the deferred thesis-V2 work on a Hankel/MP-LWE bridge, signed-secret recentering, CBD2, or a new source-hardness theorem.

The chapter uses three kinds of statements. **Arithmetic facts** are proved directly here. **Imported construction facts** are restated with their source chapter and recomputed by independent scripts. **Engineering comparisons** are descriptive and do not carry security implications. The external size baseline is NIST FIPS 203, whose published Table 3 lists the ML-KEM key and ciphertext lengths ([B37](#bib-b37)). The current NIST page, consulted on 9 November 2026, also carries a planning note that the publication has a potential future correction; this chapter uses only the displayed size table and does not infer any MODDIV security claim from the standard.

## 15.1. Parameter selection is a conjunction, not a single number

A useful parameter profile must satisfy several logically different obligations. We record them as the tuple
\[
\mathcal L(\theta)=
(C_{\rm corr},C_{\rm src},C_{\rm red},C_{\rm atk},C_{\rm fmt},C_{\rm impl}),
\tag{15.1}
\]
where the entries mean, respectively: a correction statement under the actual distribution; a justified source-hardness premise; a reduction from the requested security game to that source; an attack study on the same profile or a justified cost model; a complete canonical format; and an implementation statement covering parsing, randomness, oracle/domain separation and side-channel scope.

No component is implied by the other five. A negligible decryption-failure bound does not prove hardness. A reduction to a named source does not establish that source at the concrete parameters. A large secret space does not lower-bound attack cost. A small public key does not imply a secure key-generation distribution. Passing a functional test suite does not establish constant-time behavior.

For this chapter, a **certified deployment profile in the thesis record** would mean a row for which all six entries are positively justified at one named parameter set and at one explicitly stated classical or quantum resource target. This is a documentary criterion, not a new cryptographic definition.

## 15.2. Canonical payloads and what their length means

Suppose a format consists of fixed-width integer fields \(x_i\in\{0,\ldots,2^{b_i}-1\}\), written in a declared order and concatenated without internal padding. Let
\[
B=\sum_{i=1}^{r} b_i,
\qquad
L_{\rm byte}=\left\lceil\frac{B}{8}\right\rceil.
\tag{15.2}
\]
The final byte has \(8L_{\rm byte}-B\) unused high bits, which are required to be zero.

**Proposition 15.1 — Canonical fixed-width packing.** Under the rule above, encoding is injective and the accepted byte language contains exactly \(2^B\) strings. If a parser accepts the exact length and rejects nonzero final padding, no two accepted byte strings decode to the same field tuple.

*Proof.* Concatenation of fixed-width binary representations is a bijection between the Cartesian product of the field alphabets and \(\{0,1\}^B\). Appending the unique all-zero padding string gives one byte string per bit string. Rejecting any nonzero padding excludes all alternative representatives. \(\square\)

The proposition is a format statement. It does not say that all \(2^B\) encoded objects occur in key generation, nor that an encoded secret has \(B\) bits of min-entropy, nor that recovering it requires \(2^B\) work.

A public seed requires an additional distinction. Let \(F:\{0,1\}^{\kappa}\to\{0,1\}^{N}\) be a deterministic expansion function and publish \((\sigma,F(\sigma))\).

**Proposition 15.2 — A public deterministic expansion is not an independent-uniform replacement.** Let \(\sigma\) be uniform. The total variation distance between
\[
(\sigma,F(\sigma))
\quad\text{and}\quad
(\sigma,U_N),
\tag{15.3}
\]
where \(U_N\) is independent uniform, is exactly
\[
1-2^{-N}.
\tag{15.4}
\]

*Proof.* Condition on any seed. One distribution is a point mass at \(F(\sigma)\); the other is uniform on \(2^N\) outputs. Their total variation distance is \(1-2^{-N}\), independent of the seed. Averaging over the common seed leaves the same value. Equivalently, the test that checks equality to \(F(\sigma)\) accepts the first world with probability one and the second with probability \(2^{-N}\). \(\square\)

Thus COMPACT in Chapter 10 and seeded BLINDAGE in Chapter 12 require their stated oracle or generation model. A short seed is an excellent representation mechanism when the proof models the expander appropriately; it is not an information-theoretic compression theorem for an arbitrary independent random matrix.

## 15.3. Correctness budgets under repeated use and across keys

Let \(d(pk,sk)\) denote the maximum, over allowed messages, of the probability of honest decryption failure under fresh encryption randomness for a fixed generated key. Suppose
\[
\mathbb E_{(pk,sk)}[d(pk,sk)]\le\delta.
\tag{15.5}
\]
This is the averaged worst-message notion used for BLINDAGE C1.

**Proposition 15.3 — Repeated honest-use bound.** For at most \(r\) honest encryptions under one generated key, with fresh coins and messages chosen adaptively from the previous honest transcript,
\[
\Pr[\text{at least one decryption failure}]
\le \min\{1,r\delta\}.
\tag{15.6}
\]

*Proof.* Condition on the generated key and the full history before the \(j\)-th encryption. By definition of \(d(pk,sk)\), the conditional failure probability of the next message is at most \(d(pk,sk)\). A union bound gives at most \(r d(pk,sk)\) for the fixed key. Average over key generation and cap by one. \(\square\)

**Proposition 15.4 — Fraction of unusually bad keys.** For every \(\theta>0\),
\[
\Pr_{(pk,sk)}[d(pk,sk)>\theta]
\le\min\{1,\delta/\theta\}.
\tag{15.7}
\]

*Proof.* The random variable \(d(pk,sk)\) is nonnegative. Apply Markov's inequality to (15.5). \(\square\)

For C1, Chapter 12 proves \(2^{-6400}\le\delta<2^{-282}\). Hence (15.6) is available with \(2^{-282}\) as an upper bound; it does not become perfect correctness, and the explicit lower witness prevents writing \(\delta=0\).

## 15.4. Approximate samplers require an explicit implementation budget

Suppose an ideal experiment samples independent elementary variables \(Z_1,\ldots,Z_s\), while an implementation replaces them by independent variables \(\widetilde Z_i\) with
\[
\operatorname{TV}(Z_i,\widetilde Z_i)\le\epsilon_i.
\tag{15.8}
\]
All later computation is identical.

**Proposition 15.5 — Elementary sampler deviations add by coupling.** The total variation distance between the complete ideal and implemented transcripts is at most
\[
\epsilon_{\rm samp}
=\min\left\{1,\sum_{i=1}^{s}\epsilon_i\right\}.
\tag{15.9}
\]
Consequently every event probability, including a security-game success probability, changes by at most \(\epsilon_{\rm samp}\).

*Proof.* Maximally couple each pair \((Z_i,\widetilde Z_i)\). The probability that any elementary draw differs is at most the sum of the mismatch probabilities. Until the first mismatch, the two transcripts are identical under the same algorithmic coins. Deterministic or randomized post-processing cannot increase total variation. \(\square\)

This proposition is intentionally elementary. It does not justify assessing correlated samplers from scalar marginals. Chapter 11 gives the construction-specific count (11.37); the implementation must count every invocation actually present in its game.

## 15.5. Arithmetic-operation counts are not wall-clock benchmarks

For the non-cyclic Hankel operator
\[
(\mathcal H_{L,d}(a)x)_i=\sum_{j=0}^{d-1}a_{i+j}x_j,
\tag{15.10}
\]
a direct implementation performs one multiply per matrix entry.

**Proposition 15.6 — Direct Hankel cost.** A direct evaluation of \(\mathcal H_{L,d}(a)x\) uses exactly \(Ld\) scalar integer multiplications and \(L(d-1)\) additions before modular reduction choices are counted.

*Proof.* Each of the \(L\) output sums has \(d\) products and \(d-1\) additions. \(\square\)

This count is exact for the stated schoolbook evaluator, but it is not a lower bound on optimized convolution. Bit complexity depends on operand sizes; caching, SIMD, packed arithmetic and convolution algorithms can change wall-clock performance.

For negacyclic multiplication of two length-\(n\) coefficient arrays using the explicit formula of Chapter 12, the schoolbook evaluator uses \(n^2\) coefficient products.

**Proposition 15.7 — Direct module-product count.** For a \(k\times k\) public matrix over \(\mathbb Z_P[x]/(x^n+1)\), the direct C1 algorithms require the following numbers of coefficient multiplications attributable to ring products:
\[
\begin{aligned}
N_{\rm KeyGen}&=k^2n^2,\\
N_{\rm Enc}&=(k^2+k)n^2,\\
N_{\rm Dec}&=kn^2.
\end{aligned}
\tag{15.11}
\]
For \(k=3,n=256\), these are respectively
\[
589{,}824,\qquad786{,}432,\qquad196{,}608.
\tag{15.12}
\]

*Proof.* Key generation computes \(As\), containing \(k^2\) ring products. Encryption computes \(A^Tr\) and the inner product \(v^Tr\), containing \(k^2+k\) ring products. Decryption computes one length-\(k\) inner product. Each schoolbook negacyclic ring product uses \(n^2\) coefficient products. Substitute \(k=3,n=256\). \(\square\)

The counts exclude additions, sampling, compression, hashing and serialization. They are not implementation timings and do not claim optimality.

## 15.6. Historical P-ROUND: parameter arithmetic is not yet a deployment format

Historical P-ROUND publishes a long public ribbon and quotient windows. Chapter 9 reconstructs its arithmetic and shows that the final historical local-counter readings can fail to agree; it also separates the rounded inverse problem from the published P-REF construction. The historical manuscript does not supply the kind of complete modern KEM byte specification assumed in this chapter: profile identifiers, canonical public-key/ciphertext serialization, rejection rules, KDF domains, and a complete CCA interface are not all fixed.

**Proposition 15.8 — A field-count formula is not a canonical wire size without a wire alphabet.** Suppose an object is described only as \(r\) integers whose allowed sets \(S_i\) are not fixed by the specification. There is no unique canonical bit length determined by \(r\) alone. If the sets are fixed finite alphabets, an injective fixed-width encoding needs at least
\[
\sum_{i=1}^{r}\left\lceil\log_2|S_i|\right\rceil
\tag{15.13}
\]
bits under per-field fixed widths, but another explicitly specified joint code may have a different length.

*Proof.* Distinct choices of the alphabets give different information requirements for the same field count. Once a field alphabet is fixed, a fixed-width binary field with fewer than \(\lceil\log_2|S_i|\rceil\) bits has fewer codewords than values and cannot be injective. The last sentence follows because a joint code can exploit a different declared representation. \(\square\)

Accordingly, this chapter does not manufacture a deployment byte count for historical P-ROUND. Its effective arithmetic data can be counted under a named test convention, but that would be a new representation choice, not authentication of the old wire format.

## 15.7. P-REF: a correct conditional reference, not a compact concrete profile

Chapter 9 attributes P-REF to the published middle-product rounding construction and gives the payload formulas
\[
\begin{aligned}
B_{pk}^{\rm REF}&=t\bigl(N\log_2q_0+D_0\log_2p_0\bigr),\\
B_{sk}^{\rm REF}&=(N+D_0-1)\log_2q_0,\\
B_{ct}^{\rm REF}&=(N+k_0)\log_2q_0+d_0+k_0.
\end{aligned}
\tag{15.14}
\]
These are explicit-polynomial payloads, without a seed-compressed public representation.

**Proposition 15.9 — P-REF payload accounting.** Under the fixed-width conventions of Chapter 9, the byte lengths are exactly
\[
\left\lceil B_{pk}^{\rm REF}/8\right\rceil,
\quad
\left\lceil B_{sk}^{\rm REF}/8\right\rceil,
\quad
\left\lceil B_{ct}^{\rm REF}/8\right\rceil.
\tag{15.15}
\]
No security level follows from these lengths.

*Proof.* Apply Proposition 15.1 to the field widths in (15.14). The security statement of Chapter 9 additionally requires the specified computational source assumption and classical random-oracle extraction, neither of which is a function of payload length alone. \(\square\)

The conservative family in Proposition 9.18 takes, for integer \(\lambda\ge2\),
\[
L_0=\lfloor\log_2\lambda\rfloor+1,
\quad N=2\lambda,
\quad d_0=k_0=\lambda,
\quad t=64L_0,
\tag{15.16}
\]
then chooses \(p_0\) and \(q_0\) as specified powers of two.

**Proposition 15.10 — Exact arithmetic at the label \(\lambda=128\).** The conservative family gives
\[
L_0=8,
\quad t=512,
\quad N=D_0=256,
\quad p_0=2^{20},
\quad q_0=2^{55}.
\tag{15.17}
\]
Its payload lengths are
\[
|pk|=1{,}228{,}800\text{ bytes},
\quad |sk|=3{,}514\text{ bytes},
\quad |ct|=2{,}672\text{ bytes}.
\tag{15.18}
\]

*Proof.* The least power of two strictly above \(8\cdot512\cdot129=528{,}384\) is \(2^{20}\). The next rule requires the least power of two strictly above
\(2\cdot2^{20}\cdot256^3\cdot512=2^{54}\), hence \(q_0=2^{55}\). Substituting bit lengths 20 and 55 into (15.14) gives \(9{,}830{,}400\), \(28{,}105\), and \(21{,}376\) bits, then apply byte ceilings. \(\square\)

The symbol \(\lambda=128\) in this family is a theorem parameter, **not** a measured 128-bit security level. The family was chosen to prove non-emptiness of the conjunction of symbolic inequalities, not to optimize bandwidth.

## 15.8. WC: exact compression interface and a proof-route size barrier

For WC, let \(P=2^p\), \(Q=2^q\), \(m=hL+1\), and let \(t\) denote the number of public blocks. Chapter 10 distinguishes the explicit representation BASE from the programmable-oracle COMPACT representation. With a \(\kappa_A\)-bit public seed and \(\kappa\)-bit messages,
\[
\begin{aligned}
B_{pk,E}^{\rm WC}&=t\bigl(mp+L(p-q)\bigr),\\
B_{pk,C}^{\rm WC}&=\kappa_A+tL(p-q),\\
B_{ct}^{\rm WC}&=mp+L+\kappa.
\end{aligned}
\tag{15.19}
\]

**Proposition 15.11 — WC canonical payloads.** Under the Chapter 10 encoding, byte lengths are the ceilings of the quantities in (15.19) divided by eight. COMPACT changes the public representation but not the BASE arithmetic once the public blocks are developed.

*Proof.* This is the field count of Proposition 10.16, followed by Proposition 15.1. The coupling theorem in Chapter 10 develops the COMPACT seed into the same explicit objects in its oracle model. \(\square\)

**Proposition 15.12 — Representation-only WC profile.** For
\[
(p,q,h,L,t,\kappa,\kappa_A)=(256,128,16,32,64,32,256),
\tag{15.20}
\]
so that \(m=513\), one obtains
\[
|pk_E|=1{,}083{,}392\text{ bytes},
\quad |pk_C|=32{,}800\text{ bytes},
\quad |ct|=16{,}424\text{ bytes}.
\tag{15.21}
\]

*Proof.* Substitute (15.20) into (15.19). The bit lengths are \(8{,}667{,}136\), \(262{,}400\), and \(131{,}392\), all byte aligned. \(\square\)

These values describe a representation-only profile. Chapter 10 explicitly records that \(t=64\) does not meet the residual target that would be needed for the later numerical proof budget.

The current proof formula yields a much stronger obstruction. For target success-bias exponent \(\tau\), define \(g_*\) as the least integer \(g\ge3\) satisfying
\[
(4\tau+1)(g+1)+4\tau-2\le2^{g-2}-1.
\tag{15.22}
\]
Then the favorable relaxation of the written proof route requires quotient payload at least
\[
K_{\min}(\tau)
=2\tau g_*\bigl((4\tau+1)(g_*+1)+4\tau-2\bigr)
\tag{15.23}
\]
bits.

**Theorem 15.13 — Recomputed WC proof-route barrier.** The exact values are:

| Target exponent \(\tau\) | \(g_*\) | \(T_0(g_*)\) | Necessary quotient payload (bytes) |
|---:|---:|---:|---:|
| 32 | 13 | 1,932 | 200,928 |
| 64 | 15 | 4,366 | 1,047,840 |
| 128 | 16 | 9,231 | 4,726,272 |
| 192 | 16 | 13,839 | 10,628,352 |
| 256 | 17 | 19,472 | 21,185,536 |

*Proof.* The derivation is the necessary-condition argument of Theorem 10.18: set the source advantage and all additional losses to zero, set the Rényi factor and query factor to their favorable minima, grant free seed storage, and minimize with \(h=1\). The remaining extraction and perfect-correctness inequalities give (15.22)–(15.23). The accompanying verifier searches integer \(g\) and checks every row by exact integer arithmetic, including failure at \(g_*-1\). \(\square\)

This theorem is about **this proof formula**. A tighter extractor, another construction, or another proof can evade it. Conversely, a short WC key that violates (15.23) has not thereby been cryptanalyzed; it simply is not certified by the displayed route at that target.

## 15.9. NOISE: small illustrative payloads, unresolved source hardness

For NOISE, Chapter 11 fixes
\[
n=d+\ell-1,
\qquad m=2d+\ell-2,
\tag{15.24}
\]
and stores the upper-half public coefficients losslessly. Its exact bit lengths are
\[
\begin{aligned}
B_{pk}^{\rm N}&=m(p-1)+n(p-q),\\
B_{sk}^{\rm N}&=d(q-1),\\
B_{ct}^{\rm N}&=(n+\ell)(p-q).
\end{aligned}
\tag{15.25}
\]

**Proposition 15.14 — NOISE payload accounting.** The canonical byte lengths are the ceilings of (15.25) divided by eight. For the five illustrative rows already checked in Chapter 11, the recomputed values are:

| \(d\) | \(\ell\) | \(p\) | \(q\) | pk bytes | sk bytes | ct bytes |
|---:|---:|---:|---:|---:|---:|---:|
| 4 | 2 | 12 | 3 | 17 | 1 | 8 |
| 16 | 16 | 14 | 3 | 118 | 4 | 65 |
| 16 | 8 | 16 | 4 | 106 | 6 | 47 |
| 128 | 128 | 17 | 3 | 1,211 | 32 | 671 |
| 256 | 256 | 18 | 3 | 2,586 | 64 | 1,439 |

*Proof.* Substitute (15.24) into (15.25) and take byte ceilings. The verifier independently recomputes all five rows. \(\square\)

None of these rows is a security level. The source assumption is the exact binary-secret non-cyclic Hankel problem \(\mathsf{HB}(M,d,2n,\chi)\), not ordinary independent-row LWE.

**Proposition 15.15 — Direct arithmetic counts for NOISE.** Ignoring additions, samplers and reductions, the direct Hankel evaluator uses
\[
\begin{aligned}
N_{\rm KeyGen}^{\rm N}&=nd,\\
N_{\rm Enc}^{\rm N}&=(n+\ell)d,\\
N_{\rm Dec}^{\rm N}&=\ell d
\end{aligned}
\tag{15.26}
\]
scalar multiplications.

*Proof.* Key generation evaluates one \(n\)-row Hankel product. Encryption evaluates one \(n\)-row and one \(\ell\)-row product using the same ephemeral secret. Decryption evaluates one \(\ell\)-row product. Apply Proposition 15.6. \(\square\)

For the row \(d=\ell=256\), one has \(n=511\), so the schoolbook counts are 130,816 for KeyGen, 196,352 for encryption and 65,536 for decryption. Again these are operation counts, not optimized timings.

**Proposition 15.16 — Correct polynomial-size NOISE families exist without establishing hardness.** Let \(d=\ell=\lambda\ge2\), \(Q=8\), \(\chi=\mathrm{CBD}_1\), and choose the smallest power of two \(P\) strictly greater than \(4(140\lambda+10)\). Then the sufficient correctness condition of Chapter 11 holds and both public-key and ciphertext payloads are \(O(\lambda\log\lambda)\) bits.

*Proof.* This is Proposition 11.18. The construction gives \(P=O(\lambda)\), hence \(p=O(\log\lambda)\), while \(m,n=O(\lambda)\). Substitute into (15.25). \(\square\)

The proposition proves storage and correctness feasibility only. It neither proves HB hardness nor repairs Theorem 11.16: the unwrapped NOISE encryption remains subject to the related-ciphertext CCA2 attack described there.

## 15.10. BLINDAGE C1: compact bytes and a nonzero correctness term

The fixed C1 snapshot has
\[
n=256,
\quad k=3,
\quad P=4096,
\quad Q=4,
\quad C=2,
\quad \chi=\mathrm{CBD}_1.
\tag{15.27}
\]
The public matrix is represented from a 32-byte seed in the declared ideal expansion model, while the compressed public vector is stored explicitly.

**Proposition 15.17 — C1 payload and full-matrix accounting.** With the one-byte profile identifier of Chapter 12,
\[
|pk|=993\text{ bytes},
\qquad
|ct|=1408\text{ bytes}.
\tag{15.28}
\]
The corresponding mathematical full-matrix representation requires 4,416 bytes before metadata:
\[
9\cdot256\cdot12/8+3\cdot256\cdot10/8
=3456+960=4416.
\tag{15.29}
\]

*Proof.* Each public quotient has ten bits and there are \(3\cdot256=768\) of them, giving 960 bytes. The public seed and identifier add 33 bytes. Each ciphertext quotient has eleven bits and there are \((3+1)256=1024\), giving 1408 bytes. A full public matrix has nine ring elements, each with 256 twelve-bit coefficients. \(\square\)

The 993-byte number does not include a complete secret-key/KEM-state serialization. Chapter 12 explicitly requires enough retained public information for re-encryption plus the secret and fallback; the complete byte format was not fixed there.

**Proposition 15.18 — C1 direct ring-product cost.** Under the schoolbook negacyclic evaluator, C1 has the coefficient-product counts in (15.12): 589,824 for KeyGen, 786,432 for encryption and 196,608 for decryption.

*Proof.* Substitute (15.27) into Proposition 15.7. \(\square\)

C1's correctness certificate is strong but not perfect:
\[
2^{-6400}\le\delta<2^{-282}.
\tag{15.30}
\]
Its confidentiality and CCA theorem are conditional on two exact Module-LWE source problems and the classical random-oracle interface. Chapter 12 does not supply a concrete worst-case or best-known-attack certificate for those exact C1 source distributions. Therefore (15.28) is a payload fact, not a 128-bit-security claim.

## 15.11. A format-only comparison with standardized ML-KEM

NIST FIPS 203, published 13 August 2024, lists the following lengths in Table 3 ([B37](#bib-b37)):

| Scheme / profile | Encapsulation/public key | Ciphertext | Total transmitted pk+ct |
|---|---:|---:|---:|
| ML-KEM-512 | 800 | 768 | 1,568 |
| ML-KEM-768 | 1,184 | 1,088 | 2,272 |
| ML-KEM-1024 | 1,568 | 1,568 | 3,136 |
| MODDIV-BLINDAGE C1 | 993 | 1,408 | 2,401 |

**Proposition 15.19 — The table above is a byte comparison only.** The C1 total is 2,401 bytes, which lies numerically between the ML-KEM-768 and ML-KEM-1024 totals, while its public key lies between the ML-KEM-512 and ML-KEM-768 public-key lengths. No ordering of security strength follows from these inequalities.

*Proof.* The byte inequalities are direct integer comparisons. The non-implication follows because the four rows have different source assumptions, reductions, parameter certification histories and implementation standards. A function from byte length to security strength is not a premise of any cited theorem. \(\square\)

FIPS 203 is used here as an engineering yardstick because it provides a complete standardized KEM with explicit parameter sets and wire lengths. It is not used as a source problem for MODDIV. NIST SP 800-227 additionally emphasizes that secure KEM use involves algorithm, implementation and system conditions ([B38](#bib-b38)), reinforcing rather than replacing the six-column ledger (15.1).

## 15.12. Seed generation, domain separation, and reproducibility

A seed-based implementation has at least four distinct objects that must not be collapsed:

1. the abstract distribution required by the proof;
2. the deterministic expansion algorithm used by software;
3. the domain-separated inputs that identify roles, parameter sets and indices;
4. the canonical byte representation consumed by hashing, re-encryption and parsing.

For WC COMPACT, the theorem is formulated with a programmable classical random oracle \(\mathcal A\). For C1, the public seed is likewise part of an ideal matrix-expansion interface in the security discussion. A concrete SHAKE function can be a deterministic implementation choice, but the theorem must separately justify replacing an ideal oracle by that concrete function if such a claim is desired. Proposition 15.2 shows why the replacement is not information-theoretically exact.

A reproducible research program can use deterministic seeds for tests while the cryptographic algorithm requires fresh entropy in production. Reproducibility seeds are therefore labeled as testing controls and are never silently reinterpreted as deployment randomness.

## 15.13. Canonical parsing is necessary but does not provide authentication

Canonical serialization removes alternate byte encodings of the same mathematical object. It is valuable for hash-domain consistency, transcript equality and re-encryption checks. It does not make two *different* valid objects equivalent or prevent an algebraic modification that remains within the accepted range.

For example, NOISE's CCA2 attack changes one valid quotient by \(H/2\) and remains canonical. BLINDAGE's raw PKE admits a valid-format translation of one \(c_2\) coefficient away from ties; the KEM wrapper relies on re-encryption and implicit rejection, not on parsing alone. WC's unwrapped PKE is malleable in \(c_3\); its CCA claim likewise belongs to the explicit wrapper.

Thus the implementation checklist has two separate lines: **canonical decode** and **cryptographic acceptance**. Conflating them would turn a format property into a false security claim.

## 15.14. Timing, memory, and the danger of benchmark transplantation

The thesis contains local timings and finite benchmarks from different reproducible checks, including selected NOISE supplementary checks and implementation checks in the construction chapters. They were executed under different languages, libraries, machines, dimensions and objectives. They cannot be merged into one performance table by comparing raw seconds. Chapter 14 deliberately makes no reproducible secret-recovery timing claim in this edition.

A performance claim suitable for parameter selection would fix at least:
\[
\begin{aligned}
(&\text{hardware},\text{software versions},\text{threads},\text{compiler},\\
 &\text{input law},\text{batching},\text{precomputation},\text{memory cap}).
\end{aligned}
\tag{15.31}
\]
It would separately report key generation, encapsulation/encryption, decapsulation/decryption, serialization, expansion/hashing and peak memory. The present chapter therefore reports exact symbolic operation counts and payload lengths but does **not** invent cross-chapter speed ratios.

The finite NOISE transport optimization is a useful cautionary example. It reduced one target index from 2,097,152 identifiers to 785 dynamic-programming states for the fixed \(M=8,L=3,d=2\) witness, and improved local storage substantially. The same report explicitly retains an exponential dependence through a \(2^d\)-component weight vector and does not establish a polynomial-time family. A fast fixed toy instance is not an asymptotic reduction.

## 15.15. Attack-aware parameter selection

Let \(\mathcal A_1,\ldots,\mathcal A_s\) be executed or modeled attacks on the *same* security experiment and parameter profile. If attack \(i\) succeeds with probability \(p_i\) using work \(W_i\), the existence of that algorithm is an upper bound on the work required by an adversary willing to accept that success level. It is not a lower bound on the best attack.

Chapter 14 gives a more basic warning: a nominal secret-box cardinality is not, by itself, a computational lower bound. For the fixed Chapter 14 compatibility profile \(P=536870923\), \(Q=511\), \(d=16\), \(L=17\) with secret coordinates in \([256,511]\), the secret domain has \(256^{16}=2^{128}\) elements. The public release verifies three in-box candidates against their public quotient vectors but does not reproduce a secret-recovery algorithm or timing. The correct conclusion is therefore purely methodological: **secret entropy cannot be used as an attack-cost certificate without a computational lower-bound argument for the actual public problem**.

Accordingly, a parameter-selection document must keep four labels distinct:

- **executed cost:** an actual measured attack under a fixed environment;
- **extrapolated cost:** a model fitted beyond executed dimensions;
- **heuristic estimator output:** dependent on model and version assumptions;
- **proved bound:** a mathematical inequality with explicit quantifiers.

Only the last category can serve as a theorem, and even then its direction matters. A constructive attack gives an upper bound on optimal attack work. A timeout of one solver gives no lower bound on all attacks.

## 15.16. Parameter snapshots across the thesis

The following table consolidates the current V1 status without upgrading any result.

| Object | Established in thesis V1 | Missing deployment component(s) |
|---|---|---|
| Historical P-ROUND | Polynomial-window identities; corrected normalized local-counter analysis and exact disagreement/undefined witnesses | Universal final agreement, IND-CPA/CCA theorem, and complete canonical KEM format |
| P-REF | Perfect correctness under its published conditions; conditional classical-ROM IND-CPA; exact payload formula (15.14) | Concrete source-hardness certificate and CCA deployment profile |
| WC BASE/FAST/COMPACT/FO | Perfect BASE correctness when \(t(Q-1)<P/8\); FAST exact; conditional OW/CCA route; exact payload formulas (15.19) | Concrete source hardness and a parameter set satisfying the present proof budgets at practical size |
| NOISE | Strict-margin/tail correctness; conditional standard-model IND-CPA under HB; exact payload formula (15.25) | Derived HB hardness and a CCA-secure wrapper/profile; raw scheme has an explicit CCA2 attack |
| BLINDAGE C1 | Averaged worst-message \(2^{-6400}\le\delta<2^{-282}\); conditional single-user classical-ROM CCA; pk 993 B and ct 1408 B | Concrete hardness for the two exact Module-LWE sources; complete secret/decapsulation-state serialization; production oracle-domain strings and implementation evidence |

The table is deliberately asymmetric. Some rows have stronger correctness, some have smaller formats, some have a CCA wrapper, and some have a cleaner source interface. No row is allowed to borrow the missing column from another row merely because both use modular products or rounding.

## 15.17. The deployment criterion and the present verdict

**Proposition 15.20 — No thesis-V1 MODDIV profile is certified for deployment by the present record.** Under the six-component criterion (15.1), none of the named rows in Section 15.16 has all six components positively established at one concrete parameter set with a justified security target.

*Proof.* Historical P-ROUND fails the required correctness/security/format conjunction in the specified reading. P-REF has a conditional CPA theorem but no concrete source-hardness certification or CCA deployment profile in this thesis. WC has a conditional CCA composition, but its concrete source hardness is not certified and the current numerical proof route exhibits the size barrier of Theorem 15.13. NOISE lacks a derived hardness theorem for HB and has an explicit CCA2 attack in its unwrapped form. BLINDAGE C1 has a compact format, a strong nonzero correctness bound and a conditional classical-ROM CCA route, but Chapter 12 explicitly does not establish concrete hardness for its exact source problems or a 128-bit certificate. Therefore every row has at least one unfilled required component. \(\square\)

This proposition is a statement about **what the thesis has justified**, not a theorem that secure MODDIV parameters cannot exist. It is equally important not to reverse it: the absence of a deployment certificate is not a proof of insecurity for all untested parameter families.

## 15.18. Implementation checklist for any future candidate

A future candidate profile should enter the thesis only after the following artifacts agree on the same parameter identifier:

| Layer | Required artifact |
|---|---|
| Mathematics | exact parameters, distributions, correctness theorem and failure quantifier |
| Source hardness | named source experiment, dimensions, sample count, error/secret laws and concrete evidence |
| Reduction | game definition, advantage convention, query/resource loss and model (standard/ROM/QROM) |
| Attacks | public-only attack inputs, best-known executed/modelled costs, memory and success probabilities |
| Randomness | entropy source requirements, rejection/sampling rules and failure behavior |
| Expansion | exact seed domains, index encodings, oracle/PRG assumption and collision handling |
| Serialization | canonical byte grammar, endianness, field ranges, padding and rejection rules |
| KEM/PKE behavior | malformed inputs, decapsulation failure, implicit rejection and domain separation |
| Side channels | constant-time scope, secret-dependent branches/memory and fault behavior |
| Reproducibility | versioned code, test vectors, manifest, independent verifier and source hashes |

For C1 specifically, the existing 993/1408-byte arithmetic representation is therefore only one line of this checklist. A release-quality profile would still need a complete secret/decapsulation-key format, concrete source analysis, production domain strings, constant-time code and validation against fixed test vectors.

## 15.19. Reproducible arithmetic and package verification

The delivered Chapter 15 verifier is deliberately limited to deterministic arithmetic used by the deployment discussion. `verify.py` recomputes the C1 schoolbook ring-product counts, the 993-byte public key and 1408-byte ciphertext arithmetic, the 32,800-byte WC compact representation, and the stored WC proof-route barrier of 4,726,272 bytes at the stated target. `verify_independent.py` independently repeats five core size/product identities.

This supplementary code does not claim to test production codecs, padding rejection, constant-time parsing, total-variation examples or the Markov argument. Those statements are proved or qualified in the text; they are not represented as executed campaigns in this release. The verifiers are not security estimators and assign no concrete security level to C1, WC, NOISE or P-REF.

Run `python3 verify.py` and `python3 verify_independent.py` in the chapter directory, or `python3 verify_repository.py --jobs 4` at repository root.

## 15.20. Conclusion

Parameter selection is the point where attractive algebra meets unforgiving engineering. In the present MODDIV record, three facts can be true simultaneously: a construction can have a rigorous conditional reduction, a compact byte representation, and still lack a concrete deployment certificate. Conversely, a large representation or a weak toy profile does not prove that every future member of its mathematical family is insecure.

The practical conclusion of thesis V1 is therefore conservative. P-REF supplies a published conditional reference but is not optimized by our conservative family. WC demonstrates an exact embedding and CCA composition but exposes a severe numerical barrier in its current proof route. NOISE shows that explicit noise and a standard-model CPA reduction can coexist with efficient-looking encodings while source hardness and CCA remain unresolved. Among the concrete WC and C1 payload snapshots compared in this chapter, C1 has the smaller public-key and ciphertext payloads (993 and 1408 bytes). This comparison does not minimize payloads over either entire parameter family and does not rank their concrete security. Its exact source hardness is still an assumption rather than a concrete security certificate.

The chapter does not select a deployment winner. It closes the parameter discussion by identifying exactly what is missing from each row. Chapter 16 can therefore compare the scientific lessons of the MODDIV family without conflating compactness, correctness, reduction quality and security evidence; Chapter 17 can state the resulting open problems without disguising them as completed proofs.



```{=latex}
\part*{\phantomsection\addcontentsline{toc}{part}{PART V — Synthesis and Conclusions}PART V — Synthesis and Conclusions}
```



## Supplementary Material and Reproducibility — Chapter 15

The public supplementary material for this chapter is assigned to `supplementary/chapter-15/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 16 — Comparative Analysis and Lessons from the MODDIV Family {#ch16}
## What Survives, What Fails, and What Can Be Reused


**Scope.** This comparative synthesis introduces no new construction, source-hardness theorem, parameter set or thesis-V2 bridge.

### Abstract

This chapter compares the MODDIV line of work by separating the arithmetic operation from the distributions, correctness mechanisms, hardness assumptions, security games, attacks, formats, and parameter evidence that surround it. The comparison is deliberately non-linear: later descendants are not treated as automatically stronger versions of earlier ones. The scalar model gives an exact example in which honest agreement above three quarters coexists with efficient passive key prediction. General-modulus analysis then shows that the three-quarters phenomenon is not universal outside its stated support and alignment conditions. Exact polynomial windows preserve useful bilinear identities but can become publicly predictable by linear algebra, while rounded historical windows retain missing remainders for which no confidentiality theorem is imported. Distributional analysis explains why discarded remainders are not independent noise and why randomized lifting is exact only under a conditional cell-uniformity criterion that includes the complete public view. P-REF supplies a published conditional CPA reference; WC changes the secret law to obtain an exact binary-LWE embedding and a conditional classical-ROM CCA route, but its present proof inequalities impose a severe payload barrier at a target exponent 128. NOISE adds explicit perturbations and gives an exact conditional standard-model CPA reduction to a named binary-secret Hankel source, while the unwrapped construction remains CCA2-malleable. BLINDAGE C1 combines compact seeded payloads, a nonzero but extremely small correctness bound, two exact Module-LWE interfaces, and a conditional classical-ROM CCA route, while concrete source hardness remains uncertified. The main conclusion is methodological: no single adjective such as *rounded*, *lattice-based*, *Toeplitz*, *noisy*, *CCA*, *compact*, or *128-bit* can substitute for the full chain from specification to deployment evidence. The accompanying Chapter 16 scripts check the seven-row comparative ledger and identify the obligations left open for each construction. Repository-level integrity checks compare delivered files with their SHA-256 manifests; the chapter-local scripts do not independently reprove the imported construction results.

### Scope and contribution boundary

This chapter compares the scientific content established in Chapters 1–15. The chapter does not revise those files. When a result below is marked as **imported**, its mathematical content is attributed to the source chapter and only its comparative consequence is derived here. When a statement is proved directly, the proof is elementary and self-contained.

The historical, scalar, polynomial, WC, NOISE and BLINDAGE objects are not renamed as one cryptosystem. The same quotient map can occur in different constructions without transferring a security theorem. Likewise, a Toeplitz or Hankel representation is a structural description, not by itself an LWE or LWR hardness assumption. The postponed thesis-V2 questions — in particular signed-secret recentering, a direct HB/MP-LWE bridge, a stronger source-hardness reduction, and later BLINDAGE snapshots — remain outside this chapter.

## 16.1. A family is defined by more than its quotient map

For positive integers \(P,Q\), write
\[
F_{P,Q}(z)=\left\lfloor\frac{[z]_P}{Q}\right\rfloor,
\qquad [z]_P\in\{0,\ldots,P-1\}.
\tag{16.1}
\]
A concrete cryptographic object using this map is described here by the tuple
\[
\Theta=(\mathcal A,\mathcal D_{\rm pub},\mathcal D_{\rm sec},\mathcal D_{\rm err},
\mathsf{Rec},\mathsf{Fmt},\mathsf{Game}),
\tag{16.2}
\]
where \(\mathcal A\) is the algebraic operator, the \(\mathcal D\)'s are the public, secret and error laws, \(\mathsf{Rec}\) is the reconciliation or decryption rule, \(\mathsf{Fmt}\) is the public byte-level interface, and \(\mathsf{Game}\) is the adversarial experiment.

**Proposition 16.1 — Shared arithmetic is not a security equivalence.** Equality of the quotient map \(F_{P,Q}\) and of the ambient algebra does not imply equality of transcript distributions or security games. A security theorem for \(\Theta\) transfers to another descriptor \(\Theta'\) only through an explicit equality of the relevant joint laws or through a proved reduction whose loss and target are stated.

*Proof.* A security theorem is quantified over the transcript distribution and success event specified by its construction. Changing a secret law, adding an error, publishing a seed, changing reconciliation, or changing the game can change either the probability space or the event. Identical evaluation of the local function \(F_{P,Q}\) does not identify those spaces. Equality of the complete relevant laws makes the experiments identical; a reduction is the standard alternative for relating nonidentical experiments. \(\square\)

This proposition is the organizing rule for the whole chapter. Historical scalar MODDIV, P-WINDOW, P-ROUND, P-REF, WC, NOISE and C1 are therefore separate rows in the comparison ledger even when their arithmetic visibly overlaps.

## 16.2. The exact quotient/remainder normal form

Let
\[
J=\left\lceil\frac P Q\right\rceil,
\qquad
I_u=\{Qu,\ldots,\min(Q(u+1)-1,P-1)\},
\tag{16.3}
\]
for \(0\le u<J\), and set
\[
\omega_u=|I_u|=\min(Q,P-Qu).
\tag{16.4}
\]
The final cell can be shorter than \(Q\).

**Proposition 16.2 — Unique quotient/remainder decomposition.** For every integer \(z\), if \(U=F_{P,Q}(z)\), then there are unique integers \(K,R\) satisfying
\[
z=PK+QU+R,
\qquad 0\le R<\omega_U.
\tag{16.5}
\]
Conversely, every triple satisfying (16.5) produces quotient \(U\).

*Proof.* Euclidean division gives the unique canonical residue \([z]_P\) and wrap integer \(K\). Since \(U\) is its cell label, \([z]_P=QU+R\) for a unique offset in the corresponding cell. Conversely, (16.5) places the canonical residue in \(I_U\). \(\square\)

This identity is the common arithmetic skeleton of the thesis. Its discarded variable \(R\) is bounded, but the identity does not specify a probability law for \(R\), let alone independence from the secret or public data.

## 16.3. High agreement and confidentiality are logically separate

For the full-range scalar model of Chapter 6, let \(P=2^p\), \(Q=2^q\), \(q\ge1\), \(p>2q\). The public multiplier \(A\) is uniform modulo \(P\), the private scalars \(X,Y\) are uniform in \([0,Q)\), and \(A,X,Y\) are mutually independent. The public transcript and extraction rule are the same two-message scalar experiment used in Chapter 6. Chapter 6 proves the exact uniform lower bound
\[
\Pr[W_A=W_B]\ge
c_*:=\frac{166397}{221184}>\frac34.
\tag{16.6}
\]
Chapter 5 gives an exact expected-polynomial-time posterior sampler for the scalar interval inverse problem.
When a strict polynomial-time security-game formulation is required, the capped sampler of Chapter 5 is used with its stated abort/error accounting rather than silently identifying expected polynomial time with worst-case PPT.

**Corollary 16.3 — Agreement above three quarters can coexist with efficient passive prediction.** In the model above there is an expected-polynomial-time passive predictor \(W^*\) such that
\[
\Pr[W^*=W_B]=\Pr[W_A=W_B]\ge c_*.
\tag{16.7}
\]
Against an independent uniform candidate in a key alphabet of size \(J_K\ge2\), its acceptance gap is at least
\[
c_*-\frac1{J_K}\ge c_*-\frac12>\frac14.
\tag{16.8}
\]

*Proof.* This is the posterior-replacement argument of Chapters 5–6: condition on the public transcript, sample a fresh private scalar from the exact posterior, and apply the honest extraction rule. The conditioned pair has the same law as the honest private pair for the purpose of the derived key. Equation (16.6) then gives (16.7); comparison with an independent uniform key gives (16.8). \(\square\)

Thus agreement is a correctness quantity, not a secrecy metric. Increasing an agreement probability can improve reliability while leaving passive prediction unchanged or even easier.

## 16.4. The three-quarters phenomenon is not universal

The full-range theorem depends on its secret support and modulus regime. Chapter 6 gives the exact seven-bit upper-half witness
\[
P=2^{15},\qquad Q=2^7,
\qquad X,Y\in[64,128),
\tag{16.9}
\]
for which
\[
\Pr[W_A=W_B]
=\frac{12540509}{16777216}
\approx0.747473<\frac34.
\tag{16.10}
\]
Chapter 7 separately shows that nonaligned general-modulus families can violate a uniform three-quarters guarantee even when the arithmetic remains close to the aligned model.

**Proposition 16.4 — No unrestricted scalar three-quarters theorem follows from the quotient primitive alone.** A statement of the form
\[
\Pr[W_A=W_B]>\frac34
\tag{16.11}
\]
for every secret support and every admissible modulus is false.

*Proof.* Equation (16.10) is an explicit counterexample with the same basic quotient arithmetic but a different private support. Chapter 7 supplies additional nonaligned witnesses. One counterexample is sufficient to refute the unrestricted universal quantifier. \(\square\)

The lesson is broader than the constant \(3/4\): support, alignment, boundary cells and carry correlations are part of the theorem statement, not nuisance details to be suppressed after the calculation.

## 16.5. Structured public matrices are visibly different distributions

A Toeplitz \(L\times d\) matrix over \(\mathbb Z_P\) is determined by \(L+d-1\) entries, while an independent matrix uses \(Ld\) entries. Under uniform sampling of the defining entries, let \(\mathcal T\) be the Toeplitz law and \(\mathcal U\) the uniform law on all \(L\times d\) matrices.

**Proposition 16.5 — Exact statistical separation of Toeplitz and independent matrices.** For \(P\ge2\) and \(L,d\ge1\),
\[
\operatorname{TV}(\mathcal T,\mathcal U)
=1-P^{L+d-1-Ld}
=1-P^{-(L-1)(d-1)}.
\tag{16.12}
\]

*Proof.* The Toeplitz support has exactly \(P^{L+d-1}\) matrices, each with probability \(P^{-(L+d-1)}\). The uniform law gives each matrix probability \(P^{-Ld}\). Since \(\mathcal T\) is uniform on a subset of the support of \(\mathcal U\), the total variation distance is one minus the \(\mathcal U\)-mass of that subset, namely \(1-P^{L+d-1}/P^{Ld}\). \(\square\)

For \(L,d>1\), the distance approaches one rapidly. This is not a proof that a structured problem is easy. It proves something more modest and essential: replacing a structured public law by independent rows is not a small statistical perturbation. Any hardness transfer must respect or deliberately reduce between those structures.

## 16.6. Exact structure can help both correctness and attack

Chapter 9 distinguishes two polynomial objects. **P-WINDOW** publishes exact compatible windows over a prime field, without coefficient rounding. **P-ROUND** publishes rounded historical windows and therefore hides cell remainders.

**Proposition 16.6 — Exact compatible windows can eliminate original-secret recovery from the attack objective.** In P-WINDOW, if the public window equation is \(Mx=u\) over a field and the desired common value depends on \(x\) only through the same compatible bilinear window, then any public solution \(x'\) of \(Mx'=u\) yields the same common value. Gaussian elimination therefore suffices even when \(x'\neq x\).

*Proof.* Let \(h=x'-x\), so \(Mh=0\). Compatibility of the window identity means that the common bilinear expression factors through the published linear map. Its change under \(x\mapsto x+h\) is therefore zero. Solving the public linear system provides one representative of the fiber and hence the common value. \(\square\)

Rounding can remove this exact linear information, but that does not automatically create a hard problem. It creates missing remainders whose law and correlations must then be analyzed. The comparison is therefore not “more rounding means more security”; it is “rounding changes the inverse problem and the proof obligations.”

## 16.7. Randomized lifting is exact only under a conditional criterion

Let \(C\) denote **all** public side information relevant to a finite joint experiment, let \(Z\) be a residue vector, and let \(U=F(Z)\) be its vector of quotient labels. For a vector label \(u=(u_1,\ldots,u_s)\), write \(I_u=I_{u_1}\times\cdots\times I_{u_s}\) for the full product cell. Given \((C,U)\), sample \(\widetilde Z\) uniformly from \(I_U\).

**Proposition 16.7 — Complete-view cell-lift criterion.** The exact identity from Chapter 8 is
\[
\operatorname{TV}(\mathcal L(C,Z),\mathcal L(C,\widetilde Z))
=
\sum_{c,u}\Pr[C=c,U=u]
\operatorname{TV}\!\bigl(\mathcal L(Z\mid c,u),\operatorname{Unif}(I_u)\bigr).
\tag{16.13}
\]
Hence the lift reconstructs the real joint law exactly if and only if every positive-probability conditional law \(Z\mid(C=c,U=u)\) is uniform on its full product cell.

*Proof.* The two experiments share the same \((C,U)\) marginal, and distinct cells have disjoint support. Splitting the total-variation sum by \((c,u)\) gives (16.13). Every term is nonnegative, so equality to zero is equivalent to conditional cell uniformity. \(\square\)

A lift can therefore be exact in an ideal game while failing in the real game after additional public information is revealed. Conditioning on the quotient alone is insufficient when another public variable changes the within-cell law.

## 16.8. A discarded remainder is not independent noise by definition

From (16.5), the remainder is
\[
R=[z]_P-QF_{P,Q}(z).
\tag{16.14}
\]
It is a deterministic function of the unrounded residue and its quotient.

**Proposition 16.8 — Exact additive form does not imply an independent-error law.** There exist MODDIV observations for which the discarded remainder is perfectly correlated with the secret even though it is bounded by \(Q-1\).

*Proof.* Take \(P=4,Q=2\), a secret \(X\) uniform in \(\{0,1\}\), and let the unrounded residue be \(Z=X\). Then \(U=F_{4,2}(Z)=0\) always, while
\[
R=Z-2U=X.
\tag{16.15}
\]
The remainder is bounded in \(\{0,1\}\) but determines the secret exactly. Treating it as a fresh independent sample would change the joint law. \(\square\)

The example is intentionally elementary. In structured products the dependency can be subtler because the same public coefficients and secret coordinates influence many overlapping remainders. Bounded magnitude is useful for correctness; independence is a separate probabilistic statement that must be proved or explicitly sampled.

## 16.9. Security reductions need a visible loss ledger

Suppose a sequence of games has event probabilities \(p_0,\ldots,p_s\), and the proof justifies
\[
|p_i-p_{i+1}|\le\varepsilon_i
\qquad(0\le i<s).
\tag{16.16}
\]

**Proposition 16.9 — Additive hybrid losses accumulate explicitly.**
\[
|p_0-p_s|\le\sum_{i=0}^{s-1}\varepsilon_i.
\tag{16.17}
\]
If a separate source-to-target argument preserves a recovery event only through
\[
\beta\ge\frac{\alpha^2}{C},
\tag{16.18}
\]
then (16.18) is not an additive decision-distance statement and cannot be replaced by \(\alpha-O(\varepsilon)\) without another proof.

*Proof.* Equation (16.17) is the triangle inequality. Equation (16.18) is an oriented event-preservation inequality of a different functional form; algebra alone does not convert it into a symmetric additive bound between arbitrary decision probabilities. \(\square\)

This is the central distinction behind Chapter 8's Rényi transfer, Chapter 13's game ledger, and the later CCA wrappers. A theorem can be correct and still useless at a concrete parameter if its loss grows too quickly.

## 16.10. P-REF is a reference construction, not a retrofit of P-ROUND

P-REF is the published middle-product reference specialized in Chapter 9. Its public and secret roles, conditioned source law, inverse lifting and rounding rule are those of that construction. Historical P-ROUND has a different short-secret/public-factor arrangement and different final processing.

**Proposition 16.10 — Commutativity alone does not identify labeled transcript laws.** If two factors \(A,X\) have different distributions or different public/secret roles, the algebraic identity \(AX=XA\) alone does not imply equality between the labeled transcript laws of the original and swapped experiments.

*Proof.* Algebraic commutativity gives \(AX=XA\), but a labeled transcript contains more than the product: it records which factor is public, which is hidden, their lengths and laws, and often auxiliary data sampled conditionally on those roles. Equality of the product therefore supplies no general equality of the labeled joint law. A separate symmetry argument or reduction would be required for a particular interface. \(\square\)

Consequently, the conditional classical-ROM CPA theorem retained for P-REF does not become a theorem for historical P-ROUND by renaming factors. P-REF is valuable precisely because it supplies a clean published reference against which the historical construction can be compared.

## 16.11. WC obtains an exact source embedding by changing the construction

WC fixes one secret coordinate, widens the Hankel geometry, and uses an independent parity mask so that the auxiliary binary-secret source embeds into the declared anchored-box law. Chapter 10 then combines this exact distributional interface with residual hashing, a Rényi loss, one-way security and a selected classical-ROM implicit-rejection wrapper.

**Proposition 16.11 — Exact embedding and practical certification are different obligations.** The WC source embedding can be exact while the present proof route remains numerically incompatible with a compact target at exponent \(\tau=128\). In the favorable necessary-condition relaxation of Chapters 10 and 15, one obtains
\[
g_*=16,
\qquad T_0(g_*)=9231,
\tag{16.19}
\]
and the quotient payload alone obeys the necessary bound
\[
tLg\ge 37\,810\,176\ \text{bits}
=4\,726\,272\ \text{bytes}.
\tag{16.20}
\]

*Proof.* Exactness of the embedding is a distributional statement proved in Chapter 10. The numerical bound is the necessary-condition optimization rechecked in Chapter 15; it follows after dropping nonnegative security-loss terms, so satisfying the original proof can only be harder. Neither statement contradicts the other. \(\square\)

Equation (16.20) is not a lower bound on all possible WC variants, not a cryptanalytic attack, and not an impossibility theorem. It is a diagnostic of the current proof architecture.

## 16.12. NOISE separates standard-model CPA from chosen-ciphertext security

NOISE adds explicit integer perturbations before modular reduction and quotient extraction. Chapter 11 gives an exact two-transition simulation from a named binary-secret noncyclic Hankel source \(\mathsf{HB}\), preserving the shared secret across disjoint public segments. Under that source assumption, the construction obtains conditional standard-model IND-CPA security.

The same chapter gives a public translation of a raw ciphertext component that flips a decoded bit under a strict margin, yielding a chosen-ciphertext attack against the unwrapped scheme.

**Proposition 16.12 — Conditional CPA security and a raw CCA2 attack are compatible statements.** With the advantage conventions of Chapter 11, for every classical probabilistic polynomial-time CPA adversary \(\mathcal A\), there exist two distinguishers \(\mathcal B_0,\mathcal B_1\) for the same source family \(\mathsf{HB}(M,d,2n,\chi)\), at the stated simulation resource budgets, such that
\[
\operatorname{Adv}_{\rm CPA}(\mathcal A)
\le \operatorname{Adv}_{\rm HB}(\mathcal B_0)
  + \operatorname{Adv}_{\rm HB}(\mathcal B_1).
\tag{16.21}
\]
The CPA quantity is success bias above one half; each HB quantity is an acceptance gap. With the exact samplers of Theorem 11.12, the two simulation transitions are exact. If both source advantages are bounded by \(\varepsilon_{\rm HB}(T')\), the displayed bound gives \(2\varepsilon_{\rm HB}(T')\). If an approximate honest sampler is substituted, only the separately defined allowance of Chapter 11, equation (11.37), may be added; it is not hidden inside a generic \(\varepsilon_{\rm red}\).

There is no contradiction between this conditional CPA statement and the existence of an efficient raw CCA2 adversary.

*Proof.* The two-HB inequality is the exact hybrid accounting imported from Chapter 11 and preserves the shared secret across the \(2n\)-window source. The CPA game does not grant the post-challenge decryption capability exploited by a CCA2 adversary. Security in the weaker game does not imply security in the stronger game. The source reduction and the related-ciphertext attack therefore concern different success experiments. \(\square\)

The lesson is constructive: adding explicit noise can make a reduction cleaner, but active security still requires a wrapper or a different construction, and the HB source itself still needs an external hardness foundation.

## 16.13. BLINDAGE C1 separates compactness, correctness, and source hardness

For C1-P12-CBD1,
\[
R=\mathbb Z_{4096}[x]/(x^{256}+1),
\qquad k=3,
\qquad Q=4,
\qquad C=2.
\tag{16.22}
\]
Its specified serialization has
\[
|pk|=993\ \text{bytes},
\qquad |ct|=1408\ \text{bytes},
\tag{16.23}
\]
and Chapter 12 proves the averaged worst-message correctness interval
\[
2^{-6400}\le\delta<2^{-282}.
\tag{16.24}
\]
The conditional classical-ROM CCA route uses two exact CBD1 Module-LWE source interfaces and carries nonzero correctness loss.

**Proposition 16.13 — A tiny failure bound is not a hardness certificate.** Equations (16.23)–(16.24) establish compact representation and a strong correctness statement, but neither implies a concrete lower bound on the work of attacking the two source problems.

*Proof.* The byte counts are deterministic format facts and \(\delta\) is a probability of honest decryption failure. An attack-work lower bound is a computational statement about a distinct experiment. No logical implication connects these quantities without an additional hardness theorem or justified cost model. \(\square\)

C1 is therefore the clearest V1 example of why “compact and correct” must not be shortened to “secure.” It is also the example where the proof architecture and implementation arithmetic are closest to a deployable style, making the missing hardness certificate especially visible.

## 16.14. Compatible search, planted recovery, and key recovery are different targets

For a fixed public transcript \(T\), let
\[
\mathcal F(T)=\{x:\operatorname{Pub}(x)=T\}
\tag{16.25}
\]
be the supported fiber, and let \(K(x,T)\) be the key or derived value associated with a compatible secret.

**Proposition 16.14 — Target hierarchy inside a public fiber.** Planted-secret recovery implies compatible search. The converse fails whenever \(|\mathcal F(T)|>1\). Moreover, key recovery can be strictly easier than planted-secret recovery when \(K(\cdot,T)\) is constant on the fiber.

*Proof.* The planted secret belongs to the fiber, so recovering it gives a compatible point. If the fiber has at least two points, an algorithm may return a different compatible point and fail planted recovery. If \(K(x,T)=k_T\) for every \(x\in\mathcal F(T)\), then outputting \(k_T\) recovers the key without identifying which fiber element was planted. \(\square\)

This distinction explains why Chapter 5 focuses on posterior key prediction, Chapter 9's exact-window attack need not recover the original secret, and Chapter 14 reports compatible, planted and key outcomes separately.

## 16.15. Secret-space size is not an attack-work lower bound

The fixed Chapter 14 calibration profile
\[
P=536870923,
\quad Q=511,
\quad d=16,
\quad L=17
\tag{16.26}
\]
uses secret coordinates in \([256,511]\), so the nominal secret space has
\[
256^{16}=2^{128}
\tag{16.27}
\]
points. Chapter 14 publishes three deterministic dimension-16 compatibility fixtures for this profile, but the V1.1 release does not reproduce a secret-recovery algorithm or running time for them.

**Proposition 16.15 — Cardinality alone cannot certify 128 bits of resistance.** The equality (16.27) is a cardinality fact, and corresponds to 128 bits of prior entropy only when the secret is sampled uniformly on that box. It is not a lower bound of \(2^{128}\) operations for public recovery, nor a statement about conditional entropy after observing the transcript.

*Proof.* The size of a domain is an information-theoretic property of the prior support, whereas a computational lower bound quantifies over algorithms for the public problem. No implication from support size alone supplies such a lower bound: efficiently invertible maps can have exponentially large domains. Therefore the statement “\(2^{128}\) candidates” cannot by itself establish “\(2^{128}\) operations.” A concrete security claim requires an attack analysis or a reduction that gives a lower bound in the declared model. \(\square\)

The correct question is the cost of the best applicable attack under a declared model, not the cardinality of a hidden variable viewed in isolation.

## 16.16. Seeded representation is an interface, not information-theoretic independence

Let \(F:\{0,1\}^{\kappa}\to\{0,1\}^{N}\) be deterministic and \(\sigma\) uniform.

**Proposition 16.16 — Public deterministic expansion is maximally recognizable at large output length.**
\[
\operatorname{TV}\bigl((\sigma,F(\sigma)),(\sigma,U_N)\bigr)
=1-2^{-N},
\tag{16.28}
\]
where \(U_N\) is independent uniform.

*Proof.* Condition on \(\sigma\). The first conditional law is a point mass; the second is uniform on \(2^N\) strings, so their distance is \(1-2^{-N}\). Average over the common seed. \(\square\)

Thus the seeded forms of WC or C1 require the generation/oracle model declared in their proofs. The seed can save transmission without making its expansion statistically equivalent to a fresh independent matrix given the seed.

## 16.17. Correctness statements retain their quantifiers under deployment

Let \(d(pk,sk)\) be the maximum honest-decryption failure probability over allowed messages for a fixed generated key, and suppose
\[
\mathbb E[d(pk,sk)]\le\delta.
\tag{16.29}
\]

**Proposition 16.17 — Repeated use and bad-key fractions follow from the same averaged bound.** For \(r\) honest uses with fresh randomness,
\[
\Pr[\text{at least one failure}]\le\min(1,r\delta),
\tag{16.30}
\]
and for every \(\theta>0\),
\[
\Pr[d(pk,sk)>\theta]\le\min(1,\delta/\theta).
\tag{16.31}
\]

*Proof.* Condition on the key and apply the union bound for (16.30), then average. Equation (16.31) is Markov's inequality for the nonnegative random variable \(d(pk,sk)\). \(\square\)

These bounds preserve the original quantifier order. An average over generated keys does not silently become a uniform per-key guarantee, and nonzero \(\delta\) does not become perfect correctness after an FO transform.

## 16.18. Comparative ledger of the V1 constructions

The following table records the strongest conclusion retained in the thesis, not a ranking of “best cryptosystems.” “Conditional” means that a stated source assumption or oracle model remains part of the theorem.

| Object | Strongest retained positive result | Principal negative result or missing obligation |
|---|---|---|
| Scalar interval | Exact agreement analysis; exact posterior inversion | Efficient passive prediction; not confidential |
| P-WINDOW | Exact compatible-window algebra | Common value publicly computable by linear algebra |
| Historical P-ROUND | Exact remainder identities and corrected normalized-counter diagnostics | No imported confidentiality theorem; the printed normalized H0/H1 rules have explicit disagreement and undefined-input witnesses |
| P-REF | Conditional classical-ROM IND-CPA reference | Different distributions/roles from historical P-ROUND; no deployment certificate from V1 |
| WC | Exact binary-LWE embedding; conditional classical-ROM CCA route | Current proof route has severe parameter loss; no certified compact 128-bit profile |
| NOISE | Exact conditional standard-model IND-CPA reduction to HB | HB hardness not founded here; raw CCA2 attack |
| BLINDAGE C1 | Compact payloads; strong nonzero correctness bound; conditional classical-ROM CCA | Two exact source-hardness premises lack concrete certification; no 128-bit deployment claim |

Define the V1 deployment ledger from Chapter 15 by
\[
\mathcal L(\theta)=
(C_{\rm corr},C_{\rm src},C_{\rm red},C_{\rm atk},C_{\rm fmt},C_{\rm impl}).
\tag{16.32}
\]

**Proposition 16.18 — No V1 row closes the deployment ledger.** In the thesis-V1 record, no named MODDIV profile has all six coordinates of (16.32) positively justified at one concrete classical or quantum security target.

*Proof.* Chapter 15 checks each named row against the six obligations. P-REF lacks a V1 concrete deployment certificate; WC lacks compatible compact parameters under the current proof route; NOISE lacks founded HB hardness and CCA for the raw scheme; C1 lacks a concrete certificate for its exact source assumptions and still has only a partial complete-deployment format obligation: its public-key and ciphertext encodings are fixed, while the full secret/decapsulation-state serialization is not. The scalar and historical rows already fail confidentiality or correctness/security obligations earlier in the ledger. \(\square\)

The proposition is documentary and finite: it is about the V1 evidence set, not an impossibility theorem for future MODDIV research.

## 16.19. Six reusable lessons for structured lattice-style design

The thesis supports six rules that survive across the constructions:

1. **Normalize the arithmetic first.** Write quotients, wraps and remainders exactly before introducing probability.
2. **Keep the complete joint law.** Overlapping windows, shared secrets and public side information can invalidate marginal or independence arguments.
3. **Separate correctness from confidentiality.** Agreement, failure probability, entropy and adversarial advantage answer different questions.
4. **Name the target of every attack.** Compatible search, planted recovery, key recovery and distinguishing are not interchangeable.
5. **Carry every reduction loss to the parameters.** An asymptotic reduction can coexist with unusable concrete inequalities.
6. **Treat format and implementation as proof interfaces.** Seeds, canonical encodings, domain separation and decapsulation behavior are part of the construction actually deployed.

**Corollary 16.19 — A sound development order.** A claim of practical security is not justified until the chain
\[
\begin{aligned}
\text{specification}
&\rightarrow\text{correctness}
\rightarrow\text{source hardness}\\
&\rightarrow\text{game reduction}
\rightarrow\text{cryptanalysis}
\rightarrow\text{format/implementation}
\end{aligned}
\tag{16.33}
\]
has been closed for the same named parameter set.

*Justification.* Each arrow corresponds to a distinct failure mode exhibited by at least one row of the comparison table: historical ambiguity, agreement without secrecy, unsupported source hardness, game mismatch, practical lattice recovery, or representation/model mismatch. Closing only a strict subset leaves an identified unresolved obligation. \(\square\)

This order is not claimed as a new universal methodology for cryptography. It is the compact form of what the MODDIV case study repeatedly forced the analysis to distinguish.

## 16.20. What the MODDIV program has established by thesis V1

The research record contains both negative and positive results. The negative results are not merely failed attempts: they identify specific invalid transfers. The positive results are not merely “MODDIV works”: they apply to named descendants under named assumptions.

**Proposition 16.20 — The strongest V1 conclusions are distributed across different constructions.** Within the thesis record:

- the scalar line supplies exact agreement mathematics and an efficient passive-prediction obstruction;
- the polynomial line separates exact-window algebra, historically rounded windows and the published P-REF security reference;
- the distributional line supplies exact lift and Rényi tools without silently founding a new hard source;
- WC supplies the clearest exact binary-LWE embedding but exposes a concrete proof-budget barrier;
- NOISE supplies the clearest standard-model CPA reduction but retains an unfounded HB assumption and a raw CCA2 break;
- among the concrete WC and C1 snapshots explicitly compared, BLINDAGE C1 supplies the smaller public/ciphertext payload and a strong correctness bound, while concrete source hardness remains open;
- the attack and parameter chapters show that neither large secret spaces nor successful reductions alone complete a deployment argument.

No single row simultaneously inherits all of these strongest properties.

*Proof.* Each bullet is the scoped conclusion of Chapters 5–15 and is recorded in the comparison ledger above. Proposition 16.1 forbids transferring the remaining properties merely because the constructions share arithmetic or structure. \(\square\)

The scientific value of V1 is therefore not a final declaration that one historical protocol is secure. It is a mapped landscape: exact statements of where quotient extraction helps, where structure leaks exploitable information, where distributions block a reduction, where explicit noise repairs a proof interface, where an active attack survives, and where compact parameters outrun the current hardness evidence.

Chapter 17 can now close the thesis by classifying the unresolved questions rather than reopening them. The most important future problems are already visible: an externally founded structured source for NOISE or a proved bridge to a standard assumption; better concrete losses for WC or a different proof route; concrete hardness analysis for C1's exact sources; a disciplined treatment of signed/centered historical secrets; and a clean separation between historical preservation and newly engineered descendants. Those are research directions, not results silently completed here.

## 16.21. Reproducibility and verification package

The Chapter 16 package is a machine-readable comparison-ledger check, not a replay of the construction chapters. `verify.py` reads the seven-row ledger and verifies that no row has all six declared obligations marked complete. `verify_independent.py` reconstructs, for every row, the list of missing obligations and checks that each row has at least one. File hashes establish byte identity only; they do not certify the scientific truth of a ledger label.

The package does **not** independently enumerate quotient decompositions, Toeplitz laws, seed-expansion distances, Markov bounds, historical cryptanalysis, HB/Module-LWE hardness or security-scale BKZ. Those broader claims are therefore not attributed to these scripts. Run `python3 verify.py` and `python3 verify_independent.py` locally, or `python3 verify_repository.py --jobs 4` from the repository root.

### Attribution boundary

The elementary quotient decomposition, total-variation calculation, hybrid triangle inequality, union bound and Markov inequality are classical. Most construction-specific claims in this chapter are explicitly imported from earlier thesis chapters and are not presented as new inventions. The contribution of Chapter 16 is the cross-construction organization, the exact separation of transferable and nontransferable claims, and the consolidated evidence ledger. No exhaustive novelty or priority claim is made.



## Supplementary Material and Reproducibility — Chapter 16

The public supplementary material for this chapter is assigned to `supplementary/chapter-16/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Chapter 17 — Conclusions, Open Problems, and Research Directions {#ch17}
## What Is Established, What Remains Conditional, and What Thesis V2 May Test


**Scope.** This chapter classifies the existing record. It introduces no new cryptosystem, hardness theorem, deployment parameter set or completed thesis-V2 reduction. No external peer review, proof-assistant certification or concrete 128-bit security certificate is claimed.

### Abstract

This final chapter answers the thesis question by separating what has been established from what remains conditional. The central arithmetic primitive, modular reduction followed by integer quotient extraction, is mathematically tractable but has no security meaning in isolation. In the scalar branch, exact agreement theorems coexist with efficient passive key prediction, showing that correctness and secrecy are logically distinct. In the polynomial branch, exact compatible windows preserve useful bilinear identities but can make the derived common value publicly computable; historical rounded windows therefore require their own distributional analysis rather than inheriting a theorem by resemblance. The general distributional theory identifies the discarded remainder as a correlated latent variable and gives an exact criterion for randomized lifting only after conditioning on the complete public view. P-REF supplies a published conditional CPA reference. WC supplies an exact binary-LWE embedding and a conditional classical-ROM CCA route, but its present proof inequalities impose a severe necessary payload barrier at a target exponent 128. NOISE supplies an exact two-transition standard-model CPA reduction to a named binary-secret Hankel source while retaining an explicit raw CCA2 attack. BLINDAGE C1 supplies compact public payloads, a strong nonzero correctness bound, and a conditional classical-ROM CCA route under two exact source assumptions, but concrete hardness and complete deployment formatting remain unfinished. The thesis therefore closes without selecting a deployment winner. Its principal scientific output is a map of exact arithmetic, distributions, proof interfaces, attack targets, and failure modes. Seven open problems define a disciplined thesis-V2 agenda, including structured source hardness, signed-secret recentering with carry-aware rounding, a possible middle-product bridge, improved WC proof losses, concrete C1 hardness, stronger cryptanalysis and formal verification, and external validation.

### Scope and closure boundary

The preceding thesis chapters are Chapters 1–16 (Chapters 1–3; Chapter 4; Chapter 5; Chapter 6; Chapter 7; Chapter 8; Chapter 9; Chapter 10; Chapter 11; Chapter 12; Chapter 13; Chapter 14; Chapter 15; Chapter 16). Chapter 16 provides the immediate comparative synthesis for this chapter. Earlier constructions retain their own names, distributions, security games and stated scopes. The chapter does not retroactively merge SCALAR-INTERVAL, P-WINDOW, P-ROUND, P-REF, WC, NOISE and BLINDAGE C1 into one scheme.

Whenever a numerical or security statement below is imported, its scope is inherited exactly from the cited chapter. The open problems are specifications of future work, not claims that the corresponding reductions, parameters or security levels already exist. In particular, signed-secret recentering and a direct HB/MP-LWE bridge belong to a possible thesis V2 and are not used to strengthen any V1 theorem.

## 17.1. The thesis question has a conditional, construction-specific answer

For positive integers \(P,Q\), define
\[
F_{P,Q}(z)=\left\lfloor\frac{[z]_P}{Q}\right\rfloor,
\qquad [z]_P\in\{0,\ldots,P-1\}.
\tag{17.1}
\]
A complete cryptographic construction using this map is described by the data
\[
\Theta=(\mathcal A,\mathcal D_{\rm pub},\mathcal D_{\rm sec},\mathcal D_{\rm err},
\mathsf{Rec},\mathsf{Fmt},\mathsf{Game}).
\tag{17.2}
\]

**Conclusion 17.1 — Quotient extraction is a primitive, not a security assumption.** The thesis does not establish a theorem of the form “modular reduction followed by integer division is hard.” Security results arise only for named constructions after their joint distributions, correctness rules, source assumptions and adversarial games have been fixed.

*Justification.* Chapters 5–16 exhibit constructions sharing (17.1) but having incompatible outcomes: efficient passive prediction in the scalar model, public predictability for exact polynomial windows, conditional CPA/CCA theorems for engineered descendants, and active attacks against unwrapped variants. A property common to all rows cannot by itself imply mutually contradictory security conclusions. \(\square\)

This is the final answer to the central question posed in Chapter 1: quotient extraction can participate in provable cryptography, but only inside a fully specified construction whose proof obligations are separately discharged.

## 17.2. Exact quotient/remainder geometry is the stable mathematical core

For a quotient label \(u\), let
\[
I_u=\{Qu,\ldots,\min(Q(u+1)-1,P-1)\},
\qquad \omega_u=|I_u|.
\tag{17.3}
\]
For every integer \(z\), the quotient \(U=F_{P,Q}(z)\) determines unique integers \(K,R\) such that
\[
z=PK+QU+R,
\qquad 0\le R<\omega_U.
\tag{17.4}
\]

**Conclusion 17.2 — Carries, wraps and remainders must remain explicit until a distribution theorem removes them.** The exact normal form (17.4) survives every branch of the thesis, whereas independence assumptions about \(R\) do not.

*Justification.* The scalar agreement analysis, polynomial window identities, distributional lifting, lattice formulations and attack models all use the same Euclidean decomposition. Chapter 8 and Chapter 16 give explicit counterexamples to treating the discarded remainder as an independent error solely because it is bounded. \(\square\)

The methodological consequence is simple: the correct abstraction is not “division adds noise,” but “division hides a bounded latent variable whose conditional law must be proved.”

## 17.3. The scalar branch is mathematically successful and cryptographically negative

In the full-range binary scalar model of Chapter 6,
\[
\Pr[W_A=W_B]\ge
c_*:=\frac{166397}{221184}>\frac34.
\tag{17.5}
\]
Chapter 5 simultaneously gives a passive posterior predictor satisfying
\[
\Pr[W^*=W_B]=\Pr[W_A=W_B].
\tag{17.6}
\]
For the exact seven-bit upper-half support,
\[
\Pr[W_A=W_B]
=\frac{12540509}{16777216}<\frac34.
\tag{17.7}
\]
Chapter 7 further proves that, along the aligned family $P=J(Q)Q^2$ with integer $J(Q)\ge2$ and $Q\to\infty$, agreement tends to
\[
\frac{41}{54},
\tag{17.8}
\]
while nonaligned families can violate a uniform three-quarters claim.

**Conclusion 17.3 — Agreement theory is a correctness theory, not a secrecy theory.** The scalar branch produces exact positive results about agreement and exact negative results about confidentiality; neither invalidates the other.

*Justification.* Equation (17.6) shows that an eavesdropper can match the honest agreement probability in the same scalar experiment. Equation (17.7) shows that even the agreement constant depends on the secret support. Thus neither high agreement nor a particular universal-looking constant can serve as a security surrogate. \(\square\)

This separation is one of the most reusable lessons of the thesis.

## 17.4. Polynomial structure preserves algebra and can also preserve attack information

The polynomial chapters distinguish three different roles. P-WINDOW uses exact compatible windows; P-ROUND is the historical rounded object; P-REF is a published middle-product rounding reference construction with its own distributions and theorem.

For a commutative coefficient ring, \(n\ge0\), \(m>2n\), and \(\deg X,\deg Y\le n\), Chapter 9 establishes the exact compatible-window identity
\[
C_{m,2n}\!\left(z^nX\,C_{m,n}(AY)\right)
=C_{m,2n}(AXY)
=C_{m,2n}\!\left(z^nY\,C_{m,n}(AX)\right).
\tag{17.9}
\]
The factors \(z^n\) are essential because \(C_{m,n}\) shifts the retained coefficients down by \(n\) degrees. Equation (17.9) is the polynomial notation for the \(B_x,B_y\) operators of Chapter 9, not a schematic omission of that shift.

The same exactness can allow a public linear-system solution to compute the desired common value without recovering the planted secret.

For the historical trailing-bit procedure, Chapter 9 also preserves the printed normalization
\[
\widetilde R_i=\left\lfloor R_i/n\right\rfloor
\]
before the local bit counter. Exact witnesses show that the two normalized H0/H1 readings can disagree, and inputs with \(0\le R_i<n\) make the printed unbounded counter undefined. These are correctness/specification defects of that historical rule, not a confidentiality theorem for every rounded polynomial construction.

**Conclusion 17.4 — Exact algebraic compatibility does not imply computational hardness.** P-WINDOW is useful as an algebraic reference but cannot obtain confidentiality merely from the existence of a common exact window. P-ROUND cannot inherit P-REF security by commutativity or by renaming the factors.

*Justification.* The exact-window common value factors through the published linear map, so a compatible public solution suffices. Rounding changes the inverse problem by introducing hidden cell remainders, but Chapters 8–9 show that this requires a new distributional proof rather than a transfer by similarity. P-REF's theorem remains tied to its published roles and laws. \(\square\)

## 17.5. The complete public view is part of every distributional statement

In the finite lifting experiment of Chapter 8, let \(C\) denote all public side information, \(Z\) an unrounded vector and \(U=F(Z)\) its valid quotient labels. If \(\widetilde Z\) is sampled uniformly from the full product cell \(I_U\), Chapter 8 gives
\[
\operatorname{TV}(\mathcal L(C,Z),\mathcal L(C,\widetilde Z))
=
\sum_{c,u}\Pr[C=c,U=u]
\operatorname{TV}\!\left(\mathcal L(Z\mid c,u),\operatorname{Unif}(I_u)\right).
\tag{17.10}
\]

**Conclusion 17.5 — Exact randomized lifting is a conditional statement about the whole transcript.** Uniformity inside quotient cells before additional public information is revealed does not suffice if that information changes the conditional law.

*Justification.* Equation (17.10) is zero exactly when every positive-probability conditional law is uniform on its full cell after conditioning on all of \(C\). Omitting a public variable can therefore turn an exact-looking lift into a different joint distribution. \(\square\)

The same principle applies to overlapping Hankel windows and shared secrets: matching marginals is not matching the joint experiment.

## 17.6. WC proves an exact embedding and exposes a proof-efficiency barrier

WC changes the historical secret law and dimensions. Its unit anchor yields an exact binary-LWE embedding in the auxiliary distribution used by the proof, followed by residual hashing and a conditional classical-ROM CCA composition.

The parameter analysis also proves that, under the current displayed proof inequalities and a favorable relaxation at target exponent \(\tau=128\), a necessary payload is at least
\[
37\,810\,176\ \text{bits}
=4\,726\,272\ \text{bytes}.
\tag{17.11}
\]

**Conclusion 17.6 — An exact asymptotic reduction can coexist with an unusable current concrete proof route.** Equation (17.11) is neither a lower bound on every WC variant nor an attack; it is evidence that the present loss accounting cannot certify a compact target at the chosen exponent.

*Justification.* Chapter 10 proves exactness of the distributional embedding, while Chapters 13–16 propagate the proof losses to the parameter inequalities. Dropping nonnegative loss terms only relaxes the requirements, so failure of the relaxed route is a genuine diagnostic of that proof architecture. \(\square\)

## 17.7. NOISE separates source reduction from active security

For the NOISE construction, Chapter 11 and corrected Chapter 16 give two distinguishers \(\mathcal B_0,\mathcal B_1\) for the same binary-secret noncyclic Hankel source:
\[
\operatorname{Adv}_{\rm CPA}(\mathcal A)
\le
\operatorname{Adv}_{\rm HB}(\mathcal B_0)
+
\operatorname{Adv}_{\rm HB}(\mathcal B_1).
\tag{17.12}
\]
The shared secret and the joint public structure are preserved across the two transitions. Independently, a public ciphertext translation gives a CCA2 attack on the unwrapped encryption under the stated strict-margin condition.

**Conclusion 17.7 — A correct conditional CPA reduction does not answer source hardness or CCA security.** NOISE has a clean standard-model reduction interface, but V1 neither derives HB hardness from a standard lattice problem nor repairs the raw chosen-ciphertext attack.

*Justification.* The source assumption is a premise of (17.12), not its conclusion. CPA and CCA2 are different games, so an attack using a decryption oracle does not contradict the CPA reduction. \(\square\)

This is a positive result about proof architecture and a negative result about the unwrapped security level at the same time.

## 17.8. BLINDAGE C1 is the smaller concrete WC/C1 payload snapshot compared in V1, not a deployment certificate

For the fixed C1-P12-CBD1 profile,
\[
R=\mathbb Z_{4096}[x]/(x^{256}+1),
\qquad k=3,
\qquad Q=4,
\qquad C=2.
\tag{17.13}
\]
Its public payloads are
\[
|pk|=993\ \text{bytes},
\qquad |ct|=1408\ \text{bytes},
\tag{17.14}
\]
and the averaged worst-message correctness failure satisfies
\[
2^{-6400}\le\delta<2^{-282}.
\tag{17.15}
\]
The conditional classical-ROM CCA route depends on two exact Module-LWE source interfaces. The full secret/decapsulation-state byte format is not fixed by the two public payload numbers.

**Conclusion 17.8 — Compactness, correctness and conditional CCA composition do not together certify concrete hardness.** Among the concrete WC and C1 payload snapshots compared in V1, C1 has the smaller public-key and ciphertext payloads; this does not minimize payload over either entire parameter family or rank their concrete security. Its exact source assumptions still require concrete and externally grounded hardness analysis.

*Justification.* Equations (17.14)–(17.15) are format and correctness facts. The security reduction is conditional on source problems whose concrete cost is not certified by V1. A deployment statement would require these distinct obligations to hold simultaneously for the same parameter set. \(\square\)

## 17.9. Secret-space cardinality is not attack work

The fixed Chapter 14 calibration profile with
\[
P=536870923,
\quad Q=511,
\quad d=16,
\quad L=17,
\tag{17.16}
\]
uses secret coordinates in \([256,511]\), hence the prior support has
\[
256^{16}=2^{128}
\tag{17.17}
\]
points. Chapter 14 publishes three deterministic compatibility fixtures on that fixed profile but makes no reproducible secret-recovery timing claim for them in V1.1.

**Conclusion 17.9 — A \(2^{128}\)-element secret domain is not a 128-bit security certificate.** Structured public constraints may admit algorithms that do not enumerate the secret space, and domain cardinality alone gives no computational lower bound.

*Justification.* Exhaustive search is only one possible algorithm. A computational security claim must analyze the best relevant attacks or inherit a justified hardness reduction for the actual public distribution. The logarithm of the prior support, by itself, supplies neither. \(\square\)

## 17.10. Thesis V1 closes without a deployment winner

The deployment ledger introduced in Chapter 15 is
\[
\mathcal L(\theta)=
(C_{\rm corr},C_{\rm src},C_{\rm red},C_{\rm atk},C_{\rm fmt},C_{\rm impl}).
\tag{17.18}
\]
Its coordinates respectively record correctness, source-hardness evidence, reduction/game evidence, attack coverage, canonical formatting and implementation evidence for the same named parameter set.

**Conclusion 17.10 — No V1 profile closes all six obligations at a common concrete security target.** This is the final deployment verdict of the thesis.

*Justification.* Chapters 15–16 record the missing obligations row by row. Scalar and historical branches fail confidentiality or correction/security requirements. P-REF supplies a conditional reference but no V1 deployment certificate. WC lacks compact parameters under its current proof route. NOISE lacks a founded HB source and raw CCA security. C1 lacks concrete certification of its exact source assumptions and a complete deployment serialization. None of these facts is an impossibility theorem for future research. \(\square\)

The absence of a winner is not the absence of results. It is the consequence of applying the same evidentiary standard to every row.

## 17.11. Open Problem A — Ground the HB source or prove an obstruction

NOISE currently rests on the decisional binary-secret noncyclic Hankel source \(\mathsf{HB}(M,d,2n,\chi)\). A future hardness theorem must preserve the public Hankel law, the shared secret across the two public segments, the exact secret distribution, and the error law used by the simulator.

**Open Problem 17.11.** Establish one of the following:

1. a probabilistic polynomial-time reduction from a recognized hard source to the exact HB family used by NOISE, with explicit advantage and resource loss; or
2. a mathematically precise obstruction showing why a proposed standard-source reduction cannot preserve one of the required laws.

A useful hardness reduction must quantify over every PPT HB distinguisher \(\mathcal B\), construct a PPT source distinguisher \(\mathcal C\) within explicit polynomial resource overhead, and state a bound of the form
\[
\operatorname{Adv}_{\rm HB}(\mathcal B)
\le f\bigl(\operatorname{Adv}_{\rm source}(\mathcal C),\lambda\bigr),
\tag{17.19}
\]
where the stated loss preserves negligibility: a negligible source advantage must force a negligible right-hand side. An explicit but useless choice such as a constant \(f\equiv1\) does not ground HB hardness. Visual similarity of Hankel products to ordinary LWE samples is not a substitute for these quantifiers and resource bounds.

## 17.12. Open Problem B — Recenter positive historical secrets without hiding the carries

For the historical exact-\(q\)-bit interval and \(q\ge2\), put
\[
B=2^{q-2},
\qquad c=3B.
\tag{17.20}
\]
Then every coefficient
\[
X_i\in[2^{q-1},2^q-1]=[2B,4B-1]
\tag{17.21}
\]
has the exact signed representation
\[
X_i=c+S_i,
\qquad S_i\in[-B,B-1].
\tag{17.22}
\]
Thus, for a vector secret,
\[
AX=A S+cA\mathbf 1.
\tag{17.23}
\]
The affine offset is public when \(A\) is public. The obstacle is that quotient extraction is not additive:
\[
F_{P,Q}(AS+cA\mathbf1)
\ne
F_{P,Q}(AS)+F_{P,Q}(cA\mathbf1)
\quad\text{in general}.
\tag{17.24}
\]

**Open Problem 17.12.** Characterize the exact carry/remainder correction induced by the public affine recentering (17.23), and determine whether the resulting signed-secret observation is exactly simulable from a standard structured source with controlled loss.

This formulation preserves the historical positive secret entropy instead of silently replacing it by a new centered distribution. A negative result identifying an unavoidable secret-dependent carry obstruction would also resolve the problem in a useful way.

## 17.13. Open Problem C — Determine whether the Hankel algebra admits a middle-product hardness bridge

The noncyclic Hankel map is algebraically a window of convolution, and the middle-product literature provides a natural language for such windows. V1 nevertheless shows that algebraic resemblance is insufficient because public/secret roles, lengths, conditioning and rounding laws differ.

**Open Problem 17.13.** To ground HB hardness, construct a reduction that transforms any efficient distinguisher for the HB source used by NOISE into an efficient distinguisher for an appropriate recognized-hard MP-LWE/MP-LWR-style source, with explicit resource and advantage loss; or give a counterexample demonstrating that a specified proposed interface cannot match the required transcript laws under the stated parameter regime.

The acceptance criterion is not an identity of matrices. It is equality or quantitatively controlled distance of the **complete joint transcript**, including shared secrets and all public side information. An obstruction applies only to the interface it actually refutes; it is not automatically an impossibility theorem for every conceivable bridge.

## 17.14. Open Problem D — Repair the WC concrete proof budget without weakening the game

The current WC proof route is exact but produces the necessary barrier (17.11). Possible research directions include a tighter extraction argument, different residual hashing, different query accounting, or a separately named parameterization that preserves the proof interfaces while reducing the loss.

**Open Problem 17.14.** Produce either:

- a revised proof for a clearly named WC construction whose complete inequalities admit practical payloads at a declared target advantage; or
- a proof-specific impossibility/optimization theorem explaining why the present architecture necessarily incurs a large payload.

A smaller key obtained by deleting proof terms without a theorem is not a solution. A new construction is acceptable only if it is named as such and its distribution is analyzed independently.

## 17.15. Open Problem E — Convert C1 from a conditional snapshot into a concrete parameter claim

C1 already supplies exact arithmetic, compact public payloads, a correctness certificate and a conditional CCA route. The remaining gap is not one number but a chain of evidence.

**Open Problem 17.15.** For one fixed C1-style parameter set, complete all of the following without changing the source laws silently:

1. specify the full secret-key and decapsulation-state serialization;
2. analyze the two exact source problems with current primal, dual and hybrid lattice attacks;
3. state classical and, if claimed, quantum cost models separately;
4. propagate the source bounds through the full CCA reduction;
5. validate the implementation/format assumptions used by the proof.

Only after this chain closes can a concrete bit-security label be discussed.

## 17.16. Open Problem F — Extend independent validation

The thesis contains exact proofs, independent scripts and finite exhaustive checks. These are useful forms of evidence, but they are not substitutes for external review or formal verification.

**Open Problem 17.16.** Strengthen the validation stack in three independent directions:

- formalize selected high-value statements, beginning with the scalar agreement theorem and its finite closure, in Lean 4 or another proof assistant;
- rerun lattice cryptanalysis at larger dimensions with reference implementations such as fplll/fpylll, explicit BKZ parameters, reproducible hardware/software records and held-out instances;
- submit the principal mathematical and cryptographic claims to external expert review and state the peer-review status explicitly.

Historical provenance questions identified in Chapter 4 should be resolved through primary documents rather than by mathematical reconstruction alone.

## 17.17. Open Problem G — Thesis V2 must preserve the V1 boundary

A future thesis V2 may be more ambitious because V1.1 fixes a clearly delimited baseline. Its central candidate themes are signed-secret recentering, HB/MP-LWE or HB/MP-LWR bridges, stronger source-hardness reductions, improved proof losses, later BLINDAGE snapshots and deeper cryptanalysis.

**Open Problem 17.17 — V2 research contract.** A V2 claim should enter the permanent record only if it satisfies the following minimum discipline:
\[
\begin{aligned}
&\text{named construction or problem}\rightarrow
\text{exact joint law}\rightarrow
\text{proof or counterexample}\rightarrow\\
&\text{reproducible evidence}\rightarrow
\text{explicit scope and loss}.
\end{aligned}
\tag{17.25}
\]
No V2 theorem may be cited as if it had repaired a historical V1 construction unless an explicit equivalence or reduction is proved.

This condition protects both directions of the research program: positive results remain meaningful because their hypotheses are visible, and negative results remain useful because their target is precisely identified.

## 17.18. Final conclusion

The MODDIV program began from an unusually simple operation: multiply, reduce modulo an integer, and divide. The thesis shows that the simplicity of the operation is deceptive. Quotient cells introduce carries and latent remainders; polynomial structure creates overlapping correlations; public structure can simultaneously support efficient implementation, exact proof simulation and effective cryptanalysis. Security depends not on the presence of rounding or lattices as labels, but on the complete distribution and game.

The strongest result of thesis V1 is therefore not a single victorious parameter set. It is a disciplined separation of claims. The record contains exact agreement theorems, exact inversion algorithms, explicit counterexamples, distributional criteria, conditional reductions, active attacks, parameter barriers, compact conditional constructions and reproducible cryptanalysis. It also records where those results stop.

This is a scientifically useful endpoint. A future secure descendant, if one is found, will not need to erase the negative results. It will need to satisfy them. A future impossibility or obstruction result would be equally valuable if it explains why one of the remaining bridges cannot exist.

The final thesis verdict can be summarized as
\[
\boxed{
\text{MODDIV is not one security theorem; it is a mapped research landscape.}
}
\tag{17.26}
\]
The next stage is not to declare that landscape solved, but to choose one open bridge, preserve its exact laws, and either cross it with a reduction or close it with a proof of obstruction.

## 17.19. Reproducibility and final-chapter package

This final chapter uses a small consistency layer. `verify.py` checks results from Chapters 9–12 used in the conclusion, requires the exact compatible-window statement (17.9) to occur in its stated form, and evaluates that identity on explicit finite polynomial regressions. `verify_independent.py` repeats the core constants without importing the primary verifier and performs a separately written direct-convolution check of (17.9), including the small witness \(n=1,m=4,A=1,X=Y=z\) over \(\mathbb F_3\). Replacing the central term in (17.9) by \(2C_{m,2n}(AXY)\) therefore makes both verification paths fail.

The package does not claim to rerun source-hardness experiments, security-scale BKZ, all construction-level tests, or a proof assistant. The manually populated deployment conclusions remain constrained by the cited technical chapters; the final-chapter scripts are consistency regressions, not independent security proofs.

Run locally with

```sh
python3 verify.py
python3 verify_independent.py
```

and use `python3 verify_repository.py --jobs 4` at repository root for manifest checking plus all chapter-local verifiers. The release documentation names only entry points that are present in the archive.

### Attribution boundary

Classical Euclidean division, conditional probability, total variation, Rényi divergence, linear algebra, lattice reduction terminology, union bounds and game-hybrid accounting are not claimed as inventions of this thesis. The contribution claimed by this final chapter is the organization of the verified V1 record into a closure statement and a set of falsifiable future research obligations. No claim of worldwide priority is made for that organization.



## Supplementary Material and Reproducibility — Chapter 17

The public supplementary material for this chapter is assigned to `supplementary/chapter-17/` in the repository release associated with this thesis. The associated release contains the executable checks, exact computations, parameters, counterexamples and test vectors provided for this chapter, together with a chapter-local `README.md` and SHA-256 manifest. Essential theorem statements and proofs remain in the thesis; the supplementary files support reproduction and independent checking rather than replace the mathematical argument.

# Consolidated public bibliography {#bibliography}

Only public works are scientific references in this bibliography. Their use is limited by the hypotheses and source-use qualifications stated in the chapters.

### B01 {#bib-b01}

O. Regev, “On Lattices, Learning with Errors, Random Linear Codes, and Cryptography,” *Journal of the ACM* 56(6), Article 34, 2009.

Public record: <https://cims.nyu.edu/~regev/papers/qcrypto.pdf>.

### B02 {#bib-b02}

A. Banerjee, C. Peikert, and A. Rosen, “Pseudorandom Functions and Lattices,” *EUROCRYPT 2012*, LNCS 7237, pp. 719–737, 2012.

Public record: <https://eprint.iacr.org/2011/401>.

### B03 {#bib-b03}

C. Peikert, “A Decade of Lattice Cryptography,” *Foundations and Trends in Theoretical Computer Science* 10(4), pp. 283–424, 2016.

Public record: <https://eprint.iacr.org/2015/939>.

### B04 {#bib-b04}

D. Micciancio and O. Regev, “Lattice-based Cryptography,” in *Post-Quantum Cryptography*, Springer, pp. 147–191, 2009.

Public record: <https://cseweb.ucsd.edu/~daniele/papers/PostQuantum.html>.

### B05 {#bib-b05}

Y. Dodis, R. Ostrovsky, L. Reyzin, and A. Smith, “Fuzzy Extractors: How to Generate Strong Keys from Biometrics and Other Noisy Data,” *SIAM Journal on Computing* 38(1), pp. 97–139, 2008. (Average conditional min-entropy; see Section 2.4.)

Public record: <https://doi.org/10.1137/060651380>.

### B06 {#bib-b06}

T. M. Cover and J. A. Thomas, *Elements of Information Theory*, 2nd ed., Wiley, 2006.

Public record: <https://doi.org/10.1002/047174882X>.

### B07 {#bib-b07}

R. A. Horn and C. R. Johnson, *Matrix Analysis*, 2nd ed., Cambridge University Press, print 2012 / electronic 2013.

Public record: <https://doi.org/10.1017/CBO9781139020411>.

### B08 {#bib-b08}

D. Bini and V. Pan, *Polynomial and Matrix Computations, Vol. 1: Fundamental Algorithms*, Birkhäuser, 1994.

Public record: <https://doi.org/10.1007/978-1-4612-0265-3>.

### B09 {#bib-b09}

S. Bai, K. Boudgoust, D. Das, A. Roux-Langlois, W. Wen, and Z. Zhang, “Middle-Product Learning with Rounding Problem and Its Applications,” *ASIACRYPT 2019*, Part I, LNCS 11921, pp. 55–81, 2019. DOI: 10.1007/978-3-030-34578-5_3. Cryptology ePrint Archive, Paper 2019/1001. <https://eprint.iacr.org/2019/1001>

Public record: <https://doi.org/10.1007/978-3-030-34578-5_3>.

### B10 {#bib-b10}

S. Bouftass and A. Azhari, *On a new fast public key cryptosystem*, IACR Cryptology ePrint Archive, Report 2014/946; received 19 November 2014. <https://eprint.iacr.org/2014/946>

### B11 {#bib-b11}

S. Bouftass, *On a new fast public key cryptosystem*, arXiv:1508.07756v1, 31 August 2015. <https://arxiv.org/pdf/1508.07756v1>

Public record: <https://arxiv.org/abs/1508.07756v1>.

### B12 {#bib-b12}

S. Bouftass, *On a new fast public key cryptosystem*, arXiv:1508.07756v2, 24 April 2021. <https://arxiv.org/pdf/1508.07756v2>

Public record: <https://arxiv.org/html/1508.07756v2>.

### B13 {#bib-b13}

Y. Zhang, *A practical attack to Bouftass's cryptosystem*, arXiv:1605.00987v1, 3 May 2016. <https://arxiv.org/abs/1605.00987>

Public record: <https://arxiv.org/pdf/1605.00987>.

### B14 {#bib-b14}

S. Bouftass, *Multidimentional ModDiv public key exchange protocol*, IACR Cryptology ePrint Archive, Report 2021/701. <https://eprint.iacr.org/2021/701> (used only within the scope stated in this thesis).

### B15 {#bib-b15}

DBLP, *Samir Bouftass* bibliography record, <https://dblp.org/pid/148/1583.html> (consulted 7 November 2026).

### B16 {#bib-b16}

M. Barcau, V. Paşol, C. Pleşca, and M. Togan, *On a Key Exchange Protocol*, in P. Farshim and E. Simion (eds.), *Innovative Security Solutions for Information Technology and Communications*, SecITC 2017, LNCS 10543, Springer, pp. 187–199, 2017. <https://doi.org/10.1007/978-3-319-69284-5_13> . Publisher metadata verified; the article's technical proofs have not been independently verified here.

### B17 {#bib-b17}

Hendrik W. Lenstra, Jr., *Integer Programming with a Fixed Number of Variables*, *Mathematics of Operations Research* 8(4), pp. 538–548, 1983. DOI: <https://doi.org/10.1287/moor.8.4.538>.

### B18 {#bib-b18}

AtCoder Library contributors, *Math — floor_sum*, official documentation and implementation, accessed 7 November 2026. <https://atcoder.github.io/ac-library/master/document_en/math.html>; <https://github.com/atcoder/ac-library/blob/master/atcoder/internal_math.hpp>.

### B19 {#bib-b19}

Joël Alwen, Stephan Krenn, Krzysztof Pietrzak, and Daniel Wichs, *Learning with Rounding, Revisited: New Reduction, Properties and Applications*, CRYPTO 2013, Part I, LNCS 8042, pp. 57–74. DOI: <https://doi.org/10.1007/978-3-642-40041-4_4>. Official preprint record: <https://eprint.iacr.org/2013/098>.

### B20 {#bib-b20}

Terence Tao, *254B, Notes 1: Equidistribution of polynomial sequences in tori*, 28 March 2010, Section 1, Proposition 1 and its proof. Author's course notes, consulted 8 November 2026. <https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/>.

### B21 {#bib-b21}

Tim van Erven and Peter Harremoës, *Rényi Divergence and Kullback–Leibler Divergence*, IEEE Transactions on Information Theory 60(7), 3797–3820, 2014. DOI: <https://doi.org/10.1109/TIT.2014.2320500>. Author manuscript: <https://arxiv.org/abs/1206.2459>.

Public record: <https://timvanerven.nl/assets/publications/2014/Renyi-errata-2024-4-2.pdf>.

### B22 {#bib-b22}

Leonard Schuchman, *Dither Signals and Their Effect on Quantization Noise*, IEEE Transactions on Communication Technology 12(4), 162–165, 1964. DOI: <https://doi.org/10.1109/TCOM.1964.1088973>.

### B23 {#bib-b23}

Katharina Boudgoust, *Theoretical Hardness of Algebraically Structured Learning With Errors*, doctoral thesis, Université de Rennes 1, defended 16 November 2021. Author's PDF: <https://katinkabou.github.io/Documents/Thesis_Boudgoust_Final.pdf>.

### B24 {#bib-b24}

Dennis Hofheinz, Kathrin Hövelmanns, and Eike Kiltz, *A Modular Analysis of the Fujisaki–Okamoto Transformation*, TCC 2017; corrected full version dated 2 November 2021, Cryptology ePrint 2017/604. <https://eprint.iacr.org/2017/604>.

Public record: <https://eprint.iacr.org/2017/604.pdf>.

### B25 {#bib-b25}

Zvika Brakerski, Adeline Langlois, Chris Peikert, Oded Regev, and Damien Stehlé, *Classical Hardness of Learning with Errors*, STOC 2013; arXiv:1306.0281v1. <https://arxiv.org/abs/1306.0281>; primary HTML: <https://arxiv.org/html/1306.0281v1>. Theorem 4.1 and the modulus-switching discussion were consulted for the source/binary-dimension distinction. Their entire worst-case chain is not re-proved here, and (10.47) is not its complete hypothesis list.

### B26 {#bib-b26}

Andrej Bogdanov, Siyao Guo, Daniel Masny, Silas Richelson, and Alon Rosen, *On the Hardness of Learning with Rounding over Small Modulus*, TCC 2016-A; Cryptology ePrint 2015/769, <https://eprint.iacr.org/2015/769>.

### B27 {#bib-b27}

Miruna Roşca, Amin Sakzad, Ron Steinfeld, and Damien Stehlé, *Middle-Product Learning With Errors*, Cryptology ePrint Archive, Paper 2017/628; CRYPTO 2017. <https://eprint.iacr.org/2017/628>.

### B28 {#bib-b28}

Joppe Bos, Léo Ducas, Eike Kiltz, Tancrède Lepoint, Vadim Lyubashevsky, John M. Schanck, Peter Schwabe, Gregor Seiler, and Damien Stehlé, *CRYSTALS — Kyber: a CCA-secure module-lattice-based KEM*, ePrint 2017/634; EuroS&P 2018. DOI: 10.1109/EuroSP.2018.00032. <https://eprint.iacr.org/2017/634>.

### B29 {#bib-b29}

Jan-Pieter D'Anvers, Angshuman Karmakar, Sujoy Sinha Roy, and Frederik Vercauteren, *Saber: Module-LWR based key exchange, CPA-secure encryption and CCA-secure KEM*, AFRICACRYPT 2018, ePrint 2018/230. <https://eprint.iacr.org/2018/230>.

### B30 {#bib-b30}

Tabitha Ogilvie, *On the Concrete Hardness Gap Between MLWE and LWE*, ePrint 2026/279. <https://eprint.iacr.org/2026/279>. This earlier record was later merged, together with ePrint 2026/366, into the CRYPTO 2026 publication listed as [B35](#bib-b35).

### B31 {#bib-b31}

Victor Shoup, *Sequences of Games: A Tool for Taming Complexity in Security Proofs*, author version dated 18 January 2006; first public version 30 November 2004, ePrint 2004/332. <https://shoup.net/papers/games.pdf>.

### B32 {#bib-b32}

SymPy documentation, *DomainMatrix: lll and lll_transform*. <https://docs.sympy.org/latest/modules/polys/domainmatrix.html>.

### B33 {#bib-b33}

SciPy documentation, *scipy.optimize.milp*. <https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.milp.html>.

### B34 {#bib-b34}

Lattice Estimator project, *Introduction*. <https://lattice-estimator.readthedocs.io/en/latest/readme_link.html>.

### B35 {#bib-b35}

Jianhua Hou, Haodong Jiang and Tabitha Ogilvie, *Careful with the Ring! Concrete Hardness Gaps Between LWE and MLWE*, CRYPTO 2026, Part III, LNCS 16802, pp. 462–497. DOI: <https://doi.org/10.1007/978-3-032-35377-1_15>. Publisher page: <https://link.springer.com/chapter/10.1007/978-3-032-35377-1_15>.

### B36 {#bib-b36}

fplll project, official documentation. <https://fplll.github.io/fplll/>.

### B37 {#bib-b37}

National Institute of Standards and Technology, *Module-Lattice-Based Key-Encapsulation Mechanism Standard*, FIPS 203, published 13 August 2024.

Public records: <https://doi.org/10.6028/NIST.FIPS.203>; <https://csrc.nist.gov/pubs/fips/203/final>.

### B38 {#bib-b38}

Gorjan Alagic, Elaine Barker, Lily Chen, Dustin Moody, Angela Robinson, Hamilton Silberg, and Noah Waller, *Recommendations for Key-Encapsulation Mechanisms*, NIST SP 800-227, final September 2025. DOI: [10.6028/NIST.SP.800-227](https://doi.org/10.6028/NIST.SP.800-227).

