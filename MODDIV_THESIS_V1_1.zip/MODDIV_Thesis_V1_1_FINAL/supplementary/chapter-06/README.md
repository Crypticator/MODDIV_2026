# Chapter 6 — Carries, Boundaries, and Exact Agreement: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Runs the final A1 scalar arithmetic suite. The C++ exact q=1..11 closure is compiled and executed.

## Reproduction

```sh
python3 verify.py
python3 verify_independent.py
```

All deterministic reference outputs are stored in this directory. The verification scripts write reruns to temporary files and compare exact JSON objects whenever applicable.

## Limits

The A1 program checks exact arithmetic and finite closures. It does not establish secrecy or lattice hardness.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
