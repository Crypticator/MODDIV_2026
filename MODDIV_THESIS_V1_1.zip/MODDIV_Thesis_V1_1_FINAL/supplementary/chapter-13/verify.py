#!/usr/bin/env python3
import argparse,itertools,json,pathlib
from fractions import Fraction

def fixed_length_witness(messages, equal_lengths=True):
    pairs=[(a,b) for a in messages for b in messages if (not equal_lengths or len(a)==len(b))]
    max_bias=Fraction(0); checks=0
    for a,b in pairs:
        for bits in itertools.product((0,1), repeat=len(messages)):
            decision=dict(zip(messages,bits))
            success=Fraction(int(decision[a]==0)+int(decision[b]==1),2)
            max_bias=max(max_bias,abs(success-Fraction(1,2))); checks+=1
    recovery=sum(Fraction(1,len(messages)) for _ in messages)
    return {'legal_pairs':len(pairs),'decision_cases':checks,'max_CPA_bias':str(max_bias),'identity_recovery':str(recovery)}

ap=argparse.ArgumentParser();ap.add_argument('--output');a=ap.parse_args();renyi=0;bias=0
for pa in itertools.product(range(1,4),repeat=3):
 for qa in itertools.product(range(1,4),repeat=3):
  P=[Fraction(x,sum(pa)) for x in pa];Q=[Fraction(x,sum(qa)) for x in qa];R2=sum(p*p/q for p,q in zip(P,Q))
  for mask in range(1,8):
   pe=sum(P[i] for i in range(3) if mask>>i&1);qe=sum(Q[i] for i in range(3) if mask>>i&1);assert pe*pe<=R2*qe;renyi+=1
for r in range(11):
 for i in range(11):
  gap=abs(Fraction(r-i,10)); success_bias=gap/2; assert 2*success_bias==gap;bias+=1
for qg in range(5):
 for qh in range(5):
  N=qg+qh+1; assert N>=1
  for qd in range(5):
   QG=qg+qd+1;QH=qh+2*qd+1;QRO=QG+QH;assert QRO==qg+qh+3*qd+2
w=fixed_length_witness((b'0',b'00'),True); assert w['max_CPA_bias']=='0' and w['identity_recovery']=='1'
c1=fixed_length_witness((b'0',b'1'),True); c2=fixed_length_witness((b'0',b'00'),False)
assert c1['max_CPA_bias']=='1/2' and c2['max_CPA_bias']=='1/2'
r={'status':'PASS','renyi_event_checks':renyi,'advantage_convention_checks':bias,'WC_N_formula':'q_G+q_H+1','C1_QRO_formula':'q_G+q_H+3q_D+2','NOISE_HB_terms':2,'fixed_length_negative_witness':w,'fixed_length_controls':[c1,c2]}
if a.output:pathlib.Path(a.output).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps(r,indent=2,sort_keys=True))
