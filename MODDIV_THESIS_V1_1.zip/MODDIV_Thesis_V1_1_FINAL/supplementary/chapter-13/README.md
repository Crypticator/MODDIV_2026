# Chapter 13 — Security Games and Reduction Architecture: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Exact finite checks for the Rényi event inequality, advantage-convention factor, WC query coefficient, C1 query-budget identities, and the fixed-length-premise counterexample from Section 13.4. Both verifiers explicitly enumerate deterministic challenge decisions on the two-message witness. Under the equal-length rule the maximum CPA bias is zero while identity recovery is perfect; two negative controls attain bias 1/2. The independent checker also repeats the budget identities over a larger finite grid. No exhaustive random-function oracle experiment is executed in this release.

## Reproduction

```sh
python3 verify.py
python3 verify_independent.py
```

The scripts print deterministic results; `verify.py` also accepts `--output` when a file is desired.

## Limits

This package checks proof interfaces and accounting identities, not the computational hardness of source problems.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
