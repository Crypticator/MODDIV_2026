#!/usr/bin/env python3
import itertools,json
from fractions import Fraction
for qg in range(20):
 for qh in range(20):
  assert qg+qh+1==1+qg+qh
  for qd in range(20): assert (qg+qd+1)+(qh+2*qd+1)==qg+qh+3*qd+2
def witness(messages,equal_lengths):
 pairs=[(a,b) for a in messages for b in messages if (not equal_lengths or len(a)==len(b))]
 best=Fraction(0); cases=0
 for a,b in pairs:
  for outputs in itertools.product((0,1),repeat=len(messages)):
   f=dict(zip(messages,outputs)); p=Fraction((f[a]==0)+(f[b]==1),2); best=max(best,abs(p-Fraction(1,2))); cases+=1
 return str(best),cases
b,c=witness((b'0',b'00'),True); assert b=='0'
b1,c1=witness((b'0',b'1'),True); b2,c2=witness((b'0',b'00'),False); assert b1==b2=='1/2'
print(json.dumps({'status':'PASS','budget_profiles':8000,'fixed_length_negative_witness':{'max_CPA_bias':b,'identity_recovery':'1','decision_cases':c},'controls':[{'max_CPA_bias':b1,'decision_cases':c1},{'max_CPA_bias':b2,'decision_cases':c2}]},indent=2))
