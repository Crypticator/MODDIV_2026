# Chapter 12 — MODDIV-BLINDAGE C1: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Runs the final A6 v1.1 C1-P12-CBD1 arithmetic/probability suite and independent certificate checker.

## Reproduction

```sh
python3 verify.py
python3 verify_independent.py
```

All deterministic reference outputs are stored in this directory. The verification scripts write reruns to temporary files and compare exact JSON objects whenever applicable.

## Limits

The exact Module-LWE source assumptions and classical-ROM transform remain conditional; no concrete 128-bit certificate is claimed.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
