# MODDIV Thesis V1.1 — Supplementary Data Index

**GO 4 status:** cross-chapter scientific synthesis is synchronized; full public artifact population and reruns remain GO 5.

| Chapter | Public path | Scope |
|---:|---|---|
| 1 | `supplementary/chapter-01/` | Roadmap/notation consistency checks; no construction-specific security experiment. |
| 2 | `supplementary/chapter-02/` | Exact quotient/remainder examples; lifting, cell and finite-probability checks. |
| 3 | `supplementary/chapter-03/` | Toeplitz/Hankel identities, convolution equivalence and covariance examples. |
| 4 | `supplementary/chapter-04/` | Public-source chronology ledger and exact historical witness calculators. |
| 5 | `supplementary/chapter-05/` | Scalar interval inversion, floor-sum counter, posterior sampler and exact witnesses. |
| 6 | `supplementary/chapter-06/` | Finite q=1..11 closure, seven-bit counterexample and carry-table regression. |
| 7 | `supplementary/chapter-07/` | Aligned/nonaligned exact counters, prime finite certificate and asymptotic supporting computations. |
| 8 | `supplementary/chapter-08/` | Conditional lifting, dither, total-variation, support and Rényi finite examples. |
| 9 | `supplementary/chapter-09/` | Polynomial window checks and, after GO3, the corrected normalized historical-counter regression. |
| 10 | `supplementary/chapter-10/` | WC arithmetic, wire format, FAST/COMPACT checks, KEM-interface regression and proof-route barrier. |
| 11 | `supplementary/chapter-11/` | NOISE exact simulators, HB finite controls, encoding/parser tests and CCA2 regression. |
| 12 | `supplementary/chapter-12/` | BLINDAGE C1 rational correctness certificate, ring arithmetic, codecs and random-tape law checks. |
| 13 | `supplementary/chapter-13/` | Finite security-game countermodels and loss/query-accounting regressions. |
| 14 | `supplementary/chapter-14/` | Exact graph-lattice model, LLL/Babai calibration fixtures and attack-target verification. |
| 15 | `supplementary/chapter-15/` | Payload calculators, parameter tables, serialization checks and deployment-ledger consistency. |
| 16 | `supplementary/chapter-16/` | Machine-readable comparative ledger and cross-chapter consistency checks. |
| 17 | `supplementary/chapter-17/` | Final imported-constant regression, conclusion ledger and global consistency checks. |
