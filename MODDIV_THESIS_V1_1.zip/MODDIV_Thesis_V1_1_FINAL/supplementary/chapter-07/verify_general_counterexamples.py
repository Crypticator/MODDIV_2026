#!/usr/bin/env python3
import argparse, json, pathlib, subprocess, tempfile
ROOT=pathlib.Path(__file__).resolve().parent
EXPECTED=[(217,12,23398,31248),(409,17,86295,118201),(6144,64,18398712,25165824)]
ap=argparse.ArgumentParser(); ap.add_argument('--output'); a=ap.parse_args()
with tempfile.TemporaryDirectory() as td:
    exe=pathlib.Path(td)/'counter'
    subprocess.run(['g++','-O2','-std=c++17',str(ROOT/'count_general_counterexamples.cpp'),'-o',str(exe)],check=True)
    rows=[]
    for P,Q,expected,total in EXPECTED:
        got=int(subprocess.check_output([str(exe),str(P),str(Q)],text=True).strip())
        assert got==expected and total==P*Q*Q
        rows.append({'P':P,'Q':Q,'agreements':got,'total':total})
r={'status':'PASS','profiles':rows}
if a.output:pathlib.Path(a.output).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps(r,indent=2,sort_keys=True))
