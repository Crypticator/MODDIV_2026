#!/usr/bin/env python3
import argparse,csv,json,pathlib,subprocess,sys,tempfile
from fractions import Fraction
from regenerate_prime_certificate import generate
ap=argparse.ArgumentParser();ap.add_argument('--output');a=ap.parse_args();R=pathlib.Path(__file__).parent
stored=[{k:int(v) for k,v in r.items()} for r in csv.DictReader((R/'prime_certificate.csv').open())]
regen=generate(269)
assert len(stored)==57 and regen==stored
for x in stored:
 Q=x['Q'];A=x['agreements'];D=x['Q4'];M=x['margin'];assert D==Q**4;assert M==4*A-3*D and M>0
assert stored[-1]['Q']==269 and Fraction(stored[-1]['agreements'],stored[-1]['Q4'])>Fraction(3,4)
na=list(csv.DictReader((R/'nonaligned_family.csv').open()));flags=[Fraction(int(x['agreements']),int(x['total']))>Fraction(3,4) for x in na]
assert flags==[True,True,False,False];assert Fraction(41,54)>Fraction(3,4)
with tempfile.TemporaryDirectory() as td:
 out=pathlib.Path(td)/'general.json'
 subprocess.run([sys.executable,str(R/'verify_general_counterexamples.py'),'--output',str(out)],cwd=R,check=True)
 general=json.loads(out.read_text())
r={'status':'PASS','prime_rows_regenerated':57,'exact_rows_match':True,'Q3_agreements':next(x['agreements'] for x in stored if x['Q']==3),'all_prime_margins_positive':True,'last_prime':269,'aligned_limit':'41/54','nonaligned_above_3_4':flags,'general_counterexamples':general['profiles']}
if a.output:pathlib.Path(a.output).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps(r,indent=2,sort_keys=True))
