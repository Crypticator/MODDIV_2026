#!/usr/bin/env python3
import argparse,csv,functools,pathlib

def is_prime(n):
    if n<2:return False
    d=2
    while d*d<=n:
        if n%d==0:return False
        d+=1
    return True

def prime_count(Q):
    bad=0
    def cmp(a,b):
        # (x,f); compare f/x exactly
        l=a[1]*b[0]; r=b[1]*a[0]
        return -1 if l<r else (1 if l>r else (-1 if a[0]<b[0] else (1 if a[0]>b[0] else 0)))
    key=functools.cmp_to_key(cmp)
    for a in range(Q):
        v=[(x,(a*x)//Q) for x in range(1,Q)]
        v.sort(key=key)
        sx=sf=0
        for x,f in v:
            bad += 2*(f*sx-x*sf)
            sx += x; sf += f
    return Q**4-bad

def generate(limit=269):
    out=[]
    for Q in range(2,limit+1):
        if is_prime(Q):
            A=prime_count(Q); D=Q**4
            out.append({'Q':Q,'agreements':A,'Q4':D,'margin':4*A-3*D})
    return out

def read_csv(path):
    return [{k:int(v) for k,v in r.items()} for r in csv.DictReader(open(path,newline=''))]

def write_csv(path,rows):
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['Q','agreements','Q4','margin']);w.writeheader();w.writerows(rows)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--check');ap.add_argument('--write');ap.add_argument('--limit',type=int,default=269);a=ap.parse_args()
    rows=generate(a.limit)
    if a.check:
        ref=read_csv(a.check)
        assert rows==ref, next((x for x,y in zip(rows,ref) if x!=y),('row-count',len(rows),len(ref)))
    if a.write: write_csv(a.write,rows)
    print(f'PASS: regenerated {len(rows)} exact prime rows through Q={a.limit}')
if __name__=='__main__':main()
