#!/usr/bin/env python3
import csv,json,pathlib
from fractions import Fraction
R=pathlib.Path(__file__).parent;rows=[{k:int(v) for k,v in r.items()} for r in csv.DictReader((R/'prime_certificate.csv').open())]
def direct(P,Q):
 good=0
 for A in range(P):
  pub=[(A*s%P)//Q for s in range(Q)]
  for x in range(Q):
   for y in range(Q):
    left=(Q*x*pub[y]%P)//(Q*Q);right=(Q*y*pub[x]%P)//(Q*Q)
    good += left==right
 return good
small=[]
for r in rows:
 Q=r['Q']; assert r['Q4']==Q**4 and r['margin']==4*r['agreements']-3*r['Q4'] and r['margin']>0
 if Q<=11:
  g=direct(2*Q*Q,Q); assert g==2*r['agreements'];small.append(Q)
assert 3 in small and next(r['agreements'] for r in rows if r['Q']==3)==79
general=[]
for P,Q,expected in [(217,12,23398),(409,17,86295)]:
 got=direct(P,Q);assert got==expected;general.append({'P':P,'Q':Q,'agreements':got})
na=list(csv.DictReader((R/'nonaligned_family.csv').open()));flags=[Fraction(int(x['agreements']),int(x['total']))>Fraction(3,4) for x in na];assert flags==[True,True,False,False]
print(json.dumps({'status':'PASS','direct_prime_checks':small,'Q3_exact':79,'all_57_denominators_and_margins_checked':True,'direct_general_counterexamples':general},indent=2))
