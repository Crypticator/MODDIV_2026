#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>

static std::uint64_t count_agreements(std::uint64_t P, std::uint64_t Q) {
    std::uint64_t good = 0;
    const std::uint64_t Q2 = Q * Q;
    std::vector<std::uint64_t> pub(Q);
    for (std::uint64_t A = 0; A < P; ++A) {
        for (std::uint64_t s = 0; s < Q; ++s)
            pub[s] = ((A * s) % P) / Q;
        for (std::uint64_t x = 0; x < Q; ++x) {
            for (std::uint64_t y = 0; y < Q; ++y) {
                const auto wa = ((Q * x * pub[y]) % P) / Q2;
                const auto wb = ((Q * y * pub[x]) % P) / Q2;
                good += (wa == wb);
            }
        }
    }
    return good;
}

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "usage: count_general_counterexamples P Q\n";
        return 2;
    }
    const auto P = std::strtoull(argv[1], nullptr, 10);
    const auto Q = std::strtoull(argv[2], nullptr, 10);
    if (P == 0 || Q == 0) return 2;
    std::cout << count_agreements(P, Q) << "\n";
    return 0;
}
