"""Exact finite probability tools for A2 distributional MODDIV.

Reference mathematics only. No security parameter recommendation or production
cryptographic sampler is supplied. Enumeration helpers are small-test oracles,
not algorithms claimed polynomial in the bit length of a modulus.
"""
from __future__ import annotations

from collections import defaultdict
from fractions import Fraction
from itertools import product
from math import gcd
from typing import Callable, Hashable, Iterable, Mapping, TypeVar

K = TypeVar('K', bound=Hashable)
L = TypeVar('L', bound=Hashable)
PMF = dict[Hashable, Fraction]


def validate_pmf(p: Mapping[K, Fraction]) -> None:
    if not p or any(v < 0 for v in p.values()) or sum(p.values()) != 1:
        raise ValueError('Expected a nonnegative normalized finite probability law')


def uniform(items: Iterable[K]) -> dict[K, Fraction]:
    items = list(items)
    if not items:
        raise ValueError('Cannot sample an empty set')
    out: dict[K, Fraction] = defaultdict(Fraction)
    for x in items:
        out[x] += Fraction(1, len(items))
    return dict(out)


def pushforward(p: Mapping[K, Fraction], f: Callable[[K], L]) -> dict[L, Fraction]:
    out: dict[L, Fraction] = defaultdict(Fraction)
    for x, w in p.items():
        out[f(x)] += w
    return {x: w for x, w in out.items() if w}


def tv(p: Mapping[K, Fraction], q: Mapping[K, Fraction]) -> Fraction:
    return sum((abs(p.get(x, 0) - q.get(x, 0)) for x in p.keys() | q.keys()), Fraction()) / 2


def r2(p: Mapping[K, Fraction], q: Mapping[K, Fraction]) -> Fraction | None:
    """Exponentiated Renyi divergence of order two; None denotes infinity."""
    value = Fraction()
    for x, w in p.items():
        if not w:
            continue
        v = q.get(x, Fraction())
        if not v:
            return None
        value += w*w/v
    return value


def apply_kernel(p: Mapping[K, Fraction], kernel: Mapping[K, Mapping[L, Fraction]]) -> dict[L, Fraction]:
    out: dict[L, Fraction] = defaultdict(Fraction)
    for x, w in p.items():
        for y, v in kernel[x].items():
            out[y] += w*v
    return {x: w for x, w in out.items() if w}


def quotient(z: int, P: int, Q: int) -> int:
    if P < 1 or Q < 1:
        raise ValueError('Modulus and divisor must be positive')
    return (z % P) // Q


def cell(j: int, P: int, Q: int) -> range:
    if P < 1 or Q < 1 or j < 0 or j*Q >= P:
        raise ValueError('Empty or invalid quotient cell')
    return range(j*Q, min((j+1)*Q, P))


def cell_center(j: int, P: int, Q: int) -> int:
    I = cell(j, P, Q)
    return I.start + (len(I)-1)//2


def quotient_vector(z: tuple[int, ...], P: int, Q: int) -> tuple[int, ...]:
    return tuple(quotient(v, P, Q) for v in z)


def perturbation_formula(z: int, e: int, P: int, Q: int) -> int:
    """General-modulus carry identity, using canonical z first."""
    z %= P
    u, r = divmod(z, Q)
    h, delta = divmod(e, Q)
    a, b = divmod(P, Q)
    k = (z+e)//P
    return u + h - k*a + (r+delta-k*b)//Q


def lift_joint(p: Mapping[tuple[K, tuple[int, ...]], Fraction], P: int, Q: int) -> dict:
    """Uniformize the full residue vector within its product cell; preserve K.

    Input atoms are (side_information, residue_vector). This deliberately
    enumerative oracle is used only to check distribution identities.
    """
    out = defaultdict(Fraction)
    for (c, z), w in p.items():
        cells = [cell(quotient(v, P, Q), P, Q) for v in z]
        volume = 1
        for I in cells:
            volume *= len(I)
        for b in product(*cells):
            out[(c, b)] += w/volume
    return dict(out)


def retention(z: int, P: int, Q: int, chi: Mapping[int, Fraction]) -> Fraction:
    u = quotient(z, P, Q)
    return sum((w for e, w in chi.items() if quotient(z+e, P, Q) == u), Fraction())


def modular_cost(P: int, Q: int, chi: Mapping[int, Fraction]) -> Fraction | None:
    out = Fraction()
    for z in range(P):
        s = retention(z, P, Q, chi)
        if not s:
            return None
        out += 1/s - 1
    return out


def cell_cost(a: int, B: int) -> Fraction:
    if a < 1 or B < 0:
        raise ValueError('Cell length positive; noise radius nonnegative')
    return sum((Fraction(2*B+1, 1+min(B,j)+min(B,a-1-j))-1 for j in range(a)), Fraction())


def cell_cost_formula(a: int, B: int) -> Fraction:
    """O(B) summation at worst, NOT polynomial in log B."""
    if a < 1 or B < 0:
        raise ValueError('Invalid arguments')
    if a <= B+1:
        return Fraction(2*B+1-a)
    k = min(B, a-B-1)
    harmonic = sum((Fraction(1,j) for j in range(B+1,B+k+1)), Fraction())
    return 2*((2*B+1)*harmonic-k) + (a-2*k)*(Fraction(2*B+1, min(a,2*B+1))-1)


def cell_cost_envelope(a: int, B: int) -> int:
    if a < 1 or B < 0:
        raise ValueError('Invalid arguments')
    return 2*B+1-a if a <= B+1 else B


def sharp_cost(P: int, Q: int, B: int) -> Fraction:
    J = (P+Q-1)//Q
    last = P-(J-1)*Q
    return (J-1)*cell_cost_formula(Q, B)+cell_cost_formula(last, B)


def hankel(a: tuple[int, ...], x: tuple[int, ...], outputs: int) -> tuple[int, ...]:
    if not x or outputs < 1 or len(a) != outputs+len(x)-1:
        raise ValueError('Incompatible Hankel dimensions')
    return tuple(sum(a[i+j]*x[j] for j in range(len(x))) for i in range(outputs))


def factor_bound(P: int, interval_length: int, endpoint_gcd_bound: int, V: Fraction, outputs: int) -> Fraction:
    if not (1 <= interval_length <= P and 1 <= endpoint_gcd_bound <= P and outputs >= 1):
        raise ValueError('Invalid structured comparison parameters')
    return (1+Fraction(endpoint_gcd_bound, interval_length)*V)**outputs


def noisy_scalar_law(z: int, P: int, Q: int, chi: Mapping[int, Fraction]) -> dict[int, Fraction]:
    return pushforward(chi, lambda e: quotient(z+e, P, Q))
