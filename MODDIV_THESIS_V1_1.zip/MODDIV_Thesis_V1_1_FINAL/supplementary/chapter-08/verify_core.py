#!/usr/bin/env python3
"""Reproduce A2's finite checks with integers and exact fractions."""
from __future__ import annotations
from collections import Counter, defaultdict
from fractions import Fraction as F
from itertools import product
from math import gcd
from random import Random
import argparse
import json
from pathlib import Path
import distribution_tools as dt


def fs(x):
    if x is None:
        return 'infinity'
    if isinstance(x, F):
        return f'{x.numerator}/{x.denominator}'
    if isinstance(x, dict):
        return {str(k):fs(v) for k,v in x.items()}
    if isinstance(x, (tuple,list)):
        return [fs(v) for v in x]
    return x


def verify():
    checks = Counter()
    rng = Random(2026110808)
    # All signed arguments in these explicitly bounded boxes.
    for P in range(1,19):
        for Q in range(1, P+1):
            for z in range(-P,2*P):
                for e in range(-2*P,2*P+1):
                    assert dt.perturbation_formula(z,e,P,Q) == dt.quotient(z+e,P,Q)
                    checks['signed_multiwrap_identities'] += 1
    for P in range(1,41):
        for Q in range(1,41):
            joint=dt.uniform([(dt.quotient(z,P,Q), (z%P)%Q) for z in range(P)])
            up=dt.pushforward(joint,lambda t:t[0]); rp=dt.pushforward(joint,lambda t:t[1])
            a,b=divmod(P,Q); J=(P+Q-1)//Q
            assert rp == {r:F(a+(r<b),P) for r in range(Q) if a+(r<b)}
            assert dt.tv(rp,dt.uniform(range(Q))) == F(b*(Q-b),P*Q)
            target = F(0) if b==0 else F(a*(Q-b), P*J)
            assert dt.tv(up,dt.uniform(range(J))) == target
            for j in range(J):
                assert up[j] == F(len(dt.cell(j,P,Q)),P)
            checks['uniform_cell_and_remainder_profiles'] += 1
    # Lifting identities with arbitrary correlated side information and outputs.
    for P,Q,n in [(4,2,1),(5,2,1),(6,4,1),(6,2,2),(4,3,2),(3,1,2),(3,3,2)]:
        atoms=list(product(range(2),product(range(P),repeat=n)))
        for _ in range(8):
            weights=[rng.randrange(0,8) for _ in atoms]
            if not sum(weights): weights[0]=1
            p={a:F(w,sum(weights)) for a,w in zip(atoms,weights) if w}
            lift=dt.lift_joint(p,P,Q)
            assert dt.lift_joint(lift,P,Q)==lift
            pu=dt.pushforward(p,lambda a:(a[0],dt.quotient_vector(a[1],P,Q)))
            lu=dt.pushforward(lift,lambda a:(a[0],dt.quotient_vector(a[1],P,Q)))
            assert pu==lu
            # Compute the conditional remainder law independently per fiber.
            total=F()
            for (c,u),w in pu.items():
                cond={tuple(z[i]-Q*u[i] for i in range(n)):v/w
                      for (cc,z),v in p.items() if cc==c and dt.quotient_vector(z,P,Q)==u}
                unif=dt.uniform(product(*[range(len(dt.cell(ui,P,Q))) for ui in u]))
                total += w*dt.tv(cond,unif)
            assert dt.tv(p,lift)==total
            if P%Q==0:
                pc=dt.pushforward(p,lambda a:a[0])
                reference={(c,z):v/F(P**n) for c,v in pc.items() for z in product(range(P),repeat=n)}
                qref={(c,u):v/F((P//Q)**n) for c,v in pc.items() for u in product(range(P//Q),repeat=n)}
                assert dt.tv(lift,reference)==dt.tv(pu,qref)
            checks['joint_lifting_profiles']+=1
    # 49-point structured residual witness: direct Hankel (swapped secret names).
    ribbon=(257,258,257,259); P=257; Q=15
    secrets=list(product(range(8,16),repeat=2))
    compatible=[]
    for x in secrets:
        z=tuple(v%P for v in dt.hankel(ribbon,x,3))
        if dt.quotient_vector(z,P,Q)==(0,0,1):
            compatible.append(tuple(zi-Q*ui for zi,ui in zip(z,(0,0,1))))
    assert len(compatible)==49
    p=dt.uniform(compatible)
    marg=[dt.pushforward(p,lambda t,i=i:t[i]) for i in range(3)]
    prodlaw={t:marg[0][t[0]]*marg[1][t[1]]*marg[2][t[2]] for t in product(*[m.keys() for m in marg])}
    assert dt.tv(p,prodlaw)==F(6,7)
    checks['structured_correlated_remainder_witnesses']=1
    # Exact universal-channel obstruction: finite laws invariant under shift 1.
    for P in range(2,9):
        for _ in range(50):
            weights=[rng.randrange(1,8) for _ in range(P)]
            p={i:F(w,sum(weights)) for i,w in enumerate(weights)}
            translated=dt.pushforward(p,lambda i:(i+1)%P)
            assert (p==translated)==(len(set(weights))==1)
            checks['translation_invariance_profiles']+=1
    # Approximate smoothing and odd-cell minimax equality.
    for P in range(2,19):
        for Q in range(1,P+1):
            for T in range(0,7):
                chi=dt.uniform(range(-T,T+1))
                for z in range(P):
                    c=dt.cell_center(dt.quotient(z,P,Q),P,Q)
                    exact=dt.pushforward(chi,lambda e:(z+e)%P)
                    simulated=dt.pushforward(chi,lambda e:(c+e)%P)
                    radius=len(dt.cell(dt.quotient(z,P,Q),P,Q))//2
                    assert dt.tv(exact,simulated)<=min(F(1),F(radius,2*T+1))
                    checks['scalar_smoothing_inputs']+=1
                if Q%2==1 and T>=(Q-1)//2 and P>=2*T+Q:
                    h=(Q-1)//2
                    distributions=[dt.pushforward(chi,lambda e,z=z:(z+e)%P) for z in range(Q)]
                    assert dt.tv(distributions[0],distributions[-1])/2==F(h,2*T+1)
                    assert max(dt.tv(distributions[h],q) for q in distributions)==F(h,2*T+1)
                    checks['odd_cell_minimax_profiles']+=1
    # Dither: include Z and the public dither in the joint law.
    for Q in range(1,8):
        for H in range(1,6):
            P=Q*H
            zlaw=dt.uniform(range(P))
            real=defaultdict(F); ideal=defaultdict(F)
            for z,w in zlaw.items():
                for t in range(Q):
                    y=(Q*dt.quotient(z+t,P,Q)-t)%P
                    real[(z,t,y)]+=w/Q
                    for r in range(Q): ideal[(z,t,(z-r)%P)]+=w/(Q*Q)
            rz=dt.pushforward(real,lambda a:(a[0],a[2]))
            iz=dt.pushforward(ideal,lambda a:(a[0],a[2]))
            assert rz==iz
            assert dt.tv(real,ideal)==1-F(1,Q)
            assert dt.tv(dt.pushforward(real,lambda a:a[1:]),dt.pushforward(ideal,lambda a:a[1:]))==1-F(1,Q)
            checks['dither_complete_transcript_profiles']+=1
    # TV and Renyi kernel/data-processing/probability inequalities.
    for _ in range(250):
        wa=[rng.randrange(0,9) for _ in range(4)]; wb=[rng.randrange(1,9) for _ in range(4)]
        if not sum(wa):wa[0]=1
        p={i:F(w,sum(wa)) for i,w in enumerate(wa) if w}; q={i:F(w,sum(wb)) for i,w in enumerate(wb)}
        kernel={}
        for i in range(4):
            ws=[rng.randrange(1,8) for _ in range(3)]
            kernel[i]={j:F(w,sum(ws)) for j,w in enumerate(ws)}
        kp=dt.apply_kernel(p,kernel); kq=dt.apply_kernel(q,kernel)
        r=dt.r2(p,q); assert r is not None
        assert dt.tv(kp,kq)<=dt.tv(p,q)
        assert dt.r2(kp,kq)<=r
        assert 4*dt.tv(p,q)**2<=r-1
        for mask in range(16):
            pe=sum((w for i,w in p.items() if mask>>i&1),F())
            qe=sum((w for i,w in q.items() if mask>>i&1),F())
            assert pe*pe<=qe*r
            checks['renyi_event_checks']+=1
        checks['kernel_and_renyi_profiles']+=1
    # Exact modular cell costs, including singleton quotient and wraparound.
    for P in range(1,41):
        for Q in range(1,P+1):
            for B in range(0,7):
                chi=dt.uniform(range(-B,B+1))
                V=dt.modular_cost(P,Q,chi); sharp=dt.sharp_cost(P,Q,B)
                assert V is not None and V<=sharp
                if B<=P-Q:assert V==sharp
                if Q==P:assert V==0
                checks['modular_retention_cost_profiles']+=1
    for a in range(1,61):
        for B in range(0,21):
            g=dt.cell_cost(a,B)
            assert g==dt.cell_cost_formula(a,B)
            assert g<=dt.cell_cost_envelope(a,B)
            if a>=2*B+1:
                psi=2*((2*B+1)*sum((F(1,j) for j in range(B+1,2*B+1)),F())-B)
                assert g==psi
            checks['harmonic_cell_cost_profiles']+=1
    # Mixtures: only finite rational mixtures are tested.
    for _ in range(80):
        P=rng.randrange(2,22);Q=rng.randrange(1,P+1)
        ws=[rng.randrange(1,7) for _ in range(5)]; total=sum(ws)
        mix=defaultdict(F); upper=F()
        for B,w in enumerate(ws):
            upper+=F(w,total)*dt.sharp_cost(P,Q,B)
            for e in range(-B,B+1):mix[e]+=F(w,total*(2*B+1))
        assert dt.modular_cost(P,Q,mix)<=upper
        checks['finite_noise_mixture_profiles']+=1
    # Before/after-quotient translations: all shifts for small divisible moduli.
    for Q in range(1,9):
        for H in range(2,9):
            P=Q*H
            for c in range(P):
                compatible=True
                for j in range(H):
                    values={dt.quotient(z+c,P,Q) for z in dt.cell(j,P,Q)}
                    compatible &= len(values)==1
                assert compatible==(c%Q==0)
                checks['quotient_translation_profiles']+=1
    # Counterexamples deliberately outside theorem assumptions.
    assert dt.quotient(18-1,19,3)==5 and dt.quotient(18+1,19,3)==0
    evec=[(-1,0,1),(0,1,-1),(1,-1,0)]
    assert not any(dt.quotient_vector(e,19,3)==(0,0,0) for e in evec)
    assert dt.retention(0,19,3,dt.uniform([-1,0,1]))==F(2,3)
    bern_p={0:F(3,4),1:F(1,4)}; bern_q={0:F(1,2),1:F(1,2)}
    assert dt.r2(bern_p,bern_q)==F(5,4) and dt.tv(bern_p,bern_q)==F(1,4)
    checks['explicit_scope_counterexamples']=3
    # Structured full-law comparisons. Main program uses conditional products.
    profiles=[
      dict(P=7,Q=3,M=4,start=4,d=2,L=2,t=1,alphabet=[1,2],noise='uniform1'),
      dict(P=8,Q=4,M=8,start=0,d=2,L=2,t=1,alphabet=[1,3],noise='cbd1'),
      dict(P=11,Q=4,M=6,start=5,d=2,L=3,t=1,alphabet=[1,2],noise='uniform1'),
      dict(P=5,Q=2,M=3,start=3,d=2,L=2,t=2,alphabet=[1,2],noise='uniform1'),
      dict(P=8,Q=3,M=4,start=6,d=2,L=2,t=1,alphabet=[0,2],noise='uniform1')]
    results=[]
    for cfg in profiles:
        P,Q,M,start,d,L,t=[cfg[k] for k in ['P','Q','M','start','d','L','t']]
        chi=dt.uniform([-1,0,1]) if cfg['noise']=='uniform1' else {-1:F(1,4),0:F(1,2),1:F(1,4)}
        xs=list(product(cfg['alphabet'],repeat=d));ribbons=list(product(range(start,start+M),repeat=L+d-1))
        states=len(xs)*len(ribbons)**t; rsum=F(); gamma=max(gcd(x[-1],P) for x in xs)
        # Exact (public,output) distributions and a finite enumerating recovery oracle.
        p_pub=defaultdict(F);q_pub=defaultdict(F); alpha=F(); beta=F();state_mass=F(1,states)
        for avec in product(ribbons,repeat=t):
            originals={x:tuple(z%P for a in avec for z in dt.hankel(a,x,L)) for x in xs}
            outputs={x:dt.quotient_vector(z,P,Q) for x,z in originals.items()}
            oracle={}
            for x in xs:oracle.setdefault(outputs[x],x)
            for x,z in originals.items():
                u=outputs[x]; p_pub[(avec,u)]+=state_mass
                if oracle[u]==x:alpha+=state_mass
                scalar=[dt.noisy_scalar_law(zi,P,Q,chi) for zi in z]
                ret=F(1)
                for zi in z:ret*=dt.retention(zi,P,Q,chi)
                rsum+=state_mass/ret
                for out in product(*[s.keys() for s in scalar]):
                    w=state_mass
                    for idx,v in enumerate(out):w*=scalar[idx][v]
                    q_pub[(avec,out)]+=w
                    if oracle.get(out)==x:beta+=w
                checks['structured_public_secret_states']+=1
        V=dt.modular_cost(P,Q,chi); bound=dt.factor_bound(P,M,gamma,V,t*L)
        assert rsum<=bound and beta*rsum>=alpha*alpha
        delta=min(F(1),F(gamma*((P+Q-1)//Q),M)*t*L*sum((abs(e)*w for e,w in chi.items()),F()))
        assert dt.tv(p_pub,q_pub)<=delta
        rpublic=dt.r2(p_pub,q_pub);assert rpublic<=rsum
        if M==P and gamma==1:assert rsum==(1+V/P)**(t*L)
        results.append(dict(parameters=cfg,states=states,R2_joint=rsum,R2_public=rpublic,C_bound=bound,V=V,TV_public=dt.tv(p_pub,q_pub),delta_bound=delta,success_noiseless=alpha,success_noisy=beta))
    # Numerical reduction-loss illustration; exact rational test, not parameter security.
    P,Q,M,L,B=65536,256,65536,32,1
    V=dt.sharp_cost(P,Q,B)
    assert V==256
    C=(1+V/M)**L
    assert C < F(8,7)
    illustration=dict(P=P,Q=Q,M=M,L=L,B=B,gamma=1,V=V,C=C,search_factor=1/C,TV_union_bound=F(1,12))
    return dict(status='PASS',seed=2026110808,scope='Finite exact tests, not asymptotic proofs or cryptographic benchmarks',checks=dict(checks),structured_profiles=fs(results),loss_illustration=fs(illustration))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',default='A2_RESULTS.json');args=ap.parse_args()
    result=verify();Path(args.output).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(result['checks'],indent=2));print('PASS:',args.output)
