# Chapter 8 — General Distributional Theory: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Runs the final A2 distributional suite and an independent finite checker.

## Reproduction

```sh
python3 verify.py
python3 verify_independent.py
```

All deterministic reference outputs are stored in this directory. The verification scripts write reruns to temporary files and compare exact JSON objects whenever applicable.

## Limits

No LWE hardness, IND-CPA/CCA theorem, or concrete parameter claim follows from these distributional checks.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
