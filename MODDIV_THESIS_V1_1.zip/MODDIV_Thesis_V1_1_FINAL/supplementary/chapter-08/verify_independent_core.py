#!/usr/bin/env python3
"""Differently organized exact checks; does not import distribution_tools.

Computes each structured output by ordinary polynomial convolution with the
secret reversed; explicitly enumerates the entire noise vector. This is a
finite implementation cross-check, not external peer review.
"""
from collections import Counter, defaultdict
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import argparse
import json


def tv(p,q):
    return sum((abs(p.get(k,0)-q.get(k,0)) for k in p.keys()|q.keys()),F())/2


def rd(p,q):
    assert all(q.get(k,0)>0 for k,v in p.items() if v)
    return sum((v*v/q[k] for k,v in p.items() if v),F())


def middle(a,x,L):
    rev=x[::-1];c=[0]*(len(a)+len(x)-1)
    for i,ai in enumerate(a):
        for j,xj in enumerate(rev):c[i+j]+=ai*xj
    return tuple(c[len(x)-1:len(x)-1+L])


def main(expected):
    counts=Counter();comparisons=[]
    for item in expected['structured_profiles']:
        cfg=item['parameters']
        P,Q,M,start,d,L,t=[cfg[k] for k in ['P','Q','M','start','d','L','t']]
        chi={-1:F(1,3),0:F(1,3),1:F(1,3)} if cfg['noise']=='uniform1' else {-1:F(1,4),0:F(1,2),1:F(1,4)}
        xs=list(product(cfg['alphabet'],repeat=d)); As=list(product(range(start,start+M),repeat=L+d-1))
        noises=[]
        for es in product(chi,repeat=L*t):
            w=F(1)
            for e in es:w*=chi[e]
            noises.append((es,w))
        total=len(xs)*len(As)**t; mass=F(1,total)
        pub0=defaultdict(F);pub1=defaultdict(F);rjoint=F();alpha=F();beta=F()
        for Avec in product(As,repeat=t):
            products={x:tuple(v%P for A in Avec for v in middle(A,x,L)) for x in xs}
            Us={x:tuple(v//Q for v in z) for x,z in products.items()}
            oracle={}
            for x in xs:oracle.setdefault(Us[x],x)
            for x,z in products.items():
                original=Us[x];pub0[(Avec,original)]+=mass
                if oracle[original]==x:alpha+=mass
                keep=F()
                for es,w in noises:
                    out=tuple(((zi+ei)%P)//Q for zi,ei in zip(z,es))
                    pub1[(Avec,out)]+=mass*w
                    if out==original:keep+=w
                    if oracle.get(out)==x:beta+=mass*w
                    counts['explicit_structured_noise_outcomes']+=1
                assert keep>0
                rjoint+=mass/keep
                counts['structured_states_rechecked']+=1
        actual=dict(R2_joint=rjoint,R2_public=rd(pub0,pub1),TV_public=tv(pub0,pub1),success_noiseless=alpha,success_noisy=beta)
        for k,v in actual.items():assert v==F(item[k]),(cfg,k,v,item[k])
        comparisons.append(dict(parameters=cfg,values={k:str(v) for k,v in actual.items()}))
    # Complete residue-grid and row-freshness check, not using an inequality oracle.
    from math import gcd
    for P in range(1,17):
        for M in range(1,P+1):
            for x in range(P):
                for start in [-3,0,5]:
                    hist=Counter((x*a+2)%P for a in range(start,start+M))
                    assert max(hist.values())<=gcd(x,P)
                    counts['fresh_coefficient_mass_profiles']+=1
    # Boundary cardinality bound for signed, possibly multi-period shifts.
    for P in range(1,25):
        for Q in range(1,P+1):
            J=(P+Q-1)//Q
            for e in range(-2*P,2*P+1):
                bad=sum(z//Q!=((z+e)%P)//Q for z in range(P))
                assert bad<=min(P,J*abs(e))
                counts['boundary_cardinality_profiles']+=1
    # Unimodal-mixture reconstruction by successive mass differences.
    for B in range(0,15):
        raw={e:B+1-abs(e) for e in range(-B,B+1)};Z=sum(raw.values())
        chi={e:F(w,Z) for e,w in raw.items()}
        lambdas={b:(2*b+1)*(chi[b]-chi.get(b+1,0)) for b in range(B+1)}
        assert sum(lambdas.values())==1 and min(lambdas.values())>=0
        for e in range(-B,B+1):
            assert sum((w/F(2*b+1) for b,w in lambdas.items() if abs(e)<=b),F())==chi[e]
        counts['finite_unimodal_reconstructions']+=1
    return dict(status='PASS',method='No import of the candidate mathematical module; convolution and full-vector noise enumeration',checks=dict(counts),structured_comparisons=comparisons)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--reference',default='A2_RESULTS.json');ap.add_argument('--output',default='A2_INDEPENDENT.json');a=ap.parse_args()
    result=main(json.loads(Path(a.reference).read_text()))
    Path(a.output).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result['checks'],indent=2));print('PASS:',a.output)
