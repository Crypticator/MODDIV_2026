// Exact finite closure for the A1 full-range scalar ModDiv agreement theorem.
// Compile: g++ -O3 -std=c++17 count_agreement_a1.cpp -o count_agreement
// Usage: ./count_agreement quotient 11  or ./count_agreement crossing 11
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>
static unsigned valuation2(uint32_t x) {
    if (!x) throw std::invalid_argument("nonzero integer required");
    unsigned t=0; while ((x&1u)==0u) {++t; x >>= 1u;} return t;
}
static uint64_t errors(unsigned q, bool crossing) {
    const uint32_t Q=1u<<q; uint64_t total=0;
    for (uint32_t x=1;x<Q;++x) for (uint32_t y=x+1;y<Q;++y) {
        const unsigned s=std::min(q,valuation2(x)+valuation2(y));
        const uint32_t g=1u<<s; uint64_t subtotal=0;
        for(uint32_t a=0;a<Q;++a) {
            const uint32_t u=x*((a*y)>>q), v=y*((a*x)>>q);
            if (!crossing) {
                const int64_t c=int64_t(v>>s)-int64_t(u>>s);
                subtotal += uint64_t(c<0?-c:c);
            } else {
                const uint32_t phase=u&(g-1u);
                const int64_t delta=int64_t(v)-int64_t(u);
                if(delta>=0) subtotal += (uint64_t(delta)+phase)>>s;
                else {
                    const uint64_t size=uint64_t(-delta);
                    if(size>phase) subtotal += (size-phase+g-1u)>>s;
                }
            }
        }
        total += 2u*uint64_t(g)*subtotal;
    }
    return total;
}
int main(int argc,char** argv) {
    try {
        if(argc!=3) throw std::invalid_argument("usage: count_agreement quotient|crossing qmax");
        const std::string mode=argv[1];
        if(mode!="quotient" && mode!="crossing") throw std::invalid_argument("unknown mode");
        const int qmax=std::stoi(argv[2]);
        if(qmax<1 || qmax>11) throw std::invalid_argument("certified range is 1<=qmax<=11");
        std::cout << "q,Q,errors,total,agreement,margin_above_three_quarters\n";
        for(int q=1;q<=qmax;++q) {
            const uint64_t Q=uint64_t(1)<<q, total=Q*Q*Q*Q;
            const uint64_t bad=errors(unsigned(q),mode=="crossing"), good=total-bad;
            if(bad>total) throw std::runtime_error("invalid count");
            const int64_t margin=int64_t(4*good)-int64_t(3*total);
            std::cout << q << ',' << Q << ',' << bad << ',' << total << ',' << good << ',' << margin << std::endl;
        }
    } catch(const std::exception& e) { std::cerr<<e.what()<<'\n'; return 1; }
}
