#!/usr/bin/env python3
import pathlib, runpy
runpy.run_path(str(pathlib.Path(__file__).resolve().parent/'verify.py'),run_name='__main__')
