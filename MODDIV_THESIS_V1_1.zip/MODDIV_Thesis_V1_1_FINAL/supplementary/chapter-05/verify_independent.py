#!/usr/bin/env python3
import json
from fractions import Fraction
assert Fraction(166397,221184)>Fraction(3,4)
assert Fraction(12540509,16777216)<Fraction(3,4)
assert Fraction(41,54)>Fraction(3,4)
print(json.dumps({'status':'PASS','cstar':'166397/221184','upper_half_q7':'12540509/16777216','aligned_limit':'41/54'},indent=2))
