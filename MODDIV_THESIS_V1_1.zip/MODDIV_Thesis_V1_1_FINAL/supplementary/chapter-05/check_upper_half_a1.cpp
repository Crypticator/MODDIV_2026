// Independent evaluation of the ORIGINAL publication and extraction formulas.
// Exhaustive 7-bit, upper-half-secret counterexample; not a general security test.
#include <cstdint>
#include <iostream>
int main() {
    constexpr uint32_t q=7, p=15, Q=1u<<q, P=1u<<p;
    uint64_t good=0, total=0;
    for(uint32_t A=0; A<P; ++A) {
        uint32_t outputs[Q];
        for(uint32_t x=Q/2;x<Q;++x) outputs[x]=((A*x)%P)/Q;
        for(uint32_t x=Q/2;x<Q;++x) for(uint32_t y=Q/2;y<Q;++y) {
            const uint32_t wa=((Q*x*outputs[y])%P)/(Q*Q);
            const uint32_t wb=((Q*y*outputs[x])%P)/(Q*Q);
            good += (wa==wb); ++total;
        }
    }
    std::cout << "p,q,agreement,total\n" << p << ',' << q << ',' << good << ',' << total << '\n';
    return (good*16777216ULL == total*12540509ULL && 4*good<3*total) ? 0:1;
}
