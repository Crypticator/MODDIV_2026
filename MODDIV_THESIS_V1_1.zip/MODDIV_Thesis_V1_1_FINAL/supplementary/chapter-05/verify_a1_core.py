#!/usr/bin/env python3
"""Exact arithmetic checks for A1 v1.1 - Scalar ModDiv Revisited.

Standard-library Python checks the identities, floor-sum inversion, small direct
protocol profiles, exact full-range rows through q=7, and the 7-bit upper-half
counterexample via the proved reduced count.  With --full-closure, a C++17
compiler is used to regenerate the exact q=1..11 certificate.

This is reproducibility code, not a security certification.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
import shutil
import subprocess
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPECTED = [
    Fraction(1,1),
    Fraction(123,128),
    Fraction(459,512),
    Fraction(6901,8192),
    Fraction(52809,65536),
    Fraction(3289931,4194304),
    Fraction(51841515,67108864),
    Fraction(822654211,1073741824),
    Fraction(3276319387,4294967296),
    Fraction(209209404217,274877906944),
    Fraction(3343422968633,4398046511104),
]
CSTAR = Fraction(166397,221184)


def md(z: int, P: int, Q: int) -> int:
    return (z % P) // Q


def floor_sum(n: int, m: int, a: int, b: int) -> int:
    """sum_{0<=i<n} floor((a*i+b)/m), exact for signed a,b."""
    if n < 0 or m <= 0:
        raise ValueError("require n>=0, m>0")
    qa, a = divmod(a, m)
    qb, b = divmod(b, m)
    ans = qa * n * (n - 1) // 2 + qb * n
    # Now 0<=a,b<m. Apply Euclidean reciprocity iteratively.
    while True:
        y = a * n + b
        if a == 0 or y < m:
            return ans
        n2, b2 = divmod(y, m)
        # S(n,m,a,b) = S(n2,a,m,b2)
        n, m, a, b = n2, a, m, b2
        if a >= m:
            q, a = divmod(a, m)
            ans += q * n * (n - 1) // 2
        if b >= m:
            q, b = divmod(b, m)
            ans += q * n


def count_interval(a: int, P: int, Q: int, u: int, L: int, R: int) -> int:
    if R < L:
        raise ValueError("R must be >= L")
    if u < 0 or Q * u >= P:
        return 0
    n = R - L
    lo = Q * u
    hi = min(Q * (u + 1), P)
    return floor_sum(n, P, a, a * L - lo) - floor_sum(n, P, a, a * L - hi)


def compatible(a: int, P: int, Q: int, u: int, x: int) -> bool:
    return md(a * x, P, Q) == u


def select_rank(a: int, P: int, Q: int, u: int, L: int, R: int, k: int) -> int:
    total = count_interval(a, P, Q, u, L, R)
    if not (1 <= k <= total):
        raise ValueError("rank out of range")
    lo, hi = L, R
    while hi - lo > 1:
        mid = (lo + hi) // 2
        left = count_interval(a, P, Q, u, lo, mid)
        if k <= left:
            hi = mid
        else:
            lo = mid
            k -= left
    assert compatible(a, P, Q, u, lo)
    return lo


def local_data(a: int, x: int, y: int, Q: int):
    ux = (a * x) // Q
    uy = (a * y) // Q
    u = x * uy
    v = y * ux
    delta = v - u
    g = math.gcd(x * y, Q)
    return u, v, delta, g


def reduced_errors(Q: int, support=None) -> int:
    xs = range(Q) if support is None else support
    total = 0
    for a in range(Q):
        for x in xs:
            for y in xs:
                u, v, _, g = local_data(a, x, y, Q)
                total += g * abs(v // g - u // g)
    return total


def alpha_from_formula(q: int) -> Fraction:
    # Proposition count already averages over h: bad count per (a,x,y) is g*|...|,
    # so alpha = 1 - sum_bad / Q^4 after multiplying each bad phase count by g;
    # reduced_errors above exactly sums g*|...| over (a,x,y).
    Q = 1 << q
    bad = reduced_errors(Q)
    return Fraction(Q**4 - bad, Q**4)


def upper_half_alpha(q: int) -> Fraction:
    Q = 1 << q
    supp = range(Q//2, Q)
    bad = reduced_errors(Q, supp)
    den = Q * Q * (Q//2) ** 2  # a,h,x,y
    # reduced_errors sums the number of bad h values for each (a,x,y), hence denominator Q*(Q/2)^2*Q
    return Fraction(den - bad, den)


def direct_keys(A: int, x: int, y: int, p: int, q: int):
    P, Q = 1 << p, 1 << q
    U = md(A * x, P, Q)
    V = md(A * y, P, Q)
    wa = md(Q * x * V, P, Q * Q)
    wb = md(Q * y * U, P, Q * Q)
    return wa, wb


def direct_alpha(p: int, q: int, support=None) -> Fraction:
    P, Q = 1 << p, 1 << q
    xs = list(range(Q) if support is None else support)
    good = 0
    total = P * len(xs) * len(xs)
    for A in range(P):
        for x in xs:
            for y in xs:
                good += direct_keys(A, x, y, p, q)[0] == direct_keys(A, x, y, p, q)[1]
    return Fraction(good, total)


def aligned_direct(P: int, Q: int) -> Fraction:
    good = 0
    total = P * Q * Q
    for A in range(P):
        U = [md(A*x, P, Q) for x in range(Q)]
        for x in range(Q):
            for y in range(Q):
                wa = md(Q*x*U[y], P, Q*Q)
                wb = md(Q*y*U[x], P, Q*Q)
                good += wa == wb
    return Fraction(good, total)


def verify_floor_sums() -> int:
    cases = 0
    rng = random.Random(0xA1)
    for _ in range(5000):
        n = rng.randrange(0, 40)
        m = rng.randrange(1, 50)
        a = rng.randrange(-100, 101)
        b = rng.randrange(-100, 101)
        got = floor_sum(n, m, a, b)
        exp = sum((a*i+b)//m for i in range(n))
        assert got == exp, (n,m,a,b,got,exp)
        cases += 1
    return cases


def verify_interval_counts() -> int:
    cases = 0
    for P in range(1, 18):
        for Q in range(1, 9):
            for a in range(-5, 8):
                for L in range(-4, 4):
                    for R in range(L, 7):
                        for u in range(-1, (P + Q - 1)//Q + 2):
                            got = count_interval(a,P,Q,u,L,R)
                            vals = [x for x in range(L,R) if compatible(a,P,Q,u,x)]
                            assert got == len(vals)
                            if vals:
                                for k in (1, len(vals), (len(vals)+1)//2):
                                    assert select_rank(a,P,Q,u,L,R,k) == vals[k-1]
                            cases += 1
    return cases


def run_full_closure() -> list[dict]:
    compiler = shutil.which("g++") or shutil.which("clang++")
    if not compiler:
        raise RuntimeError("No C++17 compiler found")
    src = ROOT / "count_agreement_a1.cpp"
    exe = ROOT / "_count_agreement_a1"
    subprocess.run([compiler, "-O3", "-std=c++17", str(src), "-o", str(exe)], check=True)
    out = subprocess.check_output([str(exe), "quotient", "11"], text=True)
    rows = list(csv.DictReader(out.splitlines()))
    assert len(rows) == 11
    for q, row in enumerate(rows, 1):
        Q = 1 << q
        good = int(row["agreement"])
        total = int(row["total"])
        assert total == Q**4
        assert Fraction(good,total) == EXPECTED[q-1]
        assert 4*good - 3*total == int(row["margin_above_three_quarters"])
        assert Fraction(good,total) >= CSTAR
    (ROOT / "A1_COUNTS_Q1_Q11.csv").write_text(out, encoding="utf-8")
    return rows


def run() -> dict:
    checks = {}
    checks["floor_sum_random_cases"] = verify_floor_sums()
    checks["interval_count_exhaustive_cases"] = verify_interval_counts()

    # A1-01 regression: the autonomous counting formula is guarded outside the output alphabet.
    assert count_interval(1, 5, 2, -1, 4, 5) == 0
    assert count_interval(1, 5, 2, 3, 0, 1) == 0
    checks["guard_regression_cases"] = 2

    # Direct protocol profiles and independence from p for small q.
    direct = []
    for q in range(1, 5):
        vals = []
        for p in (2*q+1, 2*q+2):
            a = direct_alpha(p,q)
            vals.append(a)
            direct.append({"p":p,"q":q,"alpha":str(a)})
        assert vals[0] == vals[1] == EXPECTED[q-1]
    checks["direct_small_profiles"] = len(direct)

    # Exact reduced formula through q=7 in pure Python.
    py_table = []
    for q in range(1, 8):
        a = alpha_from_formula(q)
        assert a == EXPECTED[q-1]
        assert a >= CSTAR
        py_table.append({"q":q,"alpha":str(a)})
    checks["python_full_range_rows"] = len(py_table)

    uh = upper_half_alpha(7)
    assert uh == Fraction(12540509,16777216) < Fraction(3,4)
    checks["upper_half_reduced_profile"] = 1

    # Small aligned J-invariance checks with arbitrary integer Q.
    aligned = []
    for Q in range(2, 7):
        vals = []
        for J in (2,3,4):
            a = aligned_direct(J*Q*Q, Q)
            vals.append(a)
            aligned.append({"Q":Q,"J":J,"alpha":str(a)})
        assert len(set(vals)) == 1
    checks["aligned_direct_profiles"] = len(aligned)

    assert CSTAR == Fraction(41,54) - Fraction(57,8192)
    assert CSTAR > Fraction(3,4)
    assert Fraction(41,54) > Fraction(3,4)
    assert Fraction(241,324) < Fraction(3,4)

    return {
        "status":"PASS",
        "scope":"A1 scalar exact arithmetic and finite checks; no security certification",
        "checks":checks,
        "cstar":str(CSTAR),
        "python_full_range_table":py_table,
        "upper_half_q7":str(uh),
        "direct_small_profiles":direct,
        "aligned_small_profiles":aligned,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", type=Path, default=ROOT/"A1_VERIFY_RESULTS.json")
    ap.add_argument("--full-closure", action="store_true", help="compile/run C++ exact q=1..11 counter")
    args = ap.parse_args()
    result = run()
    if args.full_closure:
        result["full_closure_rows"] = run_full_closure()
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result["checks"], indent=2))
    if args.full_closure:
        print("full closure: PASS (q=1..11)")
    print("PASS:", args.output)

if __name__ == "__main__":
    main()
