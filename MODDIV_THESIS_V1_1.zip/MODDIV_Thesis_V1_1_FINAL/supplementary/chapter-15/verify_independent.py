#!/usr/bin/env python3
import json,math
assert math.ceil((8+256+7680)/8)==993
assert (1024*11)//8==1408
assert 9*256*256==589824 and 12*256*256==786432 and 3*256*256==196608
print(json.dumps({'status':'PASS','independent_exact_checks':5},indent=2))
