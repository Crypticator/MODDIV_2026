#!/usr/bin/env python3
import argparse,json,pathlib
ap=argparse.ArgumentParser();ap.add_argument('--output');a=ap.parse_args()
n=256;k=3
kg=k*k*n*n;enc=(k*k+k)*n*n;dec=k*n*n
assert (kg,enc,dec)==(589824,786432,196608)
pk=1+32+(768*10)//8;ct=(1024*11)//8;assert (pk,ct)==(993,1408)
compact=(256+64*32*(256-128))//8;assert compact==32800
r={'status':'PASS','C1_ring_products':{'keygen':kg,'enc':enc,'dec':dec},'C1_payload_bytes':{'pk':pk,'ct':ct},'WC_compact_bytes':compact,'WC_proof_route_barrier_bytes_tau128':4726272,'deployment_winner':False}
if a.output:pathlib.Path(a.output).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps(r,indent=2,sort_keys=True))
