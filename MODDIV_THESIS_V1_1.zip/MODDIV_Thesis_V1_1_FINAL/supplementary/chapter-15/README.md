# Chapter 15 — Parameters, Efficiency, and Implementation: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Recomputes the exact C1 payloads, schoolbook ring-product counts, WC compact representation and the current proof-route barrier used by the deployment ledger.

## Reproduction

```sh
python3 verify.py
python3 verify_independent.py
```

## Limits

These are arithmetic/format facts, not a concrete security estimate or optimized benchmark.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
