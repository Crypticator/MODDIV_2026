"""Exact research arithmetic for A3 Polynomial ModDiv article.

Not a deployment library. Fixed-length coefficient lists, increasing degree.
Historical rules, the unrounded field model and the MP-CLWR reference
specialization are separate interfaces. No network, floating-point arithmetic,
or hidden planted secret is used by the public linear solver.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Sequence
import random


def conv(a: Sequence[int], b: Sequence[int]) -> list[int]:
    if not a or not b:
        raise ValueError('polynomial arrays must be nonempty')
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += x * y
    return out


def window(a: Sequence[int], m: int, n: int) -> list[int]:
    if not 0 <= n < m:
        raise ValueError('require 0 <= n < m')
    return [a[i] if i < len(a) else 0 for i in range(n, m)]


def matrix(a: Sequence[int], m: int, n: int) -> list[list[int]]:
    if n < 0 or m <= n or len(a) < m:
        raise ValueError('invalid public ribbon or dimensions')
    return [[a[n + i - j] for j in range(n + 1)] for i in range(m - n)]


def matvec(M: Sequence[Sequence[int]], x: Sequence[int]) -> list[int]:
    if any(len(row) != len(x) for row in M):
        raise ValueError('matrix/vector dimension mismatch')
    return [sum(a * b for a, b in zip(row, x)) for row in M]


def stage(x: Sequence[int], v: Sequence[int], m: int, n: int) -> list[int]:
    if n < 0 or m <= 2 * n or len(x) != n + 1 or len(v) != m - n:
        raise ValueError('incompatible nested-window dimensions')
    return [sum(x[j] * v[n + i - j] for j in range(n + 1))
            for i in range(m - 2 * n)]


def floor_round(z: int, P: int, Q: int) -> int:
    if P <= 0 or Q <= 0:
        raise ValueError('positive modulus and divisor required')
    return (z % P) // Q


def publication(a: Sequence[int], x: Sequence[int], m: int, n: int,
                P: int, Q: int) -> list[int]:
    if P <= Q or Q < 1:
        raise ValueError('require P > Q >= 1')
    return [floor_round(z, P, Q) for z in matvec(matrix(a, m, n), x)]


def trailing_run(w: int) -> int:
    """Length of the terminal equal-bit run; zero is deliberately undefined."""
    if w <= 0:
        raise ValueError('historical counter is undefined for nonpositive input')
    bit, run = w & 1, 0
    while (w & 1) == bit:
        run += 1
        w >>= 1
    return run


def historical_outputs(R: Sequence[int], P: int, Q: int,
                       n: int, qbits: int, mode: int) -> list[int] | None:
    """Two exact symmetric readings of the public counter in ePrint 2021/701.

    The printed rule first performs integer division R_i // n and then counts
    the terminal equal-bit run.  ``mode=0`` models the printed loop and
    ``mode=1`` the prose interpretation.  A normalized counter input of zero
    is undefined for the unbounded-integer loop and is therefore reported as
    ``None`` rather than counted as an agreement.
    """
    if n < 1 or qbits < 1 or mode not in (0, 1):
        raise ValueError('invalid historical convention')
    normalized = [w // n for w in R]
    if any(w <= 0 for w in normalized):
        return None
    return [(Q*raw % P) // (n * (1 << (2*qbits + trailing_run(w) + mode)))
            for raw, w in zip(R, normalized)]


def exchange(a: Sequence[int], x: Sequence[int], y: Sequence[int],
             m: int, n: int, P: int, Q: int, qbits: int) -> dict:
    U = publication(a, x, m, n, P, Q)
    V = publication(a, y, m, n, P, Q)
    RA, RB = stage(x, V, m, n), stage(y, U, m, n)
    return {'U': U, 'V': V, 'RA': RA, 'RB': RB,
            'SA': [Q*w % P for w in RA], 'SB': [Q*w % P for w in RB],
            'H0A': historical_outputs(RA, P, Q, n, qbits, 0),
            'H0B': historical_outputs(RB, P, Q, n, qbits, 0),
            'H1A': historical_outputs(RA, P, Q, n, qbits, 1),
            'H1B': historical_outputs(RB, P, Q, n, qbits, 1)}


def rank_mod(M: Sequence[Sequence[int]], prime: int) -> int:
    """Gaussian rank over a *known prime* modulus; caller verifies primality."""
    if prime < 2 or not M:
        raise ValueError('nonempty matrix and prime modulus required')
    a = [[v % prime for v in row] for row in M]
    cols = len(a[0])
    if any(len(row) != cols for row in a):
        raise ValueError('ragged matrix')
    row = 0
    for col in range(cols):
        pivot = next((i for i in range(row, len(a)) if a[i][col]), None)
        if pivot is None:
            continue
        a[row], a[pivot] = a[pivot], a[row]
        inv = pow(a[row][col], -1, prime)
        a[row] = [v*inv % prime for v in a[row]]
        for i in range(row + 1, len(a)):
            c = a[i][col]
            if c:
                a[i] = [(v-c*w) % prime for v, w in zip(a[i], a[row])]
        row += 1
        if row == len(a):
            break
    return row


def solve_field(M: Sequence[Sequence[int]], b: Sequence[int], prime: int) -> list[int] | None:
    """Return any solution over F_prime, not a support-constrained secret."""
    if not M or len(M) != len(b) or prime < 2:
        raise ValueError('invalid system')
    cols = len(M[0])
    if any(len(row) != cols for row in M):
        raise ValueError('ragged matrix')
    a = [[v % prime for v in row] + [rhs % prime] for row, rhs in zip(M, b)]
    pivots: list[int] = []
    for col in range(cols):
        r = len(pivots)
        pivot = next((i for i in range(r, len(a)) if a[i][col]), None)
        if pivot is None:
            continue
        a[r], a[pivot] = a[pivot], a[r]
        inv = pow(a[r][col], -1, prime)
        a[r] = [v*inv % prime for v in a[r]]
        for i in range(len(a)):
            if i != r and a[i][col]:
                c = a[i][col]
                a[i] = [(v-c*w) % prime for v, w in zip(a[i], a[r])]
        pivots.append(col)
        if len(pivots) == len(a):
            break
    if any(not any(row[:cols]) and row[-1] for row in a):
        return None
    x = [0] * cols
    for i, col in enumerate(pivots):
        x[col] = a[i][-1]
    return x


def middle(a: Sequence[int], b: Sequence[int], length: int) -> list[int]:
    delta = len(a) + len(b) - 1 - length
    if length <= 0 or delta < 0 or delta % 2:
        raise ValueError('incompatible middle-product lengths')
    start = delta // 2
    return window(conv(a, b), start + length, start)


def nearest_round(c: int, q: int, p: int) -> int:
    if p < 2 or q % p or (q // p) % 2:
        raise ValueError('require q = p*B, B positive even, p >= 2')
    B = q // p
    return ((c + B//2) % q) // B


def lift_value(y: int, e: int, q: int, p: int) -> int:
    B = q // p
    if not (0 <= y < p and 0 <= e < B) or q % p or B % 2:
        raise ValueError('invalid lift input')
    return (B*y - B//2 + e) % q


def keybit(x: int, q: int) -> int:
    if q % 8 or q < 8:
        raise ValueError('q must be divisible by 8')
    return ((2*(x % q) + q//2) // q) % 2


def hintbit(x: int, q: int) -> int:
    if q % 8 or q < 8:
        raise ValueError('q must be divisible by 8')
    return (4*(x % q) // q) % 2


def reconcile(y: int, b: int, q: int) -> int:
    if q % 8 or q < 8 or b not in (0, 1):
        raise ValueError('invalid reconciliation parameters')
    lo = (-q//8) if b == 0 else (-3*q//8)
    hi = (3*q//8 - 2) if b == 0 else (q//8 - 2)
    return 0 if (y - lo) % q <= hi - lo else 1


@dataclass(frozen=True)
class ReferenceParameters:
    n: int
    d: int
    k: int
    t: int
    p: int
    q: int

    def validate(self) -> None:
        if min(self.d, self.k) < 2 or self.n < self.d + self.k or self.t < 1:
            raise ValueError('invalid reference dimensions')
        if self.p < 2 or self.q <= self.p or self.p & (self.p-1) or self.q & (self.q-1):
            raise ValueError('p and q must be powers of two with 2 <= p < q')
        if self.q % 8:
            raise ValueError('q must be divisible by 8')

    @property
    def D(self) -> int:
        return self.d + self.k

    def correct(self) -> bool:
        return self.p > 8*self.t*(self.k+1)

    def security_inequalities(self, lam: int) -> bool:
        return (lam > 0 and self.d >= lam and self.correct()
                and self.t*(self.k+1) >= 2*lam + (self.n+self.k+self.d)*(self.q.bit_length()-1))


def reference_keygen(par: ReferenceParameters, rng=None, max_attempts: int | None = None):
    par.validate()
    rng = rng or random.SystemRandom()
    attempts = 0
    while max_attempts is None or attempts < max_attempts:
        attempts += 1
        s = [rng.randrange(par.q) for _ in range(par.n+par.D-1)]
        hank = [[s[i+j] for j in range(par.n)] for i in range(par.D)]
        if rank_mod(hank, 2) == par.D:
            pk = []
            for _ in range(par.t):
                a = [rng.randrange(par.q) for _ in range(par.n)]
                b = [nearest_round(v, par.q, par.p) for v in middle(a, s, par.D)]
                pk.append((a, b))
            return pk, s, attempts
    return None


class TestOracle:
    """Lazy ideal-oracle table for tests only; not a real hash security claim."""
    def __init__(self, k: int, rng):
        self.k, self.rng, self.table = k, rng, {}

    def __call__(self, bits: Sequence[int]) -> list[int]:
        key = tuple(bits)
        if any(b not in (0, 1) for b in key):
            raise ValueError('oracle domain is binary')
        if key not in self.table:
            self.table[key] = [self.rng.randrange(2) for _ in range(self.k)]
        return self.table[key][:]


def reference_encrypt(par: ReferenceParameters, pk, msg: Sequence[int], oracle,
                      rng=None, extreme: int | None = None):
    par.validate()
    if len(pk) != par.t or len(msg) != par.k or any(b not in (0, 1) for b in msg):
        raise ValueError('invalid key/message size')
    rng = rng or random.SystemRandom()
    c1, v = [0]*(par.n+par.k), [0]*par.d
    rlist, ulist = [], []
    B = par.q//par.p
    for a, b in pk:
        if len(a) != par.n or len(b) != par.D:
            raise ValueError('invalid public-key block')
        r = [rng.randrange(2) for _ in range(par.k+1)] if extreme is None else [1]*(par.k+1)
        u = [lift_value(y, rng.randrange(B) if extreme is None else (0 if extreme == 0 else B-1),
                        par.q, par.p) for y in b]
        c1 = [(x+y) % par.q for x,y in zip(c1, conv(r,a))]
        v = [(x+y) % par.q for x,y in zip(v, middle(r,u,par.d))]
        rlist.append(r); ulist.append(u)
    c2 = [hintbit(x, par.q) for x in v]
    z = [keybit(x, par.q) for x in v]
    c3 = [a ^ b for a,b in zip(oracle(z), msg)]
    return (c1,c2,c3), {'r':rlist, 'u':ulist, 'v':v, 'z':z}


def reference_decrypt(par: ReferenceParameters, s: Sequence[int], ct, oracle):
    c1,c2,c3 = ct
    if len(s) != par.n+par.D-1 or len(c1) != par.n+par.k or len(c2) != par.d or len(c3) != par.k:
        raise ValueError('invalid secret/ciphertext dimensions')
    w = [v % par.q for v in middle(c1,s,par.d)]
    z = [reconcile(a,b,par.q) for a,b in zip(w,c2)]
    return [a ^ b for a,b in zip(c3,oracle(z))], w, z


def next_power_strict(x: int) -> int:
    return 1 << x.bit_length()


def conservative_family(lam: int) -> ReferenceParameters:
    """Conservative illustrative family; no concrete security claim."""
    if lam < 2:
        raise ValueError('lambda >= 2 required')
    n = 2*lam
    t = 64*lam.bit_length()
    p = next_power_strict(8*t*(lam+1))
    q = next_power_strict(2*p*n**3*t)
    return ReferenceParameters(n,lam,lam,t,p,q)
