# Chapter 9 — Polynomial MODDIV: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Runs the final A3 v1.1 normalized-counter suite and independent reconstruction. The exact 944/1600 and 986/1606 counts and normalized-zero regression are included.

## Reproduction

```sh
python3 verify.py
python3 verify_independent.py
```

All deterministic reference outputs are stored in this directory. The verification scripts write reruns to temporary files and compare exact JSON objects whenever applicable.

## Limits

P-ROUND and P-REF remain distinct. The finite checks do not transfer MP-LWR hardness to historical P-ROUND.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
