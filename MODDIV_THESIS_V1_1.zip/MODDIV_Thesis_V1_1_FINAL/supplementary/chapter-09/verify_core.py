#!/usr/bin/env python3
"""Deterministic finite checks. Run from the package directory."""
from __future__ import annotations
import argparse, json, random
from collections import Counter
from fractions import Fraction
from itertools import product
from pathlib import Path
from math import gcd
from polynomial_moddiv_a3 import *


def ratio(n, d):
    v = Fraction(n,d)
    return f'{v.numerator}/{v.denominator}'


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',default='A3_RESULTS.json')
    args=ap.parse_args(); rng=random.Random(2026110901)
    counts=Counter(); result={'seed':2026110901,'status':'PASS','counts':counts}
    # Pure polynomial windows, including signed coefficients.
    for _ in range(2500):
        n=rng.randrange(0,6); m=rng.randrange(2*n+1,3*n+9)
        a=[rng.randrange(-9,10) for _ in range(m+1)]
        x=[rng.randrange(-5,6) for _ in range(n+1)]
        y=[rng.randrange(-5,6) for _ in range(n+1)]
        ax=window(conv(a,x),m,n); ay=window(conv(a,y),m,n)
        assert ax==matvec(matrix(a,m,n),x)
        assert stage(x,ay,m,n)==window(conv(conv(a,x),y),m,2*n)==stage(y,ax,m,n)
        # Last coefficient a_m is outside every published window.
        aa=a[:]; aa[m]+=12345
        assert matvec(matrix(aa,m,n),x)==ax
        counts['window_and_nested_signed_instances']+=1
    # Exact field model: recover the shared product, not necessarily true x.
    for prime,n,m in [(2,1,4),(2,2,6),(3,1,4)]:
        vectors=list(product(range(prime),repeat=n+1))
        for a in product(range(prime),repeat=m):
            M=matrix(a,m,n); rank=rank_mod(M,prime)
            pubs={x:[v%prime for v in matvec(M,x)] for x in vectors}
            for x in vectors:
                xs=solve_field(M,pubs[x],prime); assert xs is not None
                assert [v%prime for v in matvec(M,xs)]==pubs[x]
                for y in vectors:
                    expected=[v%prime for v in stage(y,pubs[x],m,n)]
                    predicted=[v%prime for v in stage(xs,pubs[y],m,n)]
                    assert predicted==expected
                    counts['bare_field_key_predictions']+=1
                    if rank<n+1: counts['predictions_with_rank_deficiency']+=1
    # Rounded residue identities and integer feasibility, not an inversion solver.
    for _ in range(4000):
        n=rng.randrange(1,5); d=n+1; m=rng.randrange(2*n+1,3*n+7)
        P=rng.randrange(3,90); Q=rng.randrange(1,P)
        a=[rng.randrange(-2*P,3*P) for _ in range(m+1)]
        x=[rng.randrange(0,16) for _ in range(d)]; y=[rng.randrange(0,16) for _ in range(d)]
        M=matrix(a,m,n); ax=matvec(M,x); ay=matvec(M,y)
        U=[floor_round(z,P,Q) for z in ax]; V=[floor_round(z,P,Q) for z in ay]
        ex=[(z%P)%Q for z in ax]; ey=[(z%P)%Q for z in ay]
        SA=[Q*z%P for z in stage(x,V,m,n)]; SB=[Q*z%P for z in stage(y,U,m,n)]
        eps=[b-a for a,b in zip(stage(x,ey,m,n),stage(y,ex,m,n))]
        bound=(Q-1)*max(sum(x),sum(y))
        assert all((s-t-e)%P==0 and abs(e)<=bound for s,t,e in zip(SA,SB,eps))
        for i,z in enumerate(ax):
            r=z%P
            assert Q*U[i]<=r<=min(Q*(U[i]+1)-1,P-1)
        counts['rounded_residue_identity_instances']+=1
        # Column boundary relation.
        sums=[sum(row[j] for row in M) for j in range(d)]
        for j in range(n): assert sums[j]-sums[j+1]==a[m-1-j]-a[n-1-j]
        counts['column_sum_boundary_instances']+=1
    # Common divisor does not by itself guarantee equality.
    n,m,P,Q,qbits=2,6,1543,5,3
    a1=[1580,1057,1283,1933,1248,1713,1749]; x1=[4,4,5];y1=[5,4,4]
    a2=[1810,1110,2023,1815,1926,1554,2031]
    # First printed disagreement witness, corrected by normalizing R_i with // n.
    w1=exchange(a1,x1,y1,m,n,P,Q,qbits)
    assert w1['H0A']==[4,2] and w1['H0B']==[4,1]
    assert w1['H1A']==[2,1] and w1['H1B']==[2,0]
    # Replacement witness: equal first residue but different normalized counters.
    xrep=[4,4,4]; yrep=[4,5,7]
    wrep=exchange(a1,xrep,yrep,m,n,P,Q,qbits)
    assert wrep['SA'][0]==wrep['SB'][0]==1216
    assert wrep['RA'][0]==2712 and wrep['RB'][0]==1169
    assert wrep['H0A']==[2,0] and wrep['H0B']==[1,0]
    assert wrep['H1A']==[1,0] and wrep['H1B']==[0,0]
    assert all(1543%k for k in range(2,40))
    for a in [a1,a2]:
        assert rank_mod(matrix(a,m,n),P)==3
        assert any((a[i+3]-a[i])%P for i in range(m-3))
    result['historical_witnesses']=[w1,wrep]
    result['historical_count_ribbons']=[a1,a2]
    conditional=[]
    vecs=list(product(range(4,8),repeat=3))
    for a in [a1,a2]:
        c=Counter()
        for x in vecs:
            for y in vecs:
                w=exchange(a,x,y,m,n,P,Q,qbits)
                for h in (0,1):
                    left,right=w[f'H{h}A'],w[f'H{h}B']
                    if left is None or right is None: c[f'undefined_H{h}']+=1
                    elif left==right: c[f'agreements_H{h}']+=1
                counts['historical_fixed_public_secret_pairs']+=1
        conditional.append(dict(sorted(c.items())))
    assert conditional[0]['agreements_H0']==944 and conditional[0]['agreements_H1']==1600
    assert conditional[1]['agreements_H0']==986 and conditional[1]['agreements_H1']==1606
    assert all(c.get('undefined_H0',0)==0 and c.get('undefined_H1',0)==0 for c in conditional)
    result['historical_conditional_counts']=conditional
    # Deterministic selected boundary example with public common D=256.
    for trial in range(10000):
        a=[rng.randrange(1024,2048) for _ in range(7)]
        x=[rng.randrange(4,8) for _ in range(3)];y=[rng.randrange(4,8) for _ in range(3)]
        U=publication(a,x,6,2,1543,5);V=publication(a,y,6,2,1543,5)
        ra=stage(x,V,6,2);rb=stage(y,U,6,2)
        sa=[5*w%1543 for w in ra];sb=[5*w%1543 for w in rb]
        ka=[w//256 for w in sa];kb=[w//256 for w in sb]
        if ka!=kb and rank_mod(matrix(a,6,2),1543)==3:
            result['fixed_divisor_witness']={'a':a,'x':x,'y':y,'U':U,'V':V,'RA':ra,'RB':rb,'SA':sa,'SB':sb,'D':256,'KA':ka,'KB':kb};break
    else: raise AssertionError('expected witness not found')
    # Defined erasure, under minimal p. Inputs with floor(R/n)=0 are undefined
    # and are never counted as agreements or as defined erasure cases.
    for n in range(1,6):
        for qb in range(1,6):
            pbits=2*qb+n.bit_length()
            P=(1<<pbits)-1
            for w in range(1,300):
                out0=historical_outputs([w],P,(1<<qb)-1,n,qb,0)
                out1=historical_outputs([w],P,(1<<qb)-1,n,qb,1)
                if w < n:
                    assert out0 is None and out1 is None
                    counts['erasure_undefined_normalized_zero_inputs']+=1
                else:
                    assert out0==[0] and out1==[0]
                    counts['erasure_defined_inputs']+=1
    assert historical_outputs([0],97,3,1,2,0) is None
    assert historical_outputs([1],97,3,2,2,0) is None
    # Coefficient bitlength formula.
    for d in range(1,20):
        for sbits in range(1,20):
            upper=d*((1<<sbits)-1)
            assert upper.bit_length() <= sbits + (d-1).bit_length()
            counts['coefficient_bitlength_bounds']+=1
    # Matrix-structure TV by exact counting on the small full ambient space.
    struct=[]
    for P in (2,3,4):
        # n=1, m=3 -> 2 by 2; algebraic illustration only, not key-exchange dimensions.
        support={tuple(sum(matrix(a,3,1),[])) for a in product(range(P),repeat=3)}
        assert len(support)==P**3
        tv=sum(abs((Fraction(1,P**3) if v in support else 0)-Fraction(1,P**4))
               for v in product(range(P),repeat=4))/2
        assert tv==1-Fraction(1,P)
        struct.append({'P':P,'tv':str(tv)});counts['structured_matrix_TV_models']+=1
    result['structured_matrix_TV']=struct
    # Rounding, INV and reconciliation are integer-exact.
    for q in (8,16,32,64,128,256):
        for p in (2,4,8,16,32,64,128):
            if p>=q: continue
            B=q//p
            for c in range(-2*q,2*q+1):
                wanted=((2*p*(c%q)+q)//(2*q))%p
                assert nearest_round(c,q,p)==wanted
                counts['nearest_round_signed_inputs']+=1
            for yy in range(p):
                f={c for c in range(q) if nearest_round(c,q,p)==yy}
                lifts={lift_value(yy,e,q,p) for e in range(B)}
                assert f==lifts and len(f)==B
                counts['inverse_fibres']+=1
        pairs=Counter((keybit(x,q),hintbit(x,q)) for x in range(q))
        assert set(pairs.values())=={q//4} and len(pairs)==4
        for x in range(q):
            for e in range(-q//8+1,q//8):
                assert reconcile((x+e)%q,hintbit(x,q),q)==keybit(x,q)
                counts['reconciliation_inputs']+=1
    # Rank modulo 2 vs complete images modulo 4.
    for s in product(range(4),repeat=3):
        h=[[s[i+j] for j in range(2)] for i in range(2)]
        image={tuple(v%4 for v in matvec(h,x)) for x in product(range(4),repeat=2)}
        assert (rank_mod(h,2)==2)==(len(image)==16)
        counts['surjectivity_image_checks']+=1
    # Weak associativity, all dimensions explicit.
    for _ in range(1200):
        d=rng.randrange(2,7);k=rng.randrange(2,6);N=rng.randrange(d+k,d+k+5)
        a=[rng.randrange(-5,6) for _ in range(N)]
        s=[rng.randrange(-5,6) for _ in range(N+d+k-1)]
        r=[rng.randrange(2) for _ in range(k+1)]
        assert middle(r,middle(a,s,d+k),d)==middle(conv(r,a),s,d)
        counts['reference_weak_associativity_instances']+=1
    # Universality over a composite coefficient modulus.
    for delta in product((-1,0,1),repeat=3):
        if not any(delta):continue
        hist=Counter(tuple(c%4 for c in middle(delta,u,2)) for u in product(range(4),repeat=4))
        assert len(hist)==16 and set(hist.values())=={16}
        counts['universal_hash_differences']+=1
        counts['universal_hash_seed_evaluations']+=4**4
    # Functional/reference tests; no security level inferred.
    transcripts=[]; summaries=[]
    profiles=[(ReferenceParameters(8,4,4,3,256,65536),None,120),
              (conservative_family(2),2,4),(conservative_family(8),8,4),(conservative_family(16),16,4)]
    for par,lam,reps in profiles:
        par.validate();assert par.correct()
        if lam is not None:assert par.security_inequalities(lam)
        summary={'params':par.__dict__,'lambda_label':lam,'runs':reps,'max_error':0,'rejection_attempts':[]}
        for run in range(reps):
            pk,s,attempts=reference_keygen(par,rng)
            oracle=TestOracle(par.k,rng);msg=[rng.randrange(2) for _ in range(par.k)]
            ct,details=reference_encrypt(par,pk,msg,oracle,rng)
            dec,w,z=reference_decrypt(par,s,ct,oracle)
            assert dec==msg and details['z']==z
            maxerr=max(min((a-b)%par.q,(b-a)%par.q) for a,b in zip(w,details['v']))
            assert maxerr<=par.t*(par.k+1)*(par.q//par.p-1)<par.q//8
            summary['max_error']=max(summary['max_error'],maxerr)
            summary['rejection_attempts'].append(attempts)
            counts['reference_encryptions']+=1
            if run < 2:
                transcripts.append({'params':par.__dict__,'pk':pk,'s':s,'message':msg,'ct':ct,'detail':details,'w':w})
        summaries.append(summary)
    # Fixed extremal encryptions under an honest key.
    par=profiles[0][0];pk,s,_=reference_keygen(par,rng)
    for extreme in (0,1):
        oracle=TestOracle(par.k,rng);msg=[1]*par.k
        ct,detail=reference_encrypt(par,pk,msg,oracle,rng,extreme)
        dec,w,z=reference_decrypt(par,s,ct,oracle)
        assert dec==msg and z==detail['z'];counts['extremal_lift_encryptions']+=1
    result['reference_profiles']=summaries
    # Negative control when correction parameters are deliberately violated.
    a=[16,27,7,13];s=[4,16,12,13,5,15,4];r=[0,1,1];u=[26,11,20,4]
    b=[nearest_round(c,32,2) for c in middle(a,s,4)]
    assert b==[0,1,1,0] and all(nearest_round(c,32,2)==y for c,y in zip(u,b))
    v=[c%32 for c in middle(r,u,2)];w=[c%32 for c in middle(conv(r,a),s,2)]
    zz=[keybit(c,32) for c in v];got=[reconcile(a,hintbit(b,32),32) for a,b in zip(w,v)]
    assert v==[5,31] and w==[11,1] and zz==[0,0] and got==[1,0]
    result['outside_correction_bound']={'v':v,'w':w,'key':zz,'recovered':got}
    # Check entire conservative parameter family over a finite diagnostic range.
    for lam in range(2,257):
        par=conservative_family(lam);par.validate();assert par.security_inequalities(lam)
        counts['parameter_inequality_profiles']+=1
    result['counts']=dict(sorted(counts.items()))
    Path(args.output).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    Path('A3_REFERENCE_TRANSCRIPTS.json').write_text(json.dumps(transcripts,sort_keys=True,separators=(',',':'))+'\n')
    print(json.dumps(result['counts'],indent=2));print('PASS')

if __name__=='__main__':main()
