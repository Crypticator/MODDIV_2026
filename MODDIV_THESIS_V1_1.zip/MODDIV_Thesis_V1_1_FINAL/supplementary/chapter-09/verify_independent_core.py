#!/usr/bin/env python3
"""Independent arithmetic checks. Does NOT import polynomial_moddiv_a3.
The stored reference transcripts are synthetic validation records, not attacks.
"""
import argparse, json, random
from collections import Counter
from fractions import Fraction
from itertools import product
from pathlib import Path


def mul(a,b):
    # Coefficient-by-coefficient summation, different from the main scatter loop.
    return [sum(a[i]*b[k-i] for i in range(max(0,k-len(b)+1),min(len(a)-1,k)+1))
            for k in range(len(a)+len(b)-1)]


def cut(a,n,m):
    return [a[i] if i<len(a) else 0 for i in range(n,m)]


def mp(a,b,d):
    h=(len(a)+len(b)-1-d)//2
    assert 2*h==len(a)+len(b)-1-d and h>=0
    return cut(mul(a,b),h,h+d)


def rounded(a,x,m,n,P,Q):
    return [(v%P)//Q for v in cut(mul(a,x),n,m)]


def counter(w):
    # Printed loop count: one less than the full terminal equal-bit run.
    if w<=0:return None
    b=w%2;w//=2;r=0
    while b==w%2:
        r+=1;w//=2
    return r


def hist(a,x,y):
    P,Q,n,m,q=1543,5,2,6,3
    U,V=rounded(a,x,m,n,P,Q),rounded(a,y,m,n,P,Q)
    ra=cut(mul(x,V),n,m-n);rb=cut(mul(y,U),n,m-n)
    sa=[Q*w%P for w in ra];sb=[Q*w%P for w in rb]
    def f(R,s,h):
        W=[w//n for w in R]
        if any(w<=0 for w in W):return None
        return [v//(n*(1<<(2*q+counter(w)+1+h))) for v,w in zip(s,W)]
    return {'U':U,'V':V,'RA':ra,'RB':rb,'SA':sa,'SB':sb,
            'H0A':f(ra,sa,0),'H0B':f(rb,sb,0),'H1A':f(ra,sa,1),'H1B':f(rb,sb,1)}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default='A3_INDEPENDENT.json');args=ap.parse_args()
    here=Path(__file__).resolve().parent
    reference=json.loads((here/'A3_RESULTS.json').read_text())
    rgen=random.Random(2026110902);counts=Counter()
    a1=[1580,1057,1283,1933,1248,1713,1749]
    a2=[1810,1110,2023,1815,1926,1554,2031]
    witnesses=[(a1,[4,4,5],[5,4,4]),(a1,[4,4,4],[4,5,7])]
    for i,(a,x,y) in enumerate(witnesses):
        assert hist(a,x,y)==reference['historical_witnesses'][i]
    assert counter(1//2) is None
    counts['normalized_zero_counter_regressions']+=1
    for i,a in enumerate([a1,a2]):
        count=Counter()
        for x in product(range(4,8),repeat=3):
            for y in product(range(4,8),repeat=3):
                w=hist(a,x,y)
                for h in (0,1):
                    l,r=w[f'H{h}A'],w[f'H{h}B']
                    if l is None or r is None:count[f'undefined_H{h}']+=1
                    elif l==r:count[f'agreements_H{h}']+=1
                counts['historical_pairs_full_convolution']+=1
        assert dict(count)==reference['historical_conditional_counts'][i]
    z=reference['fixed_divisor_witness'];w=hist(z['a'],z['x'],z['y'])
    for name in ['U','V','RA','RB','SA','SB']: assert w[name]==z[name]
    assert [v//z['D'] for v in w['SA']]==z['KA']
    assert [v//z['D'] for v in w['SB']]==z['KB']
    for _ in range(1000):
        n=rgen.randrange(0,5);m=rgen.randrange(2*n+1,3*n+8)
        a=[rgen.randrange(-7,8) for _ in range(m+1)]
        x=[rgen.randrange(-3,4) for _ in range(n+1)];y=[rgen.randrange(-3,4) for _ in range(n+1)]
        out=cut(mul(x,cut(mul(a,y),n,m)),n,m-n)
        assert out==cut(mul(mul(a,x),y),2*n,m)
        counts['nested_convolution_signed_instances']+=1
    # Key determined by a compatible field preimage, even a different one.
    for _ in range(250):
        p=rgen.choice([2,3,5]);n=rgen.choice([1,2]);m=2*n+2
        a=[rgen.randrange(p) for _ in range(m)]
        x=[rgen.randrange(p) for _ in range(n+1)];y=[rgen.randrange(p) for _ in range(n+1)]
        U=[v%p for v in cut(mul(a,x),n,m)];V=[v%p for v in cut(mul(a,y),n,m)]
        target=[v%p for v in cut(mul(y,U),n,m-n)]
        for cand in product(range(p),repeat=n+1):
            if [v%p for v in cut(mul(a,cand),n,m)]==U:
                assert [v%p for v in cut(mul(cand,V),n,m-n)]==target
                counts['compatible_field_preimages_checked']+=1
    # Independently evaluate stored encryptions and every component of their trace.
    for rec in json.loads((here/'A3_REFERENCE_TRANSCRIPTS.json').read_text()):
        par=rec['params'];N,d,k,t,p,q=[par[x] for x in ('n','d','k','t','p','q')];B=q//p
        s=rec['s'];c1=[0]*(N+k);v=[0]*d
        for (a,b),r,u in zip(rec['pk'],rec['detail']['r'],rec['detail']['u']):
            expected=[((2*p*(c%q)+q)//(2*q))%p for c in mp(a,s,d+k)]
            assert b==expected
            assert all(((2*p*(c%q)+q)//(2*q))%p==out for c,out in zip(u,b))
            c1=[(x+y)%q for x,y in zip(c1,mul(r,a))]
            v=[(x+y)%q for x,y in zip(v,mp(r,u,d))]
        assert c1==rec['ct'][0] and v==rec['detail']['v']
        hints=[(x//(q//4))%2 for x in v]
        keys=[int(q//4<=x<3*q//4) for x in v]
        assert hints==rec['ct'][1] and keys==rec['detail']['z']
        w=[c%q for c in mp(c1,s,d)]; assert w==rec['w']
        got=[]
        for y,b in zip(w,hints):
            if b==0:zero=(y>=q-q//8 or y<=3*q//8-2)
            else:zero=(y>=q-3*q//8 or y<=q//8-2)
            got.append(0 if zero else 1)
        assert got==keys
        counts['reference_transcripts_reconstructed']+=1
    # Exhaustive independent table of nearest rounding and reconciliation on tiny q.
    for q in (8,16,32,64):
        for p in (2,4):
            if p>=q:continue
            B=q//p
            for y in range(p):
                lift={(B*y-B//2+e)%q for e in range(B)}
                actual={x for x in range(q) if ((2*p*x+q)//(2*q))%p==y}
                assert lift==actual; counts['independent_lift_fibres']+=1
        for x in range(q):
            b=x//(q//4)%2;bit=int(q//4<=x<3*q//4)
            I=list(range(q//4)) if b==0 else list(range(-q//4,0))
            E=list(range(-q//8,q//8))
            zeros={(i+e)%q for i in I for e in E}
            for e in range(-q//8+1,q//8):
                y=(x+e)%q
                assert (0 if y in zeros else 1)==bit
                counts['reconciliation_by_explicit_sets']+=1
    out={'status':'PASS','seed':2026110902,'counts':dict(sorted(counts.items())),
         'scope':'Recomputation of synthetic fixtures and finite identities; not new attack benchmarks.'}
    Path(args.output).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
