"""Independent arithmetic and finite-distribution checks. Standard library only.
No test certifies HB-LWE hardness or concrete security.
"""
from collections import Counter
from fractions import Fraction
from itertools import product
import json, random
from pathlib import Path
import a5_noise as nc

W={-1:1,0:2,1:1}
ETA=Counter()
for e,t in product(W,repeat=2): ETA[2*e+t]+=W[e]*W[t]

def h_ref(a,x,rows):
    # Ordinary polynomial product with reversed secret, independent of nc.hankel.
    c=[0]*(len(a)+len(x)-1)
    for i,a_i in enumerate(a):
        for j,x_j in enumerate(reversed(x)):
            c[i+j]+=a_i*x_j
    return tuple(c[len(x)-1+i] for i in range(rows))

def tv(c1,c2):
    n1,n2=sum(c1.values()),sum(c2.values())
    return sum(abs(Fraction(c1[k],n1)-Fraction(c2[k],n2)) for k in set(c1)|set(c2))/2

def direct_g1_bit(mu, *, lift=True, final_noise=True):
    """Full law, tiny d=ell=1,P=16,Q=8. Not a secure or correct profile."""
    out=Counter()
    for A,U,rho,Y in product(range(8,16),range(2),range(8) if lift else (0,),range(4,8)):
        B=8*U+rho
        for e1,e2 in product(ETA,ETA if final_noise else (0,)):
            v=((A*Y+e1)%16)//8
            w=((B*Y+e2+8*mu)%16)//8
            out[(A,U,v,w)]+=ETA[e1]*(ETA[e2] if final_noise else 1)
    return out

def simulator_g1_bit(mu,real):
    """Independent explicit simulator, including exact raw e and tau weights."""
    out=Counter()
    for a,c,R,bit in product(range(8),range(8),(4,5),(0,1)):
        A=a+8; B=c+8*bit; U=B//8
        if real:
            source=[]
            for S,e0,e1 in product((0,1),W,W):
                source.append(((a*S+e0)%8,(c*S+e1)%8,W[e0]*W[e1]))
        else:
            source=((b0,b1,1) for b0,b1 in product(range(8),repeat=2))
        for b0,b1,weight in source:
            for t0,t1 in product(W,repeat=2):
                v=((2*b0+A*R+t0)%16)//8
                w=((2*b1+B*R+t1+8*mu)%16)//8
                out[(A,U,v,w)]+=weight*W[t0]*W[t1]
    return out


def tensor_counts(local):
    out=Counter({():1})
    for pmf in local:
        new=Counter()
        for prefix,c in out.items():
            for value,v in pmf.items():
                if v: new[prefix+(value,)]+=c*v
        out=new
    return out

def conditional_hop2(p,a,signs,message,real=True):
    """Exact law at a fixed full source tape and fixed public lift bits.
    Retains the shared secret across ALL selected windows. Omitted windows
    are marginalized, not regenerated independently.
    """
    A=tuple(x+p.M for x in a[:p.m])
    B=tuple(a[p.m+i]+p.M*signs[i] for i in range(p.n))
    out=Counter()
    masks=[p.Q//2+4*j+e for j in range(p.Q//8) for e in (0,1)]
    for R in product(masks,repeat=p.d):
        ar=h_ref(A,R,p.n); br=h_ref(B,R,p.ell)
        secrets=list(product((0,1),repeat=p.d)) if real else [None]
        for S in secrets:
            raw=h_ref(a,S,p.source_rows) if real else None
            local=[]
            for j in list(range(p.n))+list(range(p.m,p.m+p.ell)):
                if j<p.n:
                    shift=ar[j]
                else:
                    i=j-p.m
                    shift=br[i]+(p.P//2)*message[i]
                pmf=Counter()
                if real:
                    for e,t in product(W,repeat=2):
                        b=(raw[j]+e)%p.M
                        z=((2*b+shift+t)%p.P)//p.Q
                        pmf[z]+=W[e]*W[t]
                else:
                    for b,t in product(range(p.M),W):
                        z=((2*b+shift+t)%p.P)//p.Q
                        pmf[z]+=W[t]
                local.append(pmf)
            out.update(tensor_counts(local))
    return out

def conditional_direct_g1(p,a,signs,message):
    A=tuple(x+p.M for x in a[:p.m])
    B=tuple(a[p.m+i]+p.M*signs[i] for i in range(p.n))
    out=Counter()
    for Y in product(range(p.Q//2,p.Q),repeat=p.d):
        ay=h_ref(A,Y,p.n); by=h_ref(B,Y,p.ell)
        local=[]
        values=list(ay)+[by[i]+(p.P//2)*message[i] for i in range(p.ell)]
        for value in values:
            pmf=Counter()
            for e,weight in ETA.items():
                pmf[((value+e)%p.P)//p.Q]+=weight
            local.append(pmf)
        out.update(tensor_counts(local))
    return out

def run():
    result={"date":"2026-11-10","scope":"NOISE-CPA explicit new encryption layer; conditional theorem only"}
    # Exact masks and scalar null lift, including both half and full public lifts.
    masks=[]
    for Q,d in [(8,1),(8,2),(8,4),(16,3),(32,2),(64,2)]:
        R=[Q//2+4*h+e for h in range(Q//8) for e in (0,1)]
        counts=Counter(tuple(r+2*s for r,s in zip(rr,ss)) for rr in product(R,repeat=d) for ss in product((0,1),repeat=d))
        assert len(counts)==(Q//2)**d and set(counts.values())=={1}
        masks.append({'Q':Q,'d':d,'states':len(counts),'exact_bijection':True})
    result['mask_bijections']=masks
    lifts=[]
    for M,Q in [(8,8),(16,8),(16,16),(32,8),(64,16)]:
        P=2*M
        full=Counter(a+M*s for a,s in product(range(M),(0,1)))
        assert len(full)==P and set(full.values())=={1}
        null_checks=0
        for shift in range(P):
            c=Counter()
            for b,t in product(range(M),W): c[(2*b+t+shift)%P]+=W[t]
            assert len(c)==P and set(c.values())=={2}
            u=Counter()
            for z,weight in c.items(): u[z//Q]+=weight
            assert set(u.values())=={2*Q}
            null_checks+=1
        inverse=Counter(Q*u+rho for u,rho in product(range(P//Q),range(Q)))
        assert set(inverse.values())=={1} and len(inverse)==P
        lifts.append({'M':M,'Q':Q,'shifts_checked':null_checks,'full_and_half_lifts_valid':True,
                      'uniform_no_dither_internal_TV':str(Fraction(Q-1,Q))})
    result['scalar_lifts']=lifts
    # Exact full tiny source/public/challenge laws, no floating point.
    joint=[]
    for mu in (0,1):
        direct=direct_g1_bit(mu)
        real=simulator_g1_bit(mu,True)
        null=simulator_g1_bit(mu,False)
        assert tv(direct,real)==0
        assert len(null)==64 and len(set(null.values()))==1
        joint.append({'message':mu,'joint_states':64,'real_world_TV':str(tv(direct,real)),
                      'null_uniform':True,'direct_total_integer_weight':sum(direct.values()),
                      'sim_real_total_integer_weight':sum(real.values()),
                      'sim_null_total_integer_weight':sum(null.values()),
                      'negative_control_no_lift_TV':str(tv(direct,direct_g1_bit(mu,lift=False))),
                      'negative_control_no_final_noise_TV':str(tv(direct,direct_g1_bit(mu,final_noise=False)))})
    assert all(Fraction(x['negative_control_no_lift_TV'])>0 for x in joint)
    assert all(Fraction(x['negative_control_no_final_noise_TV'])>0 for x in joint)
    result['exhaustive_hop2_tiny']=joint
    # Exact first hybrid, same tiny profile. Independent reference and lifted source.
    direct,sim=Counter(),Counter()
    for A,X,e in product(range(8,16),range(4,8),ETA):
        direct[(A,((A*X+e)%16)//8)]+=ETA[e]
    for a,S,R,e,t in product(range(8),(0,1),(4,5),W,W):
        b=(a*S+e)%8
        sim[(a+8,((2*b+(a+8)*R+t)%16)//8)]+=W[e]*W[t]
    assert tv(direct,sim)==0
    result['exhaustive_hop1_tiny']={'joint_states':len(direct),'real_world_TV':str(tv(direct,sim))}
    # Exhaustive associativity / middle-product identity for a nontrivial rectangular shape.
    count=0
    for a,x,y in product(product(range(4),repeat=4),product((0,1),repeat=2),product((0,1),repeat=2)):
        lhs=h_ref(h_ref(a,x,3),y,2)
        rhs=h_ref(h_ref(a,y,3),x,2)
        assert lhs==rhs
        count+=1
    result['double_product_exhaustive']={'public_module':4,'d':2,'ell':2,'cases':count}
    rng=random.Random(20261107)
    # Exact coin-coupling identities of the simulators at d>=2, not an exhaustive law enumeration.
    couplings=0
    for d,ell,P,Q in [(2,2,64,8),(3,2,256,8),(4,3,1024,16),(8,4,4096,32)]:
        p=nc.Params(P,Q,d,ell)
        for trial in range(250):
            a=tuple(rng.randrange(p.M) for _ in range(p.source_tape))
            s=tuple(rng.randrange(2) for _ in range(d))
            e=tuple(nc.cbd1(rng) for _ in range(p.source_rows))
            b=tuple((z+u)%p.M for z,u in zip(h_ref(a,s,p.source_rows),e))
            A=tuple(u+p.M for u in a[:p.m])
            B=tuple(a[p.m+i]+p.M*rng.randrange(2) for i in range(p.n))
            R=nc.mask_vector(p,rng)
            Y=tuple(r+2*z for r,z in zip(R,s))
            tau1=tuple(nc.cbd1(rng) for _ in range(p.n))
            tau2=tuple(nc.cbd1(rng) for _ in range(ell))
            ar=h_ref(A,R,p.n); br=h_ref(B,R,ell)
            ay=h_ref(A,Y,p.n); by=h_ref(B,Y,ell)
            c1=tuple((2*b[i]+ar[i]+tau1[i])%P for i in range(p.n))
            c2=tuple((2*b[p.m+i]+br[i]+tau2[i])%P for i in range(ell))
            assert c1==tuple((ay[i]+2*e[i]+tau1[i])%P for i in range(p.n))
            assert c2==tuple((by[i]+2*e[p.m+i]+tau2[i])%P for i in range(ell))
            assert set(range(p.n)).isdisjoint(range(p.m,p.m+ell))
            assert p.m+ell==p.source_rows
            couplings+=1
    result['higher_dimension_coin_couplings']={'cases':couplings,'dimensions':[2,3,4,8],
        'note':'Pointwise integer identities; not full high-dimensional distribution enumeration.'}

    # Full conditional distributions on a genuine 3x2 public geometry.
    p=nc.Params(16,8,2,2)
    fixed_public_checks=0
    for fixture in range(24):
        a=tuple(rng.randrange(p.M) for _ in range(p.source_tape))
        signs=tuple(rng.randrange(2) for _ in range(p.n))
        for mu in product((0,1),repeat=p.ell):
            direct=conditional_direct_g1(p,a,signs,mu)
            sim=conditional_hop2(p,a,signs,mu,real=True)
            null=conditional_hop2(p,a,signs,mu,real=False)
            assert tv(direct,sim)==0
            assert len(null)==p.H**(p.n+p.ell) and len(set(null.values()))==1
            fixed_public_checks+=1
    result['full_conditional_hop2_rectangular']={
        'params':vars(p),'fixed_public_fixtures':24,'messages_per_fixture':4,
        'joint_laws_compared':fixed_public_checks,'output_states_per_law':32,
        'TV_real':'0','null_uniform':True,
        'note':'All secrets and noises summed exactly for each fixed public; the 24 publics are not an exhaustive public set. Correctness bound is NOT satisfied at this tiny modulus.'}
    # Correction and its exact error identity on families satisfying strict bound.
    profiles=[nc.Params(4096,8,4,2),nc.Params(16384,8,16,16),nc.Params(65536,16,16,8)]
    corrections=[]
    for p in profiles:
        assert p.correctness_certified()
        max_error=0
        for trial in range(1000):
            A=tuple(p.M+rng.randrange(p.M) for _ in range(p.m))
            X=tuple(p.Q//2+rng.randrange(p.Q//2) for _ in range(p.d))
            Y=tuple(p.Q//2+rng.randrange(p.Q//2) for _ in range(p.d))
            e0=tuple(nc.noise_prime(rng) for _ in range(p.n))
            e1=tuple(nc.noise_prime(rng) for _ in range(p.n))
            e2=tuple(nc.noise_prime(rng) for _ in range(p.ell))
            rho=tuple(rng.randrange(p.Q) for _ in range(p.n))
            msg=tuple(rng.randrange(2) for _ in range(p.ell))
            ax=h_ref(A,X,p.n); ay=h_ref(A,Y,p.n)
            u=tuple(((z+e)%p.P)//p.Q for z,e in zip(ax,e0))
            pk=nc.PublicKey(p,A,u); sk=nc.SecretKey(p,X)
            ct=nc.encrypt_with_coins(pk,msg,Y,e1,e2,rho)
            assert nc.decrypt(sk,ct)==msg
            r0=tuple((z+e)%p.Q for z,e in zip(ax,e0))
            r1=tuple((z+e)%p.Q for z,e in zip(ay,e1))
            lift=tuple(p.Q*u[i]+rho[i] for i in range(p.n))
            by=h_ref(lift,Y,p.ell)
            r2=tuple((by[i]+e2[i])%p.Q for i in range(p.ell))
            first=h_ref(tuple(e0[i]-r0[i]+rho[i] for i in range(p.n)),Y,p.ell)
            second=h_ref(tuple(e1[i]-r1[i] for i in range(p.n)),X,p.ell)
            err=tuple(first[i]-second[i]+e2[i]-r2[i] for i in range(p.ell))
            dec_signal=h_ref(tuple(p.Q*v for v in ct.v),X,p.ell)
            for i in range(p.ell):
                assert (p.Q*ct.w[i]-dec_signal[i]-(p.P//2)*msg[i]-err[i])%p.P==0
                assert abs(err[i])<=p.error_bound()
            max_error=max(max_error,max(map(abs,err)))
        # Reused key, fresh encryptions and one independent KEM functionality check.
        pk,sk=nc.keygen(p,rng)
        for _ in range(100):
            msg=tuple(rng.randrange(2) for _ in range(p.ell))
            assert nc.decrypt(sk,nc.encrypt(pk,msg,rng))==msg
        c,k=nc.encaps(pk,rng); assert nc.decaps(sk,c)==k
        corrections.append({'params':vars(p),'proof_bound':p.error_bound(),'radius':p.P//4,
          'random_identity_and_decryption_cases':1000,'max_observed_integer_error':max_error,
          'same_key_fresh_ciphertexts':100,'kem_roundtrip':True,
          'security_level':'none claimed'})
    result['correctness']=corrections
    # Exhaust all decoding points inside the strict radius, with both message bits.
    points=0
    for P in (16,32,64,256,4096):
        for b in (0,1):
            for delta in range(-P//4+1,P//4):
                assert nc.decode_bit((P//2)*b+delta,P)==b
                points+=1
        assert nc.decode_bit(P//4,P)==0 and nc.decode_bit(3*P//4,P)==0
    result['decoder']={'interior_points_checked':points,'ties':'zero','strict_margin_required':True}
    # Malformed inputs: fail before computation, without claiming CCA.
    errors=0
    pk,sk=nc.keygen(profiles[0],rng)
    for msg in ((0,), (0,2), ('1',0)):
        try: nc.encrypt(pk,msg,rng)
        except ValueError: errors+=1
        else: raise AssertionError('bad message accepted')
    for ct in (nc.Ciphertext((0,), (0,0)),nc.Ciphertext((0,)*pk.params.n,(-1,0))):
        try: nc.decrypt(sk,ct)
        except ValueError: errors+=1
        else: raise AssertionError('bad ciphertext accepted')
    result['validation_checks']=errors

    # Explicit CCA/malleability negative control: second component is additively malleable.
    p=profiles[0]
    pk,sk=nc.keygen(p,rng)
    malleability=0
    for _ in range(100):
        msg=tuple(rng.randrange(2) for _ in range(p.ell))
        ct=nc.encrypt(pk,msg,rng)
        ww=list(ct.w); ww[0]=(ww[0]+p.H//2)%p.H
        altered=nc.Ciphertext(ct.v,tuple(ww))
        assert altered!=ct
        assert nc.decrypt(sk,altered)==(1-msg[0],)+msg[1:]
        malleability+=1
    result['cca_negative_control']={
        'tests':malleability,'known_bit_flip_verified':True,
        'conclusion':'The raw encryption is malleable and not IND-CCA2; this does not contradict conditional IND-CPA.'}
    result['not_claimed']=['HB-LWE hardness','standard LWE to HB-LWE reduction','128-bit security',
                           'CCA security','constant-time implementation','formal proof-assistant checking',
                           'unchanged historical key-exchange IND-CPA','exhaustive crypto-sized tests']
    return result

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--output', default='A5_RESULTS.json')
    args=parser.parse_args()
    r=run()
    Path(args.output).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(r,indent=2,sort_keys=True))
