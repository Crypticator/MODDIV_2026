#!/usr/bin/env python3
import json, pathlib, subprocess, sys, tempfile
ROOT=pathlib.Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as td:
    out=pathlib.Path(td)/'out.json'
    cmd=[sys.executable,str(ROOT/'verify_a5_independent.py'),'--output',str(out)] + []
    subprocess.run(cmd,cwd=ROOT,check=True)
    got=json.loads(out.read_text())
    exp=json.loads((ROOT/'independent_results.json').read_text())
    if got != exp:
        raise SystemExit('FAIL: regenerated JSON differs from reference')
print(json.dumps(got,indent=2,sort_keys=True))
print('PASS')
