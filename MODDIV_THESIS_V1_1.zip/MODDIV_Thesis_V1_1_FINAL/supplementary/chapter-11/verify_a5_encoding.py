#!/usr/bin/env python3
"""Deterministic A5 canonical-encoding regression suite.

This closes the public test-coverage claim in Table 6. It checks exactly:
- 1500 canonical encode/decode round trips (500 pk, 500 sk, 500 ct),
- 2500 noncanonical-format rejections,
- 60 encryption/decryption cycles through the canonical byte encodings.

Research/reproducibility code only. No hardness or deployment claim.
"""
from __future__ import annotations
import argparse
import json
import random
from pathlib import Path

import a5_noise as N
import a5_codec as C

ROOT = Path(__file__).resolve().parent
SEED = 2026111051
PROFILES = (
    N.Params(P=4096, Q=8, d=4, ell=2),
    N.Params(P=16384, Q=8, d=16, ell=16),
    N.Params(P=65536, Q=16, d=16, ell=8),
)


def expect_reject(fn, *args):
    try:
        fn(*args)
    except ValueError:
        return
    raise AssertionError('noncanonical encoding accepted')


def set_first_padding_bit(raw: bytes, nbits: int) -> bytes:
    if nbits % 8 == 0:
        raise AssertionError('fixture has no padding bit')
    out = bytearray(raw)
    out[-1] |= 1 << (nbits % 8)
    return bytes(out)


def run():
    rng = random.Random(SEED)
    counts = {
        'pk_roundtrips': 0,
        'sk_roundtrips': 0,
        'ct_roundtrips': 0,
        'canonical_roundtrips_total': 0,
        'noncanonical_rejections': 0,
        'encoded_encryptions': 0,
    }

    # 500 generated key/ciphertext fixtures. Each contributes three independent
    # canonical object round trips => exactly 1500 round trips.
    for i in range(500):
        p = PROFILES[i % len(PROFILES)]
        pk, sk = N.keygen(p, rng)
        msg = tuple(rng.randrange(2) for _ in range(p.ell))
        ct = N.encrypt(pk, msg, rng)

        pk_raw = C.pack_pk(pk)
        sk_raw = C.pack_sk(sk)
        ct_raw = C.pack_ct(p, ct)
        assert C.unpack_pk(p, pk_raw) == pk
        assert C.unpack_sk(p, sk_raw) == sk
        assert C.unpack_ct(p, ct_raw) == ct
        counts['pk_roundtrips'] += 1
        counts['sk_roundtrips'] += 1
        counts['ct_roundtrips'] += 1

        # Five deterministic invalid encodings per fixture => exactly 2500.
        # This profile family always has padding in pk and ct encodings.
        pk_bits = C.sizes_bits(p)['pk']
        ct_bits = C.sizes_bits(p)['ct']
        assert pk_bits % 8 != 0 and ct_bits % 8 != 0
        expect_reject(C.unpack_pk, p, pk_raw[:-1])
        expect_reject(C.unpack_pk, p, pk_raw + b'\x00')
        expect_reject(C.unpack_pk, p, set_first_padding_bit(pk_raw, pk_bits))
        expect_reject(C.unpack_ct, p, ct_raw + b'\x00')
        expect_reject(C.unpack_ct, p, set_first_padding_bit(ct_raw, ct_bits))
        counts['noncanonical_rejections'] += 5

    counts['canonical_roundtrips_total'] = (
        counts['pk_roundtrips'] + counts['sk_roundtrips'] + counts['ct_roundtrips']
    )

    # Exactly 60 end-to-end encryption tests that cross the byte boundary:
    # encode/decode pk and sk, encrypt using decoded pk, encode/decode ct,
    # decrypt using decoded sk.
    for i in range(60):
        p = PROFILES[i % len(PROFILES)]
        pk, sk = N.keygen(p, rng)
        pk2 = C.unpack_pk(p, C.pack_pk(pk))
        sk2 = C.unpack_sk(p, C.pack_sk(sk))
        msg = tuple(rng.randrange(2) for _ in range(p.ell))
        ct = N.encrypt(pk2, msg, rng)
        ct2 = C.unpack_ct(p, C.pack_ct(p, ct))
        assert N.decrypt(sk2, ct2) == msg
        counts['encoded_encryptions'] += 1

    assert counts == {
        'pk_roundtrips': 500,
        'sk_roundtrips': 500,
        'ct_roundtrips': 500,
        'canonical_roundtrips_total': 1500,
        'noncanonical_rejections': 2500,
        'encoded_encryptions': 60,
    }
    return {
        'status': 'PASS',
        'date': '2026-11-10',
        'seed': SEED,
        'profiles': [vars(p) for p in PROFILES],
        'counts': counts,
        'scope': 'Canonical encoding regression only; no HB-hardness, CCA, concrete-security, or deployment claim.',
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', default='A5_ENCODING_RESULTS.json')
    args = ap.parse_args()
    result = run()
    Path(args.output).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
