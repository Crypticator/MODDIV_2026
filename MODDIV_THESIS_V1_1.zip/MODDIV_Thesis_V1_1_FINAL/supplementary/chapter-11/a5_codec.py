"""Canonical bit packing for NOISE-CPA-LIFT. Parameters are external.
This reversible encoding does not compress the public tape to a seed.
Research code only; no constant-time or deployment claim.
"""
from __future__ import annotations
from typing import Iterable, Sequence
from a5_noise import Params, PublicKey, SecretKey, Ciphertext, validate_pk, _vec


def widths(p: Params) -> tuple[int, int]:
    return p.P.bit_length() - 1, p.Q.bit_length() - 1


def sizes_bits(p: Params) -> dict[str, int]:
    a, b = widths(p)
    return {'pk': p.m*(a-1)+p.n*(a-b), 'sk': p.d*(b-1),
            'ct': (p.n+p.ell)*(a-b)}


def sizes_bytes(p: Params) -> dict[str, int]:
    return {k: (v+7)//8 for k,v in sizes_bits(p).items()}


def _pack(fields: Iterable[tuple[int, int]]) -> bytes:
    acc = 0
    offset = 0
    for value, width in fields:
        if type(value) is not int or width < 1 or not 0 <= value < (1 << width):
            raise ValueError('non-canonical field')
        acc |= value << offset
        offset += width
    return acc.to_bytes((offset+7)//8, 'little')


def _unpack(data: bytes, field_widths: Sequence[int]) -> tuple[int, ...]:
    if not isinstance(data, bytes):
        raise ValueError('expected bytes')
    nbits = sum(field_widths)
    if len(data) != (nbits+7)//8:
        raise ValueError('incorrect encoded length')
    acc = int.from_bytes(data, 'little')
    if acc >> nbits:
        raise ValueError('nonzero padding')
    result = []
    for width in field_widths:
        if width < 1:
            raise ValueError('invalid field width')
        result.append(acc & ((1 << width)-1))
        acc >>= width
    return tuple(result)


def pack_pk(pk: PublicKey) -> bytes:
    validate_pk(pk)
    p = pk.params
    a, b = widths(p)
    return _pack([(x-p.M, a-1) for x in pk.a] + [(u, a-b) for u in pk.u])


def unpack_pk(p: Params, data: bytes) -> PublicKey:
    a,b = widths(p)
    v = _unpack(data, [a-1]*p.m+[a-b]*p.n)
    return PublicKey(p, tuple(x+p.M for x in v[:p.m]), v[p.m:])


def pack_sk(sk: SecretKey) -> bytes:
    p=sk.params
    _vec(sk.x, p.d, p.Q//2, p.Q, 'secret')
    _,b=widths(p)
    return _pack([(x-p.Q//2,b-1) for x in sk.x])


def unpack_sk(p: Params, data: bytes) -> SecretKey:
    _,b=widths(p)
    return SecretKey(p, tuple(x+p.Q//2 for x in _unpack(data,[b-1]*p.d)))


def pack_ct(p: Params, ct: Ciphertext) -> bytes:
    _vec(ct.v,p.n,0,p.H,'ciphertext v')
    _vec(ct.w,p.ell,0,p.H,'ciphertext w')
    a,b=widths(p)
    return _pack([(x,a-b) for x in ct.v+ct.w])


def unpack_ct(p: Params, data: bytes) -> Ciphertext:
    a,b=widths(p)
    v=_unpack(data,[a-b]*(p.n+p.ell))
    return Ciphertext(v[:p.n],v[p.n:])
