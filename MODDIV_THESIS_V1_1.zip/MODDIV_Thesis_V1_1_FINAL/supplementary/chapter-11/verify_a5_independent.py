#!/usr/bin/env python3
"""Independent A5 checks; imports no submitted arithmetic module.

Uses full polynomial multiplication and exhaustive error vectors for selected
rectangular games. Small examples do not certify a computational assumption.
"""
from __future__ import annotations
import argparse, json
from collections import Counter
from fractions import Fraction
from itertools import product
from pathlib import Path
ROOT=Path(__file__).resolve().parent
WEIGHT={-3:1,-2:2,-1:3,0:4,1:3,2:2,3:1}
CBD={-1:1,0:2,1:1}

def window(a,x,r):
    z=[0]*(len(a)+len(x)-1)
    for i in range(len(a)):
        for j in range(len(x)):
            z[i+j]+=a[i]*x[len(x)-1-j]
    return z[len(x)-1:len(x)-1+r]

def dist(a,b):
    na,nb=sum(a.values()),sum(b.values())
    return sum(abs(Fraction(a[k],na)-Fraction(b[k],nb)) for k in a.keys()|b.keys())/2

def binary_pack(fields):
    bits=''.join(format(v, '0%db'%w)[::-1] for v,w in fields)
    bits+='0'*((-len(bits))%8)
    return bytes(int(bits[i:i+8][::-1],2) for i in range(0,len(bits),8)).hex()

def error_vectors(n):
    answer=[]
    for es in product(WEIGHT,repeat=n):
        w=1
        for e in es:w*=WEIGHT[e]
        answer.append((es,w))
    return answer

def direct_law(A,B,mu,errors):
    out=Counter()
    for y in product(range(4,8),repeat=2):
        z=window(A,y,3)+[v+8*t for v,t in zip(window(B,y,2),mu)]
        for es,w in errors:
            out[tuple(((z[i]+es[i])%16)//8 for i in range(5))]+=w
    return out

def source_law(a,high,mu):
    A=[v+8 for v in a[:4]];B=[a[4+i]+8*high[i] for i in range(3)]
    out=Counter()
    for s in product((0,1),repeat=2):
        raw=window(a,s,6)
        for R in product((4,5),repeat=2):
            shift=window(A,R,3)+[v+8*t for v,t in zip(window(B,R,2),mu)]
            local=[]
            for index,j in enumerate((0,1,2,4,5)):
                c=Counter()
                for e,t in product(CBD,repeat=2):
                    b=(raw[j]+e)%8
                    c[((2*b+shift[index]+t)%16)//8]+=CBD[e]*CBD[t]
                local.append(c)
            for bits in product((0,1),repeat=5):
                mass=1
                for i,z in enumerate(bits):mass*=local[i][z]
                if mass:out[bits]+=mass
    return out

def run():
    data=json.loads((ROOT/'A5_TRANSCRIPTS.json').read_text())
    transcripts=0;coeffs=0
    for f in data['transcripts']:
        P,Q,d,ell=(f[k] for k in ('P','Q','d','ell'))
        n=d+ell-1;m=n+d-1
        A,X,Y,e0,e1,e2,rho,mu=(f[k] for k in ('A','X','Y','E0','E1','E2','rho','mu'))
        ax=window(A,X,n);ay=window(A,Y,n)
        U=[((v+e)%P)//Q for v,e in zip(ax,e0)]
        V=[((v+e)%P)//Q for v,e in zip(ay,e1)]
        B=[Q*u+r for u,r in zip(U,rho)];by=window(B,Y,ell)
        W=[((v+e+(P//2)*b)%P)//Q for v,e,b in zip(by,e2,mu)]
        assert [U,V,W]==[f['U'],f['V'],f['W']]
        r0=[(v+e)%Q for v,e in zip(ax,e0)];r1=[(v+e)%Q for v,e in zip(ay,e1)]
        r2=[(v+e)%Q for v,e in zip(by,e2)]
        delta0=window([a-r+s for a,r,s in zip(e0,r0,rho)],Y,ell)
        delta1=window([a-r for a,r in zip(e1,r1)],X,ell)
        delta=[a-b+e-r for a,b,e,r in zip(delta0,delta1,e2,r2)]
        assert delta==f['delta']
        qv=window([Q*v for v in V],X,ell)
        decoded=[int(P//4<((Q*w-v)%P)<3*P//4) for w,v in zip(W,qv)]
        assert decoded==mu
        for i in range(ell):assert (Q*W[i]-qv[i]-P//2*mu[i]-delta[i])%P==0
        p=P.bit_length()-1;q=Q.bit_length()-1
        assert binary_pack([(a-P//2,p-1) for a in A]+[(u,p-q) for u in U])==f['pk_hex']
        assert binary_pack([(x-Q//2,q-1) for x in X])==f['sk_hex']
        assert binary_pack([(c,p-q) for c in V+W])==f['ct_hex']
        transcripts+=1;coeffs+=ell
    # Direct enumeration has a different organization from the factored main checker.
    errors=error_vectors(5);laws=0;atoms=0
    picked=[data['conditional_law_fixtures'][i] for i in (0,7,8,15)]
    for fixture in picked:
        a=fixture['a'];high=fixture['high']
        A=[v+8 for v in a[:4]];B=[a[4+i]+8*high[i] for i in range(3)]
        for mu in product((0,1),repeat=2):
            direct=direct_law(A,B,mu,errors);sim=source_law(a,high,mu)
            assert dist(direct,sim)==0
            laws+=1;atoms+=16*len(errors)
    joint=direct_law([8]*4,[8]*3,(0,0),errors)
    m1=Counter();m2=Counter()
    for z,w in joint.items():m1[z[:3]]+=w;m2[z[3:]]+=w
    wrong=Counter({x+y:v*w for x,v in m1.items() for y,w in m2.items()})
    negative=dist(joint,wrong);assert negative==Fraction(47,1024)
    # Null raw lift holds even for the following auxiliary non-power-of-two M.
    null=0
    for M in range(1,25):
        P=2*M
        for shift in range(P):
            c=Counter()
            for b,t in product(range(M),CBD):c[(2*b+t+shift)%P]+=CBD[t]
            assert c==Counter({j:2 for j in range(P)})
            null+=1
    # The public lift must be full range for the ideal U used in G1.
    P=32;Q=8;n=3
    wrongU=Counter(tuple(b//Q for b in v) for v in product(range(P//2,P),repeat=n))
    idealU=Counter({v:1 for v in product(range(P//Q),repeat=n)})
    highbit_tv=dist(wrongU,idealU);assert highbit_tv==Fraction(7,8)
    # Wrong source-row offset n instead of m fails the unrounded identity.
    a=list(range(7));s=[1,0];R=[4,4];Y=[6,4];B=[4,5,6]
    b=window(a,s,6)
    wrongC=[(2*b[3+i]+v)%16 for i,v in enumerate(window(B,R,2))]
    trueC=[v%16 for v in window(B,Y,2)]
    assert wrongC!=trueC
    return {'date':'2026-11-10','standalone_no_arithmetic_imports':True,
       'transcripts_reconstructed':transcripts,'decryption_error_coordinates':coeffs,
       'independent_rectangular_joint_laws':laws,'direct_secret_error_vectors':atoms,
       'same_ephemeral_secret_negative_TV':str(negative),
       'auxiliary_null_lift_shifts':null,'wrong_upper_half_lift_U_TV':str(highbit_tv),
       'wrong_window_witness':{'a':a,'S':s,'R':R,'B':B,'wrong_C':wrongC,'correct_C':trueC},
       'auxiliary_tie_witness':{'P':16,'residues':[4,12],'decoded':[0,0]},
       'scope':'Finite algebra/distribution checks; no source hardness or CCA certification.'}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',default='A5_INDEPENDENT.json')
    args=parser.parse_args();res=run()
    Path(args.output).write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
    print(json.dumps(res,indent=2,sort_keys=True))
