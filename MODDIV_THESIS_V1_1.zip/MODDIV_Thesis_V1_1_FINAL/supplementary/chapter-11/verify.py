#!/usr/bin/env python3
import json,pathlib,subprocess,sys,tempfile
R=pathlib.Path(__file__).parent
jobs=[('verify_a5.py','results.json'),('verify_a5_encoding.py','encoding_results.json')]
for core,expname in jobs:
 with tempfile.TemporaryDirectory() as td:
  out=pathlib.Path(td)/'o.json';subprocess.run([sys.executable,str(R/core),'--output',str(out)],cwd=R,check=True);assert json.loads(out.read_text())==json.loads((R/expname).read_text())
print(json.dumps({'status':'PASS','main':'exact','encoding':'exact'},indent=2))
