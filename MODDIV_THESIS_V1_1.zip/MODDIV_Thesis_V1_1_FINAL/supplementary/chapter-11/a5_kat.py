"""Deterministic synthetic known-answer test; the seeded RNG is only for tests."""
import argparse, json, random
from pathlib import Path
import a5_noise as nc
from a5_codec import pack_pk, pack_sk, pack_ct
p=nc.Params(P=4096,Q=8,d=4,ell=2)
rng=random.Random(20261107)
pk,sk=nc.keygen(p,rng)
message=(1,0)
ct=nc.encrypt(pk,message,rng)
assert nc.decrypt(sk,ct)==message
answer={'profile':vars(p),'seed':20261107,'message':message,
        'public_a':pk.a,'public_u':pk.u,'secret_x':sk.x,
        'ciphertext_v':ct.v,'ciphertext_w':ct.w,
        'encoded_pk_hex':pack_pk(pk).hex(),'encoded_sk_hex':pack_sk(sk).hex(),
        'encoded_ct_hex':pack_ct(p,ct).hex(),'decrypted':nc.decrypt(sk,ct),
        'warning':'Public synthetic test vector. Not a security parameter set.'}
parser=argparse.ArgumentParser()
parser.add_argument('--output',default=str(Path(__file__).resolve().parent/'A5_KAT.json'))
args=parser.parse_args()
Path(args.output).write_text(json.dumps(answer,indent=2,sort_keys=True)+'\n')
print(json.dumps(answer,indent=2,sort_keys=True))
