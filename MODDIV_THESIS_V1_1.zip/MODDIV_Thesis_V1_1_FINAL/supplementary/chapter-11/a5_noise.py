"""MODDIV-NOISE-CPA: explicit research instantiation, not deployment code.

Non-cyclic Hankel products; positive box secrets; exact E'=2e+tau.
CPA theorem is CONDITIONAL on the stated binary HB-LWE assumption.
No claim of standard-LWE hardness, CCA, constant time, or 128-bit security.
Only the CBD1 profile is implemented; the paper treats general iid chi.
"""
from __future__ import annotations
from dataclasses import dataclass
import secrets
from typing import Protocol, Sequence

class RNG(Protocol):
    def randrange(self, stop: int) -> int: ...

@dataclass(frozen=True)
class Params:
    P: int
    Q: int
    d: int
    ell: int
    def __post_init__(self):
        if self.P < 16 or self.P & (self.P-1):
            raise ValueError('P must be a power of two >=16')
        if self.Q < 8 or self.Q & (self.Q-1) or self.P % self.Q or self.Q > self.P//2:
            raise ValueError('Q must be a power of two, 8<=Q<=P/2, Q|P')
        if self.d < 1 or self.ell < 1:
            raise ValueError('d and ell must be positive')
    @property
    def M(self): return self.P//2
    @property
    def H(self): return self.P//self.Q
    @property
    def n(self): return self.d+self.ell-1
    @property
    def m(self): return 2*self.d+self.ell-2
    @property
    def source_rows(self): return 2*self.n
    @property
    def source_tape(self): return 3*self.d+2*self.ell-3
    def error_bound(self, raw_error_bound: int=1):
        if raw_error_bound < 0: raise ValueError('negative bound')
        return (2*self.d*(self.Q-1)+1)*(self.Q+2*raw_error_bound)
    def correctness_certified(self, raw_error_bound: int=1):
        return 4*self.error_bound(raw_error_bound) < self.P

@dataclass(frozen=True)
class PublicKey:
    params: Params
    a: tuple[int,...]
    u: tuple[int,...]

@dataclass(frozen=True)
class SecretKey:
    params: Params
    x: tuple[int,...]

@dataclass(frozen=True)
class Ciphertext:
    v: tuple[int,...]
    w: tuple[int,...]

def _rng(rng):
    return secrets.SystemRandom() if rng is None else rng

def _vec(v, length, lo, hi, name):
    if len(v)!=length or any(type(x) is not int or not lo<=x<hi for x in v):
        raise ValueError(f'invalid {name}')

def hankel(a: Sequence[int], x: Sequence[int], rows: int, modulus: int|None=None):
    if rows < 1 or len(x)<1 or len(a)!=rows+len(x)-1:
        raise ValueError('bad Hankel dimensions')
    z=[sum(a[i+j]*x[j] for j in range(len(x))) for i in range(rows)]
    return tuple(v % modulus for v in z) if modulus is not None else tuple(z)

def cbd1(rng: RNG) -> int:
    return rng.randrange(2)-rng.randrange(2)

def noise_prime(rng: RNG) -> int:
    return 2*cbd1(rng)+cbd1(rng)

def mask_vector(p: Params, rng: RNG):
    return tuple(p.Q//2+4*rng.randrange(p.Q//8)+rng.randrange(2) for _ in range(p.d))

def quantize(z: Sequence[int], p: Params):
    return tuple((x%p.P)//p.Q for x in z)

def validate_pk(pk):
    p=pk.params
    _vec(pk.a,p.m,p.M,p.P,'public tape')
    _vec(pk.u,p.n,0,p.H,'public quotient')

def keygen(p: Params, rng: RNG|None=None):
    rng=_rng(rng)
    a=tuple(p.M+rng.randrange(p.M) for _ in range(p.m))
    x=tuple(p.Q//2+rng.randrange(p.Q//2) for _ in range(p.d))
    e0=tuple(noise_prime(rng) for _ in range(p.n))
    ax=hankel(a,x,p.n,p.P)
    u=quantize([z+e for z,e in zip(ax,e0)],p)
    return PublicKey(p,a,u),SecretKey(p,x)

def encrypt_with_coins(pk: PublicKey, message: Sequence[int], y, e1, e2, rho):
    """Public deterministic core. Explicit coins are for tests and proof audit."""
    validate_pk(pk); p=pk.params
    _vec(message,p.ell,0,2,'message')
    _vec(y,p.d,p.Q//2,p.Q,'ephemeral secret')
    _vec(e1,p.n,-3,4,'CBD1 lifted error e1')
    _vec(e2,p.ell,-3,4,'CBD1 lifted error e2')
    _vec(rho,p.n,0,p.Q,'lifting remainders')
    lifted=tuple(p.Q*u+r for u,r in zip(pk.u,rho))
    ay=hankel(pk.a,y,p.n,p.P)
    by=hankel(lifted,y,p.ell,p.P)
    v=quantize([z+e for z,e in zip(ay,e1)],p)
    w=quantize([by[i]+e2[i]+(p.P//2)*message[i] for i in range(p.ell)],p)
    return Ciphertext(v,w)

def encrypt(pk: PublicKey, message: Sequence[int], rng: RNG|None=None):
    rng=_rng(rng); p=pk.params
    y=tuple(p.Q//2+rng.randrange(p.Q//2) for _ in range(p.d))
    e1=tuple(noise_prime(rng) for _ in range(p.n))
    e2=tuple(noise_prime(rng) for _ in range(p.ell))
    rho=tuple(rng.randrange(p.Q) for _ in range(p.n))
    return encrypt_with_coins(pk,message,y,e1,e2,rho)

def decode_bit(z: int, P: int):
    z%=P
    d0=min(z,P-z)
    t=(z-P//2)%P
    d1=min(t,P-t)
    return int(d1<d0)  # deterministic tie: zero

def decrypt(sk: SecretKey, ct: Ciphertext):
    p=sk.params
    _vec(sk.x,p.d,p.Q//2,p.Q,'secret')
    _vec(ct.v,p.n,0,p.H,'ciphertext v')
    _vec(ct.w,p.ell,0,p.H,'ciphertext w')
    t=hankel(tuple(p.Q*z for z in ct.v),sk.x,p.ell,p.P)
    return tuple(decode_bit(p.Q*ct.w[i]-t[i],p.P) for i in range(p.ell))

def encaps(pk: PublicKey, rng: RNG|None=None):
    rng=_rng(rng)
    key=tuple(rng.randrange(2) for _ in range(pk.params.ell))
    return encrypt(pk,key,rng),key

def decaps(sk: SecretKey, ct: Ciphertext):
    return decrypt(sk,ct)

def hb_sample(p: Params, real: bool, rng: RNG|None=None):
    """Synthetic HB challenge for tests. This does not assume or demonstrate hardness."""
    rng=_rng(rng)
    a=tuple(rng.randrange(p.M) for _ in range(p.source_tape))
    if not real:
        return a,tuple(rng.randrange(p.M) for _ in range(p.source_rows))
    s=tuple(rng.randrange(2) for _ in range(p.d))
    z=hankel(a,s,p.source_rows,p.M)
    return a,tuple((b+cbd1(rng))%p.M for b in z)

def hop1_public(p: Params, a, b, rng: RNG|None=None):
    """HB real -> genuine pk; HB null -> ideal uniform pk. No source secret input."""
    rng=_rng(rng)
    _vec(a,p.source_tape,0,p.M,'source tape')
    _vec(b,p.source_rows,0,p.M,'source observations')
    A=tuple(x+p.M for x in a[:p.m])
    R=mask_vector(p,rng)
    ar=hankel(A,R,p.n,p.P)
    c=tuple((2*b[i]+ar[i]+cbd1(rng))%p.P for i in range(p.n))
    return PublicKey(p,A,quantize(c,p))

def hop2_public(p: Params, a, rng: RNG|None=None):
    """Prepare pk for second hybrid before the adversary chooses its messages."""
    rng=_rng(rng)
    _vec(a,p.source_tape,0,p.M,'source tape')
    A=tuple(x+p.M for x in a[:p.m])
    B=tuple(a[p.m+i]+p.M*rng.randrange(2) for i in range(p.n))
    pk=PublicKey(p,A,tuple(x//p.Q for x in B))
    return pk,B

def hop2_challenge(pk: PublicKey, lifted, b, message, rng: RNG|None=None):
    """HB real -> G1 challenge; HB null -> uniform independent challenge."""
    rng=_rng(rng); validate_pk(pk); p=pk.params
    _vec(lifted,p.n,0,p.P,'internal full lift')
    _vec(b,p.source_rows,0,p.M,'source observations')
    _vec(message,p.ell,0,2,'message')
    if tuple(x//p.Q for x in lifted)!=pk.u:
        raise ValueError('inconsistent lift')
    R=mask_vector(p,rng)
    ar=hankel(pk.a,R,p.n,p.P)
    br=hankel(lifted,R,p.ell,p.P)
    c1=tuple((2*b[i]+ar[i]+cbd1(rng))%p.P for i in range(p.n))
    c2=tuple((2*b[p.m+i]+br[i]+cbd1(rng)+(p.P//2)*message[i])%p.P for i in range(p.ell))
    return Ciphertext(quantize(c1,p),quantize(c2,p))

if __name__=='__main__':
    p=Params(P=4096,Q=8,d=4,ell=2)
    pk,sk=keygen(p)
    msg=(1,0)
    ct=encrypt(pk,msg)
    assert decrypt(sk,ct)==msg
    print({'profile':vars(p),'correctness_bound':p.error_bound(),
           'decoding_radius':p.P//4,'message':msg,'decrypted':decrypt(sk,ct),
           'warning':'Toy profile; no security level claimed'})
