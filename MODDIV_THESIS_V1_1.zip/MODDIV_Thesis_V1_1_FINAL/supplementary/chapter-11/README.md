# Chapter 11 — MODDIV-NOISE: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Runs the final A5 v1.1 main suite, exact canonical-encoding regression, and independent checker.

## Reproduction

```sh
python3 verify.py
python3 verify_independent.py
```

All deterministic reference outputs are stored in this directory. The verification scripts write reruns to temporary files and compare exact JSON objects whenever applicable.

## Limits

HB hardness is an assumption, not a result of these tests. The raw scheme remains CCA2-malleable as proved in the thesis.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
