#!/usr/bin/env python3
import argparse,itertools,json,pathlib
from fractions import Fraction
ap=argparse.ArgumentParser();ap.add_argument('--output');a=ap.parse_args();R=pathlib.Path(__file__).parent
F=json.loads((R/'calibration_fixtures.json').read_text()); stored=json.loads((R/'results.json').read_text())
def pub(f,x):return [(sum(f['B'][i][j]*x[j] for j in range(len(x)))%f['P'])//f['Q'] for i in range(len(f['B']))]
# exact floor-indicator witness family
indicator=0
for P in range(2,13):
 for aa in range(P):
  for bb in range(aa,P):
   for z in range(-2*P,2*P+1):
    assert int(aa<=z%P<=bb)==(z-aa)//P-(z-bb-1)//P;indicator+=1
assert Fraction(1,4)+Fraction(1,2)==Fraction(3,4)
# m02 regression: publication compatibility must include the box.
f0={'B':[[1]],'U':[0],'P':4,'Q':2,'lo':0,'hi':0}; cand=[1]
assert pub(f0,cand)==f0['U'] and not all(f0['lo']<=z<=f0['hi'] for z in cand)
small=[f for f in F if f['type']!='d16_hankel']; uniq=0
for f in small:
 sols=[x for x in itertools.product(range(f['lo'],f['hi']+1),repeat=len(f['B'][0])) if pub(f,x)==f['U']]
 uniq += len(sols)==1
assert len(small)==38 and uniq==36
for rec in stored['d16_cases']:
 f=next(x for x in F if x['id']==rec['id']);x=rec['candidate']
 assert all(f['lo']<=z<=f['hi'] for z in x) and pub(f,x)==f['U']
r={'status':'PASS','indicator_cases':indicator,'small_fibers_reenumerated':38,'unique_small_fibers':36,'d16_stored_candidates_box_and_publication_checked':3,'out_of_box_negative_regression':True}
if a.output:pathlib.Path(a.output).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps(r,indent=2,sort_keys=True))
