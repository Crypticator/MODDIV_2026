# Chapter 14 — Cryptanalysis and Attack Models: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Publishes 38 deterministic small calibration fixtures and three deterministic dimension-16 compatibility fixtures. The release verifier re-enumerates the exact small fibers and checks that each stored dimension-16 candidate lies in the declared secret box and reproduces the public quotient vector. It includes a negative regression for a candidate that matches the public observation but lies outside the box.

The release does **not** provide or claim to reproduce a secret-recovery algorithm, an LLL/Babai run, a reduced-basis certificate, or a secret-recovery running time for the dimension-16 fixtures. Those fixtures are compatibility regressions only.

## Reproduction

```sh
python3 verify.py
python3 verify_independent.py
```

## Limits

The small fixtures are calibration cases, not a security success-rate estimate. The dimension-16 fixtures demonstrate only that the stored candidates satisfy the stated public constraints and secret boxes.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
