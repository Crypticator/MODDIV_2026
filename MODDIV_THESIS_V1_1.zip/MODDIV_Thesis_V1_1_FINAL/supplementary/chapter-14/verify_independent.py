#!/usr/bin/env python3
import itertools,json,pathlib
R=pathlib.Path(__file__).parent;F=json.loads((R/'calibration_fixtures.json').read_text());res=json.loads((R/'results.json').read_text())
def pub(f,x):return [(sum(f['B'][i][j]*x[j] for j in range(len(x)))%f['P'])//f['Q'] for i in range(len(f['B']))]
f0={'B':[[1]],'U':[0],'P':4,'Q':2,'lo':0,'hi':0};x=[1];assert pub(f0,x)==f0['U'] and not all(f0['lo']<=z<=f0['hi'] for z in x)
small=[f for f in F if f['type']!='d16_hankel'];cnt=[]
for f in small:
 sols=sum(1 for x in itertools.product(range(f['lo'],f['hi']+1),repeat=len(f['B'][0])) if pub(f,x)==f['U']);cnt.append(sols)
assert len(cnt)==38 and sum(c==1 for c in cnt)==36
for r in res['d16_cases']:
 f=next(x for x in F if x['id']==r['id']);assert all(f['lo']<=z<=f['hi'] for z in r['candidate']) and pub(f,r['candidate'])==f['U']
print(json.dumps({'status':'PASS','small_cases':38,'unique_cases':36,'d16_public_outputs_and_boxes_checked':3,'out_of_box_negative_regression':True},indent=2))
