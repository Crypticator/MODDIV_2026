# Chapter 2 — Mathematical Foundations: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Exact finite checks for Euclidean quotient/remainder decomposition, cell lifting and total-variation data processing.

## Reproduction

```sh
python3 verify.py
python3 verify_independent.py
```

All deterministic reference outputs are stored in this directory. The verification scripts write reruns to temporary files and compare exact JSON objects whenever applicable.

## Limits

Finite examples validate the identities and implementation conventions; the general proofs are in Chapter 2.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
