#!/usr/bin/env python3
import argparse,json,pathlib,itertools
from fractions import Fraction
ap=argparse.ArgumentParser();ap.add_argument('--output');a=ap.parse_args()
qr=0; lifts=0; dp=0
for P in range(2,18):
 for Q in range(1,20):
  J=(P+Q-1)//Q
  for z in range(-2*P,2*P+1):
   r=z%P; u=r//Q; rho=r-Q*u
   assert 0<=r<P and 0<=rho<Q and r==Q*u+rho and 0<=u<J; qr+=1
  for u in range(J):
   cell=list(range(Q*u,min(Q*(u+1),P)))
   assert cell
   # uniform lift from (u, uniform cell-offset) is uniform inside its cell
   probs={x:Fraction(1,len(cell)) for x in cell}
   assert sum(probs.values())==1; lifts+=len(cell)
# finite data processing for TV under deterministic coarsening
laws=[([1,2,3],[3,2,1]),([1,1,2,4],[4,2,1,1]),([2,5,1],[1,3,4])]
for aa,bb in laws:
 s1=sum(aa);s2=sum(bb); p=[Fraction(x,s1) for x in aa];q=[Fraction(x,s2) for x in bb]
 tv=sum(abs(x-y) for x,y in zip(p,q))/2
 # coarsen parity of index
 for mapping in itertools.product(range(2),repeat=len(p)):
  pp=[sum(p[i] for i,m in enumerate(mapping) if m==j) for j in range(2)]
  qq=[sum(q[i] for i,m in enumerate(mapping) if m==j) for j in range(2)]
  tv2=sum(abs(x-y) for x,y in zip(pp,qq))/2
  assert tv2<=tv; dp+=1
r={'status':'PASS','quotient_remainder_cases':qr,'cell_lift_atoms':lifts,'tv_data_processing_maps':dp}
if a.output:pathlib.Path(a.output).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps(r,indent=2,sort_keys=True))
