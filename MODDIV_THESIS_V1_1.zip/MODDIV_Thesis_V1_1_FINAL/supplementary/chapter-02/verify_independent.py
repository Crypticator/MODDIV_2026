#!/usr/bin/env python3
import json
count=0
for P in range(2,11):
 for Q in range(1,12):
  for z in range(-P,P+1):
   r=z-P*(z//P);u=r//Q;rho=r-Q*u
   assert z%P==r and r==Q*u+rho and 0<=rho<Q; count+=1
print(json.dumps({'status':'PASS','direct_cases':count},indent=2))
