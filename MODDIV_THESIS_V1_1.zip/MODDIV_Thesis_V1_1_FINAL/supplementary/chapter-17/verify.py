#!/usr/bin/env python3
import argparse,json,pathlib,itertools
ap=argparse.ArgumentParser();ap.add_argument('--output');a=ap.parse_args();R=pathlib.Path(__file__).parent;root=R.parents[1];T=next((root/'thesis').glob('*.md')).read_text();F=json.loads((R/'canonical_facts.json').read_text())
expected17=r'''C_{m,2n}\!\left(z^nX\,C_{m,n}(AY)\right)
=C_{m,2n}(AXY)
=C_{m,2n}\!\left(z^nY\,C_{m,n}(AX)\right).'''
def norm(x):return ''.join(x.split())
checks={'normalized_counter':r'\widetilde R_i=\left\lfloor R_i/n\right\rfloor' in T,'WC_barrier':'4,726,272' in T,'NOISE_two_terms':r'\operatorname{Adv}_{\rm HB}(\mathcal B_0)' in T and r'\operatorname{Adv}_{\rm HB}(\mathcal B_1)' in T,'C1_failure_bounds':'2^{-6400}' in T and '2^{-282}' in T,'C1_payloads':'993' in T and '1408' in T,'final_landscape':'MODDIV is not one security theorem; it is a mapped research landscape.' in T,'eq17_9_exact_text':norm(expected17) in norm(T)}
assert all(checks.values())
def conv(a,b,p):
 out=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]=(out[i+j]+x*y)%p
 return out
def C(F,m,n):
 return [(F[i] if i<len(F) else 0) for i in range(n,m)]
def shift(F,n):return [0]*n+F
def eq(A,X,Y,m,n,p):
 AY=conv(A,Y,p);AX=conv(A,X,p);AXY=conv(AX,Y,p)
 l=C(conv(shift(X,n),C(AY,m,n),p),m,2*n)
 c=C(AXY,m,2*n)
 r=C(conv(shift(Y,n),C(AX,m,n),p),m,2*n)
 return l==c==r
cases=0
for p in (3,5):
 for n,m in ((1,4),(1,5),(2,5),(2,6)):
  for seed in range(12):
   A=[(seed+2*i+1)%p for i in range(m)]
   X=[(seed+i)%p for i in range(n+1)]
   Y=[(2*seed+i+1)%p for i in range(n+1)]
   assert eq(A,X,Y,m,n,p);cases+=1
r={'status':'PASS','checks':checks,'compatible_window_regressions':cases,'canonical_sections':sorted(F)}
if a.output:pathlib.Path(a.output).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps(r,indent=2,sort_keys=True))
