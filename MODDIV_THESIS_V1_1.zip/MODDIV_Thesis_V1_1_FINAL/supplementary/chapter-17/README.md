# Chapter 17 — Conclusions and Open Problems: Supplementary Material

This package checks canonical A3–A6 facts used by the final synthesis and includes a direct regression for the compatible-window identity (17.9). Both verification paths require the corrected equation text and evaluate the polynomial identity independently on finite examples; a mutation of the central term is therefore rejected.

Run:

```sh
python3 verify.py
python3 verify_independent.py
```

These are consistency regressions, not an independent security proof or a concrete security certificate.
