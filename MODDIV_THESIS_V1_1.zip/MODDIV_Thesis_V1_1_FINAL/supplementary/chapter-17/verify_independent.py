#!/usr/bin/env python3
import json,pathlib
R=pathlib.Path(__file__).parent;root=R.parents[1];T=next((root/'thesis').glob('*.md')).read_text();F=json.loads((R/'canonical_facts.json').read_text())
assert F['A3_polynomial_counter']['counts_ribbon_1']['H0']==944
assert F['A4_WC']['proof_route_barrier_bytes_tau128']==4726272
assert len(F['A5_NOISE']['cpa_terms'])==2
assert F['A6_C1']['pk_bytes']==993 and F['A6_C1']['ct_bytes']==1408
def norm(x):return ''.join(x.split())
expected=r'''C_{m,2n}\!\left(z^nX\,C_{m,n}(AY)\right)=C_{m,2n}(AXY)=C_{m,2n}\!\left(z^nY\,C_{m,n}(AX)\right).'''
assert norm(expected) in norm(T)
def mul(a,b,p):
 o=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):o[i+j]=(o[i+j]+x*y)%p
 return o
def win(f,m,n):return [(f[i] if i<len(f) else 0) for i in range(n,m)]
def side(A,X,Y,m,n,p):return win(mul([0]*n+X,win(mul(A,Y,p),m,n),p),m,2*n)
def center(A,X,Y,m,n,p):return win(mul(mul(A,X,p),Y,p),m,2*n)
# Explicit falsification witness: n=1,m=4,A=1,X=Y=z over F3 gives central window [1,0].
A=[1];X=[0,1];Y=[0,1];c=center(A,X,Y,4,1,3);assert c==[1,0] and side(A,X,Y,4,1,3)==c and side(A,Y,X,4,1,3)==c
print(json.dumps({'status':'PASS','canonical_fact_groups':4,'eq17_9_exact_text':True,'eq17_9_witness':[1,0]},indent=2))
