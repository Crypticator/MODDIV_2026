#!/usr/bin/env python3
import json
# Storage identity nd-(n+d-1)=(n-1)(d-1)
c=0
for n in range(1,50):
 for d in range(1,50):
  assert n*d-(n+d-1)==(n-1)*(d-1);c+=1
print(json.dumps({'status':'PASS','storage_identity_profiles':c},indent=2))
