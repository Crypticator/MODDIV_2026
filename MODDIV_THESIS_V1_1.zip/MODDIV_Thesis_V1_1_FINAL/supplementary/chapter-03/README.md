# Chapter 3 — Toeplitz and Hankel Operators: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Checks the Hankel/Toeplitz reversal identity, exact double-product symmetry, the storage identity and small exact covariance laws.

## Reproduction

```sh
python3 verify.py
python3 verify_independent.py
```

All deterministic reference outputs are stored in this directory. The verification scripts write reruns to temporary files and compare exact JSON objects whenever applicable.

## Limits

The covariance enumeration uses small iid public alphabets; the theorem in the thesis supplies the general formula.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
