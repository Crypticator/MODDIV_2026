#!/usr/bin/env python3
import argparse,json,pathlib,itertools
from fractions import Fraction
ap=argparse.ArgumentParser();ap.add_argument('--output');a=ap.parse_args()
def hankel(a,n,d):return [[a[i+j] for j in range(d)] for i in range(n)]
def toeplitz_from_hankel(a,n,d):
 H=hankel(a,n,d);return [list(reversed(r)) for r in H]
def mv(M,x):return [sum(a*b for a,b in zip(r,x)) for r in M]
rep=0;double=0;cov=0
for n in range(1,5):
 for d in range(1,5):
  arr=list(range(1,n+d))
  H=hankel(arr,n,d);T=toeplitz_from_hankel(arr,n,d);Jx=list(reversed(list(range(1,d+1))))
  assert mv(T,Jx)==mv(H,list(range(1,d+1)));rep+=1
# double-product symmetry H(H(A)X)Y = H(H(A)Y)X for matching dimensions
for d in [1,2,3]:
 for ell in [1,2,3]:
  n=ell+d-1; arr2=[(i*3+1)%7 for i in range(n+d-1)];X=list(range(1,d+1));Y=list(range(d,0,-1))
  hx=mv(hankel(arr2,n,d),X);hy=mv(hankel(arr2,n,d),Y)
  left=mv(hankel(hx,ell,d),Y);right=mv(hankel(hy,ell,d),X);assert left==right;double+=1
# covariance identity by exact enumeration of iid A in {0,1,2}
for d in [2,3]:
 x=list(range(1,d+1)); n=4
 for t in range(d):
  vals=[]
  for A in itertools.product(range(3),repeat=n+d-1):
   z=mv(hankel(A,n,d),x);vals.append((z[0],z[t]))
  N=len(vals); ez0=Fraction(sum(v[0] for v in vals),N); ezt=Fraction(sum(v[1] for v in vals),N)
  cv=Fraction(sum((u-ez0)*(v-ezt) for u,v in vals),N)
  varA=Fraction(2,3)
  rhs=varA*sum(x[j]*x[j-t] for j in range(t,d))
  assert cv==rhs;cov+=1
r={'status':'PASS','toeplitz_hankel_representation_profiles':rep,'double_product_profiles':double,'covariance_profiles':cov}
if a.output:pathlib.Path(a.output).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps(r,indent=2,sort_keys=True))
