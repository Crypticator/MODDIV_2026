# Chapter 10 — Unit-Anchored MODDIV-WC: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Runs the final A4 v1.2 functional/algebraic suite and independent checker, including the 4,726,272-byte proof-route barrier, public-dependent-noise exclusion, persistent fallback and key-only decapsulation interface.

## Reproduction

```sh
python3 verify.py
python3 verify_independent.py
```

All deterministic reference outputs are stored in this directory. The verification scripts write reruns to temporary files and compare exact JSON objects whenever applicable.

## Limits

These checks do not prove the external binary-LWE assumption, programmable-ROM idealization, QROM security or 128-bit concrete security.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
