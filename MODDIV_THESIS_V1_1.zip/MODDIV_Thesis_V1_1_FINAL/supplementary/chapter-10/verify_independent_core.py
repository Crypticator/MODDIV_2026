#!/usr/bin/env python3
"""Independent checker for selected A4 claims.

This file deliberately does not import a4_wc_tools.py or verify_a4.py.
"""
from __future__ import annotations
import argparse, itertools, json, hashlib, math
from fractions import Fraction as Fr
from pathlib import Path


def H(a,x,L,P):
    return [sum(a[i+j]*x[j] for j in range(len(x)))%P for i in range(L)]

def F(z,P,Q): return (z%P)//Q

def K(z,P): return ((z+P//4)%P)//(P//2)
def C(z,P): return ((z%P)//(P//4))%2
def R(y,b,P): return 0 if ((y+(2*b+1)*(P//8))%P)<=P//2-2 else 1



def pack(vals,widths):
    acc=off=0
    for v,w in zip(vals,widths):
        if not 0<=v<(1<<w): raise ValueError('range')
        acc |= v<<off; off+=w
    return acc.to_bytes((off+7)//8,'little')

def unpack(raw,widths):
    total=sum(widths); n=(total+7)//8
    if len(raw)!=n: raise ValueError('length')
    acc=int.from_bytes(raw,'little')
    if acc>>total: raise ValueError('padding')
    out=[]
    for w in widths:
        out.append(acc & ((1<<w)-1)); acc >>= w
    return out

def ro(m,c,nbytes=1):
    h=hashlib.shake_256();h.update(bytes(m));h.update(c);return h.digest(nbytes)

def barrier(tau):
    g=3
    while True:
        T=(4*tau+1)*(g+1)+4*tau-2
        if T <= (1<<(g-2))-1:
            bits=2*tau*g*T
            return g,T,bits,(bits+7)//8
        g+=1

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',default='A4_INDEPENDENT.json'); args=ap.parse_args()
    counts={}

    # Unit-anchor exhaustive fibers for a larger tiny case.
    P,L,x=4,2,(1,2,3); m=L+len(x)-1
    freq={}
    for a in itertools.product(range(P), repeat=m):
        y=tuple(H(a,x,L,P)); freq[y]=freq.get(y,0)+1
    assert len(freq)==P**L and set(freq.values())=={P**(len(x)-1)}
    counts['fiber_public_inputs']=P**m

    # FAST identity independently derived: Q*A + S equals Hankel integer sum.
    P,Q,L,x=32,4,2,(1,5,7)
    n=0
    for a in itertools.product(range(4), repeat=L+len(x)-1):
        for i in range(L):
            A=sum(a[i+j] for j in range(1,len(x)))
            S=a[i]+sum(a[i+j]*(x[j]-Q) for j in range(1,len(x)))
            assert (Q*A+S)%P == H(a,x,L,P)[i]
            assert (A+S//Q)%(P//Q)==F(H(a,x,L,P)[i],P,Q)
            n+=1
    counts['fast_coordinate_checks']=n

    # Reconciliation full exhaustive for P=128.
    P=128; a=P//8; n=0
    for z in range(P):
        for e in range(-a+1,a):
            assert R((z+e)%P,C(z,P),P)==K(z,P); n+=1
    counts['reconciliation_pairs']=n

    # Wraparound witness.
    P=32; assert (30-0-(-2))%P==0 and abs(30-0)==30 and abs(-2)<P//8
    assert R(0,C(30,P),P)==K(30,P)
    counts['wraparound_witness']=1

    # Exact parity-mask distribution for Q=4, h=2, L=1.
    Q=4; freq={}
    for s0,s1 in itertools.product((0,1),repeat=2):
        for r0,r1 in itertools.product((4,6),repeat=2):
            X=(1,r0+s0,r1+s1); freq[X]=freq.get(X,0)+1
    assert len(freq)==16 and set(freq.values())=={1}
    counts['mask_states']=16

    # Proof-barrier table.
    rows=[barrier(t) for t in (32,64,128,192,256)]
    assert [r[3] for r in rows]==[200928,1047840,4726272,10628352,21185536]
    counts['barrier_rows']=5

    # Representation-only payload arithmetic.
    p,q,h,L,t,kA=256,128,16,32,64,256
    m=h*L+1
    explicit=t*(m*p+L*(p-q)); compact=kA+t*L*(p-q)
    assert explicit//8==1083392 and compact//8==32800
    counts['payload_profiles']=1

    # Independent Renyi regression and public-dependent exclusion.
    rd=sum(1/(Fr(int(z//4==((z-1)%32)//4),2)+Fr(int(z//4==((z+1)%32)//4),2))
           for z in range(32))/32
    assert rd==Fr(3,2)
    zeros=[]
    for z in range(32):
        es=(-1,-1) if z%4==0 else (1,1) if z%4==3 else (-1,1)
        if all(((z+e)%32)//4 != z//4 for e in es): zeros.append(z)
    assert len(zeros)==16
    counts['renyi_independent_profile']=1
    counts['public_dependent_excluded_residues']=16

    # Independent canonical-wire model: round trips and padding-alias rejection.
    pbits,m,L,kappa=6,5,2,2
    widths=[pbits]*m+[1]*(L+kappa)
    nwire=0
    for a0 in range(8):
        vals=[a0,1,2,3,4,0,1,1,0]
        raw=pack(vals,widths); assert unpack(raw,widths)==vals
        alias=bytearray(raw); alias[-1]|=0x80
        try: unpack(bytes(alias),widths)
        except ValueError: pass
        else: raise AssertionError('padding alias accepted')
        nwire+=1
    counts['strict_wire_roundtrips']=nwire

    # Persistent fallback: same secret and same rejected bytes give the same oracle value.
    sfix=(1,0); bad=b'bad-ciphertext'
    k1=ro(sfix,bad); k2=ro(sfix,bad); assert k1==k2
    counts['persistent_fallback_model']=1

    # Independent challenge-refusal model with a decapsulation-call counter.
    challenge=b'canonical-challenge'
    calls=[0]
    def decaps_model(raw):
        calls[0]+=1
        return ro(sfix,raw)
    def game_oracle_model(raw):
        if raw==challenge:
            raise ValueError('challenge-refused')
        return decaps_model(raw)
    try:
        game_oracle_model(challenge)
    except ValueError:
        pass
    else:
        raise AssertionError('challenge was not refused')
    assert calls[0]==0
    distinct=challenge+b'\x00'
    assert game_oracle_model(distinct)==ro(sfix,distinct)
    assert calls[0]==1
    counts['challenge_refusal_before_decaps_model']=1
    counts['distinct_query_reaches_decaps_model']=1

    # Resampling the secret is a different algorithmic law; exact two-rejection equality for kappa=2,kK=3.
    eq=Fr(1,4)+Fr(3,4)*Fr(1,8); assert eq==Fr(11,32)

    # Quantitative final-noise premises: exact arithmetic on representative growing profiles.
    nasy=0
    for klog in (8,10,12,14):
        lam=1<<klog; h=(lam+1)*(lam//2)+8*lam; LL=lam
        pb=16*klog; qb=11*klog
        tt=((h+1)*LL+1)*pb+2*(lam-1); M=tt*LL
        root=klog**5; sr=math.isqrt(root)+(math.isqrt(root)**2<root)
        B=lam**5*sr; QQ=1<<qb
        assert 2*B<QQ and Fr(M*B,QQ)<1 and Fr(M,lam**6)<1
        nasy+=1
    counts['asymptotic_final_noise_profiles']=nasy

    out={'status':'PASS','scope':'Independent finite checks; no imported candidate code and no security certification.',
         'counts':counts,
         'barrier':[{'tau':t,'g_star':r[0],'T0':r[1],'bits':r[2],'bytes':r[3]} for t,r in zip((32,64,128,192,256),rows)]}
    Path(args.output).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps(out,indent=2,sort_keys=True))

if __name__=='__main__': main()
