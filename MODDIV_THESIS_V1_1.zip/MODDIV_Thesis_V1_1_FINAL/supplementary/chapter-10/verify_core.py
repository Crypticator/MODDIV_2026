#!/usr/bin/env python3
"""Primary deterministic verifier for A4 / MODDIV-WC V2.

The checks validate finite algebra, exact identities, witness calculations, payload
arithmetic and a functional SHAKE expansion. They do not prove LWE hardness, the
random-oracle model, or adaptive CCA security.
"""
from __future__ import annotations
import argparse, itertools, json, random
from math import isqrt
from fractions import Fraction as F
from pathlib import Path
import a4_wc_tools as W

SEED = 20261110

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', default='A4_RESULTS.json')
    args = ap.parse_args()
    rng = random.Random(SEED)
    counts = {}

    # 1. Exact FAST identity: exhaustive small anchored profiles.
    nfast = 0
    for P,Q,L,d in [(16,2,1,2),(16,4,1,2),(32,4,2,2),(32,4,1,3)]:
        H=P//Q
        # deterministic representative sample of ribbons; exhaustive tails/secrets for tiny ranges
        a_values = list(itertools.product(range(min(P,4)), repeat=L+d-1))
        for a in a_values:
            tails = itertools.product(range(Q,2*Q), repeat=d-1)
            for tail in tails:
                x=(1,)+tail
                direct=[W.fq(z,P,Q) for z in W.hankel(a,x,L,P)]
                fast=W.fast_round(a,x,L,P,Q)
                assert direct==fast
                assert W.hankel(a,x,L,P)==W.fast_unrounded(a,x,L,P,Q)
                nfast += 1
    counts['fast_exact_small']=nfast

    # Signed/range-independent public inputs.
    for _ in range(2500):
        p=rng.choice([5,6,7]); q=rng.randrange(1,p-2); P=1<<p; Q=1<<q
        L=rng.randrange(1,5); d=rng.randrange(2,6)
        a=[rng.randrange(-3*P,3*P+1) for _ in range(L+d-1)]
        x=[1]+[rng.randrange(Q,2*Q) for _ in range(d-1)]
        assert [W.fq(z,P,Q) for z in W.hankel(a,x,L,P)]==W.fast_round(a,x,L,P,Q)
    counts['fast_signed_random']=2500

    # 2. Unit-anchor fibers and right inverse.
    nfib=0
    for P,L,d,x in [
        (4,1,2,(1,2)),(4,2,2,(1,3)),(4,2,3,(1,2,3)),(8,1,3,(1,4,7))]:
        m=L+d-1
        image={}
        for a in itertools.product(range(P), repeat=m):
            y=tuple(W.hankel(a,x,L,P))
            image[y]=image.get(y,0)+1
        assert len(image)==P**L
        assert set(image.values())=={P**(d-1)}
        for target in itertools.product(range(P), repeat=L):
            for tail in itertools.product(range(P), repeat=d-1):
                a=W.anchor_right_inverse(target,tail,x,P)
                assert tuple(W.hankel(a,x,L,P))==target
                nfib += 1
    counts['anchored_right_inverse_targets']=nfib

    # 3. Sparse embedding exactness.
    nembed=0
    for P,h,L in [(8,2,2),(8,3,1),(16,2,2)]:
        # cover all binary matrices when manageable, otherwise deterministic sample
        nbits=L*h
        mats=itertools.product((0,1), repeat=nbits)
        for flat in mats:
            A=[list(flat[i*h:(i+1)*h]) for i in range(L)]
            for s in itertools.product((0,1), repeat=h):
                a=W.develop_matrix(A, 3, P)
                ii=W.iota(s,L)
                assert W.hankel(a,ii,L,P)==W.matvec(A,s,P)
                nembed += 1
    counts['sparse_embedding_states']=nembed

    # 4. Exact parity mask law for a small full secret.
    # h=2,L=1 -> d=3; active tail positions 1,2.
    Q=4; L=1; h=2; d=3
    freq={}
    active_even=list(range(Q,2*Q,2))
    for s in itertools.product((0,1), repeat=h):
        for r1 in active_even:
            for r2 in active_even:
                R=[1,r1,r2]
                I=W.iota(s,L)
                X=tuple(R[j]+I[j] for j in range(d))
                freq[X]=freq.get(X,0)+1
    expected={(1,x1,x2) for x1 in range(Q,2*Q) for x2 in range(Q,2*Q)}
    assert set(freq)==expected and set(freq.values())=={1}
    counts['parity_mask_exact_states']=sum(freq.values())

    # 5. Reconciliation exactness and strict-boundary counterexample.
    nrec=0
    for P in [16,32,64]:
        a=P//8
        for z in range(P):
            for e in range(-a+1,a):
                y=(z+e)%P
                assert W.recp(y,W.cp(z,P),P)==W.kp(z,P)
                nrec += 1
    assert W.kp(3,16)==0 and W.recp(5,W.cp(3,16),16)==1
    counts['reconciliation_strict_pairs']=nrec

    # 6. Signed wraparound correctness witness from the corrected proof.
    P,Q,L,t=32,2,1,2
    X=[1,2]
    blocks=[[1,0],[31,0]]
    pk=[]
    taus=[]
    for a in blocks:
        Y=W.hankel(a,X,L,P)
        U=[W.fq(Y[0],P,Q)]
        pk.append((a,U)); taus.append(Y[0]-Q*U[0])
    c,v=W.base_encrypt(pk,[1],[1,1],[[0],[0]],P,Q)
    w=W.hankel(c[0],X,L,P)
    delta=sum([1,1][b]*(0-taus[b]) for b in range(2))
    assert v==[30] and w==[0] and delta==-2 and abs((v[0]-w[0]))==30
    assert (v[0]-w[0]-delta)%P==0
    assert W.base_decrypt(X,c,P,Q)==[1]
    counts['signed_wraparound_witness']=1

    # 7. Honest BASE correctness on deterministic random toy profiles satisfying t(Q-1)<P/8.
    nbase=0
    for _ in range(1500):
        P,Q=64,2; h,L,t,kappa=2,2,2,2; d=(h-1)*L+2; m=h*L+1
        X=[1]+[rng.randrange(Q,2*Q) for _ in range(d-1)]
        pk=[]
        for _b in range(t):
            a=[rng.randrange(P) for _ in range(m)]
            U=[W.fq(z,P,Q) for z in W.hankel(a,X,L,P)]
            pk.append((a,U))
        M=[rng.randrange(2) for _ in range(kappa)]
        selectors=[rng.randrange(2) for _ in range(t)]
        remainders=[[rng.randrange(Q) for _ in range(L)] for _ in range(t)]
        c,_=W.base_encrypt(pk,M,selectors,remainders,P,Q)
        assert W.base_decrypt(X,c,P,Q)==M
        nbase += 1
    counts['base_correctness_random']=nbase

    # 8. Payload and proof-route arithmetic.
    assert W.explicit_payload_bits(256,128,16,32,64)//8 == 1083392
    assert W.compact_payload_bits(256,128,32,64,256)//8 == 32800
    barrier=[W.proof_barrier(t) for t in (32,64,128,192,256)]
    expected_bytes=[200928,1047840,4726272,10628352,21185536]
    assert [x['bytes'] for x in barrier]==expected_bytes
    counts['proof_barrier_rows']=len(barrier)

    # 9. Exact threshold arithmetic over a grid.
    nth=0
    for p in range(6,13):
        for q in range(1,p-2):
            for h in range(1,4):
                for L in range(1,5):
                    for s in (1,4,8):
                        te=W.extraction_t_min(p,h,L,s)
                        tc=W.correction_t_max(p,q)
                        assert isinstance(te,int) and isinstance(tc,int)
                        # exact equivalence of strict correction with t<=tc for nearby t
                        P=1<<p; Q=1<<q
                        for t in {max(0,tc-1),tc,tc+1}:
                            assert (t*(Q-1)<P//8)==(t<=tc)
                        nth += 1
    counts['threshold_profiles']=nth

    # 10. Functional deterministic SHAKE expansion (not RO security).
    seed=b'A4-public-seed-test'
    v0=W.expand_public(seed,0,16,9)
    v1=W.expand_public(seed,1,16,9)
    assert v0==W.expand_public(seed,0,16,9) and v0!=v1
    assert all(0<=x<2**16 for x in v0+v1)
    counts['shake_functional_blocks']=2

    # 11. Renyi regression: independent symmetric noise is finite; public-dependent noise is excluded.
    rd=sum(1/(F(int(z//4==((z-1)%32)//4),2)+F(int(z//4==((z+1)%32)//4),2))
           for z in range(32))/32
    assert rd==F(3,2)
    dependent_zero=[]
    for z in range(32):
        es=([-1,-1] if z%4==0 else [1,1] if z%4==3 else [-1,1])
        if all(((z+e)%32)//4 != z//4 for e in es): dependent_zero.append(z)
    assert len(dependent_zero)==16
    counts['renyi_independent_symmetric_profile']=1
    counts['renyi_public_dependent_excluded_residues']=len(dependent_zero)

    # 12. Strict wire format and persistent-fallback functional KEM tests.
    wp=dict(p=6,q=1,h=2,L=2,t=2,kappa=2,kappa_A=13,kappa_K=8)
    wire_roundtrips=0; kem_roundtrips=0; fallback_repeats=0; key_only_checks=0; challenge_refusals=0; distinct_query_checks=0
    for _ in range(100):
        pk,sk=W.compact_test_keygen(rng,**{k:wp[k] for k in ('p','q','h','L','t','kappa','kappa_A')})
        seed,U=pk
        pk_wire=W.encode_compact_pk(seed,U,wp['kappa_A'],wp['p'],wp['q'],wp['L'],wp['t'])
        seed2,U2=W.decode_compact_pk(pk_wire,wp['kappa_A'],wp['p'],wp['q'],wp['L'],wp['t'])
        assert (seed2,U2)==(seed,U)
        # Flip a high padding bit: the strict parser must reject the alias.
        total_pk=wp['kappa_A']+wp['t']*wp['L']*(wp['p']-wp['q'])
        if total_pk%8:
            alias=bytearray(pk_wire); alias[-1]|=0x80
            try: W.decode_compact_pk(bytes(alias),wp['kappa_A'],wp['p'],wp['q'],wp['L'],wp['t'])
            except ValueError: pass
            else: raise AssertionError('compact-key padding alias accepted')
        mu=[rng.randrange(2) for _ in range(wp['kappa'])]
        cwire,key=W.compact_test_encaps(pk,mu,**wp)
        key2=W.compact_test_decaps(sk,cwire,**wp)
        dkey,dvalid=W._compact_test_decaps_diagnostic(sk,cwire,**wp)
        assert dvalid and key2==dkey==key and isinstance(key2,int)
        key_only_checks += 1
        c=W.decode_ciphertext(cwire,wp['p'],wp['h']*wp['L']+1,wp['L'],wp['kappa'])
        assert W.encode_ciphertext(c,wp['p'],wp['L'],wp['kappa'])==cwire
        total_ct=(wp['h']*wp['L']+1)*wp['p']+wp['L']+wp['kappa']
        if total_ct%8:
            alias=bytearray(cwire); alias[-1]|=0x80
            try: W.decode_ciphertext(bytes(alias),wp['p'],wp['h']*wp['L']+1,wp['L'],wp['kappa'])
            except ValueError: pass
            else: raise AssertionError('ciphertext padding alias accepted')
        malformed=cwire[:-1]
        k3=W.compact_test_decaps(sk,malformed,**wp)
        k4=W.compact_test_decaps(sk,malformed,**wp)
        d3,v3=W._compact_test_decaps_diagnostic(sk,malformed,**wp)
        d4,v4=W._compact_test_decaps_diagnostic(sk,malformed,**wp)
        assert not v3 and not v4 and k3==k4==d3==d4 and isinstance(k3,int)
        key_only_checks += 1
        # Security-game wrapper refuses the exact challenge before decapsulation.
        try:
            W.cca_test_oracle(sk,cwire,cwire,**wp)
        except W.ChallengeCiphertextQuery:
            challenge_refusals += 1
        else:
            raise AssertionError('exact challenge query was not refused')
        # A distinct byte string reaches key-only decapsulation and returns only a key.
        qkey=W.cca_test_oracle(sk,malformed,cwire,**wp)
        assert qkey==k3 and isinstance(qkey,int)
        distinct_query_checks += 1
        wire_roundtrips+=1; kem_roundtrips+=1; fallback_repeats+=1
    counts['wire_roundtrips']=wire_roundtrips
    counts['kem_roundtrips']=kem_roundtrips
    counts['persistent_fallback_repeats']=fallback_repeats
    counts['public_decaps_key_only_checks']=key_only_checks
    counts['challenge_refusals']=challenge_refusals
    counts['distinct_queries_reach_decapsulation']=distinct_query_checks

    # 13. Exact arithmetic checks for the quantitative final-noise premises of the asymptotic corollary.
    aprofiles=0
    for k in (8,10,12,14):
        lam=1<<k; log2lam=k
        h=(lam+1)*(lam//2)+8*lam; L=lam
        pbits=16*k; qbits=11*k
        t=((h+1)*L+1)*pbits+2*(lam-1); M=t*L
        # C_B=1 representative envelope: ceil(lambda^5 * (log_2 lambda)^(5/2)).
        root=log2lam**5
        sr=isqrt(root)
        if sr*sr<root: sr+=1
        # Conservative integer envelope: lambda^5 * ceil(sqrt((log_2 lambda)^5)).
        B=(lam**5)*sr
        Q=1<<qbits
        assert 2*B<Q
        assert F(M*B,Q) < 1
        assert F(M,lam**6) < 1
        aprofiles+=1
    counts['asymptotic_final_noise_premise_profiles']=aprofiles

    result={
        'status':'PASS', 'seed':SEED,
        'scope':'Finite algebra and functional checks only; no hardness, ROM, QROM, or concrete-security certification.',
        'counts':counts, 'barrier':barrier,
        'representation_profile':{
            'explicit_bytes':1083392,'compact_bytes':32800,
            'parameters':{'p':256,'q':128,'h':16,'L':32,'t':64,'kappa_A':256}
        }
    }
    Path(args.output).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':
    main()
