#!/usr/bin/env python3
"""Public arithmetic helpers for A4 / MODDIV-WC V2.

These routines implement only the finite algebra and functional interfaces used by
A4's reproducibility checks. They are research-reference code, not constant-time
cryptographic software and not a security estimator.
"""
from __future__ import annotations
import hashlib
from typing import Iterable, Sequence


def modp(x: int, P: int) -> int:
    return x % P


def fq(z: int, P: int, Q: int) -> int:
    assert P > 0 and Q > 0 and P % Q == 0
    return (z % P) // Q


def hankel(a: Sequence[int], x: Sequence[int], L: int, P: int) -> list[int]:
    d = len(x)
    assert len(a) >= L + d - 1
    return [sum(a[i+j] * x[j] for j in range(d)) % P for i in range(L)]


def fast_round(a: Sequence[int], x: Sequence[int], L: int, P: int, Q: int) -> list[int]:
    """Exact FAST rounded Hankel identity for x0=1 and xj in [Q,2Q)."""
    assert x[0] == 1 and P % Q == 0
    H = P // Q
    d = len(x)
    s = [0] + [xj - Q for xj in x[1:]]
    assert all(0 <= sj < Q for sj in s[1:])
    out = []
    for i in range(L):
        A_i = sum(a[i+j] for j in range(1, d))
        S_i = a[i] + sum(a[i+j] * s[j] for j in range(1, d))
        out.append((A_i + S_i // Q) % H)
    return out


def fast_unrounded(a: Sequence[int], x: Sequence[int], L: int, P: int, Q: int) -> list[int]:
    """Unrounded reconstruction corresponding to the FAST decomposition."""
    assert x[0] == 1
    d = len(x)
    s = [0] + [xj - Q for xj in x[1:]]
    return [
        (Q * sum(a[i+j] for j in range(1, d))
         + a[i] + sum(a[i+j] * s[j] for j in range(1, d))) % P
        for i in range(L)
    ]


def iota(bits: Sequence[int], L: int) -> list[int]:
    h = len(bits)
    d = (h - 1) * L + 2
    out = [0] * d
    for v, b in enumerate(bits):
        assert b in (0, 1)
        out[1 + v * L] = b
    return out


def develop_matrix(A: Sequence[Sequence[int]], a0: int, P: int) -> list[int]:
    """Embed an L x h matrix into a length hL+1 public ribbon."""
    L = len(A)
    h = len(A[0]) if L else 0
    assert L > 0 and h > 0 and all(len(row) == h for row in A)
    a = [a0 % P] + [0] * (h * L)
    for v in range(h):
        for i in range(L):
            a[1 + v * L + i] = A[i][v] % P
    return a


def matvec(A: Sequence[Sequence[int]], s: Sequence[int], P: int) -> list[int]:
    return [sum(row[j] * s[j] for j in range(len(s))) % P for row in A]


def anchor_right_inverse(target: Sequence[int], tail: Sequence[int], x: Sequence[int], P: int) -> list[int]:
    """Complete a tail a[L:] to an a with Hank_L(a,x)=target, using x0=1."""
    L = len(target)
    d = len(x)
    assert x[0] % P == 1
    assert len(tail) == d - 1
    a = [0] * (L + d - 1)
    a[L:] = [v % P for v in tail]
    for i in range(L-1, -1, -1):
        a[i] = (target[i] - sum(a[i+j] * x[j] for j in range(1, d))) % P
    return a


def kp(z: int, P: int) -> int:
    assert P % 4 == 0
    return ((z + P // 4) % P) // (P // 2)


def cp(z: int, P: int) -> int:
    assert P % 4 == 0
    return ((z % P) // (P // 4)) % 2


def recp(y: int, b: int, P: int) -> int:
    assert P % 8 == 0 and b in (0, 1)
    return 0 if ((y + (2*b + 1) * (P // 8)) % P) <= P // 2 - 2 else 1


def base_encrypt(pk, message_bits: Sequence[int], selectors: Sequence[int], remainders, P: int, Q: int):
    """Deterministic-tape BASE encryption for testing.

    pk = list[(a,U)], each a length m and U length L.
    remainders = list[list[int]] of shape t x L.
    """
    t = len(pk)
    assert len(selectors) == t and len(remainders) == t
    L = len(pk[0][1])
    assert len(message_bits) <= L
    u = []
    for b in range(t):
        assert len(remainders[b]) == L
        u.append([Q*pk[b][1][i] + remainders[b][i] for i in range(L)])
    m = len(pk[0][0])
    c1 = [sum(selectors[b] * pk[b][0][i] for b in range(t)) % P for i in range(m)]
    v = [sum(selectors[b] * u[b][i] for b in range(t)) % P for i in range(L)]
    c2 = [cp(z, P) for z in v]
    key = [kp(z, P) for z in v]
    c3 = [message_bits[i] ^ key[i] for i in range(len(message_bits))]
    return (c1, c2, c3), v


def base_decrypt(sk: Sequence[int], ciphertext, P: int, Q: int) -> list[int]:
    c1, c2, c3 = ciphertext
    w = hankel(c1, sk, len(c2), P)
    z = [recp(w[i], c2[i], P) for i in range(len(c2))]
    return [c3[i] ^ z[i] for i in range(len(c3))]


def explicit_payload_bits(p: int, q: int, h: int, L: int, t: int) -> int:
    m = h * L + 1
    return t * (m * p + L * (p - q))


def compact_payload_bits(p: int, q: int, L: int, t: int, kappa_A: int) -> int:
    return kappa_A + t * L * (p - q)


def extraction_t_min(p: int, h: int, L: int, s: int) -> int:
    return ((h + 1) * L + 1) * p + 2 * (s - 1)


def correction_t_max(p: int, q: int) -> int:
    return ((1 << (p - 3)) - 1) // ((1 << q) - 1)


def proof_barrier(tau: int):
    assert tau >= 1
    for g in range(3, 10000):
        T0 = (4*tau + 1) * (g + 1) + 4*tau - 2
        if T0 <= (1 << (g - 2)) - 1:
            bits = 2 * tau * g * T0
            return {"tau": tau, "g_star": g, "T0": T0, "bits": bits, "bytes": (bits + 7)//8}
    raise RuntimeError("no g found")


def expand_public(seed: bytes, block: int, p: int, m: int, context: bytes=b"A4-WC-V2") -> list[int]:
    """Deterministic SHAKE256 test instantiation of the COMPACT expansion.

    This is only a functional test mechanism; the article's theorem uses a programmable RO.
    """
    nbytes = (m * p + 7) // 8
    h = hashlib.shake_256()
    h.update(len(context).to_bytes(2, 'little') + context)
    h.update(len(seed).to_bytes(2, 'little') + seed)
    h.update(block.to_bytes(8, 'little'))
    raw = h.digest(nbytes)
    acc = int.from_bytes(raw, 'little')
    mask = (1 << p) - 1
    return [(acc >> (i*p)) & mask for i in range(m)]


def _pack_fields(values: Sequence[int], widths: Sequence[int]) -> bytes:
    """Strict fixed-width little-endian bit packing used by the A4 reference wire format."""
    if len(values) != len(widths):
        raise ValueError("field/width mismatch")
    acc = 0
    off = 0
    for value, width in zip(values, widths):
        if width <= 0 or not 0 <= int(value) < (1 << width):
            raise ValueError("field out of range")
        acc |= int(value) << off
        off += width
    return acc.to_bytes((off + 7) // 8, "little")


def _unpack_fields(raw: bytes, widths: Sequence[int]) -> list[int]:
    """Inverse of _pack_fields; rejects length and nonzero high-padding aliases."""
    total = sum(widths)
    need = (total + 7) // 8
    if len(raw) != need:
        raise ValueError("wrong length")
    acc = int.from_bytes(raw, "little")
    if acc >> total:
        raise ValueError("noncanonical padding")
    out = []
    for width in widths:
        if width <= 0:
            raise ValueError("nonpositive width")
        out.append(acc & ((1 << width) - 1))
        acc >>= width
    return out


def encode_ciphertext(ciphertext, p: int, L: int, kappa: int) -> bytes:
    """Canonical reference encoding of (c1,c2,c3)."""
    c1, c2, c3 = ciphertext
    if len(c2) != L or len(c3) != kappa:
        raise ValueError("ciphertext shape")
    vals = list(c1) + list(c2) + list(c3)
    widths = [p] * len(c1) + [1] * (L + kappa)
    return _pack_fields(vals, widths)


def decode_ciphertext(raw: bytes, p: int, m: int, L: int, kappa: int):
    vals = _unpack_fields(raw, [p] * m + [1] * (L + kappa))
    return (vals[:m], vals[m:m+L], vals[m+L:])


def encode_compact_pk(seed_int: int, U_blocks, kappa_A: int, p: int, q: int, L: int, t: int) -> bytes:
    if len(U_blocks) != t or any(len(u) != L for u in U_blocks):
        raise ValueError("public-key shape")
    width = p - q
    vals = [seed_int] + [x for block in U_blocks for x in block]
    return _pack_fields(vals, [kappa_A] + [width] * (t * L))


def decode_compact_pk(raw: bytes, kappa_A: int, p: int, q: int, L: int, t: int):
    width = p - q
    vals = _unpack_fields(raw, [kappa_A] + [width] * (t * L))
    seed = vals[0]
    flat = vals[1:]
    return seed, [flat[i*L:(i+1)*L] for i in range(t)]


def _seed_bytes(seed_int: int, kappa_A: int) -> bytes:
    if not 0 <= seed_int < (1 << kappa_A):
        raise ValueError("seed out of range")
    return seed_int.to_bytes((kappa_A + 7)//8, "little")


def develop_compact_pk(seed_int: int, U_blocks, *, kappa_A: int, p: int, q: int, h: int, L: int, t: int):
    """Expand a compact key under the deterministic SHAKE test instantiation."""
    m = h * L + 1
    seed = _seed_bytes(seed_int, kappa_A)
    if len(U_blocks) != t or any(len(u) != L for u in U_blocks):
        raise ValueError("public-key shape")
    return [(expand_public(seed, b, p, m), list(U_blocks[b])) for b in range(t)]


def _test_ro(domain: bytes, parts: Sequence[bytes], nbits: int) -> int:
    """Deterministic SHAKE-based test oracle with explicit domain separation."""
    if nbits <= 0:
        raise ValueError("nbits")
    h = hashlib.shake_256()
    h.update(len(domain).to_bytes(2, 'little') + domain)
    for part in parts:
        h.update(len(part).to_bytes(4, 'little') + part)
    raw = h.digest((nbits + 7)//8)
    return int.from_bytes(raw, 'little') & ((1 << nbits) - 1)


def test_G(mu_bits: Sequence[int], *, t: int, L: int, q: int):
    """Functional test oracle for FO coins; not a ROM implementation."""
    mu = _pack_fields(list(mu_bits), [1]*len(mu_bits))
    nbits = t * (1 + L*q)
    z = _test_ro(b"A4-G-TEST", [mu], nbits)
    selectors = []
    remainders = []
    off = 0
    for _ in range(t):
        selectors.append((z >> off) & 1); off += 1
        row = []
        for _ in range(L):
            row.append((z >> off) & ((1 << q)-1)); off += q
        remainders.append(row)
    return selectors, remainders


def test_H(msg_bits: Sequence[int], c_wire: bytes, kappa_K: int) -> int:
    msg = _pack_fields(list(msg_bits), [1]*len(msg_bits))
    return _test_ro(b"A4-H-TEST", [msg, c_wire], kappa_K)


def compact_test_keygen(rng, *, p: int, q: int, h: int, L: int, t: int, kappa: int, kappa_A: int):
    """Reference functional KEM key generation for tests only.

    The fallback secret is sampled once and stored persistently with the key.
    """
    P = 1 << p; Q = 1 << q
    d = (h - 1) * L + 2
    X = [1] + [rng.randrange(Q, 2*Q) for _ in range(d-1)]
    seed_int = rng.randrange(1 << kappa_A)
    seed = _seed_bytes(seed_int, kappa_A)
    m = h * L + 1
    U = []
    for b in range(t):
        a = expand_public(seed, b, p, m)
        U.append([fq(z, P, Q) for z in hankel(a, X, L, P)])
    fallback = [rng.randrange(2) for _ in range(kappa)]
    pk = (seed_int, U)
    sk = (X, fallback, pk)
    return pk, sk


def compact_test_encaps(pk, mu_bits: Sequence[int], *, p: int, q: int, h: int, L: int, t: int, kappa: int, kappa_A: int, kappa_K: int):
    seed_int, U = pk
    explicit = develop_compact_pk(seed_int, U, kappa_A=kappa_A, p=p, q=q, h=h, L=L, t=t)
    selectors, remainders = test_G(mu_bits, t=t, L=L, q=q)
    c, _ = base_encrypt(explicit, list(mu_bits), selectors, remainders, 1 << p, 1 << q)
    wire = encode_ciphertext(c, p, L, kappa)
    return wire, test_H(mu_bits, wire, kappa_K)


def _compact_test_decaps_diagnostic(sk, c_wire: bytes, *, p: int, q: int, h: int, L: int, t: int, kappa: int, kappa_A: int, kappa_K: int):
    """Internal diagnostic helper returning (key, validity).

    This function is intentionally not the public decapsulation interface used
    by the game wrapper.  The validity flag exists only for regression tests.
    """
    X, fallback, pk = sk
    m = h * L + 1
    try:
        c = decode_ciphertext(c_wire, p, m, L, kappa)
    except ValueError:
        return test_H(fallback, c_wire, kappa_K), False
    seed_int, U = pk
    explicit = develop_compact_pk(seed_int, U, kappa_A=kappa_A, p=p, q=q, h=h, L=L, t=t)
    mu = base_decrypt(X, c, 1 << p, 1 << q)
    selectors, remainders = test_G(mu, t=t, L=L, q=q)
    c2, _ = base_encrypt(explicit, mu, selectors, remainders, 1 << p, 1 << q)
    expected = encode_ciphertext(c2, p, L, kappa)
    if expected == c_wire:
        return test_H(mu, c_wire, kappa_K), True
    return test_H(fallback, c_wire, kappa_K), False


def compact_test_decaps(sk, c_wire: bytes, **params):
    """Public functional decapsulation interface: return the key only."""
    key, _valid = _compact_test_decaps_diagnostic(sk, c_wire, **params)
    return key


class ChallengeCiphertextQuery(ValueError):
    """Raised by the test game when the exact challenge bytes are queried."""


def cca_test_oracle(sk, c_wire: bytes, challenge_wire: bytes, **params):
    """Reference IND-CCA game wrapper for tests only.

    The exact challenge byte string is an illegal decapsulation query and is
    rejected before decapsulation is invoked.  Every other byte string is
    passed to the strict key-only decapsulation interface.  No validity bit is
    returned to the simulated adversary.
    """
    if c_wire == challenge_wire:
        raise ChallengeCiphertextQuery("exact challenge ciphertext query")
    return compact_test_decaps(sk, c_wire, **params)
