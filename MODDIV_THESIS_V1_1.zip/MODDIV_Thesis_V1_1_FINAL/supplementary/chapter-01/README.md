# Chapter 1 — Introduction: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Checks the public V1.1 document structure and the three global scope constraints used by the introduction.

## Reproduction

```sh
python3 verify.py
```

All deterministic reference outputs are stored in this directory. The verification scripts write reruns to temporary files and compare exact JSON objects whenever applicable.

## Limits

This is an editorial/scope verifier. It does not prove a cryptographic theorem.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
