#!/usr/bin/env python3
import argparse,json,pathlib,re
ap=argparse.ArgumentParser(); ap.add_argument('--output'); a=ap.parse_args()
root=pathlib.Path(__file__).resolve().parents[2]
thesis=next((root/'thesis').glob('*.md')).read_text()
scope=json.loads((pathlib.Path(__file__).with_name('scope.json')).read_text())
chapters=len(re.findall(r'^# Chapter \d+ ',thesis,re.M))
supp=len(re.findall(r'^## Supplementary Material and Reproducibility — Chapter \d+$',thesis,re.M))
checks={p:(p in thesis) for p in scope['required_scope_phrases']}
r={'status':'PASS' if chapters==17 and supp==17 and all(checks.values()) else 'FAIL','chapter_count':chapters,'supplementary_sections':supp,'scope_checks':checks}
if a.output:pathlib.Path(a.output).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps(r,indent=2,sort_keys=True)); assert r['status']=='PASS'
