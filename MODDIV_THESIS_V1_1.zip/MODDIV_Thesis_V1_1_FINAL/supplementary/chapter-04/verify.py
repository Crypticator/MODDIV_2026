#!/usr/bin/env python3
import argparse,datetime,json,pathlib,subprocess,sys,tempfile
ap=argparse.ArgumentParser();ap.add_argument('--output');a=ap.parse_args();R=pathlib.Path(__file__).parent
rows=json.loads((R/'public_chronology.json').read_text()); dates=[datetime.date.fromisoformat(x['date']) for x in rows]
assert dates==sorted(dates); assert rows[-1]['record']=='2021/701'; assert not any(x['date'].startswith('2020') for x in rows)
subprocess.run([sys.executable,str(R/'verify_a0.py')],cwd=R,check=True,stdout=subprocess.DEVNULL)
r={'status':'PASS','public_records':len(rows),'first_public_date':str(dates[0]),'multidimensional_public_record':'2021/701','claims_public_disclosure_in_2020':False}
if a.output:pathlib.Path(a.output).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps(r,indent=2,sort_keys=True))
