from itertools import product
from random import Random
from fractions import Fraction
import argparse, json, hashlib, os
from pathlib import Path

SEED = 20261109
rng = Random(SEED)

def conv(a,b):
    out=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            out[i+j]+=x*y
    return out

def pi(poly,b,a):
    # coefficients degrees a,...,b-1 shifted down
    return [(poly[k] if k < len(poly) else 0) for k in range(a,b)]

def md(z,P,Q):
    return (z % P)//Q

def md_vec(v,P,Q):
    return [md(z,P,Q) for z in v]

def rem_vec(v,P,Q):
    return [(z % P) - Q*md(z,P,Q) for z in v]

def central(A,X,m,n):
    return pi(conv(A,X),m,n)

def cross(X,V1,m,n):
    return pi(conv(X,V1),m-n,n)

def circ_dist(a,b,K):
    return min((a-b)%K,(b-a)%K)

# 1. Scalar wraparound counterexample from reconstructed analysis
p,q,A0,X0,Y0=6,2,43,2,3
P,Q=2**p,2**q
U=md(A0*X0,P,Q); V=md(A0*Y0,P,Q)
WA=md(Q*X0*V,P,Q*Q); WB=md(Q*Y0*U,P,Q*Q)
scalar_wrap={"P":P,"Q":Q,"A":A0,"X":X0,"Y":Y0,"U":U,"V":V,"WA":WA,"WB":WB,"K":P//(Q*Q),"circular_distance":circ_dist(WA,WB,P//(Q*Q)),"ordinary_distance":abs(WA-WB)}
assert scalar_wrap["circular_distance"] <= 1 and scalar_wrap["ordinary_distance"] > 1

# 1b. Boundary case for the corrected non-strict remainder-product bound
pb,qb,Ab,Xb,Yb=3,1,1,1,1
Pb,Qb=2**pb,2**qb
eXb=(Ab*Xb)%Pb - Qb*md(Ab*Xb,Pb,Qb)
eYb=(Ab*Yb)%Pb - Qb*md(Ab*Yb,Pb,Qb)
assert Xb*eYb == (Qb-1)**2
assert Yb*eXb == (Qb-1)**2
assert Xb*eYb < Qb**2 and Yb*eXb < Qb**2

# 2. Exact scalar agreement toy profile from article
p,q=6,2; P,Q=2**p,2**q
agree0=agree1=tot=0
for A in range(32,64):
    for X in (2,3):
        for Y in (2,3):
            U=md(A*X,P,Q); V=md(A*Y,P,Q)
            wa=md(Q*X*V,P,Q*Q); wb=md(Q*Y*U,P,Q*Q)
            tot+=1
            agree0 += wa==wb
            agree1 += (wa//2)==(wb//2)
assert Fraction(agree0,tot)==Fraction(15,16)
assert Fraction(agree1,tot)==Fraction(31,32)

# 3. Polynomial identities / corrected proximity on random admissible instances
trials=20000
identity_ok=error_ok=close_ok=0
max_B_ratio=Fraction(0,1)
for _ in range(trials):
    q=rng.randint(1,3)
    Q=2**q
    n=rng.randint(1,3)
    N=n+1
    ell=(N-1).bit_length()
    r=rng.randint(0,2)
    # need p > 2q+ell+r
    p=2*q+ell+r+1+rng.randint(0,3)
    P=2**p
    m=rng.randint(2*n+1,2*n+5)
    A=[rng.randrange(P) for _ in range(m)]
    X=[rng.randrange(Q) for _ in range(N)]
    Y=[rng.randrange(Q) for _ in range(N)]

    U=central(A,X,m,n); V=central(A,Y,m,n)
    U1=md_vec(U,P,Q); V1=md_vec(V,P,Q)
    CA=cross(X,V1,m,n); CB=cross(Y,U1,m,n)
    EX=rem_vec(U,P,Q); EY=rem_vec(V,P,Q)
    T=pi(conv(conv(A,X),Y),m,2*n)
    RA=cross(X,EY,m,n); RB=cross(Y,EX,m,n)

    assert len(CA)==m-2*n and len(T)==m-2*n
    for i in range(len(T)):
        if (Q*CA[i] - (T[i]-RA[i]))%P != 0: raise AssertionError('error identity A')
        if (Q*CB[i] - (T[i]-RB[i]))%P != 0: raise AssertionError('error identity B')
    error_ok += 1

    # central identity before rounding
    left=pi(conv(X,central(A,Y,m,n)),m-n,n)
    right=pi(conv(Y,central(A,X,m,n)),m-n,n)
    mid=pi(conv(conv(A,X),Y),m,2*n)
    assert left==right==mid
    identity_ok += 1

    B=N*(Q-1)**2
    D=2**(2*q+ell+r)
    K=P//D
    max_B_ratio=max(max_B_ratio,Fraction(B,D))
    assert B < D and K>=2
    for i,t in enumerate(T):
        ci=(t%P)//D
        ka=((Q*CA[i])%P)//D
        kb=((Q*CB[i])%P)//D
        allowed={ci,(ci-1)%K}
        assert ka in allowed and kb in allowed
        assert circ_dist(ka,kb,K)<=1
    close_ok += 1

# 4. Reconciliation countermodels K=8,r=1
K=8
# model A: xor 1 -> same coarse block after /2
modelA=[]
for w in range(K):
    wb=w^1
    modelA.append((w,wb,w//2,wb//2))
assert all(a==b for _,_,a,b in modelA)
# model B: even -> -1, odd -> +1, always crosses /2 boundary including circular
modelB=[]
for w in range(K):
    wb=(w-1)%K if w%2==0 else (w+1)%K
    modelB.append((w,wb,w//2,wb//2))
assert all(a!=b for _,_,a,b in modelB)

results={
    "seed":SEED,
    "scalar_wraparound":scalar_wrap,
    "corrected_remainder_bound_witness":{"P":Pb,"Q":Qb,"A":Ab,"X":Xb,"Y":Yb,"XeY":Xb*eYb,"bound":(Qb-1)**2},
    "scalar_toy_agreement":{"total":tot,"before":f"{agree0}/{tot}","before_reduced":"15/16","after_div2":f"{agree1}/{tot}","after_reduced":"31/32"},
    "polynomial_random_trials":trials,
    "central_product_identity_trials":identity_ok,
    "exact_error_identity_trials":error_ok,
    "circular_closeness_trials":close_ok,
    "max_observed_B_over_D":str(max_B_ratio),
    "reconciliation_countermodels":{"same_after_div2":len(modelA),"different_after_div2":len(modelB)},
}
parser=argparse.ArgumentParser(description="Verify exact arithmetic checks for A0 v1.1")
parser.add_argument("--output", default=str(Path(__file__).with_name("A0_VERIFY_RESULTS_v1_1.json")), help="JSON output path")
args=parser.parse_args()
path=Path(args.output)
path.parent.mkdir(parents=True, exist_ok=True)
with path.open('w', encoding='utf-8') as f:
    json.dump(results,f,indent=2,sort_keys=True)
print(json.dumps(results,indent=2,sort_keys=True))
print(f"Wrote {path}")
