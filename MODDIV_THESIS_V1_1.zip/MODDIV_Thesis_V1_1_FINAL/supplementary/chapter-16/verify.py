#!/usr/bin/env python3
import argparse,json,pathlib
ap=argparse.ArgumentParser();ap.add_argument('--output');a=ap.parse_args();R=pathlib.Path(__file__).parent
L=json.loads((R/'comparison_ledger.json').read_text());complete=[]
for row in L:complete.append(all(row[k] for k in ['corr','src','red','atk','fmt','impl']))
assert len(L)==7 and not any(complete)
r={'status':'PASS','rows':7,'complete_rows':sum(complete),'objects':[x['object'] for x in L]}
if a.output:pathlib.Path(a.output).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps(r,indent=2,sort_keys=True))
