# Chapter 16 — Comparative Analysis and Lessons: Supplementary Material

**Status:** public reproducibility package for MODDIV Thesis V1.1.

## Scope

Machine-readable seven-row V1 deployment ledger. The checker reproduces the documentary statement that no V1 row closes all six declared obligations.

## Reproduction

```sh
python3 verify.py
python3 verify_independent.py
```

## Limits

A false cell means “not established in V1”, not a universal impossibility or insecurity theorem.

Essential theorem statements and proofs remain in the thesis. Successful execution is not a proof-assistant certificate, peer review, or a concrete security certificate.
