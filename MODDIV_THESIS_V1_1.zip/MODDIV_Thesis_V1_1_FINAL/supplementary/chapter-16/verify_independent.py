#!/usr/bin/env python3
import json,pathlib
L=json.loads((pathlib.Path(__file__).with_name('comparison_ledger.json')).read_text())
missing={x['object']:[k for k in ['corr','src','red','atk','fmt','impl'] if not x[k]] for x in L}
assert all(missing.values())
print(json.dumps({'status':'PASS','missing_obligations':missing},indent=2,sort_keys=True))
