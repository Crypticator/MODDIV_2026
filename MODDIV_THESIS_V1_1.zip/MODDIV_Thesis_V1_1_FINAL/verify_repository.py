#!/usr/bin/env python3
import argparse,hashlib,pathlib,subprocess,sys,json,concurrent.futures,os
ap=argparse.ArgumentParser();ap.add_argument('--jobs',type=int,default=4);a=ap.parse_args();ROOT=pathlib.Path(__file__).parent
for ch in range(1,18):
 d=ROOT/'supplementary'/f'chapter-{ch:02d}'
 for line in (d/'SHA256SUMS.txt').read_text().splitlines():
  h,name=line.split('  ',1);assert hashlib.sha256((d/name).read_bytes()).hexdigest()==h,(ch,name)
def run(ch):
 d=ROOT/'supplementary'/f'chapter-{ch:02d}';subprocess.run([sys.executable,str(d/'verify.py')],cwd=d,check=True,stdout=subprocess.DEVNULL,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 if (d/'verify_independent.py').exists():subprocess.run([sys.executable,str(d/'verify_independent.py')],cwd=d,check=True,stdout=subprocess.DEVNULL,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 return {'chapter':ch,'status':'PASS'}
with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as ex: rows=sorted(ex.map(run,range(1,18)),key=lambda x:x['chapter'])
print(json.dumps({'status':'PASS','chapters':rows},indent=2))
