# MODDIV Thesis V1.1 — Reproducibility

Run the complete public verification from the repository root:

```sh
python3 verify_repository.py --jobs 4
```

The checker validates each chapter-local SHA-256 manifest, reruns the canonical verifier and runs an independent checker when supplied.

Chapter 7 regenerates all 57 exact prime-certificate rows and directly enumerates the three displayed finite general-modulus counterexamples through a delivered C++17 counter; the independent Python path rechecks the first two. Chapter 13 explicitly enumerates its fixed-length-premise counterexample and two negative controls. Chapter 14 checks exact small fibers and secret-box membership together with publication compatibility; it makes no secret-recovery timing claim. Chapter 17 requires the corrected equation (17.9) and executes direct polynomial regressions.

Every command block published in the thesis names a delivered entry point. Successful execution is a reproducibility check, not a proof-assistant certificate, peer review, or a concrete security certificate.
