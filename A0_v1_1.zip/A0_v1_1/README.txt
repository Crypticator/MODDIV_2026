A0 v1.1 - Historical Multidimensional ModDiv Key Exchange

Deliverables:
- A0_MODDIV_2020_v1_1.pdf : compiled article.
- A0_MODDIV_2020_v1_1.tex : LaTeX source.
- verify_a0_v1_1.py       : deterministic verifier with portable/configurable output path.
- A0_VERIFY_RESULTS_v1_1.json : frozen verifier output.
- CHANGES_v1_1.txt         : concise v1.1 change list.
- PREFLIGHT.txt             : PDF structural preflight summary.
- SHA256SUMS.txt            : SHA-256 manifest (excluding itself and the ZIP container).

Reproduction:
  pdflatex A0_MODDIV_2020_v1_1.tex
  pdflatex A0_MODDIV_2020_v1_1.tex
  python3 verify_a0_v1_1.py

The article cites public literature only. Tests are consistency checks; mathematical claims rest on the proofs in the article.
