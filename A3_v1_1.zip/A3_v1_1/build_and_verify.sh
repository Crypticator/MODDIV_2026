#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 verify_a3.py --output A3_RESULTS_RECHECK.json
python3 verify_a3_independent.py --output A3_INDEPENDENT_RECHECK.json
python3 - <<'PY'
import json
for a,b in [('A3_RESULTS.json','A3_RESULTS_RECHECK.json'),('A3_INDEPENDENT.json','A3_INDEPENDENT_RECHECK.json')]:
    if json.load(open(a)) != json.load(open(b)):
        raise SystemExit(f'mismatch: {a} vs {b}')
print('A3 deterministic result comparison: PASS')
PY
