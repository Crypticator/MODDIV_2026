# A3 v1.1 revision notes

A3 v1.1 is a targeted revision of A3 v1.0.

- Corrects the transcription of the historical local trailing-bit counter: the printed procedure applies the bit counter to `floor(R_i / n)`, not directly to `R_i`.
- Recomputes the two historical readings, replaces the residue-dependence witness, and updates the exact conditional counts to 944/1600 and 986/1606 agreements for H0/H1 on the two selected public ribbons.
- Treats normalized zero (`floor(R_i/n)=0`) as an undefined counter input and does not count non-computation as agreement.
- Fixes the independent verifier to read `A3_REFERENCE_TRANSCRIPTS.json` and makes package scripts execute relative to their own directory.
- Removes stale Chapter-9-era filenames and harmonizes the reproducibility recipe.
- The P-WINDOW results, P-ROUND residual identity, P-REF algorithms, and conditional classical-ROM IND-CPA theorem are unchanged.

This note records changes only; the mathematical statements and their proofs remain in the article itself.
