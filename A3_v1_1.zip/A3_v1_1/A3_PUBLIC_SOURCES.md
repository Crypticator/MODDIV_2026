# A3 public source record

This file lists only public sources cited by A3.

1. Samir Bouftass, "Multidimentional ModDiv public key exchange protocol," IACR Cryptology ePrint Archive, Paper 2021/701, 20 July 2021.
   https://eprint.iacr.org/2021/701
   Used for the public non-cyclic polynomial ModDiv specification and the printed trailing-bit counter, including its preliminary integer division by n before the bit loop.

2. Shi Bai, Katharina Boudgoust, Dipayan Das, Adeline Roux-Langlois, Weiqiang Wen, Zhenfei Zhang, "Middle-Product Learning with Rounding Problem and its Applications," ASIACRYPT 2019, LNCS 11921, 55-81; IACR ePrint 2019/1001.
   https://eprint.iacr.org/2019/1001
   Used for the published MP-LWR / MP-CLWR reference construction and hardness context.

3. Katharina Boudgoust, "Theoretical Hardness of Algebraically Structured Learning With Errors," PhD thesis, Universite de Rennes 1, 2021.
   https://katinkabou.github.io/Documents/Thesis_Boudgoust_Final.pdf
   Used as a public cross-check for the conditioned-secret setting, middle-product reference construction, reconciliation, and source assumption.

No private report, chat, audit, thesis chapter, or unpublished project archive is cited in A3.
