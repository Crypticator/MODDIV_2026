A3 v1.1 - Polynomial ModDiv Revisited

Main files:
  A3_POLYNOMIAL_MODDIV_v1_1.pdf  - article
  A3_POLYNOMIAL_MODDIV_v1_1.tex  - LaTeX source
  polynomial_moddiv_a3.py        - exact arithmetic reference
  verify_a3.py                   - deterministic main verifier
  verify_a3_independent.py       - independent verifier, imports no main module
  A3_RESULTS.json                - main exact results
  A3_INDEPENDENT.json            - independent results
  A3_REFERENCE_TRANSCRIPTS.json  - synthetic validation traces
  A3_PUBLIC_SOURCES.md           - public-source record
  compile_pdf.sh                 - PDF build recipe
  build_and_verify.sh            - deterministic verification recipe
  SHA256SUMS.txt                 - file hashes

Run:
  bash build_and_verify.sh
  bash compile_pdf.sh

Scope:
The code verifies finite identities, exact counterexamples, and the functionality of the attributed P-REF specialization. It does not prove the MP-CLWR assumption, concrete bit security, CCA security, or security of historical P-ROUND.

Revision v1.1:
  Corrects the historical trailing-bit counter transcription by applying the counter to floor(R_i/n), updates the finite witnesses/counts, fixes the independent transcript path, and harmonizes the reproduction instructions.
