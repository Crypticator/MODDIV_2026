#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
pdflatex -interaction=nonstopmode -halt-on-error A3_POLYNOMIAL_MODDIV_v1_1.tex >/dev/null
pdflatex -interaction=nonstopmode -halt-on-error A3_POLYNOMIAL_MODDIV_v1_1.tex >/dev/null
printf 'Built A3_POLYNOMIAL_MODDIV_v1_1.pdf\n'
