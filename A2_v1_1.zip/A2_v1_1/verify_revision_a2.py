from pathlib import Path

root = Path(__file__).resolve().parent
tex = (root / "A2_DISTRIBUTIONAL_MODDIV_v1_1.tex").read_text(encoding="utf-8")
checks = {
    "version_header": r"Article v1.1" in tex,
    "old_crossrefs_removed": not any(x in tex for x in [
        "Theorem 8.4", "Proposition 8.5", "Theorem 8.10", "Theorem 8.11",
        "Lemma 8.9", "Proposition 8.12"
    ]),
    "new_crossrefs_present": all(x in tex for x in [
        "Theorem 4", "Proposition 5", "Theorem 10", "Theorem 11",
        "Lemma 9", "Proposition 12"
    ]),
    "support_restricted_compatible_success": all(x in tex for x in [
        r"Define compatible success to mean", r"belongs to the declared secret support",
        r"F([f(A,\widehat x)]_P)=U"
    ]),
    "article_not_chapter": "by this chapter" not in tex and "by this article" in tex,
    "compile_script_documented": r"compile\_pdf.sh" in tex and (root / "compile_pdf.sh").exists(),
    "manifest_description_corrected": "filenames and SHA-256 digests" in tex,
}
failed = [k for k,v in checks.items() if not v]
for k,v in checks.items():
    print(f"{k}: {'PASS' if v else 'FAIL'}")
if failed:
    raise SystemExit("Revision checks failed: " + ", ".join(failed))
print("PASS: all A2 v1.1 revision checks completed.")
