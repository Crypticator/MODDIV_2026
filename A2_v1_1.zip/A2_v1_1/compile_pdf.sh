#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
SRC="A2_DISTRIBUTIONAL_MODDIV_v1_1.tex"
PDF="A2_DISTRIBUTIONAL_MODDIV_v1_1.pdf"
command -v pdflatex >/dev/null 2>&1 || { echo "ERROR: pdflatex not found" >&2; exit 2; }
pdflatex -interaction=nonstopmode -halt-on-error "$SRC" >/tmp/a2_v1_1_pdflatex_1.log
pdflatex -interaction=nonstopmode -halt-on-error "$SRC" >/tmp/a2_v1_1_pdflatex_2.log
test -s "$PDF"
printf 'PASS: built %s\n' "$PDF"
