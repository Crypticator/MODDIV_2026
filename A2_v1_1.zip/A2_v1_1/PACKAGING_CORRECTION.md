# Packaging correction — A2 v1.1

This archive is a documented packaging-only derivative of A2_v1_1.zip.
Original archive SHA-256:
45e9963596a72727c0c48d2e1cd0626d5b8109dd860b54da8cbc53fd5e1ad1a8

The original SHA256SUMS.txt advertised the PDF digest:
7d1174b159198fbf798c286cb6690f78e15bb7bdcbdc15cb60b6e3f5d14bde62

The actual PDF bytes inside that original archive have SHA-256:
17b85f56ffabe55ac107aeff27e5d89df80ca74e0c6ad50b78c469e298364db0

Only SHA256SUMS.txt has been corrected among the original files.
This note has been added and included in the corrected manifest.
Every other original archive member, including the PDF, TeX, Python scripts,
shell scripts and result files, is preserved byte for byte.
The original scientific source has not been edited.

This correction identifies the distributed PDF; it does not establish the
cause of the earlier digest mismatch or certify a new PDF compilation.
A local compilation attempt stopped because pdflatex.fmt was unavailable.
The delivered PDF was visually inspected on all 15 pages.
