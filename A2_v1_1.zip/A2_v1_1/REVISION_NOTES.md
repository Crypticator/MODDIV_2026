# A2 v1.1 revision notes

A2 v1.1 applies the five local corrections requested by the independent counter-review of A2 v1.0. No numbered theorem, bound, source distribution, or cryptographic scope claim is strengthened.

- A2-01: corrected eight stale cross-references from the earlier 8.x numbering to the article-local numbering.
- A2-02: added `compile_pdf.sh`, which rebuilds the delivered TeX directly with `pdflatex`; Pandoc is not required for the delivered TeX.
- A2-03: defined compatible-preimage success only for outputs inside the declared secret support and matching the public quotient.
- A2-04: corrected the manifest description to say filenames and SHA-256 digests.
- A2-05: replaced the residual wording `this chapter` by `this article` in the dither scope note.

The public bibliography remains public-source-only. The R1 entry additionally records the authors' 2024 errata link.
