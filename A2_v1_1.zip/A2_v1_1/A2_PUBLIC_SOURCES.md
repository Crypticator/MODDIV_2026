# A2 v1.1 public sources

Only public references are cited by the article.

1. Tim van Erven and Peter Harremoës, "Rényi Divergence and Kullback-Leibler Divergence," IEEE Transactions on Information Theory 60(7), 3797-3820, 2014. DOI 10.1109/TIT.2014.2320500. Author manuscript: https://arxiv.org/abs/1206.2459
  - Author errata (2 April 2024): https://timvanerven.nl/assets/publications/2014/Renyi-errata-2024-4-2.pdf
2. Shi Bai, Katharina Boudgoust, Dipayan Das, Adeline Roux-Langlois, Weiqiang Wen, and Zhenfei Zhang, "Middle-Product Learning with Rounding Problem and its Applications," ASIACRYPT 2019, LNCS 11921, 55-81. ePrint 2019/1001. DOI 10.1007/978-3-030-34578-5_3.
3. Leonard Schuchman, "Dither Signals and Their Effect on Quantization Noise," IEEE Transactions on Communication Technology 12(4), 162-165, 1964. DOI 10.1109/TCOM.1964.1088973.

The MP-LWR reference is used only for context/conventions. Its hardness theorem is not transferred to A2.
