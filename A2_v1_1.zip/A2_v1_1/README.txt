A2 - Modular Quotient Observations
Version 1.1, November 2026

Public package contents:
- A2_DISTRIBUTIONAL_MODDIV_v1_1.pdf : revised article
- A2_DISTRIBUTIONAL_MODDIV_v1_1.tex : LaTeX source
- distribution_tools.py              : exact finite-law utilities
- verify_a2.py                       : primary exact verifier
- verify_a2_independent.py           : independently organized cross-check
- verify_revision_a2.py              : v1.1 regression checks
- A2_RESULTS.json                    : deterministic primary results
- A2_INDEPENDENT.json                : deterministic independent results
- A2_PUBLIC_SOURCES.md               : public bibliography record
- build_and_verify.sh                : mathematical reproduction command
- compile_pdf.sh                     : PDF rebuild command
- REVISION_NOTES.md                  : v1.0 -> v1.1 change log
- SHA256SUMS.txt                     : final filename/hash manifest

Reproduce the mathematical checks with:
    sh build_and_verify.sh

Rebuild the PDF with:
    ./compile_pdf.sh

Tested PDF build environment:
    pdfTeX 3.141592653-2.6-1.40.26 (TeX Live 2025/dev/Debian)

The delivered TeX is self-contained for compilation and does not require Pandoc.
It uses standard TeX Live packages declared in its preamble, including amsmath,
amssymb, setspace, lmodern, microtype, geometry, fancyvrb/fvextra, longtable,
booktabs, array, etoolbox, babel, mathtools, fancyhdr, lastpage, needspace,
hyperref/bookmark, and xurl when available.

The finite enumerations are verification artifacts, not cryptanalytic complexity claims.
No internal project document is cited by the article.
