#!/bin/sh
set -eu
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT HUP INT TERM
python3 verify_a2.py --output "$work/A2_RESULTS.json"
python3 verify_a2_independent.py --reference "$work/A2_RESULTS.json" --output "$work/A2_INDEPENDENT.json"
if [ -f A2_RESULTS.json ]; then cmp A2_RESULTS.json "$work/A2_RESULTS.json"; fi
if [ -f A2_INDEPENDENT.json ]; then cmp A2_INDEPENDENT.json "$work/A2_INDEPENDENT.json"; fi
python3 verify_revision_a2.py
printf '\nPASS: A2 v1.1 exact checks completed.\n'
